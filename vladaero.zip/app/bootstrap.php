<?php
/**
 * VladAero — начальная загрузка приложения.
 * Вызывается только после установки (config/app.php существует).
 */
declare(strict_types=1);

define('VA_APP', __DIR__);
define('VA_ROOT', dirname(__DIR__));

// Простой PSR-4 автозагрузчик: App\ → app/ (нулевые зависимости, чистый PHP 8)
spl_autoload_register(static function (string $class): void {
    if (str_starts_with($class, 'App\\')) {
        $file = VA_APP . '/' . str_replace('\\', '/', substr($class, 4)) . '.php';
        if (is_file($file)) {
            require $file;
        }
    }
});

require VA_APP . '/Core/Helpers.php';

$appConfig = require VA_APP . '/config/app.php';

define('VA_CONFIG', $appConfig);
define('VA_DEBUG', (bool)($appConfig['debug'] ?? false));
define('VA_URL', rtrim((string)($appConfig['url'] ?? ''), '/'));
define('VA_VERSION', (string)($appConfig['version'] ?? '0.1.0'));

date_default_timezone_set((string)($appConfig['timezone'] ?? 'Europe/Moscow'));
mb_internal_encoding('UTF-8');
