<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Request;
use App\Models\Notification;
use App\Services\PushService;

/**
 * Web Push (v0.8.1): подписка/отписка браузера + текст последнего уведомления для SW.
 */
final class PushController
{
    /** POST /push/subscribe {endpoint, keys:{p256dh, auth}} */
    public function subscribe(): void
    {
        $body = Request::rawJson();
        $ok = PushService::subscribe((int)(Auth::id() ?? 0), $body);
        json_response(['ok' => $ok], $ok ? 200 : 422);
    }

    /** POST /push/unsubscribe {endpoint} */
    public function unsubscribe(): void
    {
        $body = Request::rawJson();
        PushService::unsubscribe((string)($body['endpoint'] ?? ''));
        json_response(['ok' => true]);
    }

    /** GET /api/push/pending — service worker берёт здесь текст уведомления */
    public function pending(): void
    {
        if (!Auth::check()) { json_response(['title' => 'VladAero', 'body' => 'Новое на портале', 'url' => '/']); }
        $uid = (int)Auth::id();
        $n = \App\Core\Database::i()->one(
            'SELECT * FROM `{p}notifications` WHERE user_id = ? AND read_at IS NULL ORDER BY id DESC LIMIT 1', [$uid]);
        if ($n === null) {
            json_response(['title' => 'VladAero ✈', 'body' => 'Новое в вашей ленте', 'url' => '/feed']);
        }
        $p = json_decode((string)$n['payload'], true) ?: [];
        [$title, $url] = match ((string)$n['type']) {
            'dm' => ['✉ ' . ($p['from'] ?? 'Сообщения'), '/im/' . (int)($p['from_id'] ?? 0)],
            'comment_reply' => ['💬 Ответ на ваш комментарий', '/profile#bell'],
            'event_reminder' => ['📅 Скоро событие', '/events'],
            'article_new' => ['📝 Новая статья', '/articles/' . (string)($p['slug'] ?? '')],
            'photo' => ['📷 Фото', '/gallery'],
            default => ['VladAero ✈', '/profile#bell'],
        };
        json_response([
            'title' => $title,
            'body' => (string)($p['preview'] ?? $p['text'] ?? 'Откройте портал'),
            'url' => $url,
        ]);
    }
}
