<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Request;
use App\Core\View;
use App\Services\AdsbService;

/**
 * Интерактивный радар полётов (в.16–20, 85–90, 230).
 * Полноэкранный «Cockpit Mode», Leaflet + Canvas, SSE-поток.
 */
final class RadarController
{
    /** Полноэкранная страница (в.230) — без каркаса сайта */
    public function index(): void
    {
        echo View::partial('radar', ['cs' => Request::str('cs')]);
    }

    /** JSON-снимок bbox: /api/adsb?lamin=&lomin=&lamax=&lomax= */
    public function api(): void
    {
        json_response(self::snap());
    }

    /** SSE-поток снимков каждые 3 с (в.80: real-time без WebSocket) */
    public function stream(): void
    {
        @set_time_limit(0);
        while (ob_get_level() > 0) { @ob_end_clean(); }
        header('Content-Type: text/event-stream; charset=utf-8');
        header('Cache-Control: no-cache');
        header('X-Accel-Buffering: no');

        for ($i = 0; $i < 20; $i++) {
            if (connection_aborted()) { break; }
            $snap = self::snap();
            echo 'data: ' . json_encode($snap, JSON_UNESCAPED_UNICODE) . "\n\n";
            @flush();
            if ($i < 19) { sleep(3); }
        }
        echo "event: reconnect\ndata: {}\n\n";
        @flush();
        exit;
    }

    /** @return array{ok:bool,stale:bool,src:string,ts:int,count:int,ac:list<array<string,mixed>>} */
    private static function snap(): array
    {
        $f = static fn(string $k, float $d): float => is_numeric(Request::str($k)) ? (float)Request::str($k) : $d;
        return AdsbService::snapshot(
            $f('lamin', 36.0), $f('lomin', -12.0),   // юго-запад bbox
            $f('lamax', 60.0), $f('lomax', 42.0)     // северо-восток bbox
        );
    }
}
