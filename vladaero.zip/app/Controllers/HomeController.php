<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Database;
use App\Core\View;

final class HomeController
{
    /** Офлайн-страница PWA (в.73): кэшируется сервис-воркером */
    public function offline(): void
    {
        echo View::render('offline', ['title' => __('pwa.offline_title')]);
    }

    public function index(): void
    {
        $stats = [
            'users'    => 0,
            'aircraft' => 0,
            'airports' => 0,
            'photos'   => 0,
            'articles' => 0,
        ];
        try {
            $db = Database::i();
            $stats['users']    = (int)($db->val('SELECT COUNT(*) FROM `{p}users`') ?? 0);
            $stats['aircraft'] = (int)($db->val('SELECT COUNT(*) FROM `{p}aircraft`') ?? 0);
            $stats['airports'] = (int)($db->val('SELECT COUNT(*) FROM `{p}airports`') ?? 0);
            $stats['photos']   = (int)($db->val('SELECT COUNT(*) FROM `{p}photos`') ?? 0);
            $stats['articles'] = (int)($db->val('SELECT COUNT(*) FROM `{p}articles` WHERE status = \'published\'') ?? 0);
        } catch (\Throwable $e) {
            \App\Core\Logger::warning('Главная: не удалось собрать статистику — ' . $e->getMessage());
        }

        echo View::render('home/index', [
            'title' => __('app.name') . ' — ' . __('app.tagline'),
            'stats' => $stats,
        ], 'main');
    }
}
