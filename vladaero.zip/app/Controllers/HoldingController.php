<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\View;

/**
 * Зоны ожидания (в.49): учебный калькулятор входа + карта protected airspace.
 * Не для навигационного использования — тренажёр для споттеров и симмеров.
 */
final class HoldingController
{
    public function index(): void
    {
        echo View::render('holding', ['title' => __('holding.title')]);
    }
}
