<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database;
use App\Core\Request;
use App\Core\Validator;
use App\Core\View;
use App\Models\User;

/**
 * Регистрация и вход (вопросы 66–70). Telegram-код — v0.5.
 */
final class AuthController
{
    public function formLogin(): void
    {
        if (Auth::check()) {
            redirect('/');
        }
        echo View::render('auth/login', [
            'title' => __('auth.login_title') . ' — ' . __('app.name'),
        ], 'auth');
    }

    public function login(): void
    {
        csrf_verify();
        $login = Request::str('login');
        $password = Request::str('password');

        $v = Validator::make(['login' => $login, 'password' => $password], [
            'login'    => 'required',
            'password' => 'required',
        ]);
        if ($v->fails()) {
            flash('danger', $v->error('login') ?? $v->error('password') ?? __('auth.failed'));
            redirect('/login');
        }

        $result = Auth::attempt($login, $password);
        if (!$result['ok']) {
            flash('danger', $result['error']);
            redirect('/login');
        }

        flash('success', str_replace(':name', e($login), __('auth.welcome')));
        redirect('/');
    }

    /** POST /login/tg — вход по Telegram-коду (вопрос 66) */
    public function tgLogin(): void
    {
        csrf_verify();
        $code = Request::str('tg_code');
        if ($code === '') {
            flash('danger', __('auth.tg_need_code'));
            redirect('/login');
        }
        $userId = \App\Services\TelegramService::userIdByLoginCode($code);
        if ($userId === null) {
            flash('danger', __('auth.tg_bad_code'));
            redirect('/login');
        }
        $user = User::find($userId);
        if ($user === null || ($user['status'] ?? '') === 'banned') {
            flash('danger', __('auth.failed'));
            redirect('/login');
        }
        Auth::loginUser($user);
        \App\Models\Audit::log('login_tg', 'user', $user['id'], ['username' => $user['username']]);
        flash('success', str_replace(':name', e($user['username']), __('auth.welcome_tg')));
        redirect('/');
    }

    public function formRegister(): void
    {
        if (Auth::check()) {
            redirect('/');
        }
        if ((string)setting('registration_enabled', '1') !== '1') {
            flash('warning', __('auth.registration_off'));
            redirect('/login');
        }
        echo View::render('auth/register', [
            'title' => __('auth.register_title') . ' — ' . __('app.name'),
        ], 'auth');
    }

    public function register(): void
    {
        csrf_verify();
        if ((string)setting('registration_enabled', '1') !== '1') {
            flash('warning', __('auth.registration_off'));
            redirect('/login');
        }

        $data = [
            'username' => Request::str('username'),
            'email'    => strtolower(Request::str('email')),
            'password' => Request::str('password'),
            'password2' => Request::str('password2'),
        ];

        $v = Validator::make($data, [
            'username'  => 'required|username|unique:users,username',
            'email'     => 'required|email|unique:users,email',
            'password'  => 'required|password',
            'password2' => 'required|same:password',
        ]);
        if ($v->fails()) {
            foreach ($v->errors() as $msg) {
                flash('danger', $msg);
            }
            $_SESSION['_old'] = ['username' => $data['username'], 'email' => $data['email']];
            redirect('/register');
        }

        $id = User::create([
            'username'      => $data['username'],
            'email'         => $data['email'],
            'password_hash' => password_hash($data['password'], PASSWORD_BCRYPT, ['cost' => 12]),
            'role'          => 'user',
            'rank'          => 'cadet',
        ]);

        $user = User::find($id);
        if ($user !== null) {
            Auth::loginUser($user);
        }
        \App\Models\Audit::log('register', 'user', $id, ['username' => $data['username']]);
        flash('success', str_replace(':name', e($data['username']), __('auth.registered')));
        redirect('/');
    }

    public function logout(): void
    {
        csrf_verify();
        Auth::logout();
        flash('info', __('auth.logged_out'));
        redirect('/');
    }

    /** Старые значения формы при ошибке регистрации */
    public static function old(string $key): string
    {
        return e($_SESSION['_old'][$key] ?? '');
    }

    public static function clearOld(): void
    {
        unset($_SESSION['_old']);
    }
}
