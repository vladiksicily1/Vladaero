<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database;
use App\Core\Request;
use App\Core\View;

/**
 * Тематические клубы (в.27): по аэропортам, типам ВС, симуляторам.
 * Создание — пользователями, с модерацией; стена обсуждения = комментарии.
 */
final class ClubsController
{
    private const KINDS = [
        'airport' => 'Аэропорт',
        'actype' => 'Тип ВС',
        'sim' => 'Симулятор',
        'other' => 'Другое',
    ];

    public function index(): void
    {
        $clubs = Database::i()->all(
            'SELECT c.*, u.username AS owner,
                (SELECT COUNT(*) FROM `{p}club_members` m WHERE m.club_id = c.id) AS members
             FROM `{p}clubs` c JOIN `{p}users` u ON u.id = c.owner_id
             WHERE c.status = "approved" ORDER BY members DESC, c.id ASC LIMIT 200');
        $mine = $this->myClubIds();
        foreach ($clubs as &$c) { $c['joined'] = in_array((int)$c['id'], $mine, true); }
        unset($c);
        echo View::render('clubs/index', [
            'title' => __('clubs.title'),
            'clubs' => $clubs,
            'kinds' => self::KINDS,
        ]);
    }

    public function show(string $slug): void
    {
        $club = Database::i()->one(
            'SELECT c.*, u.username AS owner FROM `{p}clubs` c JOIN `{p}users` u ON u.id = c.owner_id
             WHERE c.slug = ? AND c.status = "approved" LIMIT 1', [$slug]);
        if ($club === null) { http_response_code(404); echo View::render('errors/404', ['title' => '404']); return; }
        $members = Database::i()->all(
            'SELECT u.username, u.role, m.joined_at FROM `{p}club_members` m JOIN `{p}users` u ON u.id = m.user_id
             WHERE m.club_id = ? ORDER BY m.joined_at ASC LIMIT 500', [(int)$club['id']]);
        echo View::render('clubs/show', [
            'title' => $club['title'],
            'club' => $club,
            'kindLabel' => self::KINDS[$club['kind']] ?? $club['kind'],
            'members' => $members,
            'joined' => in_array((int)$club['id'], $this->myClubIds(), true),
        ]);
    }

    /** Вступить / выйти */
    public function toggle(string $slug): void
    {
        csrf_verify();
        if (!Auth::check()) { flash('warning', __('auth.need_login')); redirect('/login'); }
        $club = Database::i()->one('SELECT id, title FROM `{p}clubs` WHERE slug = ? AND status = "approved" LIMIT 1', [$slug]);
        if ($club === null) { http_response_code(404); exit; }
        $uid = (int)Auth::id();
        $exists = Database::i()->one('SELECT id FROM `{p}club_members` WHERE club_id = ? AND user_id = ?', [(int)$club['id'], $uid]);
        if ($exists !== null && (int)$club['id'] !== 0) {
            Database::i()->run('DELETE FROM `{p}club_members` WHERE id = ?', [$exists['id']]);
            flash('success', __('clubs.left'));
        } else {
            Database::i()->insert('club_members', [
                'club_id' => (int)$club['id'], 'user_id' => $uid, 'joined_at' => date('Y-m-d H:i:s'),
            ]);
            flash('success', __('clubs.joined'));
        }
        redirect('/clubs/' . $slug);
    }

    public function createForm(): void
    {
        if (!Auth::check()) { flash('warning', __('auth.need_login')); redirect('/login'); }
        echo View::render('clubs/create', ['title' => __('clubs.create'), 'kinds' => self::KINDS]);
    }

    public function store(): void
    {
        csrf_verify();
        if (!Auth::check()) { flash('warning', __('auth.need_login')); redirect('/login'); }
        $title = trim(Request::str('title'));
        $desc = trim(Request::str('description'));
        if (mb_strlen($title) < 3 || mb_strlen($desc) < 10) {
            flash('warning', __('clubs.err_fields'));
            redirect('/clubs/create');
        }
        $slug = 'c-' . substr(bin2hex(random_bytes(5)), 0, 8);
        Database::i()->insert('clubs', [
            'slug' => $slug,
            'title' => mb_substr($title, 0, 190),
            'kind' => isset(self::KINDS[Request::str('kind')]) ? Request::str('kind') : 'other',
            'description' => mb_substr($desc, 0, 3000),
            'owner_id' => (int)Auth::id(),
            'status' => 'pending',
            'created_at' => date('Y-m-d H:i:s'),
        ]);
        flash('success', __('clubs.sent_moderation'));
        redirect('/clubs');
    }

    /** @return array<int,int> */
    private function myClubIds(): array
    {
        if (!Auth::check()) { return []; }
        $rows = Database::i()->all('SELECT club_id FROM `{p}club_members` WHERE user_id = ?', [(int)Auth::id()]);
        return array_map(static fn($r) => (int)$r['club_id'], $rows);
    }
}
