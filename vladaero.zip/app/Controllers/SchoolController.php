<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\BlockRenderer;
use App\Core\Database;
use App\Core\Request;
use App\Core\View;

/**
 * Лётная школа (в.24): пошаговые уроки от базового пилотирования до IFR,
 * разбор карт/схем, гайды по авионике, тесты для проверки знаний.
 */
final class SchoolController
{
    private const LEVELS = [
        'basic'    => ['✦', 'Базовый курс', 'аэродинамика, круг, первая практика'],
        'vfr'      => ['☁', 'VFR', 'погода, навигация визуального полёта'],
        'ifr'      => ['◉', 'IFR', 'схемы SID/STAR, приборный полёт'],
        'avionics' => ['⌗', 'Авионика', 'G1000, FMS/MCDU'],
        'pro'      => ['★', 'Профессионалам', 'фразеология, регламенты'],
    ];

    public function index(): void
    {
        $lessons = Database::i()->all(
            'SELECT id, slug, level, title_ru, summary_ru FROM `{p}lessons` WHERE published = 1 ORDER BY level, sort, id');
        $passed = [];
        if (Auth::check()) {
            foreach (Database::i()->all('SELECT lesson_id, quiz_score FROM `{p}lesson_progress` WHERE user_id = ?', [(int)Auth::id()]) as $p) {
                $passed[(int)$p['lesson_id']] = (int)$p['quiz_score'];
            }
        }
        $byLevel = [];
        foreach ($lessons as $l) {
            $byLevel[$l['level']][] = $l + ['passed' => $passed[(int)$l['id']] ?? null];
        }
        $total = count($lessons);
        $done = count($passed);
        echo View::render('school/index', [
            'title' => __('school.title'),
            'byLevel' => $byLevel,
            'levels' => self::LEVELS,
            'total' => $total,
            'done' => $done,
        ]);
    }

    public function show(string $slug): void
    {
        $lesson = Database::i()->one('SELECT * FROM `{p}lessons` WHERE slug = ? AND published = 1 LIMIT 1', [$slug]);
        if ($lesson === null) { http_response_code(404); echo View::render('errors/404', ['title' => '404']); return; }

        $blocks = json_decode((string)$lesson['body_json'], true);
        $quiz = json_decode((string)$lesson['quiz_json'], true) ?: [];
        $prev = Database::i()->one('SELECT slug, title_ru FROM `{p}lessons` WHERE published = 1 AND (level, sort, id) < (?, ?, ?) ORDER BY level DESC, sort DESC, id DESC LIMIT 1', [(string)$lesson['level'], (int)$lesson['sort'], (int)$lesson['id']]);
        $next = Database::i()->one('SELECT slug, title_ru FROM `{p}lessons` WHERE published = 1 AND (level, sort, id) > (?, ?, ?) ORDER BY level ASC, sort ASC, id ASC LIMIT 1', [(string)$lesson['level'], (int)$lesson['sort'], (int)$lesson['id']]);

        $passed = null;
        if (Auth::check()) {
            $row = Database::i()->one('SELECT quiz_score FROM `{p}lesson_progress` WHERE user_id = ? AND lesson_id = ?', [(int)Auth::id(), (int)$lesson['id']]);
            $passed = $row !== null ? (int)$row['quiz_score'] : null;
        }
        echo View::render('school/show', [
            'title' => $lesson['title_ru'],
            'lesson' => $lesson,
            'levelMeta' => self::LEVELS[$lesson['level']] ?? self::LEVELS['basic'],
            'bodyHtml' => BlockRenderer::renderList(is_array($blocks) ? $blocks : []),
            'quiz' => $quiz,
            'prev' => $prev,
            'next' => $next,
            'passed' => $passed,
        ]);
    }

    /** Проверка теста урока (серверная — ответы не подглядеть) */
    public function quiz(string $slug): void
    {
        csrf_verify();
        $lesson = Database::i()->one('SELECT id, slug, title_ru, quiz_json FROM `{p}lessons` WHERE slug = ? AND published = 1 LIMIT 1', [$slug]);
        if ($lesson === null) { http_response_code(404); exit; }
        $quiz = json_decode((string)$lesson['quiz_json'], true) ?: [];
        $questions = is_array($quiz['questions'] ?? null) ? $quiz['questions'] : [];
        $passMark = (int)($quiz['pass'] ?? 70);
        $answers = $_POST['q'] ?? [];
        if (!is_array($answers)) { $answers = []; }

        $results = [];
        $correct = 0;
        foreach ($questions as $i => $q) {
            $given = (int)($answers[$i] ?? -1);
            $ok = $given === (int)($q['correct'] ?? 0);
            if ($ok) { $correct++; }
            $results[] = ['given' => $given, 'ok' => $ok, 'correct' => (int)($q['correct'] ?? 0), 'explain' => (string)($q['explain'] ?? '')];
        }
        $total = max(1, count($questions));
        $score = (int)round($correct / $total * 100);
        $passedFlag = $score >= $passMark;

        if (Auth::check() && $passedFlag) {
            Database::i()->run(
                'INSERT INTO `{p}lesson_progress` (user_id, lesson_id, quiz_score, passed_at) VALUES (?,?,?,NOW())
                 ON DUPLICATE KEY UPDATE quiz_score = GREATEST(quiz_score, VALUES(quiz_score)), passed_at = NOW()',
                [(int)Auth::id(), (int)$lesson['id'], $score]);
        }
        $_SESSION['_quiz_result'] = [
            'slug' => $slug, 'score' => $score, 'correct' => $correct, 'total' => $total,
            'passed' => $passedFlag, 'results' => $results,
        ];
        flash($passedFlag ? 'success' : 'warning',
            $passedFlag ? __('school.quiz_passed', ['d' => $score]) : __('school.quiz_failed', ['d' => $score]));
        redirect('/school/' . $slug . '#quiz');
    }
}
