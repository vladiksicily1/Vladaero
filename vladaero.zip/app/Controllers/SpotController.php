<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database;
use App\Core\Request;
use App\Core\View;

/**
 * Карта споттинг-точек (v0.8.1): точки на Leaflet-карте у аэропортов,
 * добавление точек пользователями (на модерации), публикация — в админке.
 */
final class SpotController
{
    public function index(): void
    {
        $icao = strtoupper(Request::str('icao', ''));
        $sql = 'SELECT s.*, u.username AS author FROM `{p}spot_points` s
                LEFT JOIN `{p}users` u ON u.id = s.created_by
                WHERE s.status = "published"';
        $params = [];
        if ($icao !== '') {
            $sql .= ' AND s.icao = ?';
            $params[] = $icao;
        }
        $sql .= ' ORDER BY s.icao, s.title_ru LIMIT 500';
        $points = Database::i()->all($sql, $params);

        $airports = Database::i()->all(
            'SELECT icao, name_ru, lat, lng FROM `{p}airports` WHERE lat IS NOT NULL AND lng IS NOT NULL ORDER BY icao');
        $withPoints = Database::i()->all(
            'SELECT icao, COUNT(*) AS n FROM `{p}spot_points` WHERE status = "published" GROUP BY icao');

        echo View::render('spots/index', [
            'title' => __('spots.title'),
            'points' => $points,
            'airports' => $airports,
            'withPoints' => $withPoints,
            'icao' => $icao,
        ]);
    }

    /** POST /spots/add — предложит точку (pending до одобрения админом) */
    public function add(): void
    {
        if (!Auth::check()) { flash('warning', __('auth.need_login')); redirect('/login'); }
        csrf_verify();
        $icao = strtoupper(substr(preg_replace('~[^a-z0-9]~i', '', Request::str('icao')) ?? '', 0, 4));
        $title = trim(Request::str('title'));
        $desc = trim(Request::str('description'));
        $lat = round((float)Request::str('lat', '0'), 6);
        $lng = round((float)Request::str('lng', '0'), 6);
        $light = trim(Request::str('light_hint'));
        if ($icao === '' || $title === '' || $desc === '' || abs($lat) < 0.0001 || abs($lng) < 0.0001) {
            flash('error', __('spots.form_err'));
            redirect('/spots');
        }
        Database::i()->insert('spot_points', [
            'icao' => $icao, 'title_ru' => mb_substr($title, 0, 160), 'description_ru' => mb_substr($desc, 0, 4000),
            'lat' => $lat, 'lng' => $lng, 'light_hint' => mb_substr($light, 0, 240),
            'status' => 'pending', 'created_by' => (int)Auth::id(), 'created_at' => date('Y-m-d H:i:s'),
        ]);
        flash('success', __('spots.submitted'));
        redirect('/spots' . ($icao !== '' ? '?icao=' . $icao : ''));
    }
}
