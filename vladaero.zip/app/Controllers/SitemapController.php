<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Database;

/**
 * Многоуровневый динамический Sitemap XML (в.104–105).
 * Индекс: /sitemap.xml, секции: /sitemap-{section}.xml
 */
final class SitemapController
{
    public function index(): void
    {
        $base = rtrim(setting('base_url', (string)url('/')), '/');
        $sections = ['pages', 'aircraft', 'articles', 'airports', 'photos', 'events', 'school'];
        header('Content-Type: application/xml; charset=utf-8');
        echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        echo '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
        foreach ($sections as $s) {
            $mod = self::lastMod($s);
            printf(
                "  <sitemap><loc>%s/sitemap-%s.xml</loc>%s</sitemap>\n",
                htmlspecialchars($base, ENT_XML1),
                $s,
                $mod !== null ? '<lastmod>' . $mod . '</lastmod>' : ''
            );
        }
        echo '</sitemapindex>';
        exit;
    }

    public function section(string $section): void
    {
        $base = rtrim(setting('base_url', (string)url('/')), '/');
        $urls = match ($section) {
            'aircraft' => array_map(
                static fn($r) => ['/aircraft/' . rawurlencode($r['slug']), $r['updated_at'] ?? null],
                Database::i()->all("SELECT slug, updated_at FROM `{p}aircraft` ORDER BY id LIMIT 5000")
            ),
            'articles' => array_map(
                static fn($r) => ['/articles/' . rawurlencode($r['slug']), $r['updated_at'] ?? null],
                Database::i()->all("SELECT slug, updated_at FROM `{p}articles` WHERE status = 'published' ORDER BY id LIMIT 5000")
            ),
            'airports' => array_map(
                static fn($r) => ['/airports/' . rawurlencode(strtolower($r['icao'])), null],
                Database::i()->all('SELECT icao FROM `{p}airports` ORDER BY icao LIMIT 5000')
            ),
            'photos'   => array_map(
                static fn($r) => ['/gallery/' . $r['id'], $r['created_at']],
                Database::i()->all("SELECT id, created_at FROM `{p}photos` WHERE status = 'approved' ORDER BY id DESC LIMIT 5000")
            ),
            'events'   => array_map(
                static fn($r) => ['/events/' . rawurlencode($r['slug']), substr((string)$r['starts_at'], 0, 10)],
                Database::i()->all("SELECT slug, starts_at FROM `{p}events` WHERE status = 'published' ORDER BY starts_at DESC LIMIT 5000")
            ),
            'school'   => array_merge(
                [['/school', null]],
                array_map(
                    static fn($r) => ['/school/' . rawurlencode($r['slug']), $r['updated_at'] ?? null],
                    Database::i()->all('SELECT slug, updated_at FROM `{p}lessons` WHERE published = 1 ORDER BY id LIMIT 1000')
                ),
                array_map(
                    static fn($r) => ['/clubs/' . rawurlencode($r['slug']), null],
                    Database::i()->all("SELECT slug FROM `{p}clubs` WHERE status = 'approved' ORDER BY id LIMIT 1000")
                )
            ),
            'pages'    => [
                ['/', self::lastMod('articles')],
                ['/aircraft', null],
                ['/articles', self::lastMod('articles')],
                ['/airports', null],
                ['/gallery', self::lastMod('photos')],
                ['/versus', null],
                ['/events', null],
                ['/clubs', null],
            ],
            default    => null,
        };
        if ($urls === null) { abort(404); }

        header('Content-Type: application/xml; charset=utf-8');
        echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
        foreach ($urls as [$path, $mod]) {
            printf(
                "  <url><loc>%s%s</loc>%s</url>\n",
                htmlspecialchars($base, ENT_XML1),
                htmlspecialchars($path, ENT_XML1),
                $mod !== null ? '<lastmod>' . htmlspecialchars((string)$mod, ENT_XML1) . '</lastmod>' : ''
            );
        }
        echo '</urlset>';
        exit;
    }

    private static function lastMod(string $section): ?string
    {
        $table = match ($section) {
            'aircraft' => ['{p}aircraft', 'MAX(updated_at)'],
            'articles' => ['{p}articles', 'MAX(updated_at)'],
            'photos'   => ['{p}photos', 'MAX(created_at)'],
            default    => null,
        };
        if ($table === null) { return null; }
        $v = Database::i()->val("SELECT {$table[1]} FROM `{$table[0]}`");
        return $v !== null ? substr((string)$v, 0, 10) : null;
    }
}
