<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Database;
use App\Core\Request;
use App\Core\View;
use App\Services\FidsService;

/**
 * FIDS — онлайн-табло аэропортов (в.279): вылеты/прилёты, поиск по рейсу,
 * терминалу и статусу, связь с радаром. Данные SkyLink (ключ в админке).
 */
final class FidsController
{
    public function index(): void
    {
        $icao = strtoupper(Request::str('icao', ''));
        echo View::render('fids', [
            'title'    => __('fids.title'),
            'icao'     => $icao,
            'type'     => Request::str('type', 'departure') === 'arrival' ? 'arrival' : 'departure',
            'airports' => Database::i()->all('SELECT icao, iata, name_ru FROM `{p}airports` ORDER BY icao LIMIT 400'),
            'hasKey'   => (string)setting('skylink_api_key', '') !== '',
        ]);
    }

    /** JSON: /api/fids?icao=UUEE&type=departure */
    public function api(): void
    {
        json_response(FidsService::board(Request::str('icao'), Request::str('type', 'departure')));
    }
}
