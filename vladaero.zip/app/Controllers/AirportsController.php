<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Request;
use App\Core\View;
use App\Models\Airport;
use App\Models\Blocks;

/**
 * Публичный каталог аэропортов (в.10, 33).
 */
final class AirportsController
{
    public function index(): void
    {
        $q = Request::str('q');
        $page = max(1, Request::int('page', 1));
        $res = Airport::search($q, 30, ($page - 1) * 30);
        echo View::render('airports/index', [
            'title' => __('ap.section') . ' — ' . __('app.name'),
            'rows'  => $res['rows'],
            'total' => $res['total'],
            'q'     => $q,
            'page'  => $page,
            'pages' => max(1, (int)ceil($res['total'] / 30)),
        ], 'main');
    }

    public function show(string $icao): void
    {
        $ap = Airport::findByIcao($icao);
        if ($ap === null) {
            abort(404);
        }
        echo View::render('airports/show', [
            'title'     => $ap['name_ru'] . ' (' . $ap['icao'] . ') — ' . __('app.name'),
            'ap'        => $ap,
            'blocksHtml'=> Blocks::render('airport', (int)$ap['id']),
        ], 'main');
    }
}
