<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database;
use App\Core\Request;
use App\Core\View;
use App\Models\Notification;

/**
 * Календарь авиационных событий (в.56–60): карта с пинами, фильтры, «Я пойду»,
 * экспорт .ics, создание встреч пользователями (с модерацией), медиа-хаб.
 */
final class EventsController
{
    private const TYPES = [
        'airshow' => 'Авиасалон / авиашоу',
        'spotting' => 'День споттинга',
        'virtual' => 'Виртуальный слёт',
        'museum' => 'Музей / день открытых дверей',
        'meetup' => 'Встреча / выезд',
    ];

    public function index(): void
    {
        $type = Request::str('type');
        $country = strtoupper(Request::str('country'));
        $past = Request::str('past') === '1';
        $where = ['e.status = "published"'];
        $args = [];
        if (isset(self::TYPES[$type])) { $where[] = 'e.type = ?'; $args[] = $type; }
        if (strlen($country) === 2) { $where[] = 'e.country_code = ?'; $args[] = $country; }
        $where[] = $past ? 'e.starts_at < NOW()' : 'e.starts_at >= NOW()';
        $order = $past ? 'e.starts_at DESC' : 'e.starts_at ASC';

        $events = Database::i()->all(
            'SELECT e.*, (SELECT COUNT(*) FROM `{p}event_attendees` a WHERE a.event_id = e.id) AS attendees
             FROM `{p}events` e WHERE ' . implode(' AND ', $where) . " ORDER BY $order LIMIT 200", $args);

        $countries = Database::i()->all(
            'SELECT country_code, COUNT(*) n FROM `{p}events` WHERE status = "published" AND country_code IS NOT NULL AND country_code <> ""
             GROUP BY country_code ORDER BY n DESC LIMIT 40');

        echo View::render('events/index', [
            'title' => __('ev.title'),
            'events' => $events,
            'countries' => $countries,
            'types' => self::TYPES,
            'filters' => ['type' => $type, 'country' => $country, 'past' => $past],
            'myEvents' => $this->myEventIds(),
        ]);
    }

    public function show(string $slug): void
    {
        $ev = Database::i()->one('SELECT * FROM `{p}events` WHERE slug = ? AND status = "published" LIMIT 1', [$slug]);
        if ($ev === null) { http_response_code(404); echo View::render('errors/404', ['title' => '404']); return; }

        $attendees = Database::i()->all(
            'SELECT u.username FROM `{p}event_attendees` a JOIN `{p}users` u ON u.id = a.user_id
             WHERE a.event_id = ? ORDER BY a.created_at ASC LIMIT 200', [(int)$ev['id']]);
        $photos = Database::i()->all(
            'SELECT id, filename, title, registration FROM `{p}photos` WHERE event_id = ? AND status = "approved" ORDER BY id DESC LIMIT 24',
            [(int)$ev['id']]);

        echo View::render('events/show', [
            'title' => $ev['title_ru'],
            'ev' => $ev,
            'typeLabel' => self::TYPES[$ev['type']] ?? $ev['type'],
            'attendees' => $attendees,
            'photos' => $photos,
            'going' => in_array((int)$ev['id'], $this->myEventIds(), true),
            'gcal' => 'https://calendar.google.com/calendar/render?action=TEMPLATE&text=' . rawurlencode($ev['title_ru'])
                . '&dates=' . gmdate('Ymd\THis\Z', strtotime((string)$ev['starts_at'])) . '/' . gmdate('Ymd\THis\Z', strtotime((string)($ev['ends_at'] ?: $ev['starts_at']) . ' +2 hours'))
                . '&details=' . rawurlencode(rtrim(url('/'), '/') . '/events/' . $ev['slug']),
        ]);
    }

    /** Отметка «Я пойду» — переключатель (в.57) */
    public function attend(string $slug): void
    {
        csrf_verify();
        if (!Auth::check()) { flash('warning', __('auth.need_login')); redirect('/login'); }
        $ev = Database::i()->one('SELECT id, title_ru FROM `{p}events` WHERE slug = ? AND status = "published" LIMIT 1', [$slug]);
        if ($ev === null) { http_response_code(404); exit; }
        $uid = (int)Auth::id();
        $exists = Database::i()->one('SELECT id FROM `{p}event_attendees` WHERE event_id = ? AND user_id = ?', [(int)$ev['id'], $uid]);
        if ($exists !== null) {
            Database::i()->run('DELETE FROM `{p}event_attendees` WHERE id = ?', [$exists['id']]);
            flash('success', __('ev.unsubscribed'));
        } else {
            Database::i()->insert('event_attendees', [
                'event_id' => (int)$ev['id'], 'user_id' => $uid, 'created_at' => date('Y-m-d H:i:s'),
            ]);
            Notification::push($uid, 'event_going', ['event' => $ev['title_ru'], 'url' => '/events/' . $slug]);
            flash('success', __('ev.subscribed'));
        }
        redirect('/events/' . $slug);
    }

    /** Экспорт .ics (в.57: Google/Apple/Outlook в один клик) */
    public function ics(string $slug): void
    {
        $ev = Database::i()->one('SELECT * FROM `{p}events` WHERE slug = ? AND status = "published" LIMIT 1', [$slug]);
        if ($ev === null) { http_response_code(404); exit; }
        $dt = static fn(string $s) => gmdate('Ymd\THis\Z', strtotime($s));
        $end = $ev['ends_at'] ?: gmdate('Y-m-d H:i:s', strtotime((string)$ev['starts_at']) + 7200);
        $lines = [
            'BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//VladAero//Events//RU', 'CALSCALE:GREGORIAN',
            'BEGIN:VEVENT',
            'UID:vladaero-event-' . $ev['id'] . '@vladinc.ru',
            'DTSTAMP:' . $dt(date('Y-m-d H:i:s')),
            'DTSTART:' . $dt((string)$ev['starts_at']),
            'DTEND:' . $dt((string)$end),
            'SUMMARY:' . self::icsEscape((string)$ev['title_ru']),
            'DESCRIPTION:' . self::icsEscape(mb_substr(trim((string)$ev['description_ru']), 0, 400)),
            'LOCATION:' . self::icsEscape(trim($ev['venue'] . ', ' . $ev['city'] . ', ' . $ev['country_code'], ', ')),
            'END:VEVENT', 'END:VCALENDAR',
        ];
        header('Content-Type: text/calendar; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $ev['slug'] . '.ics"');
        echo implode("\r\n", $lines);
        exit;
    }

    private static function icsEscape(string $s): string
    {
        return str_replace(['\\', ',', ';'], ['\\\\', '\\,', '\\;'], $s);
    }

    /** Создание встречи пользователем (в.57) — на модерацию */
    public function createForm(): void
    {
        if (!Auth::check()) { flash('warning', __('auth.need_login')); redirect('/login'); }
        echo View::render('events/create', ['title' => __('ev.create'), 'types' => self::TYPES]);
    }

    public function store(): void
    {
        csrf_verify();
        if (!Auth::check()) { flash('warning', __('auth.need_login')); redirect('/login'); }
        $title = trim(Request::str('title'));
        $starts = Request::str('starts'); // datetime-local
        if (mb_strlen($title) < 4 || strtotime($starts) === false) {
            flash('warning', __('ev.err_fields'));
            redirect('/events/create');
        }
        $slug = 'event-' . substr(bin2hex(random_bytes(5)), 0, 8);
        Database::i()->insert('events', [
            'slug' => $slug,
            'title_ru' => mb_substr($title, 0, 220),
            'type' => isset(self::TYPES[Request::str('type')]) ? Request::str('type') : 'meetup',
            'status' => 'pending',
            'starts_at' => date('Y-m-d H:i:s', strtotime($starts)),
            'ends_at' => Request::str('ends') !== '' && strtotime(Request::str('ends')) !== false
                ? date('Y-m-d H:i:s', strtotime(Request::str('ends'))) : null,
            'country_code' => mb_strtoupper(mb_substr(Request::str('country'), 0, 2)),
            'city' => mb_substr(trim(Request::str('city')), 0, 120),
            'venue' => mb_substr(trim(Request::str('venue')), 0, 190),
            'lat' => is_numeric(Request::str('lat')) && (float)Request::str('lat') !== 0.0 ? (float)Request::str('lat') : null,
            'lng' => is_numeric(Request::str('lng')) && (float)Request::str('lng') !== 0.0 ? (float)Request::str('lng') : null,
            'description_ru' => mb_substr(trim(Request::str('description')), 0, 5000),
            'url' => mb_substr(trim(Request::str('url')), 0, 255),
            'created_by' => (int)Auth::id(),
            'created_at' => date('Y-m-d H:i:s'),
        ]);
        flash('success', __('ev.sent_moderation'));
        redirect('/events');
    }

    /** @return array<int,int> */
    private function myEventIds(): array
    {
        if (!Auth::check()) { return []; }
        $rows = Database::i()->all('SELECT event_id FROM `{p}event_attendees` WHERE user_id = ?', [(int)Auth::id()]);
        return array_map(static fn($r) => (int)$r['event_id'], $rows);
    }
}
