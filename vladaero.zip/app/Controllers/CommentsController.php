<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Request;
use App\Services\CommentService;

/**
 * Комментарии с ветками (в.27) — под фото, статьями, бортами, в клубах и событиях.
 * Мат-фильтр + карантин (в.194), анти-флуд.
 */
final class CommentsController
{
    public function store(): void
    {
        csrf_verify();
        if (!Auth::check()) { flash('warning', __('auth.need_login')); redirect('/login'); }
        [$id, $status, $err] = CommentService::add(
            (int)Auth::id(),
            Request::str('type'),
            (int)Request::str('id', '0'),
            (int)Request::str('parent', '0'),
            (string)($_POST['body'] ?? ''),
            $_SERVER['REMOTE_ADDR'] ?? ''
        );
        if ($err === 'flood') { flash('warning', __('cm.err_flood')); }
        elseif ($err !== null) { flash('warning', __('cm.err_' . $err)); }
        elseif ($status === 'pending') { flash('success', __('cm.sent_moderation')); }
        else { flash('success', __('cm.posted')); }

        $back = Request::str('back');
        if ($back !== '' && str_starts_with($back, '/')) {
            redirect($back . ($id > 0 ? '#comment-' . $id : ''));
        }
        redirect('/');
    }
}
