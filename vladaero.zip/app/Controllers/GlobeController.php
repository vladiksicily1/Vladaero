<?php
namespace App\Controllers;

/**
 * 3D-глобус (в.88): ортографическая проекция на canvas — аэропорты портала,
 * события и дуги маршрутов. Перетаскивание мышью/пальцем, автозавращение.
 */
final class GlobeController
{
    public function index(): void
    {
        $airports = \App\Core\Database::i()->all(
            'SELECT icao, name_ru, lat, lng FROM `{p}airports` WHERE lat IS NOT NULL AND lng IS NOT NULL ORDER BY icao LIMIT 500');
        $events = \App\Core\Database::i()->all(
            'SELECT title_ru, slug, lat, lng, starts_at FROM `{p}events`
             WHERE status = "published" AND lat IS NOT NULL AND lng IS NOT NULL AND (lat <> 0 OR lng <> 0) AND starts_at >= NOW()
             ORDER BY starts_at LIMIT 200');
        echo \App\Core\View::render('globe', [
            'title' => __('globe.title'),
            'airports' => $airports,
            'events' => $events,
        ]);
    }
}
