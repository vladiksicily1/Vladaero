<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database;
use App\Core\Request;
use App\Core\View;
use App\Services\SocialService;

/**
 * Лента подписок (v0.8.1): новые статьи авторов, на которых подписан пользователь.
 */
final class FeedController
{
    public function index(): void
    {
        if (!Auth::check()) { flash('warning', __('auth.need_login')); redirect('/login'); }
        $uid = (int)Auth::id();
        $feed = SocialService::feed($uid, 20);
        $authors = Database::i()->all(
            'SELECT u.id, u.username, u.avatar, COUNT(a.id) AS pub
             FROM `{p}author_follows` f JOIN `{p}users` u ON u.id = f.author_id
             LEFT JOIN `{p}articles` a ON a.author_id = u.id AND a.status = "published"
             WHERE f.user_id = ? GROUP BY u.id, u.username, u.avatar ORDER BY u.username', [$uid]);
        echo View::render('feed', [
            'title' => __('feed.title'),
            'feed' => $feed,
            'authors' => $authors,
        ]);
    }

    /** POST /profile/follow/{id} — AJAX-переключение подписки */
    public function follow(string $id): void
    {
        if (!Auth::check()) {
            if (Request::isAjax()) { header('Content-Type: application/json'); echo json_encode(['ok' => false, 'need_login' => true]); return; }
            flash('warning', __('auth.need_login')); redirect('/login');
        }
        $id = (int)$id;
        $target = Database::i()->one('SELECT id, username FROM `{p}users` WHERE id = ?', [$id]);
        if ($target === null) { http_response_code(404); exit('not found'); }
        $on = SocialService::toggleFollow((int)Auth::id(), $id);
        if (Request::isAjax()) {
            header('Content-Type: application/json');
            echo json_encode(['ok' => true, 'following' => $on, 'followers' => SocialService::followersCount($id)]);
            return;
        }
        flash('success', $on ? __('feed.followed', ['login' => $target['login']]) : __('feed.unfollowed', ['login' => $target['login']]));
        redirect('/profile/' . $id);
    }
}
