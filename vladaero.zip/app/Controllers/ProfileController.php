<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database;
use App\Core\View;
use App\Models\Notification;
use App\Services\CommunityService;
use App\Services\SocialService;

/**
 * Личный кабинет (в.26): статистика, виртуальный ангар (закладки),
 * прогресс школы, ранг и ачивки, лента уведомлений, статус Telegram.
 */
final class ProfileController
{
    public function index(): void
    {
        if (!Auth::check()) { flash('warning', __('auth.need_login')); redirect('/login'); }
        $uid = (int)Auth::id();

        $stats = [
            'photos' => (int)Database::i()->val('SELECT COUNT(*) FROM `{p}photos` WHERE user_id = ? AND status = "approved"', [$uid]),
            'photos_pending' => (int)Database::i()->val('SELECT COUNT(*) FROM `{p}photos` WHERE user_id = ? AND status = "pending"', [$uid]),
            'articles' => (int)Database::i()->val('SELECT COUNT(*) FROM `{p}articles` WHERE author_id = ? AND status = "published"', [$uid]),
            'comments' => (int)Database::i()->val('SELECT COUNT(*) FROM `{p}comments` WHERE user_id = ? AND status = "approved"', [$uid]),
            'likes' => (int)Database::i()->val('SELECT COALESCE(SUM(likes),0) FROM `{p}photos` WHERE user_id = ?', [$uid]),
        ];
        $points = CommunityService::points($uid);
        $rank = CommunityService::rank($points);
        $badges = CommunityService::badges($uid);

        $hangar = Database::i()->all(
            'SELECT a.id, a.slug, a.name_ru, a.icao_code, a.hero_photo FROM `{p}bookmarks` b
             JOIN `{p}aircraft` a ON a.id = b.entity_id
             WHERE b.user_id = ? AND b.entity_type = "aircraft" ORDER BY b.id DESC LIMIT 40', [$uid]);
        $bmArticles = Database::i()->all(
            'SELECT a.id, a.slug, a.title_ru FROM `{p}bookmarks` b
             JOIN `{p}articles` a ON a.id = b.entity_id
             WHERE b.user_id = ? AND b.entity_type = "article" AND a.status = "published" ORDER BY b.id DESC LIMIT 20', [$uid]);
        $bmAirports = Database::i()->all(
            'SELECT a.icao, a.name_ru FROM `{p}bookmarks` b
             JOIN `{p}airports` a ON a.id = b.entity_id
             WHERE b.user_id = ? AND b.entity_type = "airport" ORDER BY b.id DESC LIMIT 20', [$uid]);

        $lessons = Database::i()->all(
            'SELECT l.title_ru, l.slug, p.quiz_score FROM `{p}lesson_progress` p
             JOIN `{p}lessons` l ON l.id = p.lesson_id WHERE p.user_id = ? ORDER BY p.passed_at DESC LIMIT 20', [$uid]);

        $clubs = Database::i()->all(
            'SELECT c.slug, c.title FROM `{p}club_members` m JOIN `{p}clubs` c ON c.id = m.club_id
             WHERE m.user_id = ? AND c.status = "approved" ORDER BY m.joined_at DESC LIMIT 20', [$uid]);

        $tg = Database::i()->one('SELECT username, created_at FROM `{p}tg_links` WHERE user_id = ?', [$uid]);
        $notifs = Notification::latest($uid, 25);
        $unread = Notification::unreadCount($uid);

        echo View::render('profile', [
            'title' => __('profile.title'),
            'user' => Auth::user(),
            'stats' => $stats,
            'rank' => $rank,
            'badges' => $badges,
            'hangar' => $hangar,
            'bmArticles' => $bmArticles,
            'bmAirports' => $bmAirports,
            'lessons' => $lessons,
            'clubs' => $clubs,
            'tg' => $tg,
            'notifs' => $notifs,
            'unread' => $unread,
        ]);
    }

    /** Отметить уведомления прочитанными */
    /** Публичный профиль автора (v0.8.1): статьи, подписчики, кнопка подписки */
    public function show(string $id): void
    {
        $id = (int)$id;
        $u = Database::i()->one('SELECT id, username, avatar, created_at, role FROM `{p}users` WHERE id = ?', [$id]);
        if ($u === null) { http_response_code(404); echo View::render('errors/404', [], 'main'); return; }
        $articles = Database::i()->all(
            'SELECT id, slug, title_ru, excerpt_ru, published_at, views FROM `{p}articles`
             WHERE author_id = ? AND status = "published" ORDER BY published_at DESC LIMIT 10', [$id]);
        $photos = (int)Database::i()->val('SELECT COUNT(*) FROM `{p}photos` WHERE user_id = ? AND status = "approved"', [$id]);
        $points = CommunityService::points($id);
        $following = Auth::check() && SocialService::isFollowing((int)Auth::id(), $id);

        // Налёт виртуальной авиакомпании (PIREP из Telegram, в.263)
        $va = ['total_min' => 0, 'flights' => 0, 'aircraft' => [], 'recent' => []];
        try {
            $va['total_min'] = (int)(Database::i()->val('SELECT COALESCE(SUM(duration_min),0) FROM `{p}flight_logs` WHERE user_id = ?', [$id]) ?? 0);
            $va['flights']  = (int)(Database::i()->val('SELECT COUNT(*) FROM `{p}flight_logs` WHERE user_id = ?', [$id]) ?? 0);
            $va['aircraft'] = Database::i()->all('SELECT aircraft, SUM(duration_min) t FROM `{p}flight_logs` WHERE user_id = ? AND aircraft != "—" GROUP BY aircraft ORDER BY t DESC LIMIT 3', [$id]);
            $va['recent']   = Database::i()->all('SELECT route, aircraft, duration_min, created_at FROM `{p}flight_logs` WHERE user_id = ? ORDER BY id DESC LIMIT 5', [$id]);
        } catch (\Throwable) {
        }
        echo View::render('profile/show', [
            'title' => $u['login'],
            'u' => $u, 'articles' => $articles, 'photos' => $photos,
            'rank' => CommunityService::rank($points),
            'followers' => SocialService::followersCount($id),
            'following' => $following,
            'isMe' => Auth::check() && (int)Auth::id() === $id,
            'va' => $va,
        ]);
    }

    public function readAll(): void
    {
        csrf_verify();
        if (Auth::check()) { Notification::markAllRead((int)Auth::id()); }
        redirect('/profile');
    }
}
