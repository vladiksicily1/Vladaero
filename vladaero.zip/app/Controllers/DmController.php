<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database;
use App\Core\Request;
use App\Core\View;
use App\Services\SocialService;

/**
 * Личные сообщения (v0.8.1): список диалогов и переписка, уведомление в колокольчик.
 */
final class DmController
{
    public function index(): void
    {
        $this->guard();
        echo View::render('dm/index', [
            'title' => __('dm.title'),
            'dialogs' => SocialService::dialogs((int)Auth::id()),
        ]);
    }

    public function thread(string $peer): void
    {
        $this->guard();
        $uid = (int)Auth::id();
        $peerId = (int)$peer;
        $peer = Database::i()->one('SELECT id, username, avatar FROM `{p}users` WHERE id = ?', [$peerId]);
        if ($peer === null || $peerId === $uid) { http_response_code(404); echo View::render('errors/404', [], 'main'); return; }

        if (Request::isPost()) {
            $body = Request::str('body');
            csrf_verify();
            if ($body === '') { flash('error', __('dm.empty')); }
            elseif (!SocialService::sendDm($uid, $peerId, $body)) { flash('error', __('dm.fail')); }
            redirect('/im/' . $peerId);
        }

        SocialService::markRead($uid, $peerId);
        $msgs = array_reverse(SocialService::thread($uid, $peerId));
        echo View::render('dm/thread', [
            'title' => $peer['login'],
            'peer' => $peer,
            'msgs' => $msgs,
        ]);
    }

    private function guard(): void
    {
        if (!Auth::check()) { flash('warning', __('auth.need_login')); redirect('/login'); }
    }
}
