<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Database;
use App\Core\Request;
use App\Core\View;
use App\Models\Audit;

/**
 * Лётная школа (в.24): CRUD уроков. Тело — блоки JSON (как у статей),
 * тест — JSON {pass, questions[{q, options[], correct, explain}]}.
 */
final class LessonsController
{
    private const LEVELS = ['basic', 'vfr', 'ifr', 'avionics', 'pro'];

    public function index(): void
    {
        $rows = Database::i()->all(
            'SELECT l.*, (SELECT COUNT(*) FROM `{p}lesson_progress` p WHERE p.lesson_id = l.id) AS passed_n
             FROM `{p}lessons` l ORDER BY l.level, l.sort, l.id');
        echo View::render('admin/lessons', [
            'title' => __('admin.lessons'),
            'rows' => $rows,
            'levels' => self::LEVELS,
            'lesson' => null,
        ]);
    }

    public function create(): void
    {
        echo View::render('admin/lessons', [
            'title' => __('admin.lessons'),
            'rows' => Database::i()->all('SELECT id, slug, level, title_ru, published FROM `{p}lessons` ORDER BY level, sort, id'),
            'levels' => self::LEVELS,
            'lesson' => null,
            'editing' => false,
        ]);
    }

    public function store(): void
    {
        csrf_verify();
        $slug = Request::str('slug') !== ''
            ? preg_replace('~/~', '-', Request::str('slug'))
            : 'lesson-' . substr(bin2hex(random_bytes(4)), 0, 6);
        [$bodyOk, $bodyJson] = self::jsonField('body_json');
        [$quizOk, $quizJson] = self::jsonField('quiz_json');
        if (!$bodyOk) {
            flash('warning', __('school.err_body_json'));
            redirect('/admin/lessons/new');
        }
        Database::i()->insert('lessons', [
            'slug' => mb_substr($slug, 0, 190),
            'level' => in_array(Request::str('level'), self::LEVELS, true) ? Request::str('level') : 'basic',
            'sort' => max(0, min(999, (int)Request::str('sort', '100'))),
            'title_ru' => mb_substr(trim(Request::str('title')), 0, 220),
            'summary_ru' => mb_substr(trim(Request::str('summary')), 0, 500),
            'body_json' => $bodyJson,
            'quiz_json' => $quizJson,
            'published' => Request::str('published') === '0' ? 0 : 1,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        ]);
        Audit::log('lesson_create', 'lesson', null, ['slug' => $slug]);
        flash('success', __('admin.saved'));
        redirect('/admin/lessons');
    }

    public function edit(string $id): void
    {
        $lesson = Database::i()->one('SELECT * FROM `{p}lessons` WHERE id = ?', [(int)$id]);
        if ($lesson === null) { redirect('/admin/lessons'); }
        echo View::render('admin/lessons', [
            'title' => __('admin.lessons'),
            'rows' => Database::i()->all('SELECT id, slug, level, title_ru, published FROM `{p}lessons` ORDER BY level, sort, id'),
            'levels' => self::LEVELS,
            'lesson' => $lesson,
            'editing' => true,
        ]);
    }

    public function update(string $id): void
    {
        csrf_verify();
        [$bodyOk, $bodyJson] = self::jsonField('body_json');
        if (!$bodyOk) {
            flash('warning', __('school.err_body_json'));
            redirect('/admin/lessons/' . $id . '/edit');
        }
        $level = in_array(Request::str('level'), self::LEVELS, true) ? Request::str('level') : 'basic';
        Database::i()->run(
            'UPDATE `{p}lessons` SET slug = ?, level = ?, sort = ?, title_ru = ?, summary_ru = ?,
             body_json = ?, quiz_json = ?, published = ?, updated_at = NOW() WHERE id = ?',
            [
                mb_substr(preg_replace('~/~', '-', Request::str('slug')) ?: 'lesson', 0, 190),
                $level,
                max(0, min(999, (int)Request::str('sort', '100'))),
                mb_substr(trim(Request::str('title')), 0, 220),
                mb_substr(trim(Request::str('summary')), 0, 500),
                $bodyJson,
                $quizJson,
                Request::str('published') === '0' ? 0 : 1,
                (int)$id,
            ]);
        Audit::log('lesson_update', 'lesson', (int)$id, []);
        flash('success', __('admin.saved'));
        redirect('/admin/lessons');
    }

    public function delete(string $id): void
    {
        csrf_verify();
        Database::i()->run('DELETE FROM `{p}lessons` WHERE id = ?', [(int)$id]);
        Database::i()->run('DELETE FROM `{p}lesson_progress` WHERE lesson_id = ?', [(int)$id]);
        Audit::log('lesson_delete', 'lesson', (int)$id, []);
        redirect('/admin/lessons');
    }

    /** @return array{0:bool,1:?string} */
    private static function jsonField(string $key): array
    {
        $raw = trim((string)($_POST[$key] ?? ''));
        if ($raw === '') { return [true, null]; }
        $decoded = json_decode($raw, true);
        return [is_array($decoded), $is = is_array($decoded) ? json_encode($decoded, JSON_UNESCAPED_UNICODE) : null];
    }
}
