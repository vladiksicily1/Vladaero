<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Database;
use App\Core\Request;
use App\Core\View;
use App\Models\Audit;

/**
 * Клубы (в.27, 162): одобрение заявок на создание, удаление.
 */
final class ClubsController
{
    public function index(): void
    {
        $status = Request::str('status', 'all');
        $where = in_array($status, ['approved', 'pending', 'rejected'], true) ? "WHERE c.status = '$status'" : '';
        $rows = Database::i()->all(
            "SELECT c.*, u.username AS owner,
              (SELECT COUNT(*) FROM `{p}club_members` m WHERE m.club_id = c.id) AS members
             FROM `{p}clubs` c JOIN `{p}users` u ON u.id = c.owner_id
             $where ORDER BY c.id DESC LIMIT 200");
        echo View::render('admin/clubs', [
            'title' => __('admin.clubs'),
            'rows' => $rows,
            'status' => $status,
            'pending' => (int)Database::i()->val('SELECT COUNT(*) FROM `{p}clubs` WHERE status = "pending"'),
        ]);
    }

    public function setStatus(string $id): void
    {
        csrf_verify();
        $to = Request::str('to');
        if (in_array($to, ['approved', 'pending', 'rejected'], true)) {
            Database::i()->run('UPDATE `{p}clubs` SET status = ? WHERE id = ?', [$to, (int)$id]);
            Audit::log('club_status', 'club', (int)$id, ['to' => $to]);
        }
        redirect('/admin/clubs');
    }

    public function delete(string $id): void
    {
        csrf_verify();
        Database::i()->run('DELETE FROM `{p}clubs` WHERE id = ?', [(int)$id]);
        Database::i()->run('DELETE FROM `{p}club_members` WHERE club_id = ?', [(int)$id]);
        Audit::log('club_delete', 'club', (int)$id, []);
        redirect('/admin/clubs');
    }
}
