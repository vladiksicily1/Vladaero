<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Auth;
use App\Core\Request;
use App\Core\View;
use App\Models\Audit;
use App\Models\Photo;

/**
 * Экран скринера споттерских фото (в.11, 107):
 * горячие клавиши A/R, 100% зум, готовые причины отказа, аудит (в.109).
 */
final class PhotosController
{
    public function index(): void
    {
        $tab = Request::str('tab', 'pending');
        if (!in_array($tab, Photo::STATUSES, true)) { $tab = 'pending'; }

        echo View::render('admin/photos', [
            'title'  => __('ph.screen.title'),
            'tab'    => $tab,
            'items'  => Photo::queue($tab, 60),
            'counts' => Photo::counts(),
            'reasons' => Photo::REJECT_REASONS,
        ], 'admin');
    }

    /** Вердикт: A — принять, R — отклонить (в.107) */
    public function verdict(string $id): void
    {
        $id = (int)$id;
        $status = Request::str('status');
        if (!in_array($status, Photo::STATUSES, true)) {
            json_response(['ok' => false, 'error' => 'bad status'], 400);
        }
        $photo = Photo::find($id);
        if ($photo === null) {
            json_response(['ok' => false, 'error' => 'not found'], 404);
        }
        $reason = mb_substr(trim(Request::str('reason')), 0, 255);
        Photo::setStatus($id, $status, $status === 'rejected' ? $reason : '');

        Audit::log(
            $status === 'approved' ? 'photo.approve' : 'photo.reject',
            'photo',
            $id,
            ['by' => Auth::id(), 'reason' => $reason ?: null, 'author' => $photo['user_id']]
        );
        // Личное уведомление владельцу в Telegram (в.116), без модераторских рассылок (в.120)
        \App\Services\TelegramService::notifyPhotoVerdict($photo, $status, $status === 'rejected' ? $reason : '');
        json_response(['ok' => true, 'status' => $status]);
    }
}
