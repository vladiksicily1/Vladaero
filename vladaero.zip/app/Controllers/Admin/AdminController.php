<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Cache;
use App\Core\Database;
use App\Core\Logger;
use App\Core\Request;
use App\Core\View;
use App\Models\Audit;

/**
 * Дашборд центра управления (вопросы 110, 234: стиль NOC).
 */
final class AdminController
{
    public function dashboard(): void
    {
        $db = Database::i();
        $m = [
            'users_total'     => (int)($db->val('SELECT COUNT(*) FROM `{p}users`') ?? 0),
            'users_new_7d'    => (int)($db->val('SELECT COUNT(*) FROM `{p}users` WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)') ?? 0),
            'photos_pending'  => (int)($db->val("SELECT COUNT(*) FROM `{p}photos` WHERE status = 'pending'") ?? 0),
            'photos_approved' => (int)($db->val("SELECT COUNT(*) FROM `{p}photos` WHERE status = 'approved'") ?? 0),
            'articles'        => (int)($db->val("SELECT COUNT(*) FROM `{p}articles` WHERE status = 'published'") ?? 0),
            'aircraft'        => (int)($db->val('SELECT COUNT(*) FROM `{p}aircraft`') ?? 0),
            'airports'        => (int)($db->val('SELECT COUNT(*) FROM `{p}airports`') ?? 0),
            'ai_requests_7d'  => (int)($db->val('SELECT COUNT(*) FROM `{p}ai_requests` WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)') ?? 0),
            'db_size_mb'      => $db->sizeMb(),
            'cache_size'      => Cache::size(),
            'log_size'        => Logger::size(),
            'maintenance'     => (string)setting('maintenance', '0') === '1',
        ];

        // Данные для графика (14 дней): регистрации + ИИ-запросы
        $labels = [];
        $usersByDay = \App\Models\User::perDay(14);
        $aiByDay = [];
        try {
            $rows = $db->all(
                'SELECT DATE(created_at) d, COUNT(*) c FROM `{p}ai_requests`
                 WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 14 DAY)
                 GROUP BY DATE(created_at)'
            );
            $aiByDay = array_column($rows, 'c', 'd');
        } catch (\Throwable) {
        }
        $uSeries = [];
        $aSeries = [];
        for ($i = 13; $i >= 0; $i--) {
            $d = date('Y-m-d', strtotime("-$i days"));
            $labels[] = date('d.m', strtotime($d));
            $uSeries[] = (int)($usersByDay[$d] ?? 0);
            $aSeries[] = (int)($aiByDay[$d] ?? 0);
        }

        echo View::render('admin/dashboard', [
            'title'  => __('admin.dashboard') . ' — ' . __('app.name'),
            'm'      => $m,
            'chart'  => ['labels' => $labels, 'users' => $uSeries, 'ai' => $aSeries],
            'audit'  => Audit::recent(10),
        ], 'admin');
    }

    /** Переключатель режима обслуживания (вопрос 129) */
    public function toggleMaintenance(): void
    {
        csrf_verify();
        $on = (string)setting('maintenance', '0') === '1';
        \App\Models\Setting::set('maintenance', $on ? '0' : '1');
        Audit::log($on ? 'maintenance_off' : 'maintenance_on');
        flash('success', $on ? __('admin.maintenance_off') : __('admin.maintenance_on'));
        redirect('/admin');
    }

    /** Очистка файлового кэша (вопрос 82) */
    public function clearCache(): void
    {
        csrf_verify();
        $n = Cache::clear();
        Audit::log('cache_clear', '', null, ['files' => $n]);
        flash('success', str_replace(':n', (string)$n, __('admin.cache_cleared')));
        redirect('/admin');
    }
}
