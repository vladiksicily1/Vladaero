<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Auth;
use App\Core\Request;
use App\Models\Audit;
use App\Models\Blocks;

/**
 * Сохранение блоков и черновиков (в.108, 115). Блоки — у любой сущности.
 */
final class BlocksController
{
    public function save(): never
    {
        csrf_verify();
        $entity = Request::str('entity');
        $entityId = Request::int('entity_id');
        $json = (string)($_POST['blocks_json'] ?? Request::rawJson()['blocks_json'] ?? '');
        if (!in_array($entity, Blocks::ENTITIES, true) || $entityId <= 0) {
            json_response(['ok' => false, 'error' => 'Неверная сущность'], 200);
        }
        Blocks::set($entity, $entityId, $json, Auth::id());
        Audit::log('blocks_save', $entity, $entityId, ['bytes' => strlen($json)]);
        json_response(['ok' => true]);
    }

    /** Автосохранение черновика каждые 30 сек (в.115) */
    public function draft(): never
    {
        csrf_verify();
        $entity = Request::str('entity');
        $entityId = Request::int('entity_id');
        if (!in_array($entity, Blocks::ENTITIES, true) || $entityId <= 0) {
            json_response(['ok' => false], 200);
        }
        Blocks::saveDraft($entity, $entityId, Auth::id(), Request::str('blocks_json'));
        json_response(['ok' => true, 'saved_at' => date('H:i:s')]);
    }

    public function draftGet(): never
    {
        $entity = Request::str('entity');
        $entityId = Request::int('entity_id');
        if (!in_array($entity, Blocks::ENTITIES, true)) {
            json_response(['ok' => false], 200);
        }
        $draft = Blocks::getDraft($entity, $entityId, Auth::id());
        json_response(['ok' => true, 'draft' => $draft]);
    }
}
