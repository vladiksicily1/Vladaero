<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Auth;
use App\Core\Request;
use App\Core\View;
use App\Models\Article;
use App\Models\Audit;
use App\Models\Blocks;

/**
 * Статьи: блочный контент (в.42, 108–115).
 */
final class ArticlesController
{
    public function index(): void
    {
        $q = Request::str('q');
        $status = Request::str('status');
        $page = max(1, Request::int('page', 1));
        $res = Article::adminSearch($q, $status, 30, ($page - 1) * 30);
        echo View::render('admin/articles/index', [
            'title'  => __('admin.articles') . ' — ' . __('app.name'),
            'rows'   => $res['rows'],
            'total'  => $res['total'],
            'q'      => $q,
            'status' => $status,
            'page'   => $page,
            'pages'  => max(1, (int)ceil($res['total'] / 30)),
        ], 'admin');
    }

    public function create(): void
    {
        echo View::render('admin/articles/form', [
            'title'    => __('art.add') . ' — ' . __('app.name'),
            'a'        => null,
            'blocksJson' => '[]',
            'blockEntity' => 'article',
            'blockEntityId' => 0,
        ], 'admin');
    }

    public function store(): void
    {
        csrf_verify();
        $data = $this->collect();
        if ($data['title_ru'] === '') {
            flash('danger', 'Укажите заголовок');
            redirect('/admin/articles/new');
        }
        $data['slug'] = Article::uniqueSlug(slugify($data['slug'] !== '' ? $data['slug'] : $data['title_ru']));
        $data['author_id'] = Auth::id();
        if ($data['status'] === 'published') {
            $data['published_at'] = date('Y-m-d H:i:s');
        }
        $id = Article::create($data);
        if ($data['status'] === 'published') {
            \App\Services\SocialService::notifyFollowers((int)$data['author_id'], (string)$data['title_ru'], (string)$data['slug']);
        }
        $this->saveBlocks($id);
        Audit::log('article_create', 'article', $id, ['title' => $data['title_ru']]);
        flash('success', 'Статья «' . e($data['title_ru']) . '» создана');
        redirect('/admin/articles/' . $id . '/edit');
    }

    public function edit(string $id): void
    {
        $a = Article::find((int)$id);
        if ($a === null) {
            flash('danger', 'Статья не найдена');
            redirect('/admin/articles');
        }
        $blocks = Blocks::get('article', (int)$id) ?? [];
        echo View::render('admin/articles/form', [
            'title'    => __('art.edit') . ': ' . $a['title_ru'],
            'a'        => $a,
            'blocksJson' => json_encode($blocks, JSON_UNESCAPED_UNICODE),
            'blockEntity' => 'article',
            'blockEntityId' => (int)$id,
        ], 'admin');
    }

    public function update(string $id): void
    {
        csrf_verify();
        $a = Article::find((int)$id);
        if ($a === null) {
            flash('danger', 'Статья не найдена');
            redirect('/admin/articles');
        }
        $data = $this->collect();
        if ($data['title_ru'] === '') {
            flash('danger', 'Укажите заголовок');
            redirect('/admin/articles/' . (int)$id . '/edit');
        }
        $data['slug'] = Article::uniqueSlug(slugify($data['slug'] !== '' ? $data['slug'] : $data['title_ru']), (int)$id);
        if ($data['status'] === 'published' && empty($a['published_at'])) {
            $data['published_at'] = date('Y-m-d H:i:s');
            \App\Services\SocialService::notifyFollowers((int)($data['author_id'] ?? 0), (string)$data['title_ru'], (string)$data['slug']);
        }
        Article::updateById((int)$id, $data);
        $this->saveBlocks((int)$id);
        Audit::log('article_update', 'article', (int)$id, ['title' => $data['title_ru']]);
        flash('success', 'Статья сохранена');
        redirect('/admin/articles/' . (int)$id . '/edit');
    }

    public function delete(string $id): void
    {
        csrf_verify();
        $a = Article::find((int)$id);
        if ($a !== null) {
            Article::deleteById((int)$id);
            Audit::log('article_delete', 'article', (int)$id, ['title' => $a['title_ru']]);
            flash('success', 'Статья удалена');
        }
        redirect('/admin/articles');
    }

    private function collect(): array
    {
        return [
            'title_ru'    => Request::str('title_ru'),
            'title_en'    => Request::str('title_en'),
            'slug'        => Request::str('slug'),
            'excerpt_ru'  => Request::str('excerpt_ru') ?: null,
            'cover'       => Request::str('cover') ?: null,
            'status'      => in_array(Request::str('status'), Article::STATUSES, true) ? Request::str('status') : 'draft',
        ];
    }

    private function saveBlocks(int $id): void
    {
        $json = Request::str('blocks_json');
        if ($json !== '') {
            Blocks::set('article', $id, $json, Auth::id());
        }
    }
}
