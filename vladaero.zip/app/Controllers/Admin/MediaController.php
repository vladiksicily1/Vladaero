<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Request;
use App\Core\View;
use App\Models\Audit;
use App\Models\Media;
use App\Services\MediaService;

/**
 * Медиатека (в.12–15, 79, 84): загрузка, браузер, метаданные, удаление.
 */
final class MediaController
{
    public function index(): void
    {
        $res = Media::search(Request::str('q'), Request::str('kind'), 60, 0);
        echo View::render('admin/media', [
            'title' => __('media.title') . ' — ' . __('app.name'),
            'rows'  => $res['rows'],
            'total' => $res['total'],
            'q'     => Request::str('q'),
            'kind'  => Request::str('kind'),
        ], 'admin');
    }

    /** JSON для пикера медиа в блочном редакторе */
    public function apiList(): never
    {
        $offset = max(0, Request::int('offset'));
        $res = Media::search(Request::str('q'), Request::str('kind'), 40, $offset);
        $items = array_map(static fn(array $m): array => [
            'id'    => (int)$m['id'],
            'kind'  => $m['kind'],
            'path'  => $m['path'],
            'thumb' => $m['thumb_path'] ?: $m['path'],
            'name'  => $m['original_name'],
            'alt'   => $m['alt'],
            'w'     => (int)($m['width'] ?? 0),
            'h'     => (int)($m['height'] ?? 0),
            'size'  => (int)$m['size'],
        ], $res['rows']);
        json_response(['ok' => true, 'items' => $items, 'total' => $res['total'], 'hasMore' => $offset + count($items) < $res['total']]);
    }

    /** Загрузка файла (multipart). Возвращает JSON-запись медиа */
    public function upload(): never
    {
        csrf_verify();
        // v0.8.2: файл приходит multipart-ом ИЛИ JSON {file:{name,data:base64}} / {files:[...]} —
        // .zip распаковывается, каждый файл внутри проходит обычный конвейер.
        $files = MediaService::filesFromRequest('file');
        if ($files === []) {
            json_response(['ok' => false, 'error' => 'Файл не получен'], 200);
        }
        $meta = [
            'alt'     => Request::str('alt'),
            'credit'  => Request::str('credit'),
            'license' => Request::str('license', 'ARR'),
        ];
        $items = [];
        $skipped = [];
        $firstError = null;
        foreach ($files as $f) {
            $res = MediaService::ingest($f, \App\Core\Auth::id(), $meta);
            foreach ($res['items'] as $row) {
                Audit::log('media_upload', 'media', (int)$row['id'], ['name' => $row['original_name']]);
                $items[] = [
                    'id'    => (int)$row['id'],
                    'kind'  => $row['kind'],
                    'path'  => $row['path'],
                    'thumb' => $row['thumb_path'] ?: $row['path'],
                    'name'  => $row['original_name'],
                    'watermarked' => (bool)($row['watermarked'] ?? false),
                ];
            }
            foreach ($res['skipped'] as $sk) { $skipped[] = $sk; }
            if (!$res['ok'] && $firstError === null) { $firstError = $res['error']; }
        }
        json_response([
            'ok'     => $items !== [],
            'mode'   => count($files) === 1 && count($items) === 1 ? 'single' : 'batch',
            'count'  => count($items),
            'media'  => $items[0] ?? null,   // совместимость с одиночной загрузкой (blocks editor)
            'items'  => $items,
            'skipped'=> $skipped,
            'error'  => $items !== [] ? null : ($firstError ?? 'Ничего не загружено'),
        ]);
    }

    public function meta(string $id): never
    {
        csrf_verify();
        $m = Media::find((int)$id);
        if ($m === null) {
            json_response(['ok' => false, 'error' => 'Не найдено'], 200);
        }
        Media::updateMeta((int)$id, Request::str('alt'), Request::str('credit'), Request::str('license', 'ARR'));
        Audit::log('media_meta', 'media', (int)$id);
        json_response(['ok' => true]);
    }

    public function delete(string $id): never
    {
        csrf_verify();
        $m = Media::find((int)$id);
        if ($m === null) {
            json_response(['ok' => false, 'error' => 'Не найдено'], 200);
        }
        Media::deleteById((int)$id);
        Audit::log('media_delete', 'media', (int)$id, ['name' => $m['original_name']]);
        json_response(['ok' => true]);
    }
}
