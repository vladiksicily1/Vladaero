<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Database;
use App\Core\Request;
use App\Core\View;
use App\Models\Audit;

/**
 * Календарь событий (в.56–60): публикация встреч пользователей, создание, удаление.
 */
final class EventsController
{
    private const TYPES = ['airshow', 'spotting', 'virtual', 'museum', 'meetup'];

    public function index(): void
    {
        $status = Request::str('status', 'all');
        $where = in_array($status, ['published', 'pending', 'rejected'], true) ? "WHERE e.status = '$status'" : '';
        $rows = Database::i()->all(
            "SELECT e.*, u.username AS author,
              (SELECT COUNT(*) FROM `{p}event_attendees` a WHERE a.event_id = e.id) AS attendees
             FROM `{p}events` e LEFT JOIN `{p}users` u ON u.id = e.created_by
             $where ORDER BY e.starts_at DESC LIMIT 200");
        echo View::render('admin/events', [
            'title' => __('admin.events'),
            'rows' => $rows,
            'status' => $status,
            'types' => self::TYPES,
            'pending' => (int)Database::i()->val('SELECT COUNT(*) FROM `{p}events` WHERE status = "pending"'),
        ]);
    }

    public function setStatus(string $id): void
    {
        csrf_verify();
        $to = Request::str('to');
        if (in_array($to, ['published', 'pending', 'rejected'], true)) {
            Database::i()->run('UPDATE `{p}events` SET status = ? WHERE id = ?', [$to, (int)$id]);
            Audit::log('event_status', 'event', (int)$id, ['to' => $to]);
        }
        redirect('/admin/events');
    }

    public function store(): void
    {
        csrf_verify();
        $title = trim(Request::str('title'));
        $starts = Request::str('starts');
        if (mb_strlen($title) < 4 || strtotime($starts) === false) {
            flash('warning', __('ev.err_fields'));
            redirect('/admin/events');
        }
        Database::i()->insert('events', [
            'slug' => 'ev-' . substr(bin2hex(random_bytes(5)), 0, 8),
            'title_ru' => mb_substr($title, 0, 220),
            'type' => in_array(Request::str('type'), self::TYPES, true) ? Request::str('type') : 'airshow',
            'status' => 'published',
            'starts_at' => date('Y-m-d H:i:s', strtotime($starts)),
            'ends_at' => Request::str('ends') !== '' && strtotime(Request::str('ends')) !== false
                ? date('Y-m-d H:i:s', strtotime(Request::str('ends'))) : null,
            'country_code' => mb_strtoupper(mb_substr(Request::str('country'), 0, 2)),
            'city' => mb_substr(trim(Request::str('city')), 0, 120),
            'venue' => mb_substr(trim(Request::str('venue')), 0, 190),
            'lat' => is_numeric(Request::str('lat')) && (float)Request::str('lat') !== 0.0 ? (float)Request::str('lat') : null,
            'lng' => is_numeric(Request::str('lng')) && (float)Request::str('lng') !== 0.0 ? (float)Request::str('lng') : null,
            'description_ru' => mb_substr(trim(Request::str('description')), 0, 5000),
            'url' => mb_substr(trim(Request::str('url')), 0, 255),
            'created_by' => 0,
            'created_at' => date('Y-m-d H:i:s'),
        ]);
        Audit::log('event_create', 'event', null, ['title' => $title]);
        flash('success', __('admin.saved'));
        redirect('/admin/events');
    }

    public function delete(string $id): void
    {
        csrf_verify();
        Database::i()->run('DELETE FROM `{p}events` WHERE id = ?', [(int)$id]);
        Database::i()->run('DELETE FROM `{p}event_attendees` WHERE event_id = ?', [(int)$id]);
        Audit::log('event_delete', 'event', (int)$id, []);
        redirect('/admin/events');
    }
}
