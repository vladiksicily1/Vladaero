<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Auth;
use App\Models\Audit;
use App\Core\Request;
use App\Services\PushService;

/**
 * Админ-панель Web Push (v0.8.1): VAPID-ключи, статистика, рассылка.
 */
final class PushController
{
    public function index(): void
    {
        echo \App\Core\View::render('admin/push', [
            'title' => 'Web Push',
            'enabled' => PushService::enabled(),
            'public' => (string)setting('push_vapid_public', ''),
            'subject' => (string)setting('push_vapid_subject', ''),
            'subs' => PushService::subscriptionsCount(),
        ], 'admin');
    }

    /** POST /admin/push/genkeys — сгенерировать пару VAPID (перезаписывает) */
    public function genkeys(): void
    {
        $keys = PushService::generateKeys();
        if ($keys === []) { flash('error', 'openssl не смог создать ключи'); redirect('/admin/push'); }
        $subject = trim(Request::str('subject'));
        PushService::saveKeys($keys);
        if ($subject !== '') {
            \App\Core\Database::i()->run(
                'INSERT INTO `{p}settings` (k, v) VALUES (?, ?) ON DUPLICATE KEY UPDATE v = VALUES(v)',
                ['push_vapid_subject', $subject]);
            \App\Core\Cache::delete('settings.all');
        }
        flash('success', 'VAPID-ключи созданы. Public key: ' . mb_substr($keys['public'], 0, 24) . '…');
        redirect('/admin/push');
    }

    /** POST /admin/push/test — пробная рассылка (мне / всем) */
    public function test(): void
    {
        $scope = Request::str('scope', 'me');
        $stats = PushService::broadcast($scope === 'me' ? (int)Auth::id() : 0);
        Audit::log('push_test', 'push', 0, $stats);
        flash($stats['sent'] > 0 ? 'success' : 'warning',
            "Пуши: доставлено {$stats['sent']}, ошибок {$stats['failed']} (подписок: {$stats['total']}). " .
            ($stats['total'] === 0 ? 'Нет подписок — включите уведомления в профиле.' : ''));
        redirect('/admin/push');
    }
}
