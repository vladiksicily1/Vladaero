<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Logger;
use App\Core\View;

/**
 * Просмотр и очистка журнала ошибок logs/app.log (вопрос 127).
 */
final class LogsController
{
    public function index(): void
    {
        echo View::render('admin/logs', [
            'title' => __('admin.logs') . ' — ' . __('app.name'),
            'lines' => Logger::tail(400),
            'size'  => Logger::size(),
        ], 'admin');
    }

    public function clear(): void
    {
        csrf_verify();
        Logger::clear();
        \App\Models\Audit::log('logs_clear');
        flash('success', 'Журнал очищен');
        redirect('/admin/logs');
    }

    public function download(): void
    {
        $f = VA_ROOT . '/logs/app.log';
        if (!is_file($f)) {
            flash('warning', 'Файл журнала пуст');
            redirect('/admin/logs');
        }
        \App\Models\Audit::log('logs_download');
        header('Content-Type: text/plain; charset=utf-8');
        header('Content-Disposition: attachment; filename="vladaero-app-' . date('Ymd-His') . '.log"');
        header('Content-Length: ' . (string)filesize($f));
        readfile($f);
        exit;
    }
}
