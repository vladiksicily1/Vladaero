<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Database;
use App\Core\Logger;
use App\Core\View;
use App\Models\Audit;
use App\Services\TelegramService;

/**
 * Админ-панель Telegram-бота (в.269): статус Webhook, лог входящих/исходящих,
 * статистика активных пользователей, кнопка сервисного объявления (broadcast).
 */
final class TelegramController
{
    public function index(): void
    {
        @set_time_limit(30);
        $db = Database::i();

        // Статус Webhook через Bot API — не блокируем страницу, если Telegram недоступен
        $wh = [];
        try {
            $webhook = TelegramService::api('getWebhookInfo');
            if (is_array($webhook) && ($webhook['ok'] ?? false) === true) {
                $wh = is_array($webhook['result'] ?? null) ? $webhook['result'] : [];
            }
        } catch (\Throwable $e) {
            Logger::warning('TG getWebhookInfo: ' . $e->getMessage());
            $wh = [];
        }

        // Статистика
        $linked = (int)($db->val("SELECT COUNT(*) FROM `{p}tg_links`") ?? 0);
        $activeToday = (int)($db->val(
            "SELECT COUNT(DISTINCT chat_id) FROM `{p}tg_activity` WHERE created_at >= CURDATE()"
        ) ?? 0);
        $messagesToday = (int)($db->val(
            "SELECT COUNT(*) FROM `{p}tg_activity` WHERE created_at >= CURDATE()"
        ) ?? 0);
        $messagesWeek = (int)($db->val(
            "SELECT COUNT(*) FROM `{p}tg_activity` WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)"
        ) ?? 0);

        // Последние 30 записей активности
        $recent = $db->all(
            "SELECT chat_id, direction, kind, command, length, created_at
             FROM `{p}tg_activity` ORDER BY id DESC LIMIT 30"
        );

        // Топ-10 команд за 7 дней
        $topCmds = $db->all(
            "SELECT command, COUNT(*) c FROM `{p}tg_activity`
             WHERE direction = 'in' AND command != '' AND created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
             GROUP BY command ORDER BY c DESC LIMIT 10"
        );

        echo View::render('admin/telegram', [
            'title'       => 'Telegram-бот — ' . 'VladAero',
            'webhook'     => $wh,
            'linked'      => $linked,
            'active_today'=> $activeToday,
            'msg_today'   => $messagesToday,
            'msg_week'    => $messagesWeek,
            'recent'      => $recent,
            'top_cmds'    => $topCmds,
        ], 'admin');
    }

    /** POST /admin/telegram/broadcast — отправка сервисного объявления всем привязанным */
    public function broadcast(): void
    {
        @set_time_limit(120);
        csrf_verify();
        $text = trim((string)($_POST['text'] ?? ''));
        if ($text === '') {
            flash('warning', 'Введите текст объявления');
            redirect('/admin/telegram');
        }
        if (mb_strlen($text) > 3500) {
            flash('warning', 'Текст слишком длинный (макс. 3500 символов)');
            redirect('/admin/telegram');
        }

        $links = Database::i()->all('SELECT chat_id FROM `{p}tg_links`');
        $sent = 0;
        foreach ($links as $l) {
            $ok = TelegramService::send((int)$l['chat_id'],
                "📢 <b>Сервисное объявление VladAero</b>\n\n" . e($text));
            if ($ok) { $sent++; }
        }
        Audit::log('tg_broadcast', '', null, ['sent' => $sent, 'total' => count($links)]);
        flash('success', "Объявление отправлено: {$sent} / " . count($links) . " адресатов");
        redirect('/admin/telegram');
    }
}