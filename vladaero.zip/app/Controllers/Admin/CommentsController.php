<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Database;
use App\Core\Request;
use App\Core\View;
use App\Models\Audit;

/**
 * Модерация комментариев (в.194, 29): очередь карантина, отклонение, удаление.
 */
final class CommentsController
{
    public function index(): void
    {
        $status = Request::str('status', 'all');
        $where = in_array($status, ['approved', 'pending', 'rejected'], true) ? "WHERE c.status = '$status'" : '';
        $rows = Database::i()->all(
            "SELECT c.*, u.username FROM `{p}comments` c JOIN `{p}users` u ON u.id = c.user_id
             $where ORDER BY c.id DESC LIMIT 150");
        $counts = [
            'all' => (int)Database::i()->val('SELECT COUNT(*) FROM `{p}comments`'),
            'pending' => (int)Database::i()->val('SELECT COUNT(*) FROM `{p}comments` WHERE status = "pending"'),
        ];
        echo View::render('admin/comments', [
            'title' => __('admin.comments'),
            'rows' => $rows,
            'status' => $status,
            'counts' => $counts,
        ]);
    }

    public function setStatus(string $id): void
    {
        csrf_verify();
        $to = Request::str('to');
        if (in_array($to, ['approved', 'pending', 'rejected'], true)) {
            Database::i()->run('UPDATE `{p}comments` SET status = ? WHERE id = ?', [$to, (int)$id]);
            Audit::log('comment_status', 'comment', (int)$id, ['to' => $to]);
        }
        redirect('/admin/comments');
    }

    public function delete(string $id): void
    {
        csrf_verify();
        Database::i()->run('DELETE FROM `{p}comments` WHERE id = ? OR parent_id = ?', [(int)$id, (int)$id]);
        Audit::log('comment_delete', 'comment', (int)$id, []);
        redirect('/admin/comments');
    }
}
