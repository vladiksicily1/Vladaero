<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Auth;
use App\Core\Request;
use App\Core\View;
use App\Models\Audit;
use App\Models\User;

/**
 * Управление пользователями и ролями (вопрос 29).
 */
final class UsersController
{
    private const PAGE_SIZE = 30;

    public function index(): void
    {
        $q = Request::str('q');
        $page = max(1, Request::int('page', 1));
        $total = User::countFiltered($q);
        $pages = max(1, (int)ceil($total / self::PAGE_SIZE));
        $page = min($page, $pages);
        $users = User::search($q, self::PAGE_SIZE, ($page - 1) * self::PAGE_SIZE);

        echo View::render('admin/users', [
            'title' => __('admin.users') . ' — ' . __('app.name'),
            'users' => $users,
            'q'     => $q,
            'page'  => $page,
            'pages' => $pages,
            'total' => $total,
        ], 'admin');
    }

    public function setRole(string $id): void
    {
        csrf_verify();
        $this->guardEditable((int)$id);
        $role = Request::str('role');
        if (!in_array($role, Auth::ROLES, true)) {
            flash('danger', 'Неизвестная роль');
            redirect('/admin/users');
        }
        $target = User::find((int)$id);
        if ($target === null) {
            flash('danger', 'Пользователь не найден');
            redirect('/admin/users');
        }
        if ($target['role'] === 'admin' && $role !== 'admin') {
            flash('warning', 'Нельзя снять роль администратора через этот интерфейс');
            redirect('/admin/users');
        }
        \App\Core\Database::i()->update('users', ['role' => $role], ['id' => (int)$id]);
        Audit::log('user_role', 'user', (int)$id, ['new' => $role, 'old' => $target['role']]);
        flash('success', 'Роль обновлена: ' . e($target['username']) . ' → ' . __('role.' . $role));
        redirect('/admin/users');
    }

    public function ban(string $id): void
    {
        csrf_verify();
        $this->guardEditable((int)$id);
        $reason = Request::str('reason');
        $target = User::find((int)$id);
        if ($target === null) {
            flash('danger', 'Пользователь не найден');
            redirect('/admin/users');
        }
        \App\Core\Database::i()->update('users', ['status' => 'banned'], ['id' => (int)$id]);
        Audit::log('user_ban', 'user', (int)$id, ['reason' => $reason]);
        flash('success', 'Пользователь ' . e($target['username']) . ' заблокирован');
        redirect('/admin/users');
    }

    public function unban(string $id): void
    {
        csrf_verify();
        $this->guardEditable((int)$id);
        \App\Core\Database::i()->update('users', ['status' => 'active'], ['id' => (int)$id]);
        Audit::log('user_unban', 'user', (int)$id);
        flash('success', 'Блокировка снята');
        redirect('/admin/users');
    }

    /** Нельзя редактировать самого себя и администраторов */
    private function guardEditable(int $id): void
    {
        $target = User::find($id);
        if ($target === null || $target['role'] === 'admin' || $id === Auth::id()) {
            flash('warning', 'Этот профиль нельзя изменять');
            redirect('/admin/users');
        }
    }
}
