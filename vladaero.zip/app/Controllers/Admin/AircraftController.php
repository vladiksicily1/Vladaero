<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Request;
use App\Core\View;
use App\Models\Aircraft;
use App\Models\Audit;

/**
 * Управление каталогом авиатехники (вопросы 6–9, 148: ручное наполнение).
 */
final class AircraftController
{
    private const PAGE_SIZE = 20;

    public function index(): void
    {
        $q = Request::str('q');
        $page = max(1, Request::int('page', 1));
        $res = Aircraft::search(['q' => $q], $page, self::PAGE_SIZE);
        $pages = max(1, (int)ceil($res['total'] / self::PAGE_SIZE));

        echo View::render('admin/aircraft/index', [
            'title' => __('admin.aircraft') . ' — ' . __('app.name'),
            'rows'  => $res['rows'],
            'q'     => $q,
            'page'  => min($page, $pages),
            'pages' => $pages,
            'total' => $res['total'],
        ], 'admin');
    }

    public function create(): void
    {
        echo View::render('admin/aircraft/form', [
            'title' => __('ac.add') . ' — ' . __('app.name'),
            'ac'    => null,
            'specs' => [],
            'groups'=> Aircraft::SPEC_GROUPS,
            'blocksJson' => '[]',
            'blockEntity' => 'aircraft',
            'blockEntityId' => 0,
        ], 'admin');
    }

    public function store(): void
    {
        csrf_verify();
        $data = $this->collect();
        $errors = $this->validate($data);
        if ($errors !== []) {
            foreach ($errors as $e) {
                flash('danger', $e);
            }
            $_SESSION['_old_ac'] = $data;
            redirect('/admin/aircraft/new');
        }
        $data['slug'] = Aircraft::uniqueSlug(slugify($data['slug'] !== '' ? $data['slug'] : $data['name_ru']));
        $id = Aircraft::create($data);
        $this->saveBlocks($id);
        Audit::log('aircraft_create', 'aircraft', $id, ['name' => $data['name_ru']]);
        flash('success', 'Карточка «' . e($data['name_ru']) . '» создана');
        redirect('/admin/aircraft/' . $id . '/edit');
    }

    public function edit(string $id): void
    {
        $ac = Aircraft::find((int)$id);
        if ($ac === null) {
            flash('danger', 'Карточка не найдена');
            redirect('/admin/aircraft');
        }
        echo View::render('admin/aircraft/form', [
            'title' => __('ac.edit') . ': ' . $ac['name_ru'],
            'ac'    => $ac,
            'specs' => is_array($ac['specs']) ? $ac['specs'] : [],
            'groups'=> Aircraft::SPEC_GROUPS,
            'blocksJson' => json_encode(\App\Models\Blocks::get('aircraft', (int)$id) ?? [], JSON_UNESCAPED_UNICODE),
            'blockEntity' => 'aircraft',
            'blockEntityId' => (int)$id,
        ], 'admin');
    }

    public function update(string $id): void
    {
        csrf_verify();
        $ac = Aircraft::find((int)$id);
        if ($ac === null) {
            flash('danger', 'Карточка не найдена');
            redirect('/admin/aircraft');
        }
        $data = $this->collect();
        $errors = $this->validate($data);
        if ($errors !== []) {
            foreach ($errors as $e) {
                flash('danger', $e);
            }
            redirect('/admin/aircraft/' . (int)$id . '/edit');
        }
        $slug = slugify($data['slug'] !== '' ? $data['slug'] : $data['name_ru']);
        $data['slug'] = Aircraft::uniqueSlug($slug, (int)$id);
        Aircraft::updateById((int)$id, $data);
        $this->saveBlocks((int)$id);
        Audit::log('aircraft_update', 'aircraft', (int)$id, ['name' => $data['name_ru']]);
        flash('success', 'Карточка «' . e($data['name_ru']) . '» сохранена');
        redirect('/admin/aircraft/' . (int)$id . '/edit');
    }

    public function delete(string $id): void
    {
        csrf_verify();
        $ac = Aircraft::find((int)$id);
        if ($ac === null) {
            flash('danger', 'Карточка не найдена');
            redirect('/admin/aircraft');
        }
        Aircraft::deleteById((int)$id);
        Audit::log('aircraft_delete', 'aircraft', (int)$id, ['name' => $ac['name_ru']]);
        flash('success', 'Карточка «' . e($ac['name_ru']) . '» удалена');
        redirect('/admin/aircraft');
    }

    /** Блоки контента (в.108: блоки везде) */
    private function saveBlocks(int $id): void
    {
        $json = Request::str('blocks_json');
        if ($json !== '') {
            \App\Models\Blocks::set('aircraft', $id, $json, \App\Core\Auth::id());
        }
    }

    /** Собирает и нормализует данные формы, включая JSON specs */
    private function collect(): array
    {
        $firstFlight = Request::str('first_flight');
        $specs = [];
        foreach ($this->specFields() as $field => $unit) {
            $v = Request::str($field);
            if ($v !== '') {
                $specs[$field] = is_numeric(str_replace(',', '.', $v))
                    ? (float)str_replace(',', '.', $v)
                    : $v;
            }
        }
        return [
            'name_ru'        => Request::str('name_ru'),
            'name_en'        => Request::str('name_en'),
            'slug'           => Request::str('slug'),
            'icao_code'      => strtoupper(Request::str('icao_code')),
            'iata_code'      => strtoupper(Request::str('iata_code')),
            'category'       => in_array(Request::str('category'), Aircraft::CATEGORIES, true) ? Request::str('category') : 'civil',
            'manufacturer'   => Request::str('manufacturer'),
            'country'        => Request::str('country'),
            'first_flight'   => $firstFlight !== '' && strtotime($firstFlight) !== false ? date('Y-m-d', strtotime($firstFlight)) : null,
            'status'         => in_array(Request::str('status'), Aircraft::STATUSES, true) ? Request::str('status') : 'active',
            'specs'          => $specs !== [] ? json_encode($specs, JSON_UNESCAPED_UNICODE) : null,
            'description_ru' => Request::str('description_ru') !== '' ? Request::str('description_ru') : null,
        ];
    }

    /** @return array<string,string> поле → единица */
    private function specFields(): array
    {
        $out = [];
        foreach (Aircraft::SPEC_GROUPS as [, $fields]) {
            $out += $fields;
        }
        return $out;
    }

    /** @return list<string> */
    private function validate(array $data): array
    {
        $e = [];
        if ($data['name_ru'] === '') {
            $e[] = 'Укажите название (рус.)';
        }
        if ($data['icao_code'] !== '' && !preg_match('/^[A-Z0-9]{2,8}$/', $data['icao_code'])) {
            $e[] = 'ICAO-код: 2–8 латинских символов/цифр';
        }
        if ($data['iata_code'] !== '' && !preg_match('/^[A-Z0-9]{2,4}$/', $data['iata_code'])) {
            $e[] = 'IATA-код: 2–4 латинских символа/цифры';
        }
        return $e;
    }
}
