<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Database;
use App\Models\Audit;
use App\Core\Request;

/**
 * Модерация споттинг-точек (v0.8.1): очередь pending → publish/reject.
 */
final class SpotsController
{
    public function index(): void
    {
        $tab = Request::str('tab', 'pending');
        if (!in_array($tab, ['pending', 'published', 'rejected'], true)) { $tab = 'pending'; }
        $points = Database::i()->all(
            'SELECT s.*, u.username AS author FROM `{p}spot_points` s
             LEFT JOIN `{p}users` u ON u.id = s.created_by
             WHERE s.status = ? ORDER BY s.created_at DESC LIMIT 200', [$tab]);
        echo \App\Core\View::render('admin/spots', [
            'title' => 'Споттинг-точки',
            'tab' => $tab,
            'points' => $points,
            'counts' => [
                'pending' => (int)Database::i()->val('SELECT COUNT(*) FROM `{p}spot_points` WHERE status = "pending"'),
                'published' => (int)Database::i()->val('SELECT COUNT(*) FROM `{p}spot_points` WHERE status = "published"'),
                'rejected' => (int)Database::i()->val('SELECT COUNT(*) FROM `{p}spot_points` WHERE status = "rejected"'),
            ],
        ]);
    }

    public function decide(string $id): void
    {
        $id = (int)$id;
        $status = Request::str('status');
        if (!in_array($status, ['published', 'rejected', 'pending'], true)) {
            json_response(['ok' => false, 'error' => 'bad status'], 400);
        }
        Database::i()->update('spot_points', ['status' => $status], ['id' => $id]);
        Audit::log('spot_moderate', 'spot_points', $id, ['status' => $status]);
        json_response(['ok' => true, 'status' => $status]);
    }
}
