<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Database;
use App\Core\Logger;
use App\Core\Request;
use App\Core\View;
use App\Models\Audit;
use App\Services\BackupService;

/**
 * Системные операции: бэкапы, полная переустановка, диагностика
 * (вопросы 126, 149: бэкап одной кнопкой, удаление только таблиц VladAero).
 */
final class SystemController
{
    public function index(): void
    {
        $db = Database::i();
        $prefix = self::prefix();
        echo View::render('admin/system', [
            'title' => __('admin.system') . ' — ' . __('app.name'),
            'info'  => [
                'php'        => PHP_VERSION,
                'sapi'       => PHP_SAPI,
                'os'         => PHP_OS_FAMILY,
                'mysql'      => (string)$db->pdo()->getAttribute(\PDO::ATTR_SERVER_VERSION),
                'db_size_mb' => $db->sizeMb(),
                'tables'     => count($db->tablesLike($prefix)),
                'prefix'     => $prefix,
                'cache_size' => \App\Core\Cache::size(),
                'log_size'   => Logger::size(),
                'version'    => VA_VERSION,
            ],
        ], 'admin');
    }

    /** Скачивание SQL-дампа всех таблиц проекта (вопрос 126) */
    public function backup(): void
    {
        Audit::log('backup_download');
        BackupService::stream();
    }

    /**
     * Удаление ТОЛЬКО таблиц VladAero (по префиксу) с полным сбросом установки
     * и возвратом к install.php (вопрос 149).
     */
    public function dropTables(): void
    {
        csrf_verify();
        if (mb_strtoupper(Request::str('confirm')) !== 'УДАЛИТЬ') {
            flash('danger', 'Не подтверждено: введите слово УДАЛИТЬ');
            redirect('/admin/system');
        }

        $db = Database::i();
        $prefix = self::prefix();
        $tables = $db->tablesLike($prefix);

        foreach ($tables as $t) {
            $db->pdo()->exec("DROP TABLE IF EXISTS `$t`");
        }

        // Пишем в файл (БД уже удалена) и сбрасываем конфигурацию установки
        Logger::log('WARNING', 'SYSTEM WIPE: удалено таблиц: ' . count($tables) . ', IP ' . Request::ip());
        @unlink(VA_APP . '/config/app.php');
        @unlink(VA_APP . '/config/database.php');
        @unlink(VA_APP . '/config/installed.lock');

        $installer = VA_ROOT . '/install.php';
        if (is_file($installer)) {
            header('Location: ' . url('/install.php'));
        } else {
            echo 'Таблицы VladAero удалены. Загрузите install.php для новой установки.';
        }
        exit;
    }

    private static function prefix(): string
    {
        $c = require VA_APP . '/config/database.php';
        return (string)($c['prefix'] ?? '');
    }
}
