<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Database;
use App\Core\Request;
use App\Core\View;
use App\Models\Aircraft;
use App\Models\Article;
use App\Services\AiEngine;
use App\Services\AiService;
use App\Services\AiToolkit;

/**
 * Супер-Агент админа (в.161–162, 271–272, 277):
 * чат с 50 инструментами, System Doctor, пакетная генерация черновиков,
 * дашборд расхода токенов (в.177).
 */
final class AgentController
{
    public function index(): void
    {
        $byDay = Database::i()->all(
            'SELECT DATE(created_at) d, COUNT(*) c, COALESCE(SUM(prompt_tokens),0) p, COALESCE(SUM(completion_tokens),0) cm
             FROM `{p}ai_requests` WHERE created_at > DATE_SUB(NOW(), INTERVAL 14 DAY)
             GROUP BY DATE(created_at) ORDER BY d');
        $lastChats = Database::i()->all(
            'SELECT r.id, r.created_at, r.model, r.tool_calls, r.prompt_tokens, r.completion_tokens,
                    u.username, LEFT(m.content, 120) AS snippet
             FROM `{p}ai_requests` r
             LEFT JOIN `{p}users` u ON u.id = r.user_id
             LEFT JOIN `{p}ai_chat_messages` m ON m.chat_id = (
                 SELECT c.id FROM `{p}ai_chats` c WHERE c.user_id = r.user_id ORDER BY c.updated_at DESC LIMIT 1
             ) AND m.role = "user"
             ORDER BY r.id DESC LIMIT 12');

        echo View::render('admin/agent', [
            'title'   => __('admin.ai_agent'),
            'state'   => AiEngine::state(true),
            'byDay'   => $byDay,
            'lastChats' => $lastChats,
            'totals'  => [
                'requests' => (int)(Database::i()->val('SELECT COUNT(*) FROM `{p}ai_requests`') ?? 0),
                'tokens'   => (int)(Database::i()->val('SELECT COALESCE(SUM(prompt_tokens+completion_tokens),0) FROM `{p}ai_requests`') ?? 0),
                'tools'    => (int)(Database::i()->val('SELECT COALESCE(SUM(tool_calls),0) FROM `{p}ai_requests`') ?? 0),
            ],
        ], 'admin');
    }

    /** POST /admin/agent/chat → SSE (контекст agent, инструменты админа) */
    public function chat(): void
    {
        $body = Request::rawJson();
        $messages = is_array($body['messages'] ?? null) ? $body['messages'] : [];

        @set_time_limit(150);
        while (ob_get_level() > 0) { @ob_end_clean(); }
        header('Content-Type: text/event-stream; charset=utf-8');
        header('X-Accel-Buffering: no');
        $emit = static function (string $event, mixed $data): void {
            echo 'event: ' . $event . "\n" . 'data: ' . json_encode($data, JSON_UNESCAPED_UNICODE) . "\n\n";
            @flush();
        };
        if (!AiService::enabled()) {
            $emit('error', ['message' => __('ai.not_configured')]);
            exit;
        }
        AiEngine::converse($messages, 'academic', $emit, true, 'agent');
        exit;
    }

    /** POST /admin/agent/tool {tool,args} — прямой вызов локального инструмента */
    public function tool(): void
    {
        $body = Request::rawJson();
        $tool = (string)($body['tool'] ?? '');
        $catalog = AiToolkit::tools(true);
        if (!isset($catalog[$tool])) {
            json_response(['ok' => false, 'error' => 'unknown tool'], 400);
        }
        json_response(['ok' => true] + AiToolkit::execute($tool, is_array($body['args'] ?? null) ? $body['args'] : [], true));
    }

    /**
     * Пакетная генерация черновиков (в.272): список моделей → LLM → JSON → черновики карточек.
     * POST /admin/agent/batch {items:[], kind: aircraft|article}
     */
    public function batch(): void
    {
        @set_time_limit(240); // пакетная генерация может делать несколько LLM-вызовов
        $items = array_filter(array_map('trim', (array)(Request::rawJson()['items'] ?? [])));
        $items = array_slice($items, 0, 8);
        $kind = Request::rawJson()['kind'] ?? 'aircraft';
        if ($items === []) {
            json_response(['ok' => false, 'error' => 'empty'], 400);
        }
        $out = [];
        foreach ($items as $name) {
            $prompt = $kind === 'article'
                ? 'Напиши структуру статьи для авиапортала VladAero на тему «' . $name . '». Верни ТОЛЬКО JSON: {"title": "...", "excerpt": "...", "blocks": [{"t":"text","v":"lead","d":{"text":"вводный абзац"}}, {"t":"heading","v":"h2","d":{"text":"..."}} , {"t":"text","v":"","d":{"text":"2-3 абзаца в одном блоке"}}]} — 6-9 блоков, факты реальные.'
                : 'Собери данные о «' . $name . '». Верни ТОЛЬКО JSON: {"name_ru":"…","icao_code":"…","category":"civil|military|ga|historic|uav","manufacturer":"…","country":"…","first_flight":"YYYY-MM-DD","specs":{"length_m":0,"wingspan_m":0,"height_m":0,"mtow_kg":0,"engines":"…","cruise_speed_kmh":0,"max_speed_kmh":0,"range_km":0,"ceiling_m":0,"pax":0,"crew":0},"description_ru":"краткое описание 2-3 предложения"} — только проверенные ТТХ.';
            $res = AiService::chat([
                ['role' => 'system', 'content' => 'Ты — редактор авиационной энциклопедии. Возвращаешь только валидный JSON без markdown-обёрток.'],
                ['role' => 'user', 'content' => $prompt],
            ], 0.3, 1500);
            $json = null;
            if ($res['ok'] && preg_match('~\{.*\}~s', $res['content'], $m)) {
                $json = json_decode($m[0], true);
            }
            $out[] = ['item' => $name, 'ok' => is_array($json), 'data' => $json];
        }
        json_response(['ok' => true, 'kind' => $kind, 'drafts' => $out]);
    }

    /** POST /admin/agent/apply — применить черновик (создание в БД) */
    public function apply(): void
    {
        $body = Request::rawJson();
        $kind = (string)($body['kind'] ?? 'aircraft');
        $d = is_array($body['data'] ?? null) ? $body['data'] : null;
        if ($d === null) { json_response(['ok' => false, 'error' => 'no data'], 400); }

        if ($kind === 'article') {
            $title = mb_substr(trim((string)($d['title'] ?? 'Черновик ИИ')), 0, 200);
            $slug = Article::uniqueSlug(slugify($title));
            $blocks = is_array($d['blocks'] ?? null) ? $d['blocks'] : [];
            $id = Article::create([
                'slug' => $slug,
                'title_ru' => $title,
                'excerpt_ru' => mb_substr(trim((string)($d['excerpt'] ?? '')), 0, 500),
                'body_json' => json_encode($blocks, JSON_UNESCAPED_UNICODE),
                'status' => 'draft', // безопасно: публично не видно
                'author_id' => \App\Core\Auth::id(),
            ]);
            json_response(['ok' => true, 'id' => $id, 'url' => url('/admin/articles/' . $id . '/edit')]);
        }

        $specs = is_array($d['specs'] ?? null) ? $d['specs'] : [];
        $name = mb_substr(trim((string)($d['name_ru'] ?? 'Черновик')), 0, 190);
        $id = Aircraft::create([
            'slug' => Aircraft::uniqueSlug(slugify($name)),
            'name_ru' => $name,
            'icao_code' => mb_substr(trim((string)($d['icao_code'] ?? '')), 0, 10),
            'category' => in_array($d['category'] ?? '', Aircraft::CATEGORIES, true) ? $d['category'] : 'civil',
            'manufacturer' => mb_substr(trim((string)($d['manufacturer'] ?? '')), 0, 100),
            'country' => mb_substr(trim((string)($d['country'] ?? '')), 0, 2),
            'first_flight' => preg_match('~^\d{4}-\d{2}-\d{2}$~', (string)($d['first_flight'] ?? '')) ? $d['first_flight'] : null,
            'status' => 'stored', // черновик: виден в админке, в каталоге помечен
            'specs' => json_encode($specs, JSON_UNESCAPED_UNICODE),
            'description_ru' => mb_substr(trim((string)($d['description_ru'] ?? '')), 0, 3000),
        ]);
        json_response(['ok' => true, 'id' => $id, 'url' => url('/admin/aircraft/' . $id . '/edit')]);
    }
}
