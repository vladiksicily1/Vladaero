<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Request;
use App\Core\View;
use App\Models\Audit;
use App\Models\Setting;
use App\Services\AiService;

/**
 * Настройки портала (вопросы 152, 221–222, 151: любой Base URL + Fetch v1/models).
 */
final class SettingsController
{
    private const TABS = ['general', 'integrations', 'ai', 'limits'];

    public function show(string $tab = 'general'): void
    {
        if ($tab === 'telegram') {
            $tab = 'integrations';
        }
        if (!in_array($tab, self::TABS, true)) {
            $tab = 'general';
        }
        echo View::render('admin/settings', [
            'title' => __('admin.settings') . ' — ' . __('app.name'),
            'tab'   => $tab,
        ], 'admin');
    }

    public function save(string $tab = 'general'): void
    {
        csrf_verify();
        if ($tab === 'telegram') {
            $tab = 'integrations';
        }
        if (!in_array($tab, self::TABS, true)) {
            $tab = 'general';
        }

        switch ($tab) {
            case 'general':
                $this->saveGeneral();
                break;
            case 'integrations':
                $tgSecret = Request::str('tg_webhook_secret');
                if ($tgSecret === '') {
                    $tgSecret = (string)setting('tg_webhook_secret', '');
                    if ($tgSecret === '') {
                        $tgSecret = bin2hex(random_bytes(16));
                    }
                }
                $tgApiBase = trim(Request::str('tg_api_base', 'https://telegram.v7755837.deno.net'));
                if ($tgApiBase === '') {
                    $tgApiBase = 'https://telegram.v7755837.deno.net';
                }
                Setting::setMany([
                    'telegram_bot_token'   => Request::str('telegram_bot_token'),
                    'telegram_bot_username'=> ltrim(Request::str('telegram_bot_username', 'vladaero_bot'), '@'),
                    'tg_api_base'          => rtrim($tgApiBase, '/'),
                    'tg_webhook_secret'    => $tgSecret,
                    'tg_api_proxy'         => trim(Request::str('tg_api_proxy')),
                    'tg_stt_api_key'       => trim(Request::str('tg_stt_api_key')),
                    'turnstile_site_key'   => Request::str('turnstile_site_key'),
                    'turnstile_secret_key' => Request::str('turnstile_secret_key'),
                    'skylink_api_key'      => trim(Request::str('skylink_api_key')),
                    'skylink_api_base'     => rtrim(Request::str('skylink_api_base', 'https://skylinkapi.com/v2'), '/'),
                    'firecrawl_api_key'    => trim(Request::str('firecrawl_api_key')),
                    'firecrawl_api_base'   => rtrim(Request::str('firecrawl_api_base', 'https://api.firecrawl.dev/v1'), '/'),
                    'webcam_custom'        => trim(Request::str('webcam_custom')),
                ]);
                Audit::log('settings_save', 'settings', null, ['tab' => $tab]);
                break;
            case 'ai':
                $pairs = [
                    'ai_base_url'     => rtrim(Request::str('ai_base_url'), '/'),
                    'ai_model'        => Request::str('ai_model'),
                    'ai_temperature'  => (string)min(2.0, max(0.0, (float)Request::str('ai_temperature', '0.7'))),
                    'ai_system_prompt'=> Request::str('ai_system_prompt'),
                ];
                // Пустой ключ = не менять (вопрос 152)
                $newKey = Request::str('ai_api_key');
                if ($newKey !== '') {
                    $pairs['ai_api_key'] = $newKey;
                }
                Setting::setMany($pairs);
                Audit::log('settings_save', 'settings', null, ['tab' => $tab]);
                break;
            case 'limits':
                Setting::setMany([
                    'ai_limit_guest'       => (string)max(0, Request::int('ai_limit_guest', 15)),
                    'ai_limit_user'        => (string)max(0, Request::int('ai_limit_user', 100)),
                    'registration_enabled' => Request::str('registration_enabled') === '1' ? '1' : '0',
                    'maintenance_text'     => Request::str('maintenance_text'),
                ]);
                Audit::log('settings_save', 'settings', null, ['tab' => $tab]);
                break;
        }

        flash('success', __('admin.saved'));
        redirect('/admin/settings/' . $tab);
    }

    /** POST /admin/telegram/setwebhook — регистрация вебхука у Bot API (в.117) */
    public function setWebhook(): void
    {
        csrf_verify();
        $token = (string)setting('telegram_bot_token', '');
        if ($token === '') {
            flash('warning', __('tg.no_token'));
            redirect('/admin/settings/integrations');
        }
        $secret = (string)setting('tg_webhook_secret', '');
        $url = rtrim(url('/'), '/') . '/tg/webhook?key=' . $secret;
        $res = \App\Services\TelegramService::api('setWebhook', [
            'url' => $url,
            'secret_token' => $secret,
            'allowed_updates' => json_encode(['message', 'edited_message', 'callback_query']),
            'drop_pending_updates' => 'true',
        ]);
        if (($res['ok'] ?? false) === true) {
            // сразу регистрируем меню команд и кнопку-портал (Telegram Web App)
            \App\Services\TelegramService::registerCommands();
        }
        Audit::log('tg_setwebhook', 'settings', null, [
            'ok' => (bool)($res['ok'] ?? false),
            'url' => $url,
            'error' => (string)($res['description'] ?? ''),
            'error_code' => (int)($res['error_code'] ?? 0),
        ]);
        if (($res['ok'] ?? false)) {
            flash('success', __('tg.webhook_ok'));
        } else {
            $err = (string)($res['description'] ?? '');
            flash('warning', __('tg.webhook_fail')
                . (($err !== '') ? ': ' . $err : '')
                . "\nURL: " . $url
                . (str_starts_with($url, 'http://') ? "\n" . __('tg.webhook_https_hint') : ''));
        }
        redirect('/admin/settings/integrations');
    }

    private function saveGeneral(): void
    {
        Setting::setMany([
            'site_name'    => Request::str('site_name', 'VladAero'),
            'tagline'      => Request::str('tagline'),
            'hero_title'   => Request::str('hero_title'),
            'hero_sub'     => Request::str('hero_sub'),
        ]);
        $tz = Request::str('timezone', 'Europe/Moscow');
        if (in_array($tz, timezone_identifiers_list(), true)) {
            Setting::set('timezone', $tz);
        }

        // Загрузка медиа: логотип / фавикон / hero-обложка (вопросы 213, 226)
        foreach (['logo', 'favicon', 'hero_image'] as $field) {
            $path = $this->handleUpload($field);
            if ($path !== null) {
                Setting::set($field, $path);
            }
        }
        Audit::log('settings_save', 'settings', null, ['tab' => 'general']);
    }

    /** Безопасная загрузка изображения в uploads/brand/. Возвращает относительный путь или null. */
    private function handleUpload(string $field): ?string
    {
        $file = Request::file($field);
        if ($file === null || ($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) {
            return null;
        }
        if (($file['size'] ?? 0) > 8 * 1024 * 1024) {
            flash('warning', "Файл $field: превышен лимит 8 МБ");
            return null;
        }
        $allowed = ['image/png' => 'png', 'image/jpeg' => 'jpg', 'image/webp' => 'webp', 'image/svg+xml' => 'svg', 'image/x-icon' => 'ico'];
        $fi = new \finfo(FILEINFO_MIME_TYPE);
        $mime = (string)$fi->file($file['tmp_name']);
        if (!isset($allowed[$mime])) {
            flash('warning', "Файл $field: допустимы PNG, JPG, WebP, SVG, ICO");
            return null;
        }
        $dir = VA_ROOT . '/uploads/brand';
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }
        $name = $field . '-' . date('Ymd-His') . '-' . substr(bin2hex(random_bytes(3)), 0, 6) . '.' . $allowed[$mime];
        if (!move_uploaded_file($file['tmp_name'], $dir . '/' . $name)) {
            flash('warning', "Файл $field: не удалось сохранить");
            return null;
        }
        return 'uploads/brand/' . $name;
    }

    /**
     * AJAX: получение списка моделей провайдера (вопрос 151).
     * POST /admin/api/ai-models  { base_url, api_key? }
     */
    public function apiModels(): void
    {
        csrf_verify();
        $in = Request::rawJson();
        if (Request::method() === 'POST' && $in === []) {
            $in = $_POST;
        }
        $baseUrl = trim((string)($in['base_url'] ?? ''));
        $apiKey  = trim((string)($in['api_key'] ?? ''));
        if ($baseUrl === '') {
            json_response(['ok' => false, 'error' => 'Укажите Base URL провайдера']);
        }
        if ($apiKey === '') {
            $apiKey = (string)setting('ai_api_key', '');
        }
        if ($apiKey === '') {
            json_response(['ok' => false, 'error' => 'API-ключ не задан (поле ключа или настройки ИИ)']);
        }

        try {
            $models = AiService::listModels($baseUrl, $apiKey);
            json_response(['ok' => true, 'models' => $models]);
        } catch (\Throwable $e) {
            json_response(['ok' => false, 'error' => $e->getMessage()], 200);
        }
    }
}
