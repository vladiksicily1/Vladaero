<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Auth;
use App\Core\Request;
use App\Core\View;
use App\Models\Airport;
use App\Models\Audit;
use App\Models\Blocks;

/**
 * Аэропорты (в.10, 33): каталог + блочный контент.
 */
final class AirportsController
{
    public function index(): void
    {
        $q = Request::str('q');
        $page = max(1, Request::int('page', 1));
        $res = Airport::search($q, 30, ($page - 1) * 30);
        echo View::render('admin/airports/index', [
            'title' => __('admin.airports') . ' — ' . __('app.name'),
            'rows'  => $res['rows'],
            'total' => $res['total'],
            'q'     => $q,
            'page'  => $page,
            'pages' => max(1, (int)ceil($res['total'] / 30)),
        ], 'admin');
    }

    public function create(): void
    {
        echo View::render('admin/airports/form', [
            'title' => __('ap.add') . ' — ' . __('app.name'),
            'ap'    => null,
            'blocksJson' => '[]',
            'blockEntity' => 'airport',
            'blockEntityId' => 0,
        ], 'admin');
    }

    public function store(): void
    {
        csrf_verify();
        $data = $this->collect();
        if ($data['icao'] === '' || $data['name_ru'] === '') {
            flash('danger', 'Укажите ICAO и название');
            redirect('/admin/airports/new');
        }
        try {
            $data['icao'] = Airport::uniqueIcao($data['icao']);
        } catch (\Throwable $e) {
            flash('danger', $e->getMessage());
            redirect('/admin/airports/new');
        }
        $id = Airport::create($data);
        $this->saveBlocks($id);
        Audit::log('airport_create', 'airport', $id, ['icao' => $data['icao']]);
        flash('success', 'Аэропорт ' . e($data['icao']) . ' добавлен');
        redirect('/admin/airports/' . $id . '/edit');
    }

    public function edit(string $id): void
    {
        $ap = Airport::find((int)$id);
        if ($ap === null) {
            flash('danger', 'Аэропорт не найден');
            redirect('/admin/airports');
        }
        $blocks = Blocks::get('airport', (int)$id) ?? [];
        echo View::render('admin/airports/form', [
            'title' => __('ap.edit') . ': ' . $ap['name_ru'],
            'ap'    => $ap,
            'blocksJson' => json_encode($blocks, JSON_UNESCAPED_UNICODE),
            'blockEntity' => 'airport',
            'blockEntityId' => (int)$id,
        ], 'admin');
    }

    public function update(string $id): void
    {
        csrf_verify();
        $ap = Airport::find((int)$id);
        if ($ap === null) {
            flash('danger', 'Аэропорт не найден');
            redirect('/admin/airports');
        }
        $data = $this->collect();
        if ($data['icao'] === '' || $data['name_ru'] === '') {
            flash('danger', 'Укажите ICAO и название');
            redirect('/admin/airports/' . (int)$id . '/edit');
        }
        try {
            $data['icao'] = Airport::uniqueIcao($data['icao'], (int)$id);
        } catch (\Throwable $e) {
            flash('danger', $e->getMessage());
            redirect('/admin/airports/' . (int)$id . '/edit');
        }
        Airport::updateById((int)$id, $data);
        $this->saveBlocks((int)$id);
        Audit::log('airport_update', 'airport', (int)$id, ['icao' => $data['icao']]);
        flash('success', 'Аэропорт сохранён');
        redirect('/admin/airports/' . (int)$id . '/edit');
    }

    public function delete(string $id): void
    {
        csrf_verify();
        $ap = Airport::find((int)$id);
        if ($ap !== null) {
            Airport::deleteById((int)$id);
            Audit::log('airport_delete', 'airport', (int)$id, ['icao' => $ap['icao']]);
            flash('success', 'Аэропорт удалён');
        }
        redirect('/admin/airports');
    }

    private function collect(): array
    {
        $flt = static fn(string $v, float $min, float $max): ?float => $v === '' ? null : max($min, min($max, (float)str_replace(',', '.', $v)));
        return [
            'icao'          => strtoupper(Request::str('icao')),
            'iata'          => strtoupper(Request::str('iata')) ?: null,
            'name_ru'       => Request::str('name_ru'),
            'name_en'       => Request::str('name_en') ?: null,
            'city_ru'       => Request::str('city_ru') ?: null,
            'city_en'       => Request::str('city_en') ?: null,
            'country_code'  => strtoupper(substr(Request::str('country_code'), 0, 2)) ?: null,
            'lat'           => $flt(Request::str('lat'), -90, 90),
            'lng'           => $flt(Request::str('lng'), -180, 180),
            'elevation_ft'  => Request::str('elevation_ft') !== '' ? (int)Request::str('elevation_ft') : null,
            'timezone'      => Request::str('timezone') ?: null,
            'website'       => Request::str('website') ?: null,
        ];
    }

    private function saveBlocks(int $id): void
    {
        $json = Request::str('blocks_json');
        if ($json !== '') {
            Blocks::set('airport', $id, $json, Auth::id());
        }
    }
}
