<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Request;
use App\Services\AiEngine;

/**
 * Публичный ИИ-виджет (в.159–160, 273): состояние и SSE-чат.
 */
final class AiController
{
    public function state(): void
    {
        json_response(AiEngine::state(false));
    }

    /** POST /api/ai/chat {messages, tone, chat_id} → SSE-поток */
    public function chat(): void
    {
        $body = Request::rawJson();
        $messages = is_array($body['messages'] ?? null) ? $body['messages'] : [];
        $tone = (string)($body['tone'] ?? 'instructor');
        $chatId = (int)($body['chat_id'] ?? 0);
        $lastUser = '';
        foreach (array_reverse($messages) as $m) {
            if (($m['role'] ?? '') === 'user') { $lastUser = (string)($m['content'] ?? ''); break; }
        }

        @set_time_limit(150);
        while (ob_get_level() > 0) { @ob_end_clean(); }
        header('Content-Type: text/event-stream; charset=utf-8');
        header('Cache-Control: no-cache');
        header('X-Accel-Buffering: no');

        $emit = static function (string $event, mixed $data): void {
            echo 'event: ' . $event . "\n";
            echo 'data: ' . json_encode($data, JSON_UNESCAPED_UNICODE) . "\n\n";
            @flush();
        };

        if (!\App\Services\AiService::enabled()) {
            $emit('error', ['message' => __('ai.not_configured')]);
            exit;
        }
        if (AiEngine::leftFor() <= 0 && !\App\Core\Auth::isAdmin()) {
            $emit('error', ['message' => __('ai.limit')]);
            exit;
        }

        $final = AiEngine::converse($messages, $tone, $emit, false, 'widget');
        $newChat = AiEngine::persistChat($chatId, $lastUser, $final);
        if ($newChat !== 0 && $newChat !== $chatId) {
            $emit('chat', ['chat_id' => $newChat]);
        }
        exit;
    }
}
