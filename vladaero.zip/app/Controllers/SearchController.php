<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Database;
use App\Core\Request;

/**
 * API глобального поиска Ctrl+K (вопросы 96–98):
 * самолёты + аэропорты + статьи, кириллица и латиница, коды ICAO/IATA.
 */
final class SearchController
{
    private const LIMIT_PER_GROUP = 5;

    public function api(): void
    {
        $q = mb_strtolower(trim(Request::str('q')));
        if (mb_strlen($q) < 2) {
            json_response(['ok' => true, 'results' => []]);
        }
        $like = '%' . str_replace(' ', '%', $q) . '%';
        $out = [];
        $db = Database::i();

        // Самолёты (в.98: «Боинг»/«Boeing», ICAO/IATA)
        $rows = $db->all(
            'SELECT slug, name_ru, name_en, icao_code, iata_code, category
             FROM `{p}aircraft`
             WHERE name_ru LIKE ? OR name_en LIKE ? OR icao_code LIKE ? OR iata_code LIKE ? OR manufacturer LIKE ?
             ORDER BY views DESC LIMIT ' . self::LIMIT_PER_GROUP,
            [$like, $like, $like, $like, $like]
        );
        foreach ($rows as $r) {
            $out[] = [
                'group' => 'aircraft',
                'icon'  => '✈',
                'title' => $r['name_ru'] . ($r['name_en'] ? ' / ' . $r['name_en'] : ''),
                'sub'   => trim(($r['icao_code'] ?? '') . ' ' . ($r['iata_code'] ?? '')) ?: __('ac.category.' . $r['category']),
                'url'   => url('/aircraft/' . $r['slug']),
            ];
        }

        // Аэропорты (в.98: ICAO UUEE / IATA SVO / город / название)
        try {
            $rows = $db->all(
                'SELECT icao, iata, name_ru, city_ru, country_code FROM `{p}airports`
                 WHERE icao LIKE ? OR iata LIKE ? OR name_ru LIKE ? OR name_en LIKE ? OR city_ru LIKE ? OR city_en LIKE ?
                 LIMIT ' . self::LIMIT_PER_GROUP,
                [$like, $like, $like, $like, $like, $like]
            );
            foreach ($rows as $r) {
                $out[] = [
                    'group' => 'airports',
                    'icon'  => '⬡',
                    'title' => $r['name_ru'],
                    'sub'   => trim(($r['icao'] ?? '') . ' ' . ($r['iata'] ?? '') . ' ' . ($r['city_ru'] ?? '')),
                    'url'   => url('/airports/' . $r['icao']),
                ];
            }
        } catch (\Throwable) {
            // таблицы может не быть в старых установках
        }

        // Статьи (опубликованные)
        try {
            $rows = $db->all(
                "SELECT slug, title_ru FROM `{p}articles`
                 WHERE status = 'published' AND (title_ru LIKE ? OR title_en LIKE ?)
                 ORDER BY views DESC LIMIT " . self::LIMIT_PER_GROUP,
                [$like, $like]
            );
            foreach ($rows as $r) {
                $out[] = [
                    'group' => 'articles',
                    'icon'  => '▤',
                    'title' => $r['title_ru'],
                    'sub'   => '',
                    'url'   => url('/articles/' . $r['slug']),
                ];
            }
        } catch (\Throwable) {
        }

        json_response(['ok' => true, 'results' => $out, 'q' => $q]);
    }
}
