<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database;
use App\Core\Request;
use App\Core\View;
use App\Models\Photo;
use App\Services\MediaService;

/**
 * Галерея споттинга (в.11–14): лента, карточка фото, загрузка, лайки.
 */
final class GalleryController
{
    public function index(): void
    {
        $filters = [
            'aircraft_id'  => Request::int('aircraft'),
            'airport_id'   => Request::int('airport'),
            'user_id'      => Request::int('user'),
            'registration' => trim(Request::str('reg')),
            'sort'         => Request::str('sort', 'new'),
        ];
        $data = Photo::listing($filters, Request::int('page', 1), 24);

        echo View::render('gallery/index', [
            'title'   => __('gal.title'),
            'items'   => $data['items'],
            'total'   => $data['total'],
            'pages'   => $data['pages'],
            'page'    => $data['page'],
            'filters' => $filters,
            'top'     => Photo::topWeek(3),
            'airports' => Database::i()->all('SELECT id, icao, name_ru FROM `{p}airports` ORDER BY icao LIMIT 300'),
        ]);
    }

    public function show(string $id): void
    {
        $staff = in_array(Auth::role(), ['admin', 'moderator', 'screener'], true);
        $photo = Photo::findVisible((int)$id, Auth::id(), $staff);
        if ($photo === null) { abort(404); }
        if ($photo['status'] === 'approved') { Photo::incViews((int)$id); }

        $exif = is_string($photo['exif']) ? json_decode($photo['exif'], true) : $photo['exif'];

        echo View::render('gallery/show', [
            'title' => ($photo['title'] !== '' && $photo['title'] !== null ? $photo['title'] . ' — ' : '') . __('gal.title'),
            'p'     => $photo,
            'exif'  => is_array($exif) ? $exif : [],
        ]);
    }

    /** Форма загрузки (только для авторизованных) */
    public function uploadForm(): void
    {
        if (!Auth::check()) {
            flash('warning', __('auth.need_login'));
            redirect('/login');
        }
        echo View::render('gallery/upload', [
            'title'     => __('gal.upload'),
            'airports'  => Database::i()->all('SELECT id, icao, name_ru FROM `{p}airports` ORDER BY icao LIMIT 300'),
            'aircrafts' => Database::i()->all('SELECT id, slug, name_ru FROM `{p}aircraft` ORDER BY name_ru LIMIT 500'),
            'trusted'   => in_array(Auth::role(), ['admin', 'moderator', 'editor'], true),
        ]);
    }

    /** Приём фото: медиатека обрабатывает файл, фото-модель — метаданные (в.11–13) */
    public function upload(): void
    {
        if (!Auth::check()) {
            flash('warning', __('auth.need_login'));
            redirect('/login');
        }
        // v0.8.2: файл приходит multipart-ом ИЛИ JSON {file:{name,data:base64}};
        // ZIP распаковывается — каждое изображение внутри становится фото (с модерацией).
        $files = MediaService::filesFromRequest('file');
        if ($files === []) {
            flash('error', __('gal.no_file'));
            redirect('/gallery/upload');
        }
        $trusted = in_array(Auth::role(), ['admin', 'moderator', 'editor'], true);
        $meta = [
            'kind'     => 'image',
            'alt'      => mb_substr(trim(Request::str('title')), 0, 190),
            'license'  => Photo::LICENSES[Request::int('license_idx') - 1] ?? 'ARR',
        ];
        $taken = trim(Request::str('taken_at'));
        $common = [
            'user_id'      => Auth::id(),
            'aircraft_id'  => Request::int('aircraft_id') ?: null,
            'airport_id'   => Request::int('airport_id') ?: null,
            'registration' => mb_substr(strtoupper(trim(Request::str('registration'))), 0, 20),
            'title'        => mb_substr(trim(Request::str('title')), 0, 220),
            'status'       => $trusted ? 'approved' : 'pending', // в.11: гибридная модель
            'taken_at'     => preg_match('~^\d{4}-\d{2}-\d{2}$~', $taken) ? $taken : null,
        ];
        $ids = [];
        $skipped = 0;
        $error = null;
        foreach ($files as $f) {
            $res = MediaService::ingest($f, Auth::id(), $meta);
            foreach ($res['items'] as $media) {
                if (($media['kind'] ?? '') !== 'image') { $skipped++; continue; } // в галерею — только изображения
                $ids[] = Photo::create($common + [
                    'license'      => $media['license'] ?? 'ARR',
                    'filename'     => $media['path'],
                    'original_name'=> $media['original_name'] ?? null,
                    'exif'         => isset($media['exif']) && $media['exif'] !== null ? json_encode($media['exif'], JSON_UNESCAPED_UNICODE) : null,
                ]);
            }
            $skipped += count($res['skipped']);
            if (!$res['ok'] && $error === null) { $error = $res['error']; }
        }
        $n = count($ids);
        if ($n === 0) {
            flash('error', $error ?? __('gal.zip_empty'));
            redirect('/gallery/upload');
        }
        if ($n === 1) {
            flash('success', $trusted ? __('gal.uploaded_now') : __('gal.uploaded_screening'));
            redirect('/gallery/' . $ids[0]);
        }
        flash('success', __('gal.zip_done', ['n' => $n]) . ($skipped > 0 ? ' ' . __('gal.zip_skipped', ['n' => $skipped]) : '')
            . ' — ' . ($trusted ? __('gal.uploaded_now') : __('gal.uploaded_screening')));
        redirect('/gallery');
    }

    /** Лайк (один на сессию) */
    public function like(string $id): void
    {
        if (!Auth::check()) {
            json_response(['ok' => false, 'error' => 'auth'], 401);
        }
        $id = (int)$id;
        $_SESSION['liked'] ??= [];
        if (in_array($id, $_SESSION['liked'], true)) {
            json_response(['ok' => false, 'error' => 'dup']);
        }
        $_SESSION['liked'][] = $id;
        Photo::like($id);
        $row = Photo::find($id);
        json_response(['ok' => true, 'likes' => (int)($row['likes'] ?? 0)]);
    }
}
