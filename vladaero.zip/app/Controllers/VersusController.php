<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database;
use App\Core\Request;
use App\Core\View;
use App\Models\Aircraft;

/**
 * Versus — сравнение до 4 бортов (в.51–55):
 * радар-диаграмма индексов, подсветка лучших ТТХ, габариты, кросс-классовая подсказка.
 */
final class VersusController
{
    private const METRICS = [
        'length_m'         => ['vs.m_length', 'м', 1],
        'wingspan_m'       => ['vs.m_wingspan', 'м', 1],
        'mtow_kg'          => ['vs.m_mtow', 'кг', 500],
        'engines'          => ['vs.m_engines', '', 1],
        'cruise_speed_kmh' => ['vs.m_cruise', 'км/ч', 10],
        'max_speed_kmh'    => ['vs.m_vmax', 'км/ч', 10],
        'range_km'         => ['vs.m_range', 'км', 100],
        'ceiling_m'        => ['vs.m_ceiling', 'м', 100],
        'pax'              => ['vs.m_pax', '', 1],
    ];

    public function index(): void
    {
        $slugs = [];
        if (Request::path() !== '/versus') {
            // красивый URL: /versus/tu-154m-vs-b737-800 (в.55)
            $pair = trim(substr(Request::path(), strlen('/versus/')), '/');
            foreach (explode('-vs-', $pair) as $s) {
                if ($s !== '') { $slugs[] = $s; }
            }
        } else {
            foreach (['a', 'b', 'c', 'd'] as $k) {
                $s = trim(Request::str($k));
                if ($s !== '') { $slugs[] = $s; }
            }
        }
        $slugs = array_slice(array_values(array_unique($slugs)), 0, 4);

        $fleet = [];
        foreach ($slugs as $slug) {
            $ac = Aircraft::findBySlug($slug);
            if ($ac !== null) { $fleet[] = $ac; }
        }

        // Данные сравнения: значения, лучшее по каждой строке, доля от максимума
        $rows = [];
        foreach (self::METRICS as $field => [$labelKey, $unit, $step]) {
            $vals = [];
            foreach ($fleet as $ac) {
                $specs = is_string($ac['specs']) ? (json_decode($ac['specs'], true) ?? []) : ($ac['specs'] ?? []);
                $v = $specs[$field] ?? null;
                $vals[] = is_numeric($v) ? (float)$v : null;
            }
            $nums = array_filter($vals, static fn($v) => $v !== null && $v > 0);
            $max = $nums !== [] ? max($nums) : 0;
            $best = null;
            if ($nums !== [] && count($nums) > 1) {
                $best = array_search($max, $vals, true);
            }
            $rows[] = [
                'label' => __($labelKey),
                'unit'  => $unit,
                'step'  => $step,
                'vals'  => $vals,
                'max'   => $max,
                'best'  => $best,
            ];
        }

        // Кросс-классовая подсказка (в.53)
        $crossClass = false;
        if (count($fleet) > 1) {
            $cats = array_unique(array_column($fleet, 'category'));
            $crossClass = count($cats) > 1;
        }

        $shareUrl = $fleet !== [] ? url('/versus/' . implode('-vs-', array_column($fleet, 'slug'))) : '';

        // «Битва бортов» (в.54): голосование сообщества, когда выбрано ровно 2 борта
        $battle = null;
        if (count($fleet) === 2) {
            [$a, $b] = [(int)$fleet[0]['id'], (int)$fleet[1]['id']];
            [$lo, $hi] = $a < $b ? [$a, $b] : [$b, $a];
            $votes = Database::i()->all(
                'SELECT winner_id, COUNT(*) n FROM `{p}versus_votes`
                 WHERE (aircraft_a = ? AND aircraft_b = ?) GROUP BY winner_id', [$lo, $hi]);
            $tally = [ $a => 0, $b => 0 ];
            foreach ($votes as $v) { $tally[(int)$v['winner_id']] = (int)$v['n']; }
            $total = $tally[$a] + $tally[$b];
            $my = null;
            if (Auth::check()) {
                $row = Database::i()->one(
                    'SELECT winner_id FROM `{p}versus_votes` WHERE user_id = ? AND aircraft_a = ? AND aircraft_b = ?',
                    [(int)Auth::id(), $lo, $hi]);
                $my = $row !== null ? (int)$row['winner_id'] : null;
            }
            $battle = [
                'a' => $a, 'b' => $b, 'votesA' => $tally[$a], 'votesB' => $tally[$b],
                'total' => $total, 'my' => $my,
                'pctA' => $total > 0 ? (int)round($tally[$a] / $total * 100) : 50,
            ];
        }

        echo View::render('versus', [
            'title'      => __('vs.title'),
            'fleet'      => $fleet,
            'rows'       => $rows,
            'crossClass' => $crossClass,
            'shareUrl'   => $shareUrl,
            'catalog'    => Aircraft::search([], 1, 500)['items'] ?? [],
            'slugs'      => array_column($fleet, 'slug'),
            'battle'     => $battle,
        ]);
    }

    /** Голос в «Битве бортов» (в.54) — один голос на пару */
    public function vote(): void
    {
        csrf_verify();
        if (!Auth::check()) { flash('warning', __('auth.need_login')); redirect('/login'); }
        $a = (int)Request::str('a', '0');
        $b = (int)Request::str('b', '0');
        $w = (int)Request::str('w', '0');
        if ($a <= 0 || $b <= 0 || $a === $b || !in_array($w, [$a, $b], true)) {
            flash('warning', __('vs.battle_err')); redirect('/versus');
        }
        [$lo, $hi] = $a < $b ? [$a, $b] : [$b, $a];
        $exists = Database::i()->one(
            'SELECT id FROM `{p}versus_votes` WHERE user_id = ? AND aircraft_a = ? AND aircraft_b = ?',
            [(int)Auth::id(), $lo, $hi]);
        if ($exists !== null) {
            Database::i()->run('UPDATE `{p}versus_votes` SET winner_id = ? WHERE id = ?', [$w, $exists['id']]);
            flash('success', __('vs.battle_changed'));
        } else {
            Database::i()->insert('versus_votes', [
                'user_id' => (int)Auth::id(),
                'aircraft_a' => $lo, 'aircraft_b' => $hi, 'winner_id' => $w,
                'created_at' => date('Y-m-d H:i:s'),
            ]);
            flash('success', __('vs.battle_voted'));
        }
        $slugs = Database::i()->all('SELECT slug FROM `{p}aircraft` WHERE id IN (?,?) ORDER BY id', [$lo, $hi]);
        redirect('/versus/' . implode('-vs-', array_column($slugs, 'slug')));
    }
}
