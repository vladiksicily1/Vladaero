<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Request;
use App\Core\View;
use App\Models\Article;
use App\Models\Blocks;

/**
 * Публичный раздел статей (в.42, 108–115).
 */
final class ArticlesController
{
    public function index(): void
    {
        $q = Request::str('q');
        $page = max(1, Request::int('page', 1));
        $res = Article::published($page, 10, $q);
        echo View::render('articles/index', [
            'title' => __('art.section') . ' — ' . __('app.name'),
            'rows'  => $res['rows'],
            'total' => $res['total'],
            'q'     => $q,
            'page'  => $page,
            'pages' => max(1, (int)ceil($res['total'] / 10)),
        ], 'main');
    }

    public function show(string $slug): void
    {
        $a = Article::findBySlug($slug);
        if ($a === null) {
            abort(404);
        }
        $isPreview = $a['status'] !== 'published' && \App\Core\Auth::isAdmin();
        if ($a['status'] !== 'published' && !$isPreview) {
            abort(404);
        }
        if (!$isPreview) {
            Article::incrementViews((int)$a['id']);
        }
        $jsonLd = [
            '@context' => 'https://schema.org',
            '@type'    => 'NewsArticle',
            'headline' => $a['title_ru'],
            'datePublished' => $a['published_at'],
            'dateModified'  => $a['updated_at'] ?? $a['published_at'],
            'author'   => ['@type' => 'Person', 'name' => (string)($a['author'] ?? 'Редакция VladAero')],
        ];
        echo View::render('articles/show', [
            'title'   => $a['title_ru'] . ' — ' . __('app.name'),
            'a'       => $a,
            'blocksHtml' => Blocks::render('article', (int)$a['id']),
            'jsonLd'  => $jsonLd,
            'isPreview' => $isPreview,
            'authorFollowing' => \App\Core\Auth::check() && (int)$a['author_id'] > 0
                ? \App\Services\SocialService::isFollowing((int)\App\Core\Auth::id(), (int)$a['author_id']) : false,
        ], 'main');
    }
}
