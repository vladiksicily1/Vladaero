<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database;
use App\Core\Request;

/**
 * Закладки (в.26): избранные борта, статьи, аэропорты — «виртуальный ангар».
 */
final class BookmarksController
{
    private const TYPES = ['aircraft', 'article', 'airport'];

    public function toggle(): void
    {
        csrf_verify();
        if (!Auth::check()) { flash('warning', __('auth.need_login')); redirect('/login'); }
        $type = Request::str('type');
        $id = (int)Request::str('id', '0');
        if (!in_array($type, self::TYPES, true) || $id <= 0) { http_response_code(400); exit('bad request'); }
        $uid = (int)Auth::id();
        $exists = Database::i()->one(
            'SELECT id FROM `{p}bookmarks` WHERE user_id = ? AND entity_type = ? AND entity_id = ?', [$uid, $type, $id]);
        if ($exists !== null) {
            Database::i()->run('DELETE FROM `{p}bookmarks` WHERE id = ?', [$exists['id']]);
            flash('success', __('bm.removed'));
        } else {
            Database::i()->insert('bookmarks', [
                'user_id' => $uid, 'entity_type' => $type, 'entity_id' => $id, 'created_at' => date('Y-m-d H:i:s'),
            ]);
            flash('success', __('bm.added'));
        }
        $back = Request::str('back');
        if ($back !== '' && str_starts_with($back, '/')) { redirect($back); }
        redirect('/profile');
    }
}
