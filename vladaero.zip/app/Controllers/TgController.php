<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\View;
use App\Services\TelegramService;

/**
 * Telegram: страница привязки профиля (в.116) и вебхук (в.117).
 */
final class TgController
{
    /** GET /telegram — код привязки для авторизованного */
    public function page(): void
    {
        if (!Auth::check()) {
            flash('warning', __('auth.need_login'));
            redirect('/login');
        }
        $linked = \App\Core\Database::i()->one('SELECT username, created_at FROM `{p}tg_links` WHERE user_id = ?', [Auth::id()]);
        echo View::render('telegram', [
            'title' => __('tg.title'),
            'code'  => TelegramService::linkCode((int)Auth::id()),
            'bot'   => (string)setting('telegram_bot_username', ''),
            'linked' => $linked,
        ]);
    }

    /** POST /tg/webhook — входящие апдейты (проверка секретного токена) */
    public function webhook(): void
    {
        $secret = (string)setting('tg_webhook_secret', '');
        $given = $_SERVER['HTTP_X_TELEGRAM_BOT_API_SECRET_TOKEN'] ?? ($_GET['key'] ?? '');
        if ($secret === '' || !hash_equals($secret, (string)$given)) {
            http_response_code(403);
            exit('forbidden');
        }
        $update = json_decode((string)file_get_contents('php://input'), true);
        if (is_array($update)) {
            TelegramService::handleUpdate($update);
        }
        header('Content-Type: application/json');
        echo '{"ok":true}';
        exit;
    }
}
