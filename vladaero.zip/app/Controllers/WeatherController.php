<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Database;
use App\Core\Request;
use App\Core\View;
use App\Services\WxService;

/**
 * Авиационная погода (в.47, 283–295): METAR/TAF с авторасшифровкой,
 * NOTAM при наличии ключа SkyLink. Публичная страница + JSON API для блоков.
 */
final class WeatherController
{
    public function index(): void
    {
        $icao = strtoupper(Request::str('icao', ''));
        if ($icao === '') {
            $first = Database::i()->one('SELECT icao FROM `{p}airports` ORDER BY id LIMIT 1');
            $icao = $first['icao'] ?? 'UUEE';
        }
        echo View::render('weather', [
            'title'    => __('wx.title'),
            'icao'     => $icao,
            'metar'    => WxService::metar($icao),
            'taf'      => WxService::taf($icao),
            'airports' => Database::i()->all('SELECT icao, name_ru FROM `{p}airports` ORDER BY icao LIMIT 400'),
            'hasKey'   => (string)setting('skylink_api_key', '') !== '',
        ]);
    }

    /** JSON: /api/wx?icao=UUEE — для страницы аэропорта и блока METAR */
    public function api(): void
    {
        $icao = Request::str('icao');
        json_response([
            'metar' => WxService::metar($icao),
            'taf'   => WxService::taf($icao),
        ]);
    }

    /** NOTAM: /api/notam?icao=UUEE (только при ключе SkyLink) */
    public function notam(): void
    {
        json_response(WxService::notam(Request::str('icao')));
    }
}
