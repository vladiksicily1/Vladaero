<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Database;
use App\Core\Request;
use App\Core\View;
use App\Services\WxService;

/**
 * Живые веб-камеры аэропортов (в.278): сеть AviationWX.org (бесплатно)
 * + собственные камеры из настроек («ICAO|Название|URL кадра»).
 */
final class WebcamsController
{
    public function index(): void
    {
        $icao = strtoupper(Request::str('icao', ''));
        echo View::render('webcams', [
            'title'     => __('cam.title'),
            'icao'      => $icao,
            'cams'      => $icao !== '' ? WxService::webcams($icao) : ['net' => [], 'custom' => []],
            'net'       => WxService::webcamAirports(),
            'airports'  => Database::i()->all('SELECT icao, name_ru FROM `{p}airports` ORDER BY icao LIMIT 400'),
        ]);
    }
}
