<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Database;
use App\Core\Request;
use App\Core\View;

/**
 * Инструменты пилота (в.46–50): 6 калькуляторов (клиентские, шаринг через URL),
 * декодер NOTAM (серверный разбор Q-кода и секций), squawk-декодер, глоссарий.
 */
final class ToolsController
{
    public function index(): void
    {
        echo View::render('tools', [
            'title'   => __('tools.title'),
            'airports' => Database::i()->all('SELECT icao, name_ru, lat, lng FROM `{p}airports` ORDER BY icao LIMIT 400'),
        ]);
    }

    /** POST /tools/notam {text} — декодер извещения (в.47) */
    public function notamDecode(): void
    {
        $text = trim(Request::str('text'));
        if ($text === '') {
            json_response(['ok' => false, 'error' => 'empty']);
        }
        json_response(['ok' => true, 'notam' => self::decodeNotam($text)]);
    }

    /** Разбор NOTAM: секции A–G, Q-код, координаты, период действия */
    private static function decodeNotam(string $text): array
    {
        $out = ['sections' => [], 'q' => [], 'coords' => '', 'schedule' => ''];

        // Секции A) ... G)
        if (preg_match_all('~([A-G]\))\s*(.*?)(?=(?:\s[A-G]\))|$)~us', $text, $mm, PREG_SET_ORDER)) {
            foreach ($mm as $m) {
                $out['sections'][$m[1]] = trim($m[2]);
            }
        }
        if ($out['sections'] === []) {
            $out['sections']['E)'] = $text; // свободный текст
        }

        // Q-строка: Q) LIRR/QWXXX/IV/NBO/W/0002/0052/4123N01221E005 (пробелы допускаются)
        $qLine = '';
        if (preg_match('~Q\)\s*(.+)$~im', $text, $qm)) {
            $qLine = preg_replace('~\s+~', '', trim($qm[1]));
        }
        if ($qLine !== '' && preg_match('~^([A-Z]{4})/([A-Z]+)(?:/([A-Z]+))?/([A-Z0-9]+)/([A-Z0-9]+)/(\d{4})/(\d{4})/([0-9NEWS]+)~', $qLine, $q)) {
            [, $fir, $qcode, , $scope, $fl, $from, $to, $coord] = $q;
            $out['q'] = [
                'fir'   => $fir,
                'code'  => $qcode,
                'subj'  => self::qSubject(substr($qcode, 1, 2)),
                'scope' => self::qScope($scope),
                'fl'    => $fl,
                'from'  => $from,
                'to'    => $to,
            ];
            if (!isset($out['coords'])) {
                $out['coords'] = '';
            }
            if (preg_match('~(\d{2})(\d{2})N(\d{3})(\d{2})E?W?(\d{3})~', $coord, $c)) {
                $out['coords'] = sprintf('%s.%s°N %s.%s°, радиус %d км', $c[1], $c[2], $c[3], $c[4], (int)$c[5]);
            }
        }
        // Координаты радиуса: 4123N01221E005
        if (preg_match('~(\d{2})(\d{2})N(\d{3})(\d{2})E(\d{3})~', $text, $c)) {
            $out['coords'] = sprintf('%s.%s°N %s.%s°E, радиус %d км', $c[1], $c[2], $c[3], $c[4], (int)$c[5]);
        } elseif (preg_match('~(\d{2})(\d{2})N(\d{3})(\d{2})W(\d{3})~', $text, $c)) {
            $out['coords'] = sprintf('%s.%s°N %s.%s°W, радиус %d км', $c[1], $c[2], $c[3], $c[4], (int)$c[5]);
        }
        // Период: секции B) и C) или диапазон 2601140600-2601241200 (формат YYMMDDHHMM)
        $fmt = static function (string $t): string {
            if (preg_match('~^\d{10}$~', $t)) {
                return substr($t, 4, 2) . '.' . substr($t, 2, 2) . '.' . substr($t, 0, 2) . ' ' . substr($t, 6, 2) . ':' . substr($t, 8, 2) . ' UTC';
            }
            return $t;
        };
        if (isset($out['sections']['B)'], $out['sections']['C)'])) {
            $out['schedule'] = 'с ' . $fmt($out['sections']['B)']) . ' по ' . $fmt($out['sections']['C)']);
        } elseif (preg_match('~(\d{10})-(\d{10})~', $text, $s)) {
            $out['schedule'] = 'с ' . $fmt($s[1]) . ' по ' . $fmt($s[2]);
        }
        return $out;
    }

    /** Предмет Q-кода (вторая-третья буквы) — базовый словарь */
    private static function qSubject(string $q2): string
    {
        $map = [
            'AH' => 'аэродромный маяк', 'AB' => 'аэродром', 'AD' => 'аэродром',
            'BX' => 'препятствие', 'OB' => 'препятствие', 'OL' => 'препятствие с подсветкой',
            'MK' => 'маркировка', 'MM' => 'система посадки (ILS/маркеры)', 'IL' => 'ILS',
            'FA' => 'радиомаяк/NDB', 'VL' => 'VOR', 'DM' => 'DME',
            'LC' => 'светосигнальное оборудование', 'LG' => 'огни/подсветка',
            'RW' => 'ВПП', 'TW' => 'рулёжная дорожка', 'AP' => 'апрон/перрон',
            'MO' => 'движение/правила полётов', 'MR' => 'регламент полётов',
            'AC' => 'запреты/ограничения', 'R' => 'ограничение зоны', 'DA' => 'опасная зона',
            'PW' => 'прыжки с парашютом', 'W' => 'опасные явления/предупреждение', 'WX' => 'предупреждение/опасные явления',
            'MX' => 'военная деятельность', 'AX' => 'воздушное пространство/ограничения',
            'UX' => 'БПЛА', 'UW' => 'БПЛА/беспилотные работы',
            'MN' => 'содержание/ремонт', 'CN' => 'стройка/работы',
        ];
        return $map[$q2] ?? 'см. полный текст (код Q' . $q2 . ')';
    }

    private static function qScope(string $s): string
    {
        $t = ['A' => 'аэродром', 'E' => 'маршрут/энрут', 'W' => 'навигационное предупреждение', 'K' => 'контрольная зона'];
        $letters = str_split($s);
        $ru = ['I' => 'IFR', 'V' => 'VFR', 'K' => 'контрольная зона', 'N' => 'немедленно', 'B' => 'для всех', 'O' => 'операторы', 'M' => 'военные', 'A' => 'аэродром', 'E' => 'энрут', 'W' => 'предупреждение'];
        $parts = [];
        foreach ($letters as $l) { $parts[] = $ru[$l] ?? $t[$l] ?? $l; }
        return implode(' + ', array_unique($parts));
    }
}
