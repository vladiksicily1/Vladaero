<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Request;
use App\Core\View;
use App\Models\Aircraft;

/**
 * Публичная энциклопедия авиатехники (вопросы 6–9, 100, 103, 227).
 */
final class AircraftController
{
    private const PAGE_SIZE = 12;

    public function index(): void
    {
        $filters = [
            'q'            => Request::str('q'),
            'category'     => Request::str('category'),
            'manufacturer' => Request::str('manufacturer'),
            'country'      => Request::str('country'),
            'status'       => Request::str('status'),
            'era'          => Request::str('era'),
            'min_range'    => Request::int('min_range'),
            'min_pax'      => Request::int('min_pax'),
            'sort'         => Request::str('sort', 'name'),
        ];
        $page = max(1, Request::int('page', 1));
        $res = Aircraft::search($filters, $page, self::PAGE_SIZE);
        $pages = max(1, (int)ceil($res['total'] / self::PAGE_SIZE));

        echo View::render('aircraft/index', [
            'title'         => __('ac.catalog_title') . ' — ' . __('app.name'),
            'filters'       => $filters,
            'rows'          => $res['rows'],
            'total'         => $res['total'],
            'page'          => min($page, $pages),
            'pages'         => $pages,
            'manufacturers' => Aircraft::manufacturers(),
        ], 'main');
    }

    public function show(string $slug): void
    {
        $ac = Aircraft::findBySlug($slug);
        if ($ac === null) {
            abort(404);
        }
        Aircraft::incrementViews((int)$ac['id']);

        $specs = is_array($ac['specs']) ? $ac['specs'] : [];
        $summary = [];
        foreach (Aircraft::SUMMARY_FIELDS as $k) {
            if (isset($specs[$k]) && $specs[$k] !== '') {
                $summary[$k] = $specs[$k];
            }
        }

        echo View::render('aircraft/show', [
            'title'   => $ac['name_ru'] . ' — ' . __('ac.catalog_title') . ' — ' . __('app.name'),
            'ac'      => $ac,
            'specs'   => $specs,
            'summary' => $summary,
            'groups'  => Aircraft::SPEC_GROUPS,
        ], 'main');
    }
}
