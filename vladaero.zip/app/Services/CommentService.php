<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Cache;
use App\Core\Database;
use App\Models\Notification;

/**
 * Комментарии с ветками (в.27): под фото, статьями, бортами, клубами и событиями.
 * Двухуровневая модерация (в.194): авто мат-фильтр → «на проверку»; остальное сразу видно.
 */
final class CommentService
{
    public const TYPES = ['photo', 'article', 'aircraft', 'club', 'event', 'battle'];

    /** Составной id битвы: lo * 1e6 + hi (пара бортов) */
    public static function battleId(int $a, int $b): int
    {
        [$lo, $hi] = $a < $b ? [$a, $b] : [$b, $a];
        return $lo * 1000000 + $hi;
    }

    /** Грубый стоп-лист (в.194, уровень 1). Матч → статус pending */
    private const STOP = '~(\b(?:[бб][ли][яа](?:дь|ды)?|х[уеё][йя]\w*|п[иi][зс]д\w*|[еe][бb][аa][тt]\w*|муд[аа][кк]|[сc][кk][аa]?тина|идиот\w*|дебил\w*)\b)~ui';

    /**
     * Добавить комментарий. Возвращает [id, status, error?].
     *
     * @return array{0:int,1:string,2:?string}
     */
    public static function add(int $userId, string $type, int $entityId, int $parentId, string $body, string $ip = ''): array
    {
        $body = trim(preg_replace('~[ \t]+~u', ' ', $body) ?? '');
        if (mb_strlen($body) < 2) { return [0, '', 'too_short']; }
        if (mb_strlen($body) > 2000) { $body = mb_substr($body, 0, 2000); }
        if (!in_array($type, self::TYPES, true)) { return [0, '', 'bad_type']; }

        // анти-флуд: не чаще 1 в 10 секунд
        $rk = 'cm_rl_' . $userId;
        if (Cache::get($rk) !== null) { return [0, '', 'flood']; }
        Cache::set($rk, 1, 10);

        // в.194: мат-фильтр + ссылочный спам → ручная проверка
        $flag = preg_match(self::STOP, $body) === 1 || substr_count($body, 'http') > 2;
        $status = $flag ? 'pending' : 'approved';

        $parent = null;
        if ($parentId > 0) {
            $parent = Database::i()->one(
                'SELECT id, user_id FROM `{p}comments` WHERE id = ? AND entity_type = ? AND entity_id = ? AND status = "approved" LIMIT 1',
                [$parentId, $type, $entityId]);
            if ($parent === null) { $parentId = 0; }
        }

        $now = date('Y-m-d H:i:s');
        Database::i()->insert('comments', [
            'user_id' => $userId,
            'entity_type' => $type,
            'entity_id' => $entityId,
            'parent_id' => $parentId ?: null,
            'body' => $body,
            'status' => $status,
            'ip' => mb_substr($ip, 0, 45),
            'created_at' => $now,
        ]);
        $id = (int)Database::i()->val('SELECT LAST_INSERT_ID()');

        if ($parent !== null && (int)$parent['user_id'] !== $userId && $status === 'approved') {
            self::notifyReply((int)$parent['user_id'], $userId, $type, $entityId, $id, $body);
        }
        return [$id, $status, null];
    }

    /** Уведомление об ответе: веб-лента + Telegram (в.116: ответы в комментариях) */
    private static function notifyReply(int $toUserId, int $fromUserId, string $type, int $entityId, int $commentId, string $body): void
    {
        $from = (string)(Database::i()->val('SELECT username FROM `{p}users` WHERE id = ?', [$fromUserId]) ?? '');
        $url = self::entityUrl($type, $entityId) . '#comment-' . $commentId;
        Notification::push($toUserId, 'comment_reply', [
            'from' => $from, 'type' => $type, 'entity_id' => $entityId, 'url' => $url, 'excerpt' => mb_substr($body, 0, 120),
        ]);
        TelegramService::notifyCommentReply($toUserId, $from, $url, $body);
    }

    /** Ссылка на сущность комментария */
    public static function entityUrl(string $type, int $id): string
    {
        $base = rtrim(url('/'), '/');
        return match ($type) {
            'photo' => $base . '/gallery/' . $id,
            'article' => $base . '/articles/' . rawurlencode((string)(Database::i()->val('SELECT slug FROM `{p}articles` WHERE id = ?', [$id]) ?? '')),
            'aircraft' => $base . '/aircraft/' . rawurlencode((string)(Database::i()->val('SELECT slug FROM `{p}aircraft` WHERE id = ?', [$id]) ?? '')),
            'club' => $base . '/clubs/' . rawurlencode((string)(Database::i()->val('SELECT slug FROM `{p}clubs` WHERE id = ?', [$id]) ?? '')),
            'event' => $base . '/events/' . rawurlencode((string)(Database::i()->val('SELECT slug FROM `{p}events` WHERE id = ?', [$id]) ?? '')),
            'battle' => $base . '/versus/' . implode('-vs-', array_map(
                static fn($i) => rawurlencode((string)$i),
                array_column(Database::i()->all(
                    'SELECT slug FROM `{p}aircraft` WHERE id IN (?,?) ORDER BY id',
                    [intdiv($id, 1000000), $id % 1000000]
                ), 'slug')
            )),
            default => $base . '/',
        };
    }

    /**
     * Дерево комментариев (2 уровня ветвления, как в Instagram/Twitter).
     *
     * @return array<int,array<string,mixed>>
     */
    public static function tree(string $type, int $entityId, int $viewerId = 0): array
    {
        $rows = Database::i()->all(
            'SELECT c.id, c.parent_id, c.body, c.status, c.created_at, c.user_id, u.username, u.role
             FROM `{p}comments` c JOIN `{p}users` u ON u.id = c.user_id
             WHERE c.entity_type = ? AND c.entity_id = ? AND (c.status = "approved" OR c.user_id = ?)
             ORDER BY c.id ASC LIMIT 500',
            [$type, $entityId, $viewerId]);

        $byParent = [];
        foreach ($rows as $r) {
            $byParent[(int)($r['parent_id'] ?? 0)][] = $r;
        }
        $out = [];
        foreach ($byParent[0] ?? [] as $root) {
            $item = $root;
            $item['children'] = [];
            foreach ($byParent[(int)$root['id']] ?? [] as $child) {
                $item['children'][] = $child;
            }
            $out[] = $item;
        }
        return $out;
    }

    public static function count(string $type, int $entityId): int
    {
        return (int)Database::i()->val(
            'SELECT COUNT(*) FROM `{p}comments` WHERE entity_type = ? AND entity_id = ? AND status = "approved"',
            [$type, $entityId]);
    }

    /** Текст-представление сущности для уведомлений/модерации */
    public static function entityTitle(string $type, int $id): string
    {
        $table = match ($type) {
            'photo' => null,
            'article' => 'articles',
            'aircraft' => 'aircraft',
            'club' => 'clubs',
            'event' => 'events',
            'battle' => null,
            default => null,
        };
        if ($type === 'battle') { return 'Битва бортов'; }
        if ($table === null) { return '#' . $id; }
        $col = $table === 'articles' ? 'title_ru' : ($table === 'events' ? 'title_ru' : ($table === 'aircraft' ? 'name_ru' : 'title'));
        return (string)(Database::i()->val("SELECT `$col` FROM `{p}$table` WHERE id = ?", [$id]) ?? ('#' . $id));
    }
}
