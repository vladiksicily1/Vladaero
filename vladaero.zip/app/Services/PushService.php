<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Cache;
use App\Core\Database;

/**
 * Web Push (v0.8.1) в чистом PHP: VAPID (ES256) + подписки.
 * Пуши уходят без payload (упрощение: без шифрования RFC 8291) —
 * service worker сам подтягивает текст последнего уведомления
 * через /api/push/pending, поэтому содержимое всё равно персональное.
 */
final class PushService
{
    public static function enabled(): bool
    {
        return (string)setting('push_vapid_public', '') !== '' && (string)setting('push_vapid_private', '') !== '';
    }

    /** Сгенерировать пару VAPID-ключей P-256. */
    public static function generateKeys(): array
    {
        $res = openssl_pkey_new(['curve_name' => 'prime256v1', 'private_key_type' => OPENSSL_KEYTYPE_EC]);
        if ($res === false) { return []; }
        $pem = '';
        openssl_pkey_export($res, $pem);
        $details = openssl_pkey_get_details($res);
        // SPKI DER: последние 65 байт = 0x04 || X || Y (uncompressed point)
        $der = $details['key'] === false ? '' : self::pemToDer((string)$details['key']);
        $point = substr($der, -65);
        return [
            'private' => $pem,                              // PEM
            'public'  => self::b64url($point),              // base64url raw point (87 симв.)
        ];
    }

    public static function saveKeys(array $keys): void
    {
        foreach (['push_vapid_public' => $keys['public'] ?? '', 'push_vapid_private' => $keys['private'] ?? ''] as $k => $v) {
            Database::i()->run(
                'INSERT INTO `{p}settings` (k, v) VALUES (?, ?) ON DUPLICATE KEY UPDATE v = VALUES(v)', [$k, $v]);
        }
        Cache::delete('settings.all');
    }

    public static function subscribe(int $userId, array $sub): bool
    {
        $endpoint = (string)($sub['endpoint'] ?? '');
        $p256dh = (string)($sub['keys']['p256dh'] ?? '');
        $auth = (string)($sub['keys']['auth'] ?? '');
        if ($endpoint === '' || $p256dh === '' || $auth === '' || mb_strlen($endpoint) > 500) { return false; }
        Database::i()->run(
            'INSERT INTO `{p}push_subscriptions` (user_id, endpoint, p256dh, auth, lang, created_at)
             VALUES (?,?,?,?,?,NOW())
             ON DUPLICATE KEY UPDATE user_id = VALUES(user_id), p256dh = VALUES(p256dh), auth = VALUES(auth)',
            [$userId, $endpoint, mb_substr($p256dh, 0, 200), mb_substr($auth, 0, 120), 'ru']);
        return true;
    }

    public static function unsubscribe(string $endpoint): void
    {
        Database::i()->run('DELETE FROM `{p}push_subscriptions` WHERE endpoint = ?', [$endpoint]);
    }

    /**
     * Отправить пуш одной подписке. true — доставлено (2xx).
     * 404/410 — подписка умерла, удаляем.
     */
    public static function send(array $row): bool
    {
        if (!self::enabled()) { return false; }
        $endpoint = (string)$row['endpoint'];
        $parts = parse_url($endpoint);
        $aud = (($parts['scheme'] ?? 'https')) . '://' . ($parts['host'] ?? '');
        $jwt = self::vapidJwt($aud);
        $ch = curl_init($endpoint);
        if ($ch === false) { return false; }
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 12,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => '',
            CURLOPT_HTTPHEADER => [
                'TTL: 86400',
                'Urgency: normal',
                'Content-Length: 0',
                'Authorization: vapid t=' . $jwt . ', k=' . (string)setting('push_vapid_public', ''),
            ],
        ]);
        curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);
        if ($code === 404 || $code === 410) {
            Database::i()->run('DELETE FROM `{p}push_subscriptions` WHERE endpoint = ?', [$endpoint]);
            return false;
        }
        $ok = $code >= 200 && $code < 300;
        if ($ok) {
            Database::i()->run('UPDATE `{p}push_subscriptions` SET last_push_at = NOW() WHERE endpoint = ?', [$endpoint]);
        }
        return $ok;
    }

    /** @return array{sent:int, failed:int, total:int} */
    public static function broadcast(int $userId = 0, int $limit = 500): array
    {
        $stats = ['sent' => 0, 'failed' => 0, 'total' => 0];
        $rows = $userId > 0
            ? Database::i()->all('SELECT * FROM `{p}push_subscriptions` WHERE user_id = ? LIMIT ' . (int)$limit, [$userId])
            : Database::i()->all('SELECT * FROM `{p}push_subscriptions` LIMIT ' . (int)$limit);
        foreach ($rows as $row) {
            $stats['total']++;
            self::send($row) ? $stats['sent']++ : $stats['failed']++;
        }
        return $stats;
    }

    public static function subscriptionsCount(): int
    {
        return (int)Database::i()->val('SELECT COUNT(*) FROM `{p}push_subscriptions`');
    }

    /* ===================== VAPID JWT (ES256) ===================== */

    private static function vapidJwt(string $aud): string
    {
        $header = self::b64url(json_encode(['typ' => 'JWT', 'alg' => 'ES256'], JSON_UNESCAPED_SLASHES));
        $claims = self::b64url(json_encode([
            'aud' => $aud,
            'exp' => time() + 43200,
            'sub' => (string)setting('push_vapid_subject', 'mailto:admin@vladaero.local'),
        ], JSON_UNESCAPED_SLASHES));
        $input = $header . '.' . $claims;
        $sig = '';
        $key = openssl_pkey_get_private((string)setting('push_vapid_private', ''));
        if ($key === false) { return ''; }
        openssl_sign($input, $sig, $key, OPENSSL_ALGO_SHA256);
        return $input . '.' . self::b64url(self::derSigToRaw($sig));
    }

    private static function derSigToRaw(string $der): string
    {
        // ASN.1 SEQUENCE(r INTEGER, s INTEGER) → 64 байта r||s
        if (strlen($der) < 8 || ord($der[0]) !== 0x30) { return str_pad('', 64, "\0"); }
        $pos = 2;
        if (ord($der[1]) & 0x80) { $pos += ord($der[1]) & 0x7f; }
        $len = ord($der[$pos]); $pos++;                      // r: длина
        if ($len & 0x80) { $bytes = $len & 0x7f; $len = 0; for ($i = 0; $i < $bytes; $i++) { $len = ($len << 8) | ord($der[$pos + $i]); } $pos += $bytes; }
        $r = ltrim(substr($der, $pos, $len), "\0");
        $pos += $len;
        $len = ord($der[$pos]); $pos++;                      // s: длина
        if ($len & 0x80) { $bytes = $len & 0x7f; $len = 0; for ($i = 0; $i < $bytes; $i++) { $len = ($len << 8) | ord($der[$pos + $i]); } $pos += $bytes; }
        $s = ltrim(substr($der, $pos, $len), "\0");
        return str_pad($r, 32, "\0", STR_PAD_LEFT) . str_pad($s, 32, "\0", STR_PAD_LEFT);
    }

    private static function pemToDer(string $pem): string
    {
        $body = preg_replace('~-----[^-]+-----|\s~', '', $pem) ?? '';
        return base64_decode($body) ?: '';
    }

    private static function b64url(string $bin): string
    {
        return rtrim(strtr(base64_encode($bin), '+/', '-_'), '=');
    }
}
