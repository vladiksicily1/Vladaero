<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database;
use App\Core\Logger;
use App\Models\Setting;

/**
 * Автоматические миграции БД (в.285): при обновлении портала новые файлы
 * migrations/*.sql применяются сами — без ручного запуска.
 *
 * Уже установленные версии отслеживаются в настройке schema_version.
 * Базовая схема (01–08) создаётся установщиком install.php, поэтому для
 * существующего портала она считается применённой (baseline = 08) и
 * не перезапускается (в т.ч. опасный DROP TABLE из 01_schema.sql).
 * Новые миграции (09+) выполняются автоматически в порядке версий.
 */
final class MigrationService
{
    /** Версия базовой схемы, которая ставится установщиком (01–08). */
    private const BASELINE = 8;

    private const KEY = 'schema_version';

    public static function run(): void
    {
        $db = self::ready() ? Database::i() : null;
        if ($db === null) {
            return;
        }

        try {
            // Старый портал без схемы миграций — считаем, что базовая схема применена
            $current = (int)(Setting::get(self::KEY, '0') ?? 0);
            if ($current <= 0) {
                $current = self::BASELINE;
            }
        } catch (\Throwable) {
            return;
        }

        $dir = VA_ROOT . '/migrations';
        $files = is_dir($dir) ? glob($dir . '/[0-9]*_*.sql') : false;
        if ($files === false || $files === []) {
            return;
        }
        sort($files, SORT_STRING);

        foreach ($files as $file) {
            $version = (int)basename($file);
            if ($version <= $current) {
                continue;
            }
            self::apply($db, $file, $version);
            $current = $version;
            try {
                Setting::set(self::KEY, (string)$current);
            } catch (\Throwable $e) {
                Logger::warning('MigrationService: не сохранил schema_version', ['e' => $e->getMessage()]);
            }
        }
    }

    /** Готова ли БД (есть таблица настроек) — без выброса исключений. */
    private static function ready(): bool
    {
        try {
            $db = Database::i();
            $pdo = $db->pdo();
            $st = $pdo->query('SHOW TABLES LIKE ' . $pdo->quote($db->t('settings')));
            return $st !== false && $st->fetch(\PDO::FETCH_COLUMN) !== false;
        } catch (\Throwable) {
            return false;
        }
    }

    private static function apply(Database $db, string $file, int $version): void
    {
        $sql = (string)file_get_contents($file);
        $sql = (string)preg_replace('/^\s*--.*$/m', '', $sql);
        $sql = trim($sql);
        if ($sql === '') {
            return;
        }
        $pdo = $db->pdo();
        foreach (self::split($sql) as $stmt) {
            $stmt = $db->q(trim($stmt));
            if ($stmt === '') {
                continue;
            }
            try {
                $pdo->exec($stmt);
                Logger::log('INFO', "Migration {$version}: OK — " . mb_substr(trim((string)strtok($stmt, "\n")), 0, 80));
            } catch (\Throwable $e) {
                Logger::warning("Migration {$version}: пропущена инструкция — " . $e->getMessage());
            }
        }
    }

    /** Разбивка SQL на отдельные инструкции с учётом строк и кавычек. */
    private static function split(string $sql): array
    {
        $sql = rtrim($sql, ";");
        $out = [];
        $buf = '';
        $quote = null;
        $len = strlen($sql);
        for ($i = 0; $i < $len; $i++) {
            $c = $sql[$i];
            if ($quote !== null) {
                if ($c === '\\' && $i + 1 < $len) {
                    $buf .= $c . $sql[++$i];
                    continue;
                }
                if ($c === $quote) {
                    $quote = null;
                }
                $buf .= $c;
                continue;
            }
            if ($c === "'" || $c === '"' || $c === '`') {
                $quote = $c;
                $buf .= $c;
                continue;
            }
            if ($c === ';') {
                $t = trim($buf);
                if ($t !== '') {
                    $out[] = $t;
                }
                $buf = '';
                continue;
            }
            $buf .= $c;
        }
        $t = trim($buf);
        if ($t !== '') {
            $out[] = $t;
        }
        return $out;
    }
}
