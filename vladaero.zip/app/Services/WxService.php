<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Cache;
use App\Core\Logger;

/**
 * Авиационная погода (в.283–295): METAR/TAF — NOAA AWC (бесплатно, без ключа),
 * кэш: METAR 30 мин, TAF 60 мин. Веб-камеры — AviationWX.org (в.278).
 * NOTAM — SkyLink API при наличии ключа (админка → Интеграции), кэш 15 мин.
 */
final class WxService
{
    public const METAR_TTL = 1800;
    public const TAF_TTL   = 3600;
    public const NOTAM_TTL = 900;
    public const CAM_TTL   = 86400;

    private const UA = 'VladAero-Portal/0.5 (+weather)';

    /* ---------------- METAR ---------------- */

    /**
     * @return array{ok:bool,icao:string,raw:string,obs:string,fltcat:string,dec:array<string,mixed>,stale:bool}
     */
    public static function metar(string $icao): array
    {
        $icao = strtoupper(preg_replace('~[^A-Za-z0-9]~', '', $icao) ?? '');
        if ($icao === '' || strlen($icao) !== 4) {
            return ['ok' => false, 'icao' => $icao, 'raw' => '', 'obs' => '', 'fltcat' => '', 'dec' => ['error' => 'ICAO'], 'stale' => false];
        }
        $key = 'wx_metar_' . $icao;
        $hit = Cache::get($key);
        $url = 'https://aviationweather.gov/api/data/metar?ids=' . rawurlencode($icao) . '&format=json';
        $json = self::http($url);
        if (is_array($json) && isset($json[0]['rawOb'])) {
            $out = self::shapeMetar($json[0]);
            Cache::set($key, $out, self::METAR_TTL);
            return $out;
        }
        if (is_array($hit)) {
            $hit['stale'] = true;
            return $hit;
        }
        return ['ok' => false, 'icao' => $icao, 'raw' => '', 'obs' => '', 'fltcat' => '', 'dec' => ['error' => 'source'], 'stale' => false];
    }

    /** @return array<string,mixed> */
    private static function shapeMetar(array $m): array
    {
        $raw = (string)($m['rawOb'] ?? '');
        return [
            'ok'     => true,
            'icao'   => (string)($m['icaoId'] ?? ''),
            'raw'    => $raw,
            'name'   => (string)($m['name'] ?? ''),
            'obs'    => isset($m['reportTime']) ? substr((string)$m['reportTime'], 11, 5) . ' UTC' : '',
            'fltcat' => (string)($m['fltCat'] ?? ''),
            'dec'    => self::decodeMetar($m, $raw),
            'stale'  => false,
        ];
    }

    /** Человекочитаемая расшифровка METAR на русском (в.47) */
    private static function decodeMetar(array $m, string $raw): array
    {
        $dec = [];
        // Ветер
        $wdir = $m['wdir'] ?? null;
        $wspd = $m['wspd'] ?? null;
        if (is_numeric($wdir) || is_string($wdir)) {
            $gust = null;
            if (preg_match('~(?:^|\s)(?:VRB|\d{3})(?:\d{2,3})G(\d{2,3})KT~', $raw, $g)) {
                $gust = (int)$g[1];
            }
            $dirs = ['VRB' => 'переменный', '000' => 'штиль'];
            $dTxt = $dirs[(string)$wdir] ?? ((string)$wdir . '°');
            $dec['wind'] = $dTxt . ', ' . (int)$wspd . ' узл'
                . ($gust !== null ? ', порывы ' . $gust . ' узл' : '');
            if (preg_match('~(\d{3})V(\d{3})~', $raw, $v)) {
                $dec['wind'] .= ' (между ' . $v[1] . '° и ' . $v[2] . '°)';
            }
        }
        // Видимость
        if (isset($m['visib'])) {
            $vis = (string)$m['visib'];
            $dec['vis'] = $vis === '6+' ? '6+ SM (10+ км)' : (is_numeric($vis) ? $vis . ' SM (' . round((float)$vis * 1.609, 1) . ' км)' : $vis);
        }
        // Облачность
        $clouds = $m['clouds'] ?? [];
        $cRu = ['FEW' => 'редкая', 'SCT' => 'рассеянная', 'BKN' => 'значительная', 'OVC' => 'сплошная'];
        if (is_array($clouds) && $clouds !== []) {
            $parts = [];
            foreach ($clouds as $c) {
                if (!is_array($c)) { continue; }
                $cover = (string)($c['cover'] ?? '');
                $base  = $c['base'] ?? null;
                $parts[] = ($cRu[$cover] ?? $cover) . ' ' . (is_numeric($base) ? round((float)$base * 0.3048) . ' м' : '');
            }
            $dec['clouds'] = $parts !== [] ? implode('; ', $parts) : 'указана в сводке';
        } elseif (stripos($raw, 'CAVOK') !== false) {
            $dec['clouds'] = 'CAVOK — облаков нет, видимость 10+ км';
        } elseif (stripos($raw, 'NSC') !== false) {
            $dec['clouds'] = 'NSC — существенной облачности нет';
        }
        // Явления погоды
        $ph = self::phenomena($raw);
        if ($ph !== []) {
            $dec['wx'] = implode(', ', $ph);
        }
        // Температура/точка росы
        if (isset($m['temp']) && is_numeric($m['temp'])) {
            $dec['temp'] = (int)$m['temp'] . '°C / точка росы ' . (int)($m['dewp'] ?? 0) . '°C';
        }
        // Давление
        if (isset($m['altim']) && is_numeric($m['altim'])) {
            $dec['qnh'] = 'Q' . (int)$m['altim'] . ' гПа (' . round((float)$m['altim'] * 0.02953, 2) . ' inHg)';
        }
        $cat = ['VFR' => 'VFR — визуальные полёты', 'MVFR' => 'MVFR — граничные визуальные', 'IFR' => 'IFR — приборные', 'LIFR' => 'LIFR — сложные приборные'];
        if (isset($cat[(string)($m['fltCat'] ?? '')])) {
            $dec['fltcat'] = $cat[$m['fltCat']];
        }
        return $dec;
    }

    /** Явления погоды из сырой строки → русский */
    private static function phenomena(string $raw): array
    {
        $dict = [
            'RA' => 'дождь', 'SN' => 'снег', 'SG' => 'снежные зёрна', 'IC' => 'ледяные иглы',
            'GR' => 'град', 'GS' => 'снежная крупа', 'TS' => 'гроза', 'TSRA' => 'гроза с дождём',
            'TSSN' => 'гроза со снегом', 'SHRA' => 'ливневый дождь', 'SHSN' => 'ливневый снег',
            'FG' => 'туман', 'BR' => 'дымка', 'HZ' => 'мгла', 'FU' => 'дым', 'DU' => 'пыль',
            'SA' => 'пыльный песок', 'VA' => 'вулканический пепел', 'SQ' => 'шквал',
            'FC' => 'смерч/торнадо', 'SS' => 'пыльная буря', 'FZFG' => 'переохлаждённый туман',
            'FZRA' => 'переохлаждённый дождь', 'BLSN' => 'низовая метель', 'VCTS' => 'гроза в окрестностях',
            'VCSH' => 'ливень в окрестностях', 'BCFG' => 'поземный туман', 'MIFG' => 'тонкий туман',
        ];
        $out = [];
        if (preg_match_all('~(?:^|\s)([-+]?)(VC)?([A-Z]{2,6})(?=\s|$)~', $raw, $mm, PREG_SET_ORDER)) {
            foreach ($mm as $t) {
                $code = $t[3];
                if (!isset($dict[$code])) { continue; }
                $int = ['-' => 'слабый ', '+' => 'сильный '][$t[1]] ?? '';
                $out[] = $int . $dict[$code];
            }
        }
        return array_slice(array_unique($out), 0, 5);
    }

    /* ---------------- TAF ---------------- */

    /**
     * @return array{ok:bool,icao:string,raw:string,groups:list<array<string,string>>,stale:bool}
     */
    public static function taf(string $icao): array
    {
        $icao = strtoupper(preg_replace('~[^A-Za-z0-9]~', '', $icao) ?? '');
        if ($icao === '' || strlen($icao) !== 4) {
            return ['ok' => false, 'icao' => $icao, 'raw' => '', 'groups' => [], 'stale' => false];
        }
        $key = 'wx_taf_' . $icao;
        $hit = Cache::get($key);
        $json = self::http('https://aviationweather.gov/api/data/taf?ids=' . rawurlencode($icao) . '&format=json');
        if (is_array($json) && isset($json[0]['rawTAF'])) {
            $out = [
                'ok'     => true,
                'icao'   => (string)($json[0]['icaoId'] ?? $icao),
                'raw'    => (string)$json[0]['rawTAF'],
                'groups' => self::splitTaf((string)$json[0]['rawTAF']),
                'stale'  => false,
            ];
            Cache::set($key, $out, self::TAF_TTL);
            return $out;
        }
        if (is_array($hit)) {
            $hit['stale'] = true;
            return $hit;
        }
        return ['ok' => false, 'icao' => $icao, 'raw' => '', 'groups' => [], 'stale' => false];
    }

    /** TAF → группы (базовый блок + FM/BECMG/TEMPO/PROB) с русскими подписями */
    private static function splitTaf(string $raw): array
    {
        $clean = trim(preg_replace('~\s+~', ' ', $raw) ?? '');
        $parts = preg_split('~\s*(?=(?:FM\d{4}|BECMG|TEMPO|PROB\d{2}))~', $clean) ?: [];
        $names = ['FM' => 'с', 'BECMG' => 'постепенно', 'TEMPO' => 'временами', 'PROB' => 'вероятность'];
        $groups = [];
        foreach ($parts as $i => $p) {
            if ($p === '' || str_starts_with($p, 'TAF ')) { continue; }
            $kind = 'base';
            $label = 'основной прогноз';
            if ($i > 0 && preg_match('~^(FM|BECMG|TEMPO|PROB)~', $p, $k)) {
                $kind = $k[1];
                $label = $names[$kind];
                if (preg_match('~(\d{2})/(\d{2})\s+(\d{2})/(\d{2})~', $p, $t)) {
                    $label .= ': с ' . $t[1] . ' ' . $t[2] . '.00 до ' . $t[3] . ' ' . $t[4] . '.00 UTC';
                } elseif (preg_match('~^FM(\d{2})(\d{2})~', $p, $t)) {
                    $label .= ': c ' . $t[1] . ' числа ' . $t[2] . ':00 UTC';
                } elseif (preg_match('~TEMPO\s+(\d{2})/(\d{2})~', $p, $t)) {
                    $label = 'временами: период ' . $t[1] . '/' . $t[2];
                }
            } elseif ($i === 0 && preg_match('~(\d{2})(\d{2})/(\d{2})(\d{2})~', $clean, $t)) {
                $label = 'основной: с ' . $t[1] . ' ' . $t[2] . '.00 до ' . $t[3] . ' ' . $t[4] . '.00 UTC';
            }
            // выжимка явлений/ветра внутри группы
            $hints = [];
            foreach (self::phenomena($p) as $ph) { $hints[] = $ph; }
            if (preg_match('~(?:^|\s)(VRB|\d{3})(\d{2,3})KT~', $p, $w)) {
                $hints[] = 'ветер ' . ($w[1] === 'VRB' ? 'переменный' : $w[1] . '°') . ' ' . (int)$w[2] . ' узл';
            }
            $groups[] = ['kind' => $kind, 'label' => $label, 'raw' => $p, 'hints' => implode(', ', array_slice($hints, 0, 3))];
        }
        return $groups;
    }

    /* ---------------- NOTAM (SkyLink, ключ из админки) ---------------- */

    /**
     * @return array{ok:bool,error?:string,items:list<array<string,mixed>>}
     */
    public static function notam(string $icao): array
    {
        $key = (string)setting('skylink_api_key', '');
        if ($key === '') {
            return ['ok' => false, 'error' => 'no_key', 'items' => []];
        }
        $icao = strtoupper(preg_replace('~[^A-Za-z0-9]~', '', $icao) ?? '');
        $ck = 'wx_notam_' . $icao;
        $hit = Cache::get($ck);
        if (is_array($hit)) {
            return $hit;
        }
        $base = rtrim((string)setting('skylink_api_base', 'https://skylinkapi.com/v3'), '/');
        $json = self::http($base . '/notams/' . rawurlencode($icao), true, $key);
        $items = [];
        if (is_array($json)) {
            $rows = $json['notams'] ?? $json['data'] ?? $json;
            if (is_array($rows)) {
                foreach ((array)$rows as $n) {
                    if (!is_array($n)) { continue; }
                    $items[] = [
                        'id'     => (string)($n['id'] ?? $n['notam_id'] ?? ''),
                        'raw'    => (string)($n['message'] ?? $n['raw'] ?? $n['text'] ?? ''),
                        'type'   => (string)($n['type'] ?? ''),
                        'start'  => (string)($n['effective_start'] ?? $n['start'] ?? ''),
                        'end'    => (string)($n['effective_end'] ?? $n['end'] ?? ''),
                    ];
                }
            }
        }
        $out = $items !== []
            ? ['ok' => true, 'items' => array_slice($items, 0, 30)]
            : ['ok' => false, 'error' => 'source', 'items' => []];
        Cache::set($ck, $out, self::NOTAM_TTL);
        return $out;
    }

    /* ---------------- Веб-камеры (AviationWX, в.278) ---------------- */

    /**
     * Кнопка «живой сети» камер: список аэропортов AviationWX (кэш 24 ч).
     * @return list<array<string,mixed>>
     */
    public static function webcamAirports(): array
    {
        $hit = Cache::get('wx_cam_airports');
        if (is_array($hit)) {
            return $hit;
        }
        $json = self::http('https://api.aviationwx.org/v1/airports');
        $list = [];
        if (is_array($json) && isset($json['airports']) && is_array($json['airports'])) {
            foreach ($json['airports'] as $a) {
                $list[] = [
                    'id'    => (string)($a['id'] ?? ''),
                    'icao'  => (string)($a['icao'] ?? $a['faa'] ?? ''),
                    'iata'  => (string)($a['iata'] ?? ''),
                    'name'  => (string)($a['name'] ?? ''),
                    'lat'   => (float)($a['lat'] ?? 0),
                    'lon'   => (float)($a['lon'] ?? 0),
                ];
            }
        }
        Cache::set('wx_cam_airports', $list, self::CAM_TTL);
        return $list;
    }

    /**
     * Камеры конкретного аэропорта: сеть AviationWX + свои из админки.
     * @return array{net:list<array<string,mixed>>,custom:list<array<string,string>>}
     */
    public static function webcams(string $icao): array
    {
        $icao = strtolower(preg_replace('~[^A-Za-z0-9]~', '', $icao) ?? '');
        $net = [];
        if ($icao !== '') {
            $ck = 'wx_cam_' . $icao;
            $hit = Cache::get($ck);
            if (!is_array($hit)) {
                $hit = [];
                $json = self::http('https://api.aviationwx.org/v1/airports/' . rawurlencode($icao) . '/webcams');
                if (is_array($json) && isset($json['webcams']) && is_array($json['webcams'])) {
                    foreach ($json['webcams'] as $i => $c) {
                        $hit[] = [
                            'name'   => (string)($c['name'] ?? 'Camera ' . $i),
                            'img'    => 'https://api.aviationwx.org' . (string)($c['image_url'] ?? ('/v1/airports/' . $icao . '/webcams/' . $i . '/image')),
                            'heading'=> (int)($c['approximate_heading'] ?? 0),
                            'refresh'=> (int)($c['refresh_seconds'] ?? 60),
                        ];
                    }
                }
                Cache::set($ck, $hit, self::CAM_TTL);
            }
            $net = $hit;
        }
        // Свои камеры: строки «ICAO|Название|URL кадра» в настройках (в.278)
        $custom = [];
        foreach (preg_split('~\R~', (string)setting('webcam_custom', '')) ?: [] as $line) {
            $p = array_map('trim', explode('|', $line));
            if (count($p) >= 3 && strcasecmp($p[0], $icao) === 0) {
                $custom[] = ['name' => $p[1], 'img' => $p[2]];
            }
        }
        return ['net' => $net, 'custom' => $custom];
    }

    /* ---------------- HTTP ---------------- */

    private static function http(string $url, bool $auth = false, string $key = ''): ?array
    {
        $proxyBase = rtrim((string)setting('tg_api_base', 'https://telegram.v7755837.deno.net'), '/');
        $targetUrl = $url;
        if (str_contains($proxyBase, 'deno') && str_starts_with($url, 'https://aviationweather.gov')) {
            $targetUrl = str_replace('https://aviationweather.gov', $proxyBase, $url);
        }
        $ch = curl_init($targetUrl);
        if ($ch === false) { return null; }
        $headers = [
            'X-Service: aviationweather',
            'X-Target-URL: https://aviationweather.gov',
        ];
        if ($auth && $key !== '') {
            $headers[] = 'Authorization: Bearer ' . $key;
            $headers[] = 'Accept: application/json';
        }
        $opts = [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 10,
            CURLOPT_CONNECTTIMEOUT => 6,
            CURLOPT_USERAGENT      => self::UA,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTPHEADER     => $headers,
        ];
        curl_setopt_array($ch, $opts);
        $body = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $err  = curl_error($ch);
        curl_close($ch);
        if ($body === false || $code !== 200) {
            Logger::warning('WxService: источник недоступен', ['url' => $url, 'code' => $code, 'error' => $err]);
            return null;
        }
        $json = json_decode((string)$body, true);
        return is_array($json) ? $json : null;
    }
}
