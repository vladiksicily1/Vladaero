<?php
declare(strict_types=1);

namespace App\Services;

/**
 * Медиатека (в.12–13, 15, 79, 84): загрузка, превью (GD), EXIF, водяной знак.
 * Хранение: uploads/media/YYYYMM/ — оригинал + _thumb превью.
 */
final class MediaService
{
    private const IMAGE_MIMES = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'];
    private const OTHER_MIMES = [
        'video/mp4' => 'video', 'video/webm' => 'video', 'video/quicktime' => 'video',
        'audio/mpeg' => 'audio', 'audio/mp4' => 'audio', 'audio/ogg' => 'audio', 'audio/wav' => 'audio', 'audio/x-m4a' => 'audio',
        'application/pdf' => 'file', 'application/zip' => 'file', 'application/x-zip-compressed' => 'file',
        'application/octet-stream' => 'file', // .glb/.gltf часто без своего MIME
    ];
    public const MAX_FILE_SIZE = 26214400; // 25 МБ (в.84: тяжёлые фото жмём в браузере — сюда приходит уже сжатое)
    public const MAX_ZIP_SIZE  = 52428800; // 50 МБ на архив
    public const MAX_ZIP_FILES = 50;       // и не больше файлов внутри

    /** Расширения, допустимые внутри ZIP (по категориям медиатеки). */
    private const ZIP_OK_EXT = [
        'jpg' => 'image', 'jpeg' => 'image', 'png' => 'image', 'webp' => 'image', 'gif' => 'image',
        'mp4' => 'video', 'webm' => 'video', 'mov' => 'video',
        'mp3' => 'audio', 'm4a' => 'audio', 'ogg' => 'audio', 'wav' => 'audio',
        'pdf' => 'file', 'glb' => 'model3d', 'gltf' => 'model3d',
    ];

    /**
     * Приём файлов из запроса — единая точка (v0.8.2): multipart ($_FILES)
     * ИЛИ JSON с base64: {file:{name,mime,data}} / {files:[{name,data}]} / {name,data}.
     * Возвращает список псевдо-файлов вида $_FILES.
     * @return list<array{name:string,tmp_name:string,size:int,error:int,type:string}>
     */
    public static function filesFromRequest(string $key = 'file'): array
    {
        // 1) обычный multipart
        $f = $_FILES[$key] ?? null;
        if ($f !== null && is_array($f)) {
            // multiple: name[] → несколько
            if (is_array($f['name'] ?? null)) {
                $out = [];
                foreach ($f['name'] as $i => $n) {
                    if (($f['error'][$i] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_OK) {
                        $out[] = ['name' => (string)$n, 'tmp_name' => (string)$f['tmp_name'][$i],
                                  'size' => (int)$f['size'][$i], 'error' => UPLOAD_ERR_OK, 'type' => (string)$f['type'][$i]];
                    }
                }
                return $out;
            }
            return [ ['name' => (string)$f['name'], 'tmp_name' => (string)$f['tmp_name'],
                      'size' => (int)$f['size'], 'error' => (int)($f['error'] ?? 0), 'type' => (string)($f['type'] ?? '')] ];
        }
        // 2) JSON + base64
        $body = \App\Core\Request::rawJson();
        $list = [];
        if (isset($body['files']) && is_array($body['files'])) { $list = $body['files']; }
        elseif (isset($body['file']) && is_array($body['file'])) { $list = [$body['file']]; }
        elseif (isset($body['data']) && is_string($body['data'])) { $list = [$body]; }
        $out = [];
        foreach ($list as $item) {
            if (!is_array($item) || !isset($item['data']) || !is_string($item['data'])) { continue; }
            $name = (string)($item['name'] ?? 'upload.bin');
            // data: URI или чистый base64
            $data = $item['data'];
            if (str_starts_with($data, 'data:')) {
                $data = substr($data, (int)strpos($data, ',') + 1);
            }
            $bin = base64_decode($data, true);
            if ($bin === false || $bin === '') { continue; }
            if (strlen($bin) > self::MAX_ZIP_SIZE) { continue; }
            $tmp = tempnam(sys_get_temp_dir(), 'vab64_');
            if ($tmp === false) { continue; }
            file_put_contents($tmp, $bin);
            $out[] = ['name' => $name, 'tmp_name' => $tmp, 'size' => strlen($bin),
                      'error' => UPLOAD_ERR_OK, 'type' => (string)($item['mime'] ?? '')];
        }
        return $out;
    }

    /**
     * Умная загрузка (v0.8.2): один файл или ZIP-архив (распаковывается,
     * каждый валидный файл внутри проходит обычный конвейер).
     * Возвращает ['ok'=>bool,'mode'=>'single'|'zip','items'=>[],'skipped'=>[['name','reason']],...].
     */
    public static function ingest(array $file, ?int $userId, array $meta = []): array
    {
        $result = ['ok' => false, 'mode' => 'single', 'items' => [], 'skipped' => [], 'media' => null, 'error' => null];
        $isZip = self::looksLikeZip($file);
        if (!$isZip) {
            try {
                $row = self::upload($file, $userId, $meta);
                $result['ok'] = true;
                $result['items'][] = $row;
                $result['media'] = $row;
            } catch (\RuntimeException $e) {
                $result['error'] = $e->getMessage();
            }
            return $result;
        }
        // ZIP: распаковываем
        $result['mode'] = 'zip';
        if (!class_exists('ZipArchive')) {
            $result['error'] = 'На сервере нет расширения ZipArchive — распаковка недоступна, загрузите файлы по одному.';
            return $result;
        }
        if (($file['size'] ?? 0) > self::MAX_ZIP_SIZE) {
            $result['error'] = 'Архив больше ' . intdiv(self::MAX_ZIP_SIZE, 1048576) . ' МБ.';
            return $result;
        }
        $za = new \ZipArchive();
        if ($za->open($file['tmp_name']) !== true) {
            $result['error'] = 'Не удалось открыть ZIP-архив (файл повреждён?).';
            return $result;
        }
        $tmpDir = sys_get_temp_dir() . '/va_zip_' . bin2hex(random_bytes(6));
        if (!@mkdir($tmpDir, 0755, true)) {
            $za->close();
            $result['error'] = 'Не удалось создать временный каталог.';
            return $result;
        }
        $taken = 0;
        for ($i = 0; $i < $za->numFiles; $i++) {
            $entry = (string)$za->getNameIndex($i);
            $base = basename($entry);
            if ($base === '' || str_starts_with($entry, '__MACOSX') || str_starts_with($base, '.')) { continue; }
            if (substr($entry, -1) === '/') { continue; } // каталог
            $ext = strtolower(pathinfo($base, PATHINFO_EXTENSION));
            if (!isset(self::ZIP_OK_EXT[$ext])) {
                $result['skipped'][] = ['name' => $base, 'reason' => 'тип не поддерживается'];
                continue;
            }
            if ($taken >= self::MAX_ZIP_FILES) {
                $result['skipped'][] = ['name' => $base, 'reason' => 'лимит ' . self::MAX_ZIP_FILES . ' файлов'];
                continue;
            }
            $abs = $tmpDir . '/' . md5($entry) . '.' . $ext;
            $stream = $za->getStream($entry);
            if ($stream === false) { $result['skipped'][] = ['name' => $base, 'reason' => 'не читается']; continue; }
            file_put_contents($abs, $stream);
            fclose($stream);
            if (filesize($abs) > self::MAX_FILE_SIZE) {
                $result['skipped'][] = ['name' => $base, 'reason' => 'больше 25 МБ'];
                @unlink($abs);
                continue;
            }
            $pseudo = ['name' => $base, 'tmp_name' => $abs, 'size' => (int)filesize($abs), 'error' => UPLOAD_ERR_OK, 'type' => ''];
            try {
                $row = self::upload($pseudo, $userId, $meta);
                $result['items'][] = $row;
                $taken++;
            } catch (\RuntimeException $e) {
                $result['skipped'][] = ['name' => $base, 'reason' => $e->getMessage()];
            }
        }
        $za->close();
        foreach (glob($tmpDir . '/*') ?: [] as $t) { @unlink($t); }
        @rmdir($tmpDir);
        $result['ok'] = $result['items'] !== [];
        if (!$result['ok']) {
            $result['error'] = 'В архиве не нашлось подходящих файлов (jpg/png/webp/gif, mp4/webm/mov, mp3/m4a/ogg/wav, pdf, glb/gltf).';
        }
        $result['media'] = $result['items'][0] ?? null;
        return $result;
    }

    /** ZIP ли это (по MIME или расширению). */
    private static function looksLikeZip(array $file): bool
    {
        $mime = (string)($file['type'] ?? '');
        if (in_array($mime, ['application/zip', 'application/x-zip-compressed'], true)) { return true; }
        if (preg_match('~\.zip$~i', (string)$file['name'])) {
            $fi = new \finfo(FILEINFO_MIME_TYPE);
            $real = (string)$fi->file($file['tmp_name']);
            return in_array($real, ['application/zip', 'application/x-zip-compressed'], true);
        }
        return false;
    }

    /** Загрузка одного файла. Возвращает массив записи media или бросает исключение. */
    public static function upload(array $file, ?int $userId, array $meta = []): array
    {
        if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            throw new \RuntimeException('Ошибка загрузки файла (код ' . (int)($file['error'] ?? -1) . ')');
        }
        if (($file['size'] ?? 0) === 0) { $file['size'] = (int)@filesize($file['tmp_name']); }
        if (($file['size'] ?? 0) > self::MAX_FILE_SIZE) {
            throw new \RuntimeException('Файл больше 25 МБ. Сожмите фото в браузере (загрузчик v0.4) или уменьшите файл.');
        }
        $fi = new \finfo(FILEINFO_MIME_TYPE);
        $mime = (string)$fi->file($file['tmp_name']);

        $isImage = isset(self::IMAGE_MIMES[$mime]);
        $kind = $meta['kind'] ?? null;
        if (!$isImage) {
            $kind ??= self::OTHER_MIMES[$mime] ?? null;
            // .glb/.gltf проверяем по расширению
            if ($kind === 'file' && preg_match('#\.(glb|gltf)$#i', (string)$file['name'])) {
                $kind = 'model3d';
            }
            if ($kind === null) {
                throw new \RuntimeException('Тип файла не поддерживается: ' . $mime);
            }
        } else {
            $kind = 'image';
        }

        $relDir = 'uploads/media/' . date('Ym');
        $absDir = VA_ROOT . '/' . $relDir;
        if (!is_dir($absDir) && !@mkdir($absDir, 0755, true)) {
            throw new \RuntimeException('Не удалось создать каталог медиа — проверьте права uploads/');
        }
        $safeName = date('His') . '-' . substr(bin2hex(random_bytes(5)), 0, 8);
        $ext = $isImage ? self::IMAGE_MIMES[$mime] : strtolower(pathinfo((string)$file['name'], PATHINFO_EXTENSION) ?: 'bin');
        $name = $safeName . '.' . $ext;
        $abs = $absDir . '/' . $name;
        $moved = is_uploaded_file($file['tmp_name'])
            ? move_uploaded_file($file['tmp_name'], $abs)
            : (@rename($file['tmp_name'], $abs) || @copy($file['tmp_name'], $abs) && @unlink($file['tmp_name']));
        if (!$moved) {
            throw new \RuntimeException('Не удалось сохранить файл на диске');
        }
        @chmod($abs, 0644);

        $width = $height = 0;
        $exif = null;
        $thumbRel = null;
        $watermarked = false;

        if ($isImage) {
            $info = @getimagesize($abs);
            if ($info !== false) {
                [$width, $height] = $info;
            }
            $exif = self::extractExif($abs, $mime);
            if (self::imageOk($abs, $mime)) {
                if ((string)setting('media_watermark', '1') === '1' && $kind === 'image') {
                    $watermarked = self::watermark($abs, $mime);
                }
                $thumbRel = self::makeThumb($absDir, $name, $mime) ?? null;
            }
        }

        $id = \App\Core\Database::i()->insert('media', [
            'user_id'     => $userId,
            'kind'        => $kind,
            'filename'    => $name,
            'original_name' => substr((string)$file['name'], 0, 255),
            'path'        => $relDir . '/' . $name,
            'thumb_path'  => $thumbRel,
            'width'       => $width ?: null,
            'height'      => $height ?: null,
            'size'        => (int)($file['size'] ?? 0),
            'mime'        => substr($mime, 0, 100),
            'exif'        => $exif !== null ? json_encode($exif, JSON_UNESCAPED_UNICODE) : null,
            'alt'         => substr((string)($meta['alt'] ?? ''), 0, 255),
            'credit'      => substr((string)($meta['credit'] ?? ''), 0, 190),
            'license'     => substr((string)($meta['license'] ?? 'ARR'), 0, 64),
            'created_at'  => date('Y-m-d H:i:s'),
        ]);

        $row = \App\Core\Database::i()->one('SELECT * FROM `{p}media` WHERE id = ?', [$id]);
        $row['watermarked'] = $watermarked;
        return $row;
    }

    /** Ключевые EXIF-параметры съёмки (в.12) */
    private static function extractExif(string $abs, string $mime): ?array
    {
        if ($mime !== 'image/jpeg' || !function_exists('exif_read_data')) {
            return null;
        }
        $ex = @exif_read_data($abs, 'EXIF', false);
        if (!is_array($ex)) {
            return null;
        }
        $get = static fn(string $k) => isset($ex[$k]) && is_scalar($ex[$k]) ? (string)$ex[$k] : null;
        $out = array_filter([
            'camera'  => $get('Model'),
            'lens'    => $get('LensModel') ?? $get('LensMake'),
            'focal'   => $get('FocalLength'),
            'fnumber' => $get('FNumber'),
            'exposure'=> $get('ExposureTime'),
            'iso'     => $get('ISOSpeedRatings'),
            'taken'   => $get('DateTimeOriginal'),
        ], static fn($v) => $v !== null);
        return $out !== [] ? $out : null;
    }

    private static function imageOk(string $abs, string $mime): bool
    {
        if (!function_exists('imagecreatefromstring')) {
            return false;
        }
        $data = @file_get_contents($abs);
        return $data !== false && @imagecreatefromstring($data) !== false;
    }

    /** Водяной знак (в.13): имя портала внизу справа */
    private static function watermark(string $abs, string $mime): bool
    {
        $img = @imagecreatefromstring((string)@file_get_contents($abs));
        if ($img === false) {
            return false;
        }
        $w = imagesx($img);
        $h = imagesy($img);
        $font = 4; // встроенный шрифт GD
        $text = '© ' . ((string)setting('site_name', 'VladAero'));
        $tw = imagefontwidth($font) * strlen($text);
        $scale = max(1, (int)($w / 640));
        $font = min(5, 2 + $scale);
        $tw = imagefontwidth($font) * strlen($text);
        $color = imagecolorallocatealpha($img, 232, 241, 255, 55);
        imagestring($img, $font, $w - $tw - 10, $h - imagefontheight($font) - 10, $text, $color);
        $ok = match ($mime) {
            'image/jpeg' => imagejpeg($img, $abs, 90),
            'image/png'  => imagepng($img, $abs, 8),
            'image/webp' => function_exists('imagewebp') ? imagewebp($img, $abs, 90) : false,
            default => false,
        };
        imagedestroy($img);
        return (bool)$ok;
    }

    /** Превью шириной 480px (WebP при поддержке, иначе исходный формат) */
    private static function makeThumb(string $absDir, string $name, string $mime): ?string
    {
        $img = @imagecreatefromstring((string)@file_get_contents($absDir . '/' . $name));
        if ($img === false) {
            return null;
        }
        $w = imagesx($img);
        $h = imagesy($img);
        $tw = 480;
        if ($w <= $tw) {
            imagedestroy($img);
            return null; // мелкое изображение — превью не нужно
        }
        $th = (int)round($h * $tw / $w);
        $thumb = imagecreatetruecolor($tw, $th);
        imagecopyresampled($thumb, $img, 0, 0, 0, 0, $tw, $th, $w, $h);
        $thumbName = basename($name, '.' . pathinfo($name, PATHINFO_EXTENSION)) . '_t.webp';
        $ok = false;
        if (function_exists('imagewebp')) {
            $ok = imagewebp($thumb, $absDir . '/' . $thumbName, 82);
        }
        if (!$ok) {
            $thumbName = str_replace('.webp', '.jpg', $thumbName);
            $ok = imagejpeg($thumb, $absDir . '/' . $thumbName, 82);
        }
        imagedestroy($img);
        imagedestroy($thumb);
        return $ok ? 'uploads/media/' . date('Ym') . '/' . $thumbName : null;
    }

    /** Удаляет файлы записи */
    public static function deleteFiles(array $row): void
    {
        foreach (['path', 'thumb_path'] as $k) {
            $rel = $row[$k] ?? null;
            if (is_string($rel) && $rel !== '') {
                $abs = VA_ROOT . '/' . $rel;
                if (str_starts_with(realpath($abs) ?: '', VA_ROOT . '/uploads/')) {
                    @unlink($abs);
                }
            }
        }
    }
}
