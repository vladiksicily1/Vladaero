<?php
declare(strict_types=1);

namespace App\Services;

/**
 * Работа с LLM-провайдерами (OpenAI-совместимый протокол).
 * Любой Base URL + Model ID + Fetch /v1/models (вопросы 151, 186).
 * Полноценный чат с SSE-стримингом и function calling — v0.5.
 */
final class AiService
{
    private const ATTEMPTS = 3; // повторные попытки (вопрос 179)

    /**
     * Список моделей провайдера: GET {base}/models с Bearer-ключом.
     * @return list<string>
     * @throws \RuntimeException с понятным сообщением
     */
    public static function listModels(string $baseUrl, string $apiKey): array
    {
        $url = rtrim($baseUrl, '/');
        if (!str_ends_with($url, '/models')) {
            $url .= str_ends_with($url, '/v1') ? '/models' : '/v1/models';
        }

        $lastError = '';
        $delay = 1;
        for ($i = 1; $i <= self::ATTEMPTS; $i++) {
            $res = self::httpGet($url, $apiKey);
            if ($res['ok']) {
                $data = json_decode($res['body'], true);
                $list = $data['data'] ?? $data['models'] ?? null;
                if (!is_array($list)) {
                    throw new \RuntimeException('Провайдер вернул неожиданный формат ответа (нет поля data/models)');
                }
                $ids = [];
                foreach ($list as $m) {
                    $id = is_array($m) ? ($m['id'] ?? null) : (is_string($m) ? $m : null);
                    if (is_string($id) && $id !== '') {
                        $ids[] = $id;
                    }
                }
                if ($ids === []) {
                    throw new \RuntimeException('Провайдер вернул пустой список моделей');
                }
                sort($ids, SORT_NATURAL | SORT_FLAG_CASE);
                return array_values(array_unique($ids));
            }
            $lastError = $res['error'];
            if ($i < self::ATTEMPTS) {
                sleep($delay);
                $delay *= 2; // экспоненциальная пауза (вопрос 304)
            }
        }
        throw new \RuntimeException($lastError !== '' ? $lastError : 'Не удалось связаться с провайдером');
    }

    /** @return array{ok:bool,body:string,error:string,code:int} */
    private static function httpGet(string $url, string $apiKey): array
    {
        $ch = curl_init($url);
        if ($ch === false) {
            return ['ok' => false, 'body' => '', 'error' => 'cURL недоступен', 'code' => 0];
        }
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 20,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_HTTPHEADER     => [
                'Authorization: Bearer ' . $apiKey,
                'Accept: application/json',
                'X-Service: openai',
                'X-Target-URL: https://api.openai.com',
            ],
            CURLOPT_USERAGENT      => 'VladAero/' . VA_VERSION,
        ]);
        $body = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $err  = curl_error($ch);
        curl_close($ch);

        if ($body === false) {
            return ['ok' => false, 'body' => '', 'error' => 'Сеть: ' . ($err ?: 'нет ответа'), 'code' => $code];
        }
        if ($code === 401 || $code === 403) {
            return ['ok' => false, 'body' => (string)$body, 'error' => 'Ключ отклонён провайдером (HTTP ' . $code . ')', 'code' => $code];
        }
        if ($code >= 400) {
            return ['ok' => false, 'body' => (string)$body, 'error' => 'HTTP ' . $code, 'code' => $code];
        }
        return ['ok' => true, 'body' => (string)$body, 'error' => '', 'code' => $code];
    }

    /* ============================================================
     * Чат (в.573, 689): стриминг SSE OpenAI-совместимого протокола.
     * Ответы ИИ никогда не кэшируются (спецификация).
     * ============================================================ */

    public static function enabled(): bool
    {
        return (string)setting('ai_base_url', '') !== '' && (string)setting('ai_api_key', '') !== '';
    }

    private static function chatUrl(): string
    {
        $url = rtrim((string)setting('ai_base_url', ''), '/');
        if (!str_ends_with($url, '/chat/completions')) {
            $url .= str_ends_with($url, '/v1') ? '/chat/completions' : '/v1/chat/completions';
        }
        return $url;
    }

    /**
     * Нестриминговый запрос (пакетная генерация, Telegram-команды).
     * @param list<array{role:string,content:string}> $messages
     * @return array{ok:bool,content:string,error:string,usage:array<string,int>}
     */
    public static function chat(array $messages, ?float $temperature = null, int $maxTokens = 2000): array
    {
        if (!self::enabled()) {
            return ['ok' => false, 'content' => '', 'error' => 'ИИ не настроен: задайте Base URL и ключ в Админке → Настройки → ИИ', 'usage' => []];
        }
        $payload = [
            'model'       => (string)setting('ai_model', 'gpt-4o-mini'),
            'messages'    => $messages,
            'max_tokens'  => $maxTokens,
            'temperature' => $temperature ?? (float)setting('ai_temperature', '0.7'),
        ];
        $last = '';
        for ($i = 1; $i <= self::ATTEMPTS; $i++) { // в.179: 3 попытки
            $res = self::httpPostJson(self::chatUrl(), $payload, false);
            if ($res['ok']) {
                $json = json_decode($res['body'], true);
                $content = $json['choices'][0]['message']['content'] ?? null;
                if (is_string($content)) {
                    return ['ok' => true, 'content' => $content, 'error' => '',
                        'usage' => [
                            'prompt_tokens' => (int)($json['usage']['prompt_tokens'] ?? 0),
                            'completion_tokens' => (int)($json['usage']['completion_tokens'] ?? 0),
                        ]];
                }
                $last = 'провайдер вернул неожиданный формат ответа';
            } else {
                $last = $res['error'];
            }
            if ($i < self::ATTEMPTS) { usleep(500000 * $i); }
        }
        return ['ok' => false, 'content' => '', 'error' => $last, 'usage' => []];
    }

    /**
     * Стриминговый запрос: вызывает $onEvent('reasoning'|'content', $deltaChunk)
     * по мере поступления. Возвращает финальный текст и usage.
     * @param callable(string,string):void $onEvent
     * @return array{ok:bool,content:string,error:string,usage:array<string,int>}
     */
    public static function chatStream(array $messages, callable $onEvent, ?float $temperature = null, int $maxTokens = 3000): array
    {
        if (!self::enabled()) {
            return ['ok' => false, 'content' => '', 'error' => 'ИИ не настроен (Админка → Настройки → ИИ)', 'usage' => []];
        }
        $payload = [
            'model'       => (string)setting('ai_model', 'gpt-4o-mini'),
            'messages'    => $messages,
            'stream'      => true,
            'max_tokens'  => $maxTokens,
            'temperature' => $temperature ?? (float)setting('ai_temperature', '0.7'),
        ];
        $last = '';
        for ($i = 1; $i <= self::ATTEMPTS; $i++) {
            $res = self::streamOnce(self::chatUrl(), $payload, $onEvent);
            if ($res['ok'] || $res['started']) {
                return $res + ['usage' => $res['usage'] ?? []]; // стрим начался — ретраев не делаем
            }
            $last = $res['error'];
            if ($i < self::ATTEMPTS) { usleep(500000 * $i); }
        }
        return ['ok' => false, 'content' => '', 'error' => $last, 'usage' => []];
    }

    /** @return array{ok:bool,started:bool,content:string,error:string,usage:array<string,int>} */
    private static function streamOnce(string $url, array $payload, callable $onEvent): array
    {
        $started = false;
        $content = '';
        $usage = ['prompt_tokens' => 0, 'completion_tokens' => 0];
        $buffer = '';

        $ch = curl_init($url);
        if ($ch === false) {
            return ['ok' => false, 'started' => false, 'content' => '', 'error' => 'cURL недоступен', 'usage' => $usage];
        }
        $cb = static function ($ch, string $data) use (&$buffer, &$content, &$usage, &$started, $onEvent): int {
            $started = true;
            $buffer .= $data;
            while (($pos = strpos($buffer, "\n")) !== false) {
                $line = trim(substr($buffer, 0, $pos));
                $buffer = substr($buffer, $pos + 1);
                if ($line === '' || !str_starts_with($line, 'data:')) { continue; }
                $json = substr($line, 5);
                if ($json === '[DONE]') { continue; }
                $d = json_decode((string)$json, true);
                if (!is_array($d)) { continue; }
                if (isset($d['usage']) && is_array($d['usage'])) {
                    $usage['prompt_tokens'] = (int)($d['usage']['prompt_tokens'] ?? 0);
                    $usage['completion_tokens'] = (int)($d['usage']['completion_tokens'] ?? 0);
                }
                $delta = $d['choices'][0]['delta'] ?? [];
                if (!is_array($delta)) { continue; }
                // reasoning-модели: DeepSeek/Ollama шлют reasoning_content, OpenAI-совместимые — reasoning
                foreach (['reasoning_content', 'reasoning'] as $rk) {
                    if (isset($delta[$rk]) && is_string($delta[$rk]) && $delta[$rk] !== '') {
                        $onEvent('reasoning', $delta[$rk]);
                    }
                }
                if (isset($delta['content']) && is_string($delta['content']) && $delta['content'] !== '') {
                    $content .= $delta['content'];
                    $onEvent('content', $delta['content']);
                }
            }
            return strlen($data);
        };
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,   // флаг нужен для WRITEFUNCTION-потока
            CURLOPT_TIMEOUT        => 120,
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_HTTPHEADER     => [
                'Authorization: Bearer ' . (string)setting('ai_api_key', ''),
                'Content-Type: application/json',
                'Accept: text/event-stream',
                'X-Service: openai',
                'X-Target-URL: https://api.openai.com',
            ],
            CURLOPT_USERAGENT      => 'VladAero/' . VA_VERSION,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => json_encode($payload, JSON_UNESCAPED_UNICODE),
            CURLOPT_WRITEFUNCTION  => $cb,
        ]);
        $body = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $err  = curl_error($ch);
        curl_close($ch);
        unset($body);

        if ($code >= 400 || ($err !== '' && !$started)) {
            return ['ok' => false, 'started' => false, 'content' => $content,
                'error' => $err !== '' ? 'Сеть: ' . $err : 'HTTP ' . $code, 'usage' => $usage];
        }
        return ['ok' => true, 'started' => true, 'content' => $content, 'error' => '', 'usage' => $usage];
    }

    /** @return array{ok:bool,body:string,error:string,code:int} */
    private static function httpPostJson(string $url, array $payload, bool $stream): array
    {
        $ch = curl_init($url);
        if ($ch === false) {
            return ['ok' => false, 'body' => '', 'error' => 'cURL недоступен', 'code' => 0];
        }
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 90,
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_HTTPHEADER     => [
                'Authorization: Bearer ' . (string)setting('ai_api_key', ''),
                'Content-Type: application/json',
                'Accept: ' . ($stream ? 'text/event-stream' : 'application/json'),
                'X-Service: openai',
                'X-Target-URL: https://api.openai.com',
            ],
            CURLOPT_USERAGENT => 'VladAero/' . VA_VERSION,
            CURLOPT_POST      => true,
            CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE),
        ]);
        $body = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $err  = curl_error($ch);
        curl_close($ch);
        if ($body === false) { return ['ok' => false, 'body' => '', 'error' => 'Сеть: ' . ($err ?: 'нет ответа'), 'code' => $code]; }
        if ($code !== 200) { return ['ok' => false, 'body' => (string)$body, 'error' => 'HTTP ' . $code, 'code' => $code]; }
        return ['ok' => true, 'body' => (string)$body, 'error' => '', 'code' => $code];
    }
}
