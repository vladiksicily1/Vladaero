<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database;

/**
 * Сообщество (в.26–28): очки активности, авиационные ранги «Курсант → КВС», ачивки.
 */
final class CommunityService
{
    /** Ранги: минимум очков → [значок, название] */
    private const RANKS = [
        0    => ['✧', 'Курсант'],
        50   => ['✧✧', 'Слушатель'],
        150  => ['▲', 'Второй пилот'],
        400  => ['▲▲', 'Первый пилот'],
        800  => ['★', 'КВС'],
        1500 => ['★★', 'Командир-наставник'],
    ];

    public static function points(int $userId): int
    {
        $photos = (int)Database::i()->val('SELECT COUNT(*) FROM `{p}photos` WHERE user_id = ? AND status = "approved"', [$userId]);
        $articles = (int)Database::i()->val('SELECT COUNT(*) FROM `{p}articles` WHERE author_id = ? AND status = "published"', [$userId]);
        $comments = (int)Database::i()->val('SELECT COUNT(*) FROM `{p}comments` WHERE user_id = ? AND status = "approved"', [$userId]);
        $lessons = (int)Database::i()->val('SELECT COUNT(*) FROM `{p}lesson_progress` WHERE user_id = ?', [$userId]);
        $likes = (int)Database::i()->val(
            'SELECT COALESCE(SUM(p.likes),0) FROM `{p}photos` p WHERE p.user_id = ? AND p.status = "approved"', [$userId]);
        return $photos * 5 + $articles * 5 + $comments + $lessons * 2 + intdiv($likes, 5);
    }

    /** @return array{badge:string,title:string,points:int,next:?array{points:int,title:string}} */
    public static function rank(int $points): array
    {
        $current = self::RANKS[0];
        $next = null;
        foreach (self::RANKS as $min => $r) {
            if ($points >= $min) { $current = $r; }
            elseif ($next === null) { $next = ['points' => $min, 'title' => $r[1]]; }
        }
        return [
            'badge' => $current[0], 'title' => $current[1], 'points' => $points,
            'next' => $next,
        ];
    }

    /** Ачивки пользователя (в.26) — вычисляются на лету */
    public static function badges(int $userId): array
    {
        $out = [];
        $photos = (int)Database::i()->val('SELECT COUNT(*) FROM `{p}photos` WHERE user_id = ? AND status = "approved"', [$userId]);
        $comments = (int)Database::i()->val('SELECT COUNT(*) FROM `{p}comments` WHERE user_id = ? AND status = "approved"', [$userId]);
        $lessons = (int)Database::i()->val('SELECT COUNT(*) FROM `{p}lesson_progress` WHERE user_id = ?', [$userId]);
        $clubs = (int)Database::i()->val('SELECT COUNT(*) FROM `{p}club_members` WHERE user_id = ?', [$userId]);
        if ($photos >= 1) { $out[] = ['📷', 'Первый кадр', 'фото прошло скрининг']; }
        if ($photos >= 10) { $out[] = ['📸', 'Серийный споттер', '10+ фото в галерее']; }
        if ($photos >= 50) { $out[] = ['🎞', 'Фотограф года', '50+ фото в галерее']; }
        if ($comments >= 25) { $out[] = ['💬', 'Голос сообщества', '25+ комментариев']; }
        if ($lessons >= 3) { $out[] = ['🎓', 'Ученик', '3+ урока школы']; }
        if ($lessons >= 9) { $out[] = ['🎓✦', 'Выпускник школы', 'вся программа пройдена']; }
        if ($clubs >= 1) { $out[] = ['☰', 'Клубный', 'состоит в клубе']; }
        return $out;
    }
}
