<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database;
use App\Models\Notification;
use App\Services\PushService;

/**
 * Соцконтур v0.8.1: подписки на авторов + личная переписка.
 */
final class SocialService
{
    /* ===================== Подписки на авторов ===================== */

    public static function toggleFollow(int $userId, int $authorId): bool
    {
        if ($userId === 0 || $authorId === 0 || $userId === $authorId) { return false; }
        $db = Database::i();
        $exists = $db->one('SELECT id FROM `{p}author_follows` WHERE user_id = ? AND author_id = ?', [$userId, $authorId]);
        if ($exists !== null) {
            $db->run('DELETE FROM `{p}author_follows` WHERE user_id = ? AND author_id = ?', [$userId, $authorId]);
            return false;
        }
        $db->insert('author_follows', [
            'user_id' => $userId, 'author_id' => $authorId, 'created_at' => date('Y-m-d H:i:s'),
        ]);
        return true;
    }

    public static function isFollowing(int $userId, int $authorId): bool
    {
        if ($userId === 0) { return false; }
        return Database::i()->one('SELECT id FROM `{p}author_follows` WHERE user_id = ? AND author_id = ?', [$userId, $authorId]) !== null;
    }

    /** @return int[] */
    public static function followingIds(int $userId): array
    {
        return array_map('intval', array_column(Database::i()->all(
            'SELECT author_id FROM `{p}author_follows` WHERE user_id = ?', [$userId]), 'author_id'));
    }

    public static function followersCount(int $authorId): int
    {
        return (int)Database::i()->val('SELECT COUNT(*) FROM `{p}author_follows` WHERE author_id = ?', [$authorId]);
    }

    /** Лента: новые материалы всех подписок (статьи). */
    public static function feed(int $userId, int $limit = 20): array
    {
        $ids = self::followingIds($userId);
        if ($ids === []) { return []; }
        $in = implode(',', array_map('intval', $ids));
        return Database::i()->all(
            "SELECT a.id, a.slug, a.title_ru, a.excerpt_ru, a.published_at, a.views, u.username AS author, u.id AS author_id
             FROM `{p}articles` a JOIN `{p}users` u ON u.id = a.author_id
             WHERE a.author_id IN ($in) AND a.status = 'published'
             ORDER BY a.published_at DESC LIMIT " . (int)$limit);
    }

    /** Оповестить подписчиков автора о новой статье (колокольчик + Web Push). */
    public static function notifyFollowers(int $authorId, string $title, string $slug): void
    {
        if ($authorId === 0) { return; }
        $ids = array_map('intval', array_column(Database::i()->all(
            'SELECT user_id FROM `{p}author_follows` WHERE author_id = ?', [$authorId]), 'user_id'));
        foreach ($ids as $uid) {
            Notification::push($uid, 'article_new', ['preview' => mb_substr($title, 0, 80), 'slug' => $slug]);
        }
        if ($ids === []) { return; }
        $in = implode(',', $ids);
        $rows = Database::i()->all("SELECT * FROM `{p}push_subscriptions` WHERE user_id IN ($in) LIMIT 500");
        foreach ($rows as $row) {
            PushService::send($row);
        }
    }

    /* ===================== Личные сообщения ===================== */

    public static function sendDm(int $from, int $to, string $body): bool
    {
        $body = trim($body);
        if ($from === 0 || $to === 0 || $from === $to || $body === '' || mb_strlen($body) > 4000) { return false; }
        $exists = Database::i()->one('SELECT id FROM `{p}users` WHERE id = ?', [$to]);
        if ($exists === null) { return false; }
        Database::i()->insert('dm', [
            'from_user' => $from, 'to_user' => $to,
            'body' => $body, 'created_at' => date('Y-m-d H:i:s'),
        ]);
        $login = (string)Database::i()->val('SELECT username FROM `{p}users` WHERE id = ?', [$from]);
        Notification::push($to, 'dm', ['from_id' => $from, 'from' => $login, 'preview' => mb_substr($body, 0, 80)]);
        return true;
    }

    /** Список диалогов: собеседник, последнее сообщение, непрочитано. */
    public static function dialogs(int $userId): array
    {
        $rows = Database::i()->all(
            'SELECT LEAST(from_user,to_user) AS a, GREATEST(from_user,to_user) AS b
             FROM `{p}dm` WHERE from_user = ? OR to_user = ?
             GROUP BY a, b', [$userId, $userId]);
        $out = [];
        foreach ($rows as $r) {
            $peer = (int)$r['a'] === $userId ? (int)$r['b'] : (int)$r['a'];
            $last = Database::i()->one(
                'SELECT d.*, u.username, u.avatar FROM `{p}dm` d JOIN `{p}users` u ON u.id = d.from_user
                 WHERE (d.from_user = ? AND d.to_user = ?) OR (d.from_user = ? AND d.to_user = ?)
                 ORDER BY d.id DESC LIMIT 1', [$userId, $peer, $peer, $userId]);
            if ($last === null) { continue; }
            $peerRow = Database::i()->one('SELECT id, username, avatar FROM `{p}users` WHERE id = ?', [$peer]);
            $unread = (int)Database::i()->val(
                'SELECT COUNT(*) FROM `{p}dm` WHERE to_user = ? AND from_user = ? AND read_at IS NULL', [$userId, $peer]);
            $out[] = [
                'peer' => $peerRow, 'last' => $last, 'unread' => $unread,
                'mine' => (int)$last['from_user'] === $userId,
            ];
        }
        usort($out, static fn($x, $y) => $y['last']['id'] <=> $x['last']['id']);
        return $out;
    }

    public static function thread(int $userId, int $peerId, int $limit = 100): array
    {
        return Database::i()->all(
            'SELECT d.id, d.from_user, d.to_user, d.body, d.created_at, d.read_at
             FROM `{p}dm` d
             WHERE (d.from_user = ? AND d.to_user = ?) OR (d.from_user = ? AND d.to_user = ?)
             ORDER BY d.id DESC LIMIT ' . (int)$limit, [$userId, $peerId, $peerId, $userId]);
    }

    public static function markRead(int $userId, int $peerId): void
    {
        Database::i()->run(
            'UPDATE `{p}dm` SET read_at = NOW() WHERE to_user = ? AND from_user = ? AND read_at IS NULL',
            [$userId, $peerId]);
    }

    public static function unreadDm(int $userId): int
    {
        return (int)Database::i()->val('SELECT COUNT(*) FROM `{p}dm` WHERE to_user = ? AND read_at IS NULL', [$userId]);
    }
}
