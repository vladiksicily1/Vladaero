<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database;

/**
 * Резервное копирование: чистый SQL-дамп всех таблиц проекта (вопрос 126).
 * Без exec()/mysqldump — работает на любом shared-хостинге.
 */
final class BackupService
{
    /** Стримит SQL-дамп в браузер как вложение */
    public static function stream(): never
    {
        $db = Database::i();
        $prefix = '';
        $c = require VA_APP . '/config/database.php';
        $prefix = (string)($c['prefix'] ?? '');

        $name = 'vladaero-db-' . date('Ymd-His') . '.sql';
        header('Content-Type: application/sql; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $name . '"');
        header('X-Accel-Buffering: no');

        $out = self::header($prefix);
        $tables = $db->tablesLike($prefix);
        foreach ($tables as $table) {
            $out .= "\n-- ---- $table ----\n";
            $create = $db->pdo()->query("SHOW CREATE TABLE `$table`")->fetch();
            $out .= "DROP TABLE IF EXISTS `$table`;\n" . ($create['Create Table'] ?? '') . ";\n\n";

            $total = (int)$db->pdo()->query("SELECT COUNT(*) FROM `$table`")->fetchColumn();
            if ($total === 0) {
                continue;
            }
            $cols = $db->pdo()->query("SHOW COLUMNS FROM `$table`")->fetchAll(\PDO::FETCH_COLUMN);
            $hasId = in_array('id', $cols, true);

            $dumpRows = function (array $fetched) use (&$out, $db, $table): void {
                foreach ($fetched as $row) {
                    $vals = [];
                    foreach ($row as $v) {
                        $vals[] = $v === null ? 'NULL' : $db->pdo()->quote((string)$v);
                    }
                    $out .= "INSERT INTO `$table` VALUES (" . implode(', ', $vals) . ");\n";
                }
                if (strlen($out) > 65536) {
                    echo $out;
                    $out = '';
                    if (function_exists('flush')) {
                        flush();
                    }
                }
            };

            if ($hasId) {
                // Постраничная выборка по первичному ключу, чтобы не жечь память
                $lastId = 0;
                while (true) {
                    $rows = $db->pdo()->prepare("SELECT * FROM `$table` WHERE id > ? ORDER BY id LIMIT 500");
                    $rows->execute([$lastId]);
                    $fetched = $rows->fetchAll(\PDO::FETCH_ASSOC);
                    if ($fetched === []) {
                        break;
                    }
                    $dumpRows($fetched);
                    $lastId = (int)($fetched[count($fetched) - 1]['id']);
                    if (count($fetched) < 500) {
                        break;
                    }
                }
            } else {
                // Таблицы без id (например, settings) — снимок целиком
                $dumpRows($db->pdo()->query("SELECT * FROM `$table`")->fetchAll(\PDO::FETCH_ASSOC));
            }
            $out .= "\n";
        }
        $out .= self::footer();
        echo $out;
        exit;
    }

    private static function header(string $prefix): string
    {
        return "-- VladAero SQL-дамп\n-- Дата: " . date('Y-m-d H:i:s') .
             "\n-- Префикс таблиц: `$prefix`\n-- Кодировка: utf8mb4_unicode_ci\n" .
             "SET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS = 0;\n";
    }

    private static function footer(): string
    {
        return "\nSET FOREIGN_KEY_CHECKS = 1;\n-- Конец дампа VladAero\n";
    }
}
