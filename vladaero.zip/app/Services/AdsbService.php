<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Cache;
use App\Core\Logger;

/**
 * ADS-B снимок неба для радара (в.16–20, 282–295).
 * OpenSky Network (основной, без ключа) → adsb.lol (резерв).
 * Файловый кэш 30 секунд (в.82–83), ошибки только в журнал.
 */
final class AdsbService
{
    public const TTL = 30;          // кэш внешнего API (спецификация)
    private const UA = 'VladAero-Radar/0.4 (+portal)';

    /**
     * Снимок бортов в bbox. Координаты округляются до 0.2° — больше попаданий в кэш.
     *
     * @return array{ok:bool,stale:bool,src:string,ts:int,count:int,ac:list<array<string,mixed>>}
     */
    public static function snapshot(float $lamin, float $lomin, float $lamax, float $lomax): array
    {
        $lamin = max(-90.0, min(90.0, round($lamin, 1)));
        $lomax = max(-180.0, min(180.0, round($lomax, 1)));
        $lomin = max(-180.0, min(180.0, round($lomin, 1)));
        $lamax = max(-90.0, min(90.0, round($lamax, 1)));
        if ($lamin > $lamax) { [$lamin, $lamax] = [$lamax, $lamin]; }
        if ($lomin > $lomax) { [$lomin, $lomax] = [$lomax, $lomin]; }

        $key = 'adsb_' . md5(sprintf('%.1f,%.1f,%.1f,%.1f', $lamin, $lomin, $lamax, $lomax));
        $hit = Cache::get($key);
        if (is_array($hit) && (time() - (int)($hit['ts'] ?? 0)) <= self::TTL) {
            $hit['stale'] = false;
            return $hit;
        }

        $fresh = self::fetchOpenSky($lamin, $lomin, $lamax, $lomax);
        if ($fresh === null) {
            $fresh = self::fetchAdsbLol($lamin, $lomin, $lamax, $lomax);
        }
        if ($fresh === null) {
            // Ленивое обновление (в.83): источники молчат — отдаём протухший снимок
            if (is_array($hit)) {
                $hit['stale'] = true;
                return $hit;
            }
            return ['ok' => false, 'stale' => false, 'src' => 'none', 'ts' => time(), 'count' => 0, 'ac' => []];
        }

        Cache::set($key, $fresh, self::TTL + 600);
        return $fresh;
    }

    /** OpenSky /states/all (анонимно, rate-limited) */
    private static function fetchOpenSky(float $la1, float $lo1, float $la2, float $lo2): ?array
    {
        $url = 'https://opensky-network.org/api/states/all'
            . '?lamin=' . $la1 . '&lomin=' . $lo1 . '&lamax=' . $la2 . '&lomax=' . $lo2;
        $json = self::http($url);
        if ($json === null || empty($json['states']) || !is_array($json['states'])) {
            return $json === null ? null : ['ok' => true, 'stale' => false, 'src' => 'opensky', 'ts' => time(), 'count' => 0, 'ac' => []];
        }
        $ac = [];
        foreach ($json['states'] as $s) {
            $lat = $s[5] ?? null;
            $lon = $s[6] ?? null;
            if (!is_numeric($lat) || !is_numeric($lon)) { continue; }
            $alt = $s[13] ?? $s[7] ?? null;           // geo_altitude → baro_altitude
            $ac[] = [
                'icao' => trim((string)($s[0] ?? '')),
                'cs'   => trim((string)($s[1] ?? '')),
                'reg'  => '',
                'type' => '',
                'lat'  => (float)$lat,
                'lon'  => (float)$lon,
                'alt'  => is_numeric($alt) ? (int)round((float)$alt) : null,   // метры
                'gs'   => is_numeric($s[9] ?? null) ? (int)round((float)$s[9] * 3.6) : null, // м/с → км/ч
                'trk'  => is_numeric($s[10] ?? null) ? (int)round((float)$s[10]) : null,
                'vr'   => is_numeric($s[11] ?? null) ? (int)round((float)$s[11]) : null,     // м/с
                'sq'   => trim((string)($s[14] ?? '')),
                'g'    => (bool)($s[8] ?? false),
                'ctry' => (string)($s[2] ?? ''),
            ];
        }
        return ['ok' => true, 'stale' => false, 'src' => 'opensky', 'ts' => time(), 'count' => count($ac), 'ac' => $ac];
    }

    /** adsb.lol /v2/box — резервный бесплатный источник */
    private static function fetchAdsbLol(float $la1, float $lo1, float $la2, float $lo2): ?array
    {
        $url = 'https://api.adsb.lol/v2/box/' . $la1 . ',' . $lo1 . ',' . $la2 . ',' . $lo2;
        $json = self::http($url);
        if ($json === null || !isset($json['ac']) || !is_array($json['ac'])) {
            return null;
        }
        $ac = [];
        foreach ($json['ac'] as $s) {
            $lat = $s['lat'] ?? null;
            $lon = $s['lon'] ?? null;
            if (!is_numeric($lat) || !is_numeric($lon)) { continue; }
            $altRaw = $s['alt_baro'] ?? null;
            $ground = $altRaw === 'ground';
            $alt = is_numeric($altRaw) ? (int)round((float)$altRaw * 0.3048) : null; // ft → м
            $ac[] = [
                'icao' => trim((string)($s['hex'] ?? '')),
                'cs'   => trim((string)($s['flight'] ?? '')),
                'reg'  => trim((string)($s['r'] ?? '')),
                'type' => trim((string)($s['t'] ?? '')),
                'lat'  => (float)$lat,
                'lon'  => (float)$lon,
                'alt'  => $ground ? 0 : $alt,
                'gs'   => is_numeric($s['gs'] ?? null) ? (int)round((float)$s['gs'] * 1.852) : null, // kt → км/ч
                'trk'  => is_numeric($s['track'] ?? null) ? (int)round((float)$s['track']) : null,
                'vr'   => is_numeric($s['geom_rate'] ?? null) ? (int)round((float)$s['geom_rate'] * 0.00508) : null, // ft/min → м/с
                'sq'   => trim((string)($s['squawk'] ?? '')),
                'g'    => $ground,
                'ctry' => '',
            ];
        }
        return ['ok' => true, 'stale' => false, 'src' => 'adsb.lol', 'ts' => time(), 'count' => count($ac), 'ac' => $ac];
    }

    /** GET JSON с таймаутом; null → источник недоступен (журнал, без исключений) */
    private static function http(string $url): ?array
    {
        $proxyBase = rtrim((string)setting('tg_api_base', 'https://telegram.v7755837.deno.net'), '/');
        $targetUrl = $url;
        if (str_contains($proxyBase, 'deno') && str_starts_with($url, 'https://api.adsb.lol')) {
            $targetUrl = str_replace('https://api.adsb.lol', $proxyBase, $url);
        }
        $ch = curl_init($targetUrl);
        if ($ch === false) { return null; }
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 8,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_USERAGENT      => self::UA,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_HTTPHEADER     => [
                'X-Service: adsb',
                'X-Target-URL: https://api.adsb.lol',
            ],
        ]);
        $body = curl_exec($ch);
        $err  = curl_error($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);
        if ($body === false || $code !== 200) {
            Logger::warning('ADS-B источник недоступен', ['url' => $url, 'code' => $code, 'error' => $err]);
            return null;
        }
        $json = json_decode((string)$body, true);
        return is_array($json) ? $json : null;
    }
}
