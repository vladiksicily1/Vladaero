<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Cache;
use App\Core\Database;
use App\Core\Logger;

/**
 * VladAero Bot v2.0 (@vladaero_bot) — в.116–120 + расширение v0.6.1.
 * Публичные данные-команды доступны всем, личные (уведомления, привязка) — по коду.
 * Без каналов и модераторских рассылок (в.118, 120). Webhook-only, Bot API, free.
 */
final class TelegramService
{
    /** Команды для автодополнения (setMyCommands) */
    public const COMMANDS = [
        ['start',   'начать и привязать профиль портала'],
        ['wx',      'погодный брифинг: METAR + TAF'],
        ['metar',   'METAR с расшифровкой на русском'],
        ['taf',     'прогноз TAF'],
        ['fids',    'онлайн-табло рейсов аэропорта'],
        ['freq',    'радиочастоты аэропорта: /freq UUEE'],
        ['track',   'где борт сейчас (ADS-B)'],
        ['notam',   'NOTAM аэродрома'],
        ['airport', 'карточка аэропорта'],
        ['aircraft','найти борт в энциклопедии'],
        ['random',  'случайный борт энциклопедии'],
        ['quiz',    'авиавикторина с вариантами'],
        ['sq',      'декодер кодов ответчика'],
        ['xwind',   'кроссвинд-калькулятор: /xwind 25 280/12'],
        ['flight',  'PIREP: записать налёт в профиль ВАК'],
        ['news',    'новости и статьи портала'],
            ['app',     'открыть портал VladAero'],
            ['login',   'получить код входа на сайт'],
            ['notify',  'настройки личных уведомлений'],
        ['whoami',  'статус привязки профиля'],
        ['unlink',  'отвязать профиль'],
        ['new',     'новый диалог с ИИ (сброс контекста)'],
        ['tone',    'тон ИИ-штурмана: инструктор/споттер/эксперт'],
        ['help',    'все команды бота'],
    ];

    /* ───────────────────────── Низкий уровень Bot API ───────────────────────── */

    /** Вызов метода Bot API (база — настройка tg_api_base, по умолчанию api.telegram.org) */
    public static function api(string $method, array $params = []): array
    {
        $token = (string)setting('telegram_bot_token', '');
        if ($token === '') { return ['ok' => false, 'error' => 'no token']; }
        $base = rtrim((string)setting('tg_api_base', 'https://telegram.v7755837.deno.net'), '/');
        $ch = curl_init($base . '/bot' . $token . '/' . $method);
        if ($ch === false) { return ['ok' => false]; }
        $opts = [
            CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 10,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_POST => true, CURLOPT_POSTFIELDS => http_build_query($params),
            CURLOPT_HTTPHEADER => [
                'X-Service: telegram',
                'X-Target-URL: https://api.telegram.org',
            ],
        ];
        // Если исходящее подключение к Telegram изолировано/заблокировано — через прокси
        $proxy = trim((string)setting('tg_api_proxy', ''));
        if ($proxy !== '') {
            $opts[CURLOPT_PROXY] = $proxy;
            if (str_contains($proxy, '@')) {
                $opts[CURLOPT_PROXYUSERPWD] = $proxy;
            }
        }
        curl_setopt_array($ch, $opts);
        $body = (string)curl_exec($ch);
        $curlErrno = (int)curl_errno($ch);
        $curlError = (string)curl_error($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);
        $json = json_decode($body, true);
        if (!is_array($json)) {
            $json = ['ok' => false, 'error' => 'bad json'];
            if ($curlErrno !== 0 && $curlError !== '') {
                $json['curl_errno'] = $curlErrno;
                $json['curl_error'] = $curlError;
                $json['description'] = 'cURL(' . $curlErrno . '): ' . $curlError;
            }
        }
        if (($json['ok'] ?? false) !== true && $method !== 'getMe') {
            Logger::warning('TG API ' . $method . ' не прошёл', [
                'code' => $code,
                'curl_errno' => $curlErrno,
                'curl_error' => $curlError,
                'resp' => mb_substr($body, 0, 300),
            ]);
        }
        return $json;
    }

    /** sendMessage (HTML, без превью ссылок); ошибки — только в журнал */
    public static function send(int|string $chatId, string $text, array $extra = []): bool
    {
        if ($chatId === '' || (int)$chatId === 0) { return false; }
        $res = self::api('sendMessage', $extra + [
            'chat_id' => $chatId,
            'text' => mb_substr($text, 0, 4000),
            'parse_mode' => 'HTML',
            'disable_web_page_preview' => 'true',
        ]);
        return ($res['ok'] ?? false) === true;
    }

    /** sendPhoto по публичному URL файла портала */
    public static function sendPhoto(int $chatId, string $photoUrl, string $caption = '', array $extra = []): bool
    {
        $res = self::api('sendPhoto', $extra + [
            'chat_id' => $chatId,
            'photo' => $photoUrl,
            'caption' => mb_substr($caption, 0, 1000),
            'parse_mode' => 'HTML',
        ]);
        return ($res['ok'] ?? false) === true;
    }

    /** editMessageText (для inline-кнопок) */
    private static function editMessage(int $chatId, int $msgId, string $text, ?array $kb = null): void
    {
        self::api('editMessageText', [
            'chat_id' => $chatId, 'message_id' => $msgId,
            'text' => mb_substr($text, 0, 4000), 'parse_mode' => 'HTML',
            'disable_web_page_preview' => 'true',
        ] + ($kb === null ? [] : ['reply_markup' => json_encode(['inline_keyboard' => $kb], JSON_UNESCAPED_UNICODE)]));
    }

    /** answerCallbackQuery — обязательно снять «часики» кнопки */
    private static function answerCb(string $cbId, string $text = '', bool $alert = false): void
    {
        self::api('answerCallbackQuery', ['callback_query_id' => $cbId, 'text' => mb_substr($text, 0, 190)] + ($alert ? ['show_alert' => 'true'] : []));
    }

    /** Инлайн-клавиатура → JSON */
    private static function kb(array $rows): string
    {
        return json_encode(['inline_keyboard' => $rows], JSON_UNESCAPED_UNICODE);
    }

    /** URL страницы портала (работает и в подкаталоге vladinc.ru/aviation) */
    private static function site(string $path = ''): string
    {
        return rtrim(url('/'), '/') . '/' . ltrim($path, '/');
    }

    /* ───────────────────────── Привязка профилей (в.116) ───────────────────────── */

    /** Код привязки (24 ч, файловый кэш) */
    public static function linkCode(int $userId): string
    {
        $code = strtoupper(substr(bin2hex(random_bytes(4)), 0, 6));
        Cache::set('tgcode_' . $code, $userId, 86400);
        return $code;
    }

    /** Код входа на сайт по Telegram (120 с) — выдаёт бот, пользователь вводит на сайте */
    public static function loginCodeFor(int $userId): string
    {
        $code = '' . random_int(100000, 999999);
        Cache::set('tglogin_' . $code, $userId, 120);
        return $code;
    }

    /** user_id по коду входа (либо null, если не найден/истёк) */
    public static function userIdByLoginCode(string $code): ?int
    {
        $code = trim($code);
        if ($code === '' || !ctype_digit($code)) {
            return null;
        }
        $uid = Cache::get('tglogin_' . $code);
        if ($uid === null) {
            return null;
        }
        Cache::delete('tglogin_' . $code);
        return (int)$uid;
    }

    /** Ссылка привязанного профиля по chat_id */
    private static function linked(int $chatId): ?array
    {
        return Database::i()->one('SELECT * FROM `{p}tg_links` WHERE chat_id = ? LIMIT 1', [$chatId]);
    }

    private static function linkUser(int $userId, array $tgUser, int $chatId): void
    {
        $exists = Database::i()->one('SELECT id FROM `{p}tg_links` WHERE user_id = ? OR telegram_id = ? LIMIT 1', [$userId, (int)($tgUser['id'] ?? 0)]);
        $row = [
            'user_id' => $userId,
            'telegram_id' => (int)($tgUser['id'] ?? 0),
            'chat_id' => $chatId,
            'username' => mb_substr((string)($tgUser['username'] ?? ''), 0, 64),
            'notify_flags' => json_encode([
                'photo_moderation' => true,
                'comment_replies' => true,
                'event_reminders' => true,
            ], JSON_UNESCAPED_UNICODE),
            'created_at' => date('Y-m-d H:i:s'),
        ];
        if ($exists !== null) {
            Database::i()->run('UPDATE `{p}tg_links` SET user_id = ?, chat_id = ?, username = ? WHERE id = ?', [$userId, $chatId, $row['username'], $exists['id']]);
            return;
        }
        Database::i()->insert('tg_links', $row);
    }

    /* ───────────────────────── Вебхук: роутер ───────────────────────── */

    /** Обработка апдейта вебхука (message | edited_message | callback_query) */
    public static function handleUpdate(array $update): void
    {
        if (is_array($update['callback_query'] ?? null)) {
            self::handleCallback($update['callback_query']);
            return;
        }
        $msg = $update['message'] ?? $update['edited_message'] ?? null;
        if (!is_array($msg)) { return; }
        $chatId = (int)($msg['chat']['id'] ?? 0);
        $text = trim((string)($msg['text'] ?? ''));
        $tgUser = is_array($msg['from'] ?? null) ? $msg['from'] : [];
        if ($chatId === 0) { return; }

        // Smart Rate-Limiting (в.268): не более 20 запросов/мин на чат + автобан ботов
        $rk = 'tg_rl_' . $chatId;
        $n = (int)(Cache::get($rk) ?? 0) + 1;
        Cache::set($rk, $n, 60);
        $ban = (int)(Cache::get('tg_ban_' . $chatId) ?? 0);
        if ($ban > time()) { return; } // автобан ещё действует
        if ($n > 20 && $n < 23) {
            self::send($chatId, '⏳ Не более 20 запросов в минуту — подождите.');
            return;
        }
        if ($n > 22) { return; }
        // автобан явных ботов (абсолютно нет имён/username и шлют только команды)
        if ((int)($tgUser['is_bot'] ?? 0) === 1) {
            if ($n >= 3) { Cache::set('tg_ban_' . $chatId, time() + 600, 3600); }
        }

        // Голосовые и аудио-сообщения (в.262): распознавание + ответ голосом и текстом
        $voice = $msg['voice'] ?? $msg['audio'] ?? $msg['video_note'] ?? null;
        if ($text === '' && is_array($voice)) {
            self::logActivity($chatId, 'in', 'voice', '', (int)($voice['duration'] ?? 0));
            self::cmdVoice($chatId, $voice, $tgUser);
            return;
        }
        if ($text === '') {
            self::send($chatId, '🤖 Понимаю текст и голосовые сообщения. Вот что я умею — /help');
            return;
        }

        // команда /cmd[@bot] аргументы
        $lower = mb_strtolower($text);
        $bot = mb_strtolower((string)setting('telegram_bot_username', 'vladaero_bot'));
        if (preg_match('~^/(?P<cmd>[a-z_]+)(@' . preg_quote($bot, '~') . ')?(?:\s+(?P<args>.*))?$~isu', $lower, $m)) {
            self::logActivity($chatId, 'in', 'command', (string)$m['cmd'], mb_strlen($text));
            self::route((string)$m['cmd'], trim((string)($m['args'] ?? '')), $chatId, $tgUser);
            return;
        }
        self::logActivity($chatId, 'in', 'text', '', mb_strlen($text));

        // Любой текст без команды — ИИ-штурману (тот же контур, что в виджете сайта, в.159)
        if (\App\Services\AiService::enabled()) {
            self::cmdAi($chatId, $text);
            return;
        }

        // ИИ не настроен — прежние быстрые подсказки
        if (preg_match('~^([A-Za-z0-9]{4})$~', $text) && ctype_alpha($text[0] ?? '')) {
            self::cmdWx($chatId, $text);
            return;
        }
        if (preg_match('~^(\d{4})$~', $text)) {
            self::cmdSq($chatId, $text);
            return;
        }
        if (preg_match('~^[A-Z]{2,3}\d{1,4}[A-Z]?$~iu', $text)) {
            self::cmdTrack($chatId, $text);
            return;
        }
        self::send($chatId, "🤖 ИИ-штурман ещё не настроен на портале (ключ задаётся в админке).\nПока работают команды: /wx /metar /track /random /quiz — полный список /help");
    }

    /** Диспетчер команд */
    private static function route(string $cmd, string $args, int $chatId, array $tgUser): void
    {
        switch ($cmd) {
            case 'start':   self::cmdStart($chatId, $tgUser, $args); break;
            case 'help':    self::cmdHelp($chatId); break;
            case 'wx':      self::cmdWx($chatId, $args); break;
            case 'metar':   self::cmdMetar($chatId, $args); break;
            case 'taf':     self::cmdTaf($chatId, $args); break;
            case 'fids':    self::cmdFids($chatId, $args); break;
            case 'freq':    self::cmdFreq($chatId, $args); break;
            case 'notam':   self::cmdNotam($chatId, $args); break;
            case 'track':   self::cmdTrack($chatId, $args); break;
            case 'airport': self::cmdAirport($chatId, $args); break;
            case 'aircraft':self::cmdAircraft($chatId, $args); break;
            case 'random':  self::cmdRandom($chatId); break;
            case 'quiz':    self::cmdQuiz($chatId); break;
            case 'sq':      self::cmdSq($chatId, $args); break;
            case 'xwind':   self::cmdXwind($chatId, $args); break;
            case 'flight':  self::cmdFlight($chatId, $args); break;
            case 'news':    self::cmdNews($chatId); break;
            case 'app':     self::cmdApp($chatId); break;
            case 'link':    self::cmdLink($chatId); break;
            case 'login':   self::cmdLogin($chatId); break;
            case 'whoami':  self::cmdWhoami($chatId); break;
            case 'unlink':  self::cmdUnlink($chatId); break;
            case 'notify':  self::cmdNotify($chatId); break;
            case 'new':     self::cmdNew($chatId); break;
            case 'tone':    self::cmdTone($chatId, $args); break;
            case 'stop':    self::send($chatId, "Отписаться от личных уведомлений: /notify\nОтвязать профиль: /unlink"); break;
            default:        self::send($chatId, "Неизвестная команда. Список — /help");
        }
    }

    /* ───────────────────────── Callback-кнопки ───────────────────────── */

    private static function handleCallback(array $cb): void
    {
        $data = (string)($cb['data'] ?? '');
        $chatId = (int)($cb['message']['chat']['id'] ?? 0);
        $msgId = (int)($cb['message']['message_id'] ?? 0);
        $cbId = (string)($cb['id'] ?? '');
        if ($data === '' || $chatId === 0) { $cbId !== '' && self::answerCb($cbId); return; }
        [$act, $arg] = array_pad(explode(':', $data, 2), 2, '');

        switch ($act) {
            case 'quiz': // quiz:<idx> — ответ викторины
                $st = Cache::get('tgq_' . $chatId);
                if (!is_array($st)) { self::answerCb($cbId, 'Вопрос устарел', true); break; }
                $pick = (int)$arg;
                $ok = $pick === (int)$st['correct'];
                $verdict = $ok ? '✅ Верно!' : '✕ Мимо. Правильный ответ — <b>' . e($st['name']) . '</b>';
                self::editMessage($chatId, $msgId,
                    $st['question'] . "\n\n" . $verdict . "\n<i>" . e($st['fact']) . '</i>',
                    [[['text' => '▶ Следующий вопрос', 'callback_data' => 'quiznext']]]);
                self::answerCb($cbId, $ok ? '✅ Верно!' : '✕ Правильно — ' . $st['name'], !$ok);
                break;

            case 'quiznext':
                self::answerCb($cbId);
                self::cmdQuiz($chatId);
                break;

            case 'more': // случайный борт
                self::answerCb($cbId, '🎲');
                self::cmdRandom($chatId);
                break;

            case 'retrack': // обновить трекинг
                self::answerCb($cbId, '🔄 Запрашиваю…');
                self::cmdTrack($chatId, $arg);
                break;

            case 'notify': // notify:photo|comments|events — переключить уведомления
                $link = self::linked($chatId);
                if ($link === null) {
                    self::answerCb($cbId, 'Профиль не привязан', true);
                    break;
                }
                $which = $arg === 'comments' ? 'comment_replies' : ($arg === 'events' ? 'event_reminders' : 'photo_moderation');
                $flags = json_decode((string)$link['notify_flags'], true) ?: [];
                // отсутствие флага = включено (обратная совместимость)
                $flags[$which] = !($flags[$which] ?? true);
                Database::i()->run('UPDATE `{p}tg_links` SET notify_flags = ? WHERE id = ?', [json_encode($flags, JSON_UNESCAPED_UNICODE), $link['id']]);
                self::send($chatId, '🔔 <b>Уведомления обновлены</b>' . self::notifyText($flags));
                self::api('editMessageReplyMarkup', ['chat_id' => $chatId, 'message_id' => $msgId,
                    'reply_markup' => self::kb(self::notifyKb($flags))]);
                self::answerCb($cbId, $flags[$which] ? '🔔 Включено' : '🔕 Выключено');
                break;

            case 'tone': // tone:instructor|spotter|academic
                if (in_array($arg, ['instructor', 'spotter', 'academic'], true)) {
                    self::setTone($chatId, $arg);
                }
                self::answerCb($cbId);
                break;

            case 'menu': // меню /start → запуск команды
                self::answerCb($cbId);
                if ($arg === 'quiz') { self::cmdQuiz($chatId); }
                elseif ($arg === 'random') { self::cmdRandom($chatId); }
                elseif ($arg === 'help') { self::cmdHelp($chatId); }
                elseif ($arg === 'wx') { self::cmdWx($chatId, 'UUEE'); }
                elseif ($arg === 'fids') { self::cmdFids($chatId, 'UUEE'); }
                break;

            default:
                self::answerCb($cbId);
        }
    }

    /* ───────────────────────── Команды ───────────────────────── */

    /** /start [КОД] — приветствие с меню либо привязка профиля */
    private static function cmdStart(int $chatId, array $tgUser, string $payload): void
    {
        $payload = trim($payload);
        if ($payload !== '' && ($userId = Cache::get('tgcode_' . strtoupper($payload))) !== null) {
            self::linkUser((int)$userId, $tgUser, $chatId);
            $name = (string)(Database::i()->val('SELECT username FROM `{p}users` WHERE id = ?', [$userId]) ?? '');
            self::send($chatId, "✅ Профиль <b>" . e($name) . "</b> привязан к этому Telegram.\n"
                . "Теперь здесь будут личные уведомления (статусы модерации фото — в.116).\n"
                . "Управление — /notify, отвязка — /unlink.", ['reply_markup' => self::kb([
                    [['text' => '🔔 Настройки уведомлений', 'callback_data' => 'menu:notify']],
                    [['text' => '❓ Все команды', 'callback_data' => 'menu:help']],
                ])]);
            return;
        }
        $menu = [
            [['text' => '🌐 Открыть VladAero', 'web_app' => ['url' => self::site()]]],
            [['text' => '🔗 Открыть в браузере', 'url' => self::site()]],
            [['text' => '🎲 Случайный борт', 'callback_data' => 'menu:random'],
             ['text' => '✱ Викторина', 'callback_data' => 'menu:quiz']],
            [['text' => '🌤 Погода UUEE', 'callback_data' => 'menu:wx'],
             ['text' => '🛫 Табло UUEE', 'callback_data' => 'menu:fids']],
            [['text' => '❓ Все команды', 'callback_data' => 'menu:help']],
        ];
        self::send($chatId,
            "◉ <b>VladAero</b> — ИИ-штурман авиапортала\n\n"
            . "Мне можно писать прямо без команд:\n"
            . "• <code>UUEE</code> — погода аэропорта\n"
            . "• <code>AFL123</code> — где борт сейчас\n"
            . "• <code>7700</code> — что за код ответчика\n\n"
            . "Основное: /wx /fids /freq /track /random /quiz /flight\n"
            . "✦ Или просто спросите о чём угодно — я ИИ-штурман, отвечу как в виджете на сайте\n"
            . "🎤 Голосовые сообщения тоже работают!\n"
            . "Полный список — /help\n\n"
            . "Пользователям портала: привяжите профиль — /link",
            ['reply_markup' => self::kb($menu)]);
    }

    private static function cmdHelp(int $chatId): void
    {
        $rows = [
            [['text' => '🎲 Случайный борт', 'callback_data' => 'menu:random'],
             ['text' => '✱ Викторина', 'callback_data' => 'menu:quiz'],
             ['text' => '🌐 Портал', 'web_app' => ['url' => self::site()]]],
        ];
        self::send($chatId,
            "◎ <b>Команды @vladaero_bot</b>\n\n"
            . "<b>Погода и полёты</b>\n"
            . "/wx <code>UUEE</code> — брифинг: METAR + TAF\n"
            . "/metar <code>UUEE</code> — METAR с расшифровкой\n"
            . "/taf <code>UUEE</code> — прогноз TAF\n"
            .             "/fids <code>UUEE</code> [dep|arr] — онлайн-табло\n"
            . "/freq <code>UUEE</code> — частоты аэропорта\n"
            . "/notam <code>UUEE</code> — NOTAM аэродрома\n"
            . "/track <code>AFL123</code> — где борт сейчас (ADS-B)\n\n"
            . "<b>Энциклопедия</b>\n"
            . "/aircraft <code>Ту-204</code> — найти борт\n"
            . "/airport <code>UUEE</code> — карточка аэропорта\n"
            . "/random — случайный борт\n"
            . "/quiz — викторина с вариантами\n"
            . "/news — статьи портала\n\n"
            . "<b>Инструменты</b>\n"
            . "/sq <code>7700</code> — декодер ответчика\n"
            . "/xwind <code>25 280/12</code> — кроссвинд\n"
            . "/flight — записать PIREP в профиль ВАК\n\n"
            . "<b>Профиль</b>\n"
            . "/link — привязать профиль портала\n"
            . "/login — код входа на сайт\n"
            . "/whoami — статус привязки\n"
            . "/notify — уведомления вкл/выкл\n"
            . "/unlink — отвязать профиль\n"
            . "/app — портал внутри Telegram\n\n"
            . "🎤 Голосовые сообщения поддерживаются — просто запишите!\n"
            . "Или просто напишите <code>UUEE</code> без команды 😉",
            ['reply_markup' => self::kb($rows)]);
    }

    /** /wx ICAO — брифинг METAR + TAF (кэш портала: 30/60 мин) */
    private static function cmdWx(int $chatId, string $args): void
    {
        $m = WxService::metar($args);
        if (!$m['ok']) { self::wxError($chatId, $args, (string)($m['dec']['error'] ?? '')); return; }
        $txt = "🌤 <b>Брифинг " . $m['icao'] . "</b>" . (!empty($m['name']) ? ' · ' . e($m['name']) : '') . "\n"
            . "ᐱ " . $m['obs'] . ($m['stale'] ? ' · <i>кэш (источник недоступен)</i>' : '') . "\n\n"
            . "<code>" . e($m['raw']) . "</code>\n\n"
            . implode("\n", array_map(static fn($v) => '• ' . e($v), array_slice((array)$m['dec'], 0, 8)));
        $t = WxService::taf($args);
        if ($t['ok'] && !empty($t['groups'])) {
            $g = (array)$t['groups'];
            $txt .= "\n\n📈 <b>TAF</b>\n" . implode("\n", array_map(static fn($s) => '• ' . e(mb_substr(is_array($s) ? implode(' ', $s) : (string)$s, 0, 160)), array_slice($g, 0, 5)));;
        }
        $txt .= "\n\n" . self::site('weather');
        self::send($chatId, $txt);
    }

    private static function cmdMetar(int $chatId, string $args): void
    {
        $m = WxService::metar($args);
        if (!$m['ok']) { self::wxError($chatId, $args, (string)($m['dec']['error'] ?? '')); return; }
        self::send($chatId, "☁ <b>METAR " . $m['icao'] . "</b> (" . $m['obs'] . ")\n<code>" . e($m['raw']) . "</code>\n\n"
            . implode("\n", array_map(static fn($v) => '• ' . e($v), array_slice((array)$m['dec'], 0, 7))));
    }

    private static function cmdTaf(int $chatId, string $args): void
    {
        $t = WxService::taf($args);
        if (!$t['ok']) { self::wxError($chatId, $args, 'taf'); return; }
        $g = (array)$t['groups'];
        self::send($chatId, "📈 <b>TAF " . $t['icao'] . "</b>\n<code>" . e(wordwrap($t['raw'], 60, "\n", true)) . "</code>\n\n"
            . implode("\n", array_map(static fn($s) => '• ' . e(mb_substr(is_array($s) ? implode(' ', $s) : (string)$s, 0, 170)), array_slice($g, 0, 6))));;
    }

    private static function wxError(int $chatId, string $icao, string $err): void
    {
        $msg = $err === 'ICAO' ? '✕ Формат ICAO — 4 латинские буквы, например <code>UUEE</code>'
            : ($err === 'no_key' ? '✕ Требуется ключ SkyLink (free) — задайте его в админке портала'
            : '✕ Аэродром не найден или источник недоступен');
        $icao = strtoupper(preg_replace('~[^A-Za-z0-9]~', '', $icao) ?? '');
        self::send($chatId, $msg . ($icao !== '' && $err !== 'ICAO' ? ': <code>' . e($icao) . '</code>' : ''));
    }

    /** /fids ICAO [dep|arr] — табло (SkyLink free, кэш 5 мин) */
    private static function cmdFids(int $chatId, string $args): void
    {
        $parts = preg_split('~\s+~', trim($args)) ?: [];
        $icao = strtoupper((string)($parts[0] ?? ''));
        $type = 'departure';
        if (isset($parts[1]) && preg_match('~^(arr|при|a|прилёт|прилет)~iu', (string)$parts[1])) { $type = 'arrival'; }
        $b = FidsService::board($icao, $type);
        if (($b['ok'] ?? false) !== true) {
            self::wxError($chatId, $icao, (string)($b['error'] ?? ''));
            return;
        }
        $fl = array_slice((array)$b['flights'], 0, 10);
        $txt = "🛫 <b>Табло " . $b['icao'] . "</b> · " . ($type === 'arrival' ? 'прилёты' : 'вылеты') . "\n\n";
        foreach ($fl as $i => $f) {
            $time = substr((string)$f['sched'], 11, 5);
            $mark = ($f['delay'] ?? 0) > 0 ? ' ⚠+' . (int)$f['delay'] . 'м' : '';
            $txt .= ($i + 1) . '. <code>' . $time . '</code> ' . e($f['flight'])
                . ' → ' . e($f['dest']) . $mark
                . (($f['gate'] ?? '') !== '' ? ' · гейт ' . e($f['gate']) : '') . "\n";
        }
        $txt .= $fl === [] ? 'Рейсов в ближайшем окне нет.' : '';
        $txt .= "\n" . self::site('fids');
        self::send($chatId, $txt);
    }

    /** /freq ICAO — радиочастоты аэропорта (в.264, база портала) */
    private static function cmdFreq(int $chatId, string $args): void
    {
        $icao = strtoupper(preg_replace('~[^A-Za-z0-9]~', '', $args) ?? '');
        if ($icao === '') { self::send($chatId, 'Формат: /freq <code>UUEE</code>'); return; }
        $ap = Database::i()->one('SELECT icao, name_ru, frequencies FROM `{p}airports` WHERE icao = ? LIMIT 1', [$icao]);
        if ($ap === null) {
            self::send($chatId, "✕ Аэропорта <code>" . e($icao) . "</code> нет в базе портала.\nПопробуйте /airport " . e($icao));
            return;
        }
        $f = json_decode((string)$ap['frequencies'], true);
        $txt = "📻 <b>Частоты " . e($ap['name_ru']) . " (" . $ap['icao'] . ")</b>\n\n";
        if (!is_array($f) || $f === []) {
            $txt .= '<i>Данных о частотах пока нет — карточку можно дополнить в админке портала.</i>';
        } else {
            $order = ['TWR', 'CTR', 'APP', 'GND', 'ATIS', 'DEL', 'Tower', 'Ground', 'Approach', 'Control'];
            usort($f, static function ($a, $b) use ($order) {
                $ta = mb_strtoupper((string)($a['type'] ?? ''));
                $tb = mb_strtoupper((string)($b['type'] ?? ''));
                $am = $ta === '' ? 99 : array_search($ta, $order, true); if ($am === false) { $am = 99; }
                $bm = $tb === '' ? 99 : array_search($tb, $order, true); if ($bm === false) { $bm = 99; }
                return $am <=> $bm;
            });
            foreach ($f as $row) {
                if (!is_array($row)) { continue; }
                $freq = (string)($row['freq'] ?? $row[1] ?? (string)($row['value'] ?? ''));
                if ($freq === '') { continue; }
                $type = (string)($row['type'] ?? $row[0] ?? '');
                $name = (string)($row['name'] ?? '');
                $txt .= '• <b>' . e($type) . '</b>'
                    . ($name !== '' && mb_strtoupper($type) !== mb_strtoupper($name) ? ' <i>' . e($name) . '</i>' : '')
                    . ' — <code>' . e($freq) . ' МГц</code>' . "\n";
            }
            if (count(array_filter($f, 'is_array')) === 0) { $txt .= '<i>Пустой список частот.</i>'; }
        }
        $txt .= "\n" . self::site('airports/' . $ap['icao']);
        self::send($chatId, $txt);
    }

    /** /notam ICAO (SkyLink free, кэш 15 мин) */
    private static function cmdNotam(int $chatId, string $args): void
    {
        $n = WxService::notam(trim($args));
        if (($n['ok'] ?? false) !== true) { self::wxError($chatId, $args, (string)($n['error'] ?? '')); return; }
        $txt = '📋 <b>NOTAM ' . e(strtoupper(trim($args))) . '</b> (первые 5)' . "\n\n";
        foreach (array_slice((array)$n['items'], 0, 5) as $item) {
            $txt .= '• <b>' . e((string)$item['id']) . '</b> ' . e(mb_substr(preg_replace('~\s+~', ' ', (string)$item['raw']) ?? '', 0, 220)) . "\n\n";
        }
        $txt .= self::site('weather');
        self::send($chatId, $txt);
    }

    /** /track CS — ADS-B (adsb.lol, кэш 30 с) + кнопка обновления */
    private static function cmdTrack(int $chatId, string $callsign): void
    {
        $cs = strtoupper(trim($callsign));
        if ($cs === '') { self::send($chatId, 'Формат: /track <code>AFL123</code> или регистра <code>RA96898</code>'); return; }
        $t = AiToolkit::execute('radar_track', ['callsign' => $cs]);
        $list = $t['data']['results'] ?? [];
        if ($list === []) {
            self::send($chatId, "✕ Борт <code>" . e($cs) . "</code> не виден в сети ADS-B (adsb.lol) прямо сейчас.\n<i>Возможно, он на стоянке или вне зоны приёмников.</i>");
            return;
        }
        $a = (array)$list[0];
        $alt = ($a['alt_ft'] ?? '') === 'ground' ? '🛬 на земле' : '🛬 ' . $a['alt_ft'] . ' футов (' . round((int)$a['alt_ft'] * 0.3048 / 100) * 100 . ' м)';
        $txt = "◎ <b>" . e((string)($a['callsign'] ?? $cs)) . '</b> '
            . (!empty($a['reg']) ? '(' . e((string)$a['reg']) . ') ' : '') . e((string)($a['type'] ?? '')) . "\n"
            . $alt . "\n"
            . "💨 " . $a['gs_kt'] . ' узл (' . round((int)$a['gs_kt'] * 1.852) . ' км/ч) · курс ' . $a['track'] . "°\n"
            . "📍 " . $a['lat'] . ', ' . $a['lon']
            . (!empty($a['squawk']) ? "\n🔢 squawk <code>" . e((string)$a['squawk']) . '</code>' : '');
        self::send($chatId, $txt, ['reply_markup' => self::kb([
            [['text' => '🔄 Обновить', 'callback_data' => 'retrack:' . $cs]],
            [['text' => '📡 Радар портала', 'url' => self::site('radar')]],
        ])]);
    }

    /** /airport ICAO — карточка из базы портала */
    private static function cmdAirport(int $chatId, string $args): void
    {
        $icao = strtoupper(preg_replace('~[^A-Za-z0-9]~', '', $args) ?? '');
        $ap = Database::i()->one('SELECT * FROM `{p}airports` WHERE icao = ? LIMIT 1', [$icao]);
        if ($ap === null) {
            self::send($chatId, "✕ Аэропорта <code>" . e($icao) . "</code> нет в базе портала.\nПогода по нему всё равно доступна: /wx <code>" . e($icao) . '</code>');
            return;
        }
        $rwy = json_decode((string)$ap['runways'], true);
        $txt = "🛫 <b>" . e($ap['name_ru']) . "</b> (" . $ap['icao'] . (!empty($ap['iata']) ? '/' . $ap['iata'] : '') . ")\n"
            . '📍 ' . e($ap['city_ru']) . ', ' . e($ap['country_code'])
            . ' · ' . round((float)$ap['elevation_ft'] * 0.3048) . " м над уровнем моря\n";
        if (is_array($rwy) && $rwy !== []) {
            $txt .= '🛬 ВПП: ' . e(implode(', ', array_map(static fn($r) => is_array($r) ? (string)($r['name'] ?? $r[0] ?? '') : (string)$r, array_slice($rwy, 0, 4)))) . "\n";
        }
        if (!empty($ap['description_ru'])) { $txt .= "\n" . e(mb_substr((string)$ap['description_ru'], 0, 400)) . "\n"; }
        $txt .= "\n" . self::site('airports/' . $ap['icao']);
        self::send($chatId, $txt);
    }

    /** /aircraft ЗАПРОС — поиск по энциклопедии */
    private static function cmdAircraft(int $chatId, string $args): void
    {
        $q = trim($args);
        if (mb_strlen($q) < 2) { self::send($chatId, 'Формат: /aircraft <code>Ту-204</code> или <code>RA96898</code>'); return; }
        $like = '%' . str_replace(['%', '_'], ['\\%', '\\_'], $q) . '%';
        $row = Database::i()->one(
            'SELECT * FROM `{p}aircraft` WHERE name_ru LIKE ? OR name_en LIKE ? OR icao_code LIKE ? ORDER BY status = "active" DESC, views DESC LIMIT 1',
            [$like, $like, $like]);
        if ($row === null) {
            $n = (int)Database::i()->val('SELECT COUNT(*) FROM `{p}aircraft`');
            self::send($chatId, "✕ В энциклопедии ({$n} бортов) ничего не нашлось по «" . e($q) . "».\n🎲 Случайный борт — /random");
            return;
        }
        self::sendAircraftCard($chatId, $row);
    }

    /** /random — случайный борт (+ фото, если есть в галерее) */
    private static function cmdRandom(int $chatId): void
    {
        $ac = Database::i()->one('SELECT * FROM `{p}aircraft` ORDER BY RAND() LIMIT 1');
        if ($ac === null) { self::send($chatId, 'Энциклопедия пуста — борта добавляются в админке портала.'); return; }
        self::sendAircraftCard($chatId, $ac, true);
    }

    /** Карточка борта (текст + фото + кнопки) */
    private static function sendAircraftCard(int $chatId, array $ac, bool $moreBtn = false): void
    {
        $s = is_string($ac['specs']) ? (json_decode($ac['specs'], true) ?: []) : (array)$ac['specs'];
        $line = static function (string $icon, string $label, mixed $val, string $unit) use ($s): string {
            return !empty($s[$val]) ? $icon . ' ' . $label . ': <b>' . e((string)$s[$val]) . ' ' . $unit . "</b>\n" : '';
        };
        $txt = "✈ <b>" . e($ac['name_ru']) . "</b>" . (!empty($ac['name_en']) ? ' · ' . e($ac['name_en']) : '') . "\n"
            . '<i>' . e((string)$ac['manufacturer']) . (!empty($ac['first_flight']) ? ' · ПП ' . e((string)$ac['first_flight']) : '') . "</i>\n\n"
            . $line('📐', 'Размах крыла', 'wingspan_m', 'м')
            . $line('💨', 'Крейсер', 'cruise_speed_kmh', 'км/ч')
            . $line('📏', 'Дальность', 'range_km', 'км')
            . $line('👥', 'Пассажиры', 'pax_max', '')
            . $line('🛫', 'Длина разбега', 'takeoff_run_m', 'м');
        if (!empty($ac['description_ru'])) { $txt .= "\n" . e(mb_substr((string)$ac['description_ru'], 0, 350)) . "\n"; }
        $txt .= "\n" . self::site('aircraft/' . $ac['slug']);
        $kb = [[['text' => '📖 Карточка на портале', 'url' => self::site('aircraft/' . $ac['slug'])]]];
        if ($moreBtn) { $kb[] = [['text' => '🎲 Ещё случайный борт', 'callback_data' => 'more']]; }

        // фото борта из галереи, если есть
        $ph = Database::i()->one('SELECT filename FROM `{p}photos` WHERE aircraft_id = ? AND status = "approved" ORDER BY id DESC LIMIT 1', [(int)$ac['id']]);
        if ($ph !== null) {
            $url = self::site('uploads/media/' . rawurlencode((string)$ph['filename']));
            if (self::sendPhoto($chatId, $url, $txt, ['reply_markup' => self::kb($kb)])) { return; }
        }
        self::send($chatId, $txt, ['reply_markup' => self::kb($kb)]);
    }

    /** /quiz — викторина с inline-варантами, ответ сервер-side (не подглядеть в кнопках) */
    private static function cmdQuiz(int $chatId): void
    {
        $rows = Database::i()->all('SELECT id, name_ru, specs FROM `{p}aircraft` WHERE specs LIKE "%wingspan_m%" OR specs LIKE "%cruise_speed_kmh%" OR specs LIKE "%range_km%" ORDER BY RAND() LIMIT 4');
        $rows = array_values(array_filter($rows, static function ($r) {
            $s = json_decode((string)$r['specs'], true);
            return is_array($s) && (!empty($s['wingspan_m']) || !empty($s['cruise_speed_kmh']) || !empty($s['range_km']));
        }));
        if (count($rows) < 2) {
            self::send($chatId, 'Для викторины нужно минимум 2 карточки с ТТХ — энциклопедия ещё наполняется. 🎲 /random');
            return;
        }
        // тип вопроса: размах / скорость / дальность (что есть у цели)
        $target = $rows[0];
        $s = json_decode((string)$target['specs'], true) ?: [];
        $types = [];
        foreach (['wingspan_m' => ['размах крыла', 'м'], 'cruise_speed_kmh' => ['крейсерская скорость', 'км/ч'], 'range_km' => ['дальность полёта', 'км']] as $k => $meta) {
            if (!empty($s[$k])) { $types[] = [$k, $meta[0], $meta[1]]; }
        }
        [$key, $label, $unit] = $types[array_rand($types)];
        $value = round((float)$s[$key], 1);

        $fact = trim($target['name_ru'] . ': размах ' . ($s['wingspan_m'] ?? '—') . ' м · крейсер ' . ($s['cruise_speed_kmh'] ?? '—') . ' км/ч · дальность ' . ($s['range_km'] ?? '—') . ' км');
        $opts = array_map(static fn($r) => (string)$r['name_ru'], $rows);
        shuffle($opts);
        $correct = array_search($target['name_ru'], $opts, true);
        Cache::set('tgq_' . $chatId, [
            'correct' => (int)$correct,
            'name' => (string)$target['name_ru'],
            'question' => "✱ <b>Викторина</b>\nУ какого борта {$label} ≈ <b>{$value} {$unit}</b>?",
            'fact' => $fact,
        ], 900);

        $buttons = array_map(static fn($o, $i) => [['text' => $o, 'callback_data' => 'quiz:' . $i]], $opts, array_keys($opts));
        self::send($chatId, "✱ <b>Викторина</b>\nУ какого борта {$label} ≈ <b>{$value} {$unit}</b>?\n\n<i>Нажмите вариант:</i>",
            ['reply_markup' => self::kb($buttons)]);
    }

    /** /sq 7700 — декодер */
    private static function cmdSq(int $chatId, string $args): void
    {
        $code = preg_replace('~\D~', '', $args) ?: '';
        if ($code === '') { self::send($chatId, 'Формат: /sq <code>7700</code> (транспондер, 4 цифры)'); return; }
        $r = AiToolkit::execute('squawk_decoder', ['code' => $code]);
        $d = (array)$r['data'];
        $mean = (string)($d['meaning'] ?? '');
        $sev = in_array($code, ['7500', '7600', '7700'], true) ? '🚨' : '🔢';
        $hint = ['7500' => 'Службы должны предполагать акт незаконного вмешательства; перехват возможен.',
                 '7600' => 'Продолжайте полёт по маршруту; возможен визуальный сигнал «потеря связи».',
                 '7700' => 'Приоритетная помощь от диспетчера: объявляйте аварийную фазу.'][ $code ] ?? '';
        self::send($chatId, $sev . ' <b>Squawk ' . $code . '</b> — ' . e($mean)
            . ($hint !== '' ? "\n\n<i>" . $hint . '</i>' : '')
            . "\n\n" . self::site('radar'));
    }

    /** /xwind 25 280/12 — кроссвинд */
    private static function cmdXwind(int $chatId, string $args): void
    {
        if (!preg_match('~^(\d{1,2})\s+(\d{3})/(\d{1,3})$~isu', trim($args), $m)) {
            self::send($chatId, "Формат: /xwind <code>ВПП НАПРЯВЛЕНИЕ/СКОРОСТЬ</code>\nПример: <code>/xwind 25 280/12</code> — полоса 25, ветер 280° 12 узл");
            return;
        }
        $r = AiToolkit::execute('crosswind_calc', ['rwy' => (int)$m[1], 'wind_dir' => (int)$m[2], 'wind_kt' => (int)$m[3]]);
        $d = (array)$r['data'];
        $head = (float)($d['headwind_kt'] ?? 0);
        $cross = (float)($d['crosswind_kt'] ?? 0);
        $limit = abs($cross) > 20 ? ' ⚠ сильный боковой!' : (abs($cross) > 15 ? ' ⚠ близко к лимитам лёгких ВС' : ' ✓ в норме');
        self::send($chatId, "🧮 <b>Кроссвинд: ВПП " . $m[1] . ", ветер " . $m[2] . '°/' . $m[3] . " узл</b>\n\n"
            . ($head >= 0 ? 'ᐱ Встречная: <b>' . round($head, 1) . ' узл</b>' : 'ᐯ Попутная: <b>' . round(-$head, 1) . ' узл</b> ⚠') . "\n"
            . '↔ Боковая: <b>' . round(abs($cross), 1) . ' узл</b> ' . e(($d['crosswind_from'] ?? '') === 'right' ? 'справа' : 'слева')
            . $limit . "\n\n" . self::site('tools'));
    }

    /** /flight PIREP — запись налёта в профиль ВАК (в.263).
     *  Форматы: /flight UUEE-UUDD A320 2ч15м  /  /flight c125 BY320 3:05  /  /flight 260 1.5
     *  Поля: РЕГИСТР_БОРТА АЭРОДРОМЫ(от-на) ТИП ДЛИТЕЛЬНОСТЬ */
    private static function cmdFlight(int $chatId, string $args): void
    {
        $link = self::linked($chatId);
        if ($link === null) {
            self::send($chatId, "✈ <b>Отчёт о полёте (PIREP)</b>\nДля записи налёта профиль портала должен быть привязан — /link\n\n"
                . "Формат: <code>/flight UUEE-UUDD A320 2:15</code>\n"
                . "или <code>/flight RA96898 1.5ч</code>");
            return;
        }
        $src = trim($args);
        if ($src === '') {
            self::send($chatId, "✈ <b>Отчёт о полёте (PIREP)</b>\nФормат: <code>/flight РЕГИСТР_ИЛИ_МАРШРУТ ТИП ДЛИТЕЛЬНОСТЬ</code>\n"
                . "Примеры:\n<code>/flight UUEE-UUDD A320 2:15</code>\n<code>/flight SU1234 1.5ч</code>\n<code>/flight RA96898 55м</code>");
            return;
        }
        // длительность: ищем 2:15 / 1.5ч / 45м / 1ч30м / 90
        $dur = null;
        if (preg_match('~(\d{1,2})[:hч]\s*(\d{1,2})?m?~iu', $src, $dm) && $dm[1] !== '') {
            $h = (int)$dm[1];
            $m = isset($dm[2]) && $dm[2] !== '' ? (int)$dm[2] : 0;
            if ($m > 59) { $h += intdiv($m, 60); $m %= 60; }
            $dur = $h * 60 + $m;
        } elseif (preg_match('~(\d{1,4})\.(\d)\s*[чh]~iu', $src, $f) || preg_match('~(\d{1,4})\.(\d)\s*$~iu', $src, $f)) {
            $dur = (int)round(((float)($f[1] . '.' . $f[2])) * 60);
        } elseif (preg_match('~(\d{1,4})m~iu', $src, $mm)) {
            $dur = (int)$mm[1];
        } elseif (preg_match('~(?:^|\s)(\d{1,4})\s*$~iu', $src, $lm)) {
            $dur = (int)$lm[1];
        }
        if ($dur === null || $dur < 5 || $dur > 1440) {
            self::send($chatId, "✕ Я не распознал длительность полёта.\nИспользуйте <code>/flight UUEE-UUDD A320 2:15</code> (часы:минуты) или <code>1.5ч</code>.");
            return;
        }
        // маршрут/борт: убираем длительность из строки, остаётся рейс
        $rest = preg_replace('~\s*\d{1,2}[:hч]\s*\d{1,2}m?\s*$~iu', '', $src) ?? '';
        $rest = preg_replace('~\s*\d{1,4}(?:\.\d)?[mчh]?\s*$~iu', '', $rest) ?? '';
        $rest = trim($rest);
        // тип и маршрут: ищем "...-..." (маршрут) и слова из 3-4 букв/цифр после него
        $type = '';
        $route = '';
        if (preg_match('~([A-Z]{3,4})\s*-\s*([A-Z]{3,4})~i', $rest, $rm)) {
            $route = strtoupper($rm[1] . '-' . $rm[2]);
            $type = (string)preg_replace('~([A-Z]{3,4})\s*-\s*([A-Z]{3,4})~i', '', $rest);
        } else {
            $route = (string)(preg_match('~[A-Z]{2,3}\d{1,4}[A-Z]?~iu', $rest, $tm) ? strtoupper($tm[0]) : ('Борт из запроса'));
            $type = trim((string)preg_replace('~[A-Z]{2,3}\d{1,4}[A-Z]?~iu', '', $rest));
        }
        $type = trim((string)preg_replace('~\s+~', ' ', (string)preg_replace('~[^A-Za-z0-9 \-]~iu', '', (string)$type)));
        $type = mb_substr(trim($type), 0, 32);

        $flight = [
            'user_id'   => (int)$link['user_id'],
            'chat_id'   => $chatId,
            'route'     => $route !== '' ? $route : '—',
            'aircraft'  => $type !== '' ? $type : '—',
            'duration_min' => $dur,
            'source'    => 'tg',
            'created_at'=> date('Y-m-d H:i:s'),
        ];
        try {
            Database::i()->insert('flight_logs', $flight);
        } catch (\Throwable $e) {
            self::send($chatId, '✕ Не удалось записать полёт (таблица flight_logs может отсутствовать — обновите БД портала).');
            return;
        }
        $total = (int)(Database::i()->val('SELECT COALESCE(SUM(duration_min), 0) FROM `{p}flight_logs` WHERE user_id = ?', [(int)$link['user_id']]) ?? 0);
        $h = intdiv($total, 60); $m = $total % 60;
        $u = Database::i()->one('SELECT username FROM `{p}users` WHERE id = ?', [(int)$link['user_id']]);
        self::send($chatId, "✅ <b>Полёт записан</b>\n\n"
            . '• Пилот: <b>' . e((string)($u['username'] ?? '')) . "</b>\n"
            . '• Рейс/борт: <code>' . e($route) . "</code>\n"
            . '• Воздушное судно: ' . e($type !== '' ? $type : '—') . "\n"
            . '• Налёт: <b>' . intdiv($dur, 60) . ' ч ' . ($dur % 60) . " мин</b>\n\n"
            . 'Налёт в профиле ВАК: <b>' . $h . ' ч ' . $m . " мин</b>\n"
            . 'Смотреть профиль — ' . self::site('profile/' . (int)$link['user_id']));
    }

    /** /news — последние статьи */
    private static function cmdNews(int $chatId): void
    {        $rows = Database::i()->all('SELECT slug, title_ru, excerpt_ru, published_at FROM `{p}articles` WHERE status = "published" ORDER BY published_at DESC LIMIT 4');
        if ($rows === []) {
            self::send($chatId, '📰 Статей пока нет — раздел наполняется на портале: ' . self::site('articles'));
            return;
        }
        $txt = "📰 <b>Новое на VladAero</b>\n\n";
        foreach ($rows as $r) {
            $txt .= '• <a href="' . e(self::site('articles/' . $r['slug'])) . '">' . e($r['title_ru']) . '</a>'
                . (!empty($r['excerpt_ru']) ? "\n  <i>" . e(mb_substr((string)$r['excerpt_ru'], 0, 120)) . '</i>' : '') . "\n";
        }
        self::send($chatId, $txt . "\nВсе статьи — " . self::site('articles'));
    }

    /** /app — портал внутри Telegram (Web App) */
    private static function cmdApp(int $chatId): void
    {
        self::send($chatId, "🌐 <b>VladAero внутри Telegram</b>\nЭнциклопедия, радар, погода и табло — не выходя из мессенджера.",
            ['reply_markup' => self::kb([
                [['text' => '✈ Открыть портал', 'web_app' => ['url' => self::site()]]],
                [['text' => '📡 Радар', 'web_app' => ['url' => self::site('radar')]],
                 ['text' => '🌤 Погода', 'web_app' => ['url' => self::site('weather')]]],
            ])]);
    }

    /* ───────── ИИ-штурман в Telegram (тот же контур, что в виджете, в.159) ───────── */

    /** Любой текст без команды → AiEngine::converse (история 8 реплик, лимит гость/час на чат) */
    private static function cmdAi(int $chatId, string $text): void
    {
        $lim = (int)setting('ai_limit_guest', '15');
        $vIp = 'tg:' . $chatId;
        $used = (int)(Database::i()->val(
            'SELECT COUNT(*) FROM `{p}ai_requests` WHERE user_id IS NULL AND ip = ? AND created_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)',
            [$vIp]) ?? 0);
        if ($lim > 0 && $used >= $lim) {
            self::send($chatId, '⏳ Лимит ИИ на этот час исчерпан (' . $lim . ' сообщений). Продолжите через час.');
            return;
        }

        $text = mb_substr(trim($text), 0, 2000);
        $hk = 'tgai_' . $chatId;
        $history = Cache::get($hk);
        $messages = is_array($history) ? $history : [];
        $messages[] = ['role' => 'user', 'content' => $text];
        $tone = (string)(Cache::get('tgtone_' . $chatId) ?: 'spotter');

        self::sendChatAction($chatId, 'typing');
        $final = AiEngine::converse(
            $messages,
            $tone,
            static function (string $e, mixed $d): void {},
            false,
            'widget',
            $vIp,
            'Сейчас ты отвечаешь в Telegram-боте @vladaero_bot. Пиши компактно (до ~700 символов), без Markdown-таблиц и заголовков #. '
            . 'Разрешены Telegram-HTML: <b>, <i>, <code>. Списки — через «•».'
        );

        if (trim($final) === '') {
            self::send($chatId, '✕ ИИ не смог ответить (ошибка провайдера). Попробуйте ещё раз или /help');
            return;
        }
        self::send($chatId, self::mdToTg($final));

        $messages[] = ['role' => 'assistant', 'content' => mb_substr($final, 0, 1500)];
        Cache::set($hk, array_slice($messages, -8), 21600);
    }

    /** Markdown → Telegram HTML (экранируем всё, возвращаем только разрешённое) */
    private static function mdToTg(string $s): string
    {
        $s = e($s);
        $s = str_replace(['&lt;b&gt;', '&lt;/b&gt;', '&lt;i&gt;', '&lt;/i&gt;', '&lt;code&gt;', '&lt;/code&gt;'], ['<b>', '</b>', '<i>', '</i>', '<code>', '</code>'], $s);
        $s = preg_replace('~\*\*(.+?)\*\*~s', '<b>$1</b>', $s) ?? $s;
        $s = preg_replace('~`([^`\n]+)`~', '<code>$1</code>', $s) ?? $s;
        return $s;
    }

    /** Голосовые сообщения (в.262): AssemblyAI STT → ИИ → текст ответа */
    private static function cmdVoice(int $chatId, array $voice, array $tgUser): void
    {
        $apiKey = (string)setting('tg_stt_api_key', '');

        if ($apiKey === '') {
            self::send($chatId, "🎤 <b>Голосовые сообщения пока не распознаются</b>\n\n"
                . "Для включения вставьте ключ AssemblyAI в админке:\n"
                . "⚙ Настройки → Интеграции → 🔑 AssemblyAI API Key\n\n"
                . "Бесплатные кредиты на старте: assemblyai.com\n"
                . "Пока пишите текстом — /help");
            return;
        }

        $fileId = $voice['file_id'] ?? '';
        if ($fileId === '') {
            self::send($chatId, '✕ Не удалось получить файл голосового сообщения.');
            return;
        }

        // Скачиваем файл из Telegram
        $fileInfo = self::api('getFile', ['file_id' => $fileId]);
        if (($fileInfo['ok'] ?? false) !== true || empty($fileInfo['result']['file_path'])) {
            self::send($chatId, '✕ Не удалось скачать файл из Telegram.');
            return;
        }
        $filePath = (string)$fileInfo['result']['file_path'];
        $fileSize = (int)($fileInfo['result']['file_size'] ?? 0);
        if ($fileSize > 25 * 1048576) {
            self::send($chatId, '✕ Файл слишком большой (' . intdiv($fileSize, 1048576) . ' МБ). Лимит — 25 МБ.');
            return;
        }

        $tgToken = (string)setting('telegram_bot_token', '');
        $tgBase = rtrim((string)setting('tg_api_base', 'https://telegram.v7755837.deno.net'), '/');
        $downloadUrl = $tgBase . '/file/bot' . $tgToken . '/' . $filePath;

        $tmpVoice = sys_get_temp_dir() . '/va_voice_' . bin2hex(random_bytes(4)) . '.ogg';
        $ch = curl_init($downloadUrl);
        if ($ch === false) { self::send($chatId, '✕ Ошибка скачивания.'); return; }
        $fp = @fopen($tmpVoice, 'w');
        if ($fp === false) { curl_close($ch); self::send($chatId, '✕ Ошибка temp.'); return; }
        curl_setopt_array($ch, [
            CURLOPT_FILE => $fp,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTPHEADER => [
                'X-Service: telegram',
                'X-Target-URL: https://api.telegram.org',
            ],
        ]);
        curl_exec($ch);
        $httpCode = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);
        fclose($fp);

        if ($httpCode !== 200 || filesize($tmpVoice) < 100) {
            @unlink($tmpVoice);
            self::send($chatId, '✕ Не удалось скачать голос из Telegram.');
            return;
        }

        $audioData = file_get_contents($tmpVoice);
        @unlink($tmpVoice);
        if ($audioData === false) {
            self::send($chatId, '✕ Ошибка чтения аудиофайла.');
            return;
        }

        // Шаг 1: Upload в AssemblyAI
        $uploadUrl = self::assemblyaiUpload($apiKey, $audioData);
        if ($uploadUrl === null || $uploadUrl === '') {
            self::send($chatId, '✕ Не удалось загрузить аудио в AssemblyAI. Проверьте ключ в настройках.');
            return;
        }

        // Шаг 2: Создание транскрипции
        $transcriptId = self::assemblyaiTranscribe($apiKey, $uploadUrl);
        if ($transcriptId === null || $transcriptId === '') {
            self::send($chatId, '✕ Не удалось создать задачу транскрипции в AssemblyAI.');
            return;
        }

        // Шаг 3: Poll до завершения (макс. 30 секунд)
        $text = self::assemblyaiWaitResult($apiKey, $transcriptId, 30);
        if ($text === null || trim($text) === '') {
            self::send($chatId, "🎤 <b>Не удалось распознать голосовое сообщение</b>\n\n"
                . "Возможно, в аудио нет речи. Попробуйте записать ещё раз или напишите текстом.");
            return;
        }

        // Команда /new — сброс контекста
        if (mb_strtolower(trim($text)) === '/new') {
            self::cmdNew($chatId);
            return;
        }

        self::logActivity($chatId, 'in', 'voice_cmd', 'speech', mb_strlen($text));
        self::send($chatId, '🎤 <i>' . e(mb_substr($text, 0, 300)) . '</i>');

        if (\App\Services\AiService::enabled()) {
            self::cmdAi($chatId, $text);
            return;
        }

        // ИИ не настроен — быстрые подсказки по распознанному тексту
        if (preg_match('~^/(?P<cmd>[a-z_]+)(?:\s+(?P<args>.*))?$~iu', mb_strtolower(trim($text)), $m)) {
            self::route((string)$m['cmd'], trim((string)($m['args'] ?? '')), $chatId, $tgUser);
            return;
        }
        if (preg_match('~^([A-Za-z0-9]{4})$~', $text)) {
            self::cmdWx($chatId, $text);
            return;
        }
        self::send($chatId, "🎤 Голос распознан: «" . e(mb_substr($text, 0, 80)) . "»\n\n"
            . "ИИ-штурман ещё не настроен (ключ задаётся в админке).\nКоманды: /wx /fids /track /random — /help");
    }

    /** AssemblyAI: загрузка аудио, возвращает URL или null */
    private static function assemblyaiUpload(string $apiKey, string $data): ?string
    {
        $proxyBase = rtrim((string)setting('tg_api_base', 'https://telegram.v7755837.deno.net'), '/');
        $url = str_contains($proxyBase, 'deno') ? ($proxyBase . '/v2/upload') : 'https://api.assemblyai.com/v2/upload';
        $ch = curl_init($url);
        if ($ch === false) { return null; }
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 60,
            CURLOPT_POST => true, CURLOPT_POSTFIELDS => $data,
            CURLOPT_HTTPHEADER => [
                'Authorization: ' . $apiKey,
                'Content-Type: application/octet-stream',
                'X-Service: assemblyai',
                'X-Target-URL: https://api.assemblyai.com',
            ],
        ]);
        $resp = (string)curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);
        if ($code !== 200) {
            Logger::warning('AssemblyAI upload failed', ['code' => $code, 'resp' => mb_substr($resp, 0, 300)]);
            return null;
        }
        $json = json_decode($resp, true);
        return is_array($json) ? (string)($json['upload_url'] ?? '') : null;
    }

    /** AssemblyAI: создание транскрипции, возвращает ID или null */
    private static function assemblyaiTranscribe(string $apiKey, string $audioUrl): ?string
    {
        $body = json_encode([
            'audio_url'     => $audioUrl,
            'language_code' => 'ru',
            'punctuate'     => true,
            'format_text'   => true,
            'speech_models' => ['universal-3-pro', 'universal-2'],
        ], JSON_UNESCAPED_UNICODE);
        $proxyBase = rtrim((string)setting('tg_api_base', 'https://telegram.v7755837.deno.net'), '/');
        $url = str_contains($proxyBase, 'deno') ? ($proxyBase . '/v2/transcript') : 'https://api.assemblyai.com/v2/transcript';
        $ch = curl_init($url);
        if ($ch === false) { return null; }
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15,
            CURLOPT_POST => true, CURLOPT_POSTFIELDS => $body,
            CURLOPT_HTTPHEADER => [
                'Authorization: ' . $apiKey,
                'Content-Type: application/json',
                'X-Service: assemblyai',
                'X-Target-URL: https://api.assemblyai.com',
            ],
        ]);
        $resp = (string)curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);
        if ($code !== 200) {
            Logger::warning('AssemblyAI transcribe failed', ['code' => $code, 'resp' => mb_substr($resp, 0, 300)]);
            return null;
        }
        $json = json_decode($resp, true);
        return is_array($json) ? (string)($json['id'] ?? '') : null;
    }

    /** AssemblyAI: poll до завершения (макс. $timeout сек), возвращает текст или null */
    private static function assemblyaiWaitResult(string $apiKey, string $id, int $timeout): ?string
    {
        $start = time();
        $proxyBase = rtrim((string)setting('tg_api_base', 'https://telegram.v7755837.deno.net'), '/');
        $url = str_contains($proxyBase, 'deno') ? ($proxyBase . "/v2/transcript/{$id}") : "https://api.assemblyai.com/v2/transcript/{$id}";
        while ((time() - $start) < $timeout) {
            usleep(1500000); // 1.5 сек
            $ch = curl_init($url);
            if ($ch === false) { return null; }
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 10,
                CURLOPT_HTTPHEADER => [
                    'Authorization: ' . $apiKey,
                    'X-Service: assemblyai',
                    'X-Target-URL: https://api.assemblyai.com',
                ],
            ]);
            $resp = (string)curl_exec($ch);
            curl_close($ch);
            $json = json_decode($resp, true);
            if (!is_array($json)) { continue; }
            $status = (string)($json['status'] ?? '');
            if ($status === 'completed') {
                return (string)($json['text'] ?? '');
            }
            if ($status === 'error') {
                Logger::warning('AssemblyAI transcript error', ['id' => $id, 'error' => (string)($json['error'] ?? '')]);
                return null;
            }
        }
        Logger::warning('AssemblyAI poll timeout', ['id' => $id, 'timeout' => $timeout]);
        return null;
    }

    private static function sendChatAction(int $chatId, string $action): void
    {
        self::api('sendChatAction', ['chat_id' => $chatId, 'action' => $action]);
    }

    /** Лог телеметрии (в.269): входящие/исходящие сообщения для админки */
    private static function logActivity(int $chatId, string $dir, string $kind, string $cmd, int $len): void
    {
        try {
            Database::i()->run(
                'INSERT INTO `{p}tg_activity` (chat_id, direction, kind, command, length, created_at) VALUES (?,?,?,?,?,?)',
                [$chatId, $dir, $kind, $cmd, $len, date('Y-m-d H:i:s')]
            );
        } catch (\Throwable) {
        }
    }

    /** /new — сброс контекста диалога */
    private static function cmdNew(int $chatId): void
    {
        Cache::set('tgai_' . $chatId, [], 3600);
        self::send($chatId, '✦ Новый диалог: контекст очищен. Спрашивайте!');
    }

    /** /tone — тон ИИ (в.181) */
    private static function cmdTone(int $chatId, string $args): void
    {
        $map = ['instructor' => 'instructor', 'пилот' => 'instructor', 'spotter' => 'spotter', 'споттер' => 'spotter', 'academic' => 'academic', 'эксперт' => 'academic'];
        $tone = $map[mb_strtolower(trim($args))] ?? null;
        if ($tone !== null) {
            self::setTone($chatId, $tone);
            return;
        }
        $cur = (string)(Cache::get('tgtone_' . $chatId) ?: 'spotter');
        $names = ['instructor' => 'Пилот-инструктор', 'spotter' => 'Дружелюбный споттер', 'academic' => 'Академический эксперт'];
        $kb = [];
        foreach (['instructor', 'spotter', 'academic'] as $t) {
            $kb[] = [['text' => ($t === $cur ? '● ' : '○ ') . $names[$t], 'callback_data' => 'tone:' . $t]];
        }
        self::send($chatId, '✦ Тон ИИ-штурмана:', ['reply_markup' => self::kb($kb)]);
    }

    private static function setTone(int $chatId, string $tone): void
    {
        Cache::set('tgtone_' . $chatId, $tone, 31536000);
        $names = ['instructor' => '👨‍✈️ Пилот-инструктор', 'spotter' => '📷 Дружелюбный споттер', 'academic' => '🎓 Академический эксперт'];
        self::send($chatId, '✦ Тон изменён: <b>' . $names[$tone] . '</b>');
    }

    /** /link — как привязать профиль */
    private static function cmdLink(int $chatId): void
    {
        $bot = (string)setting('telegram_bot_username', 'vladaero_bot');
        self::send($chatId, "🔗 <b>Привязка профиля портала</b>\n\n"
            . "1. Откройте на портале страницу <b>Telegram</b> (" . self::site('telegram') . ")\n"
            . "2. Скопируйте персональный код\n"
            . "3. Пришлите его сюда: <code>/start КОД</code>\n\n"
            . "После привязки бот будет сообщать статусы модерации ваших фото (" . e($bot) . ', в.116).',
            ['reply_markup' => self::kb([[['text' => ' Открыть страницу привязки', 'url' => self::site('telegram')]]])]);
    }

    /** /login — код входа на сайт (в.66: Telegram-вход по коду) */
    private static function cmdLogin(int $chatId): void
    {
        $link = self::linked($chatId);
        if ($link === null) {
            self::send($chatId, "🔑 <b>Вход по Telegram-коду</b>\n\n"
                . "Для входа на портал этим способом профиль должен быть привязан к боту.\n"
                . "1. На портале откройте страницу Telegram (" . self::site('telegram') . ")\n"
                . "2. Скопируйте персональный код\n"
                . "3. Пришлите его сюда: <code>/start КОД</code>\n\n"
                . "После привязки просто нажмите /login — я выдам код для входа на сайт.",
                ['reply_markup' => self::kb([[['text' => ' Открыть страницу привязки', 'url' => self::site('telegram')]]])]);
            return;
        }
        $code = self::loginCodeFor((int)$link['user_id']);
        self::send($chatId, "🔑 <b>Код входа на портал</b>\n\n"
            . "<code>{$code}</code>\n\n"
            . "Введите этот код на странице входа: " . self::site('login') . "\n"
            . "Действует 2 минуты, одноразовый.",
            ['reply_markup' => self::kb([[['text' => '🔓 Перейти ко входу', 'url' => self::site('login')]]])]);
    }

    /** /whoami */
    private static function cmdWhoami(int $chatId): void
    {
        $link = self::linked($chatId);
        if ($link === null) {
            self::send($chatId, '👤 Профиль портала не привязан. Как привязать — /link');
            return;
        }
        $u = Database::i()->one('SELECT username, role FROM `{p}users` WHERE id = ?', [(int)$link['user_id']]);
        $flags = json_decode((string)$link['notify_flags'], true) ?: [];
        self::send($chatId, '👤 Привязан профиль: <b>' . e((string)($u['username'] ?? '—')) . '</b> (' . e((string)($u['role'] ?? '')) . ")\n"
            . self::notifyText($flags) . "\n"
            . 'Дата привязки: ' . e(substr((string)$link['created_at'], 0, 10)) . "\n\n/notify — настройки · /unlink — отвязать");
    }

    /** /unlink */
    private static function cmdUnlink(int $chatId): void
    {
        $link = self::linked($chatId);
        if ($link === null) { self::send($chatId, 'Профиль и так не привязан.'); return; }
        Database::i()->run('DELETE FROM `{p}tg_links` WHERE id = ?', [$link['id']]);
        self::send($chatId, '✅ Профиль отвязан. Личные уведомления больше не придут. Повторная привязка — /link');
    }

    /** /notify — управление уведомлениями (в.116 + в.255: inline-переключатели) */
    private static function cmdNotify(int $chatId): void
    {
        $link = self::linked($chatId);
        if ($link === null) {
            self::send($chatId, '🔕 Настройки уведомлений доступны после привязки профиля — /link');
            return;
        }
        $flags = json_decode((string)$link['notify_flags'], true) ?: [];
        self::send($chatId, "🔔 <b>Личные уведомления</b>\n\n" . self::notifyText($flags),
            ['reply_markup' => self::kb(self::notifyKb($flags))]);
    }

    /** Текст состояния переключателей */
    private static function notifyText(array $flags): string
    {
        $on = static fn(bool $v) => $v ? 'вкл ✅' : 'выкл ⛔';
        return '• Статусы модерации фото: ' . $on((bool)($flags['photo_moderation'] ?? true)) . "\n"
            . '• Ответы на комментарии: ' . $on((bool)($flags['comment_replies'] ?? true)) . "\n"
            . '• Напоминания о событиях: ' . $on((bool)($flags['event_reminders'] ?? true));
    }

    /** Инлайн-клавиатура переключателей (в.255) */
    private static function notifyKb(array $flags): array
    {
        $btn = static function (string $label, bool $v, string $cb): array {
            return ['text' => ($v ? '🔔 ' : '🔕 ') . $label . ($v ? ' [ВКЛ]' : ' [ВЫКЛ]'), 'callback_data' => $cb];
        };
        return [
            [$btn('Фото: скрининг', (bool)($flags['photo_moderation'] ?? true), 'notify:photo')],
            [$btn('Ответы в комментариях', (bool)($flags['comment_replies'] ?? true), 'notify:comments')],
            [$btn('События: напоминания', (bool)($flags['event_reminders'] ?? true), 'notify:events')],
        ];
    }

    /* ───────────────────────── Регистрация бота (кнопка setWebhook) ───────────────────────── */

    /** setMyCommands (RU) + меню-кнопка «Открыть VladAero» (Telegram Web App) */
    public static function registerCommands(): void
    {
        $cmds = array_map(static fn($c) => ['command' => $c[0], 'description' => mb_substr($c[1], 0, 256)], self::COMMANDS);
        self::api('setMyCommands', ['commands' => json_encode($cmds, JSON_UNESCAPED_UNICODE)]);
        self::api('setChatMenuButton', [
            'menu_button' => json_encode(['type' => 'web_app', 'text' => 'VladAero', 'web_app' => ['url' => self::site()]], JSON_UNESCAPED_UNICODE),
        ]);
    }

    /** Уведомление владельцу фото о вердикте скрининга (в.116; без рассылки модераторам — в.120) */
    public static function notifyPhotoVerdict(array $photo, string $status, string $reason = ''): void
    {
        $link = Database::i()->one(
            "SELECT t.chat_id FROM `{p}tg_links` t WHERE t.user_id = ?
             AND (t.notify_flags IS NULL OR t.notify_flags = '' OR JSON_EXTRACT(t.notify_flags, '$.photo_moderation') = true)",
            [(int)$photo['user_id']]);
        if ($link === null) { return; }
        $title = (string)($photo['title'] ?: $photo['registration'] ?: '#' . $photo['id']);
        $url = self::site('gallery/' . $photo['id']);
        $text = $status === 'approved'
            ? '✅ Ваше фото «' . e($title) . "» прошло скрининг!\nСейчас оно в галерее: " . $url
            : '✕ Фото «' . e($title) . '» отклонено' . ($reason !== '' ? ': ' . e($reason) : '') . "\nПодробнее: " . $url;
        self::send((int)$link['chat_id'], $text);
    }

    /** Ответ на комментарий (в.116: ответы в комментариях) */
    public static function notifyCommentReply(int $toUserId, string $fromUser, string $url, string $excerpt): void
    {
        $link = Database::i()->one(
            "SELECT t.chat_id FROM `{p}tg_links` t WHERE t.user_id = ?
             AND (t.notify_flags IS NULL OR t.notify_flags = '' OR JSON_EXTRACT(t.notify_flags, '$.comment_replies') = true)",
            [$toUserId]);
        if ($link === null) { return; }
        self::send((int)$link['chat_id'],
            '💬 <b>' . e($fromUser) . '</b> ответил на ваш комментарий:\n<i>' . e(mb_substr($excerpt, 0, 200)) . "</i>\n" . $url);
    }

    /** Напоминание о событии за неделю/за день (в.60) */
    public static function notifyEventReminder(int $toUserId, array $event, string $when): void
    {
        $link = Database::i()->one(
            "SELECT t.chat_id FROM `{p}tg_links` t WHERE t.user_id = ?
             AND (t.notify_flags IS NULL OR t.notify_flags = '' OR JSON_EXTRACT(t.notify_flags, '$.event_reminders') = true)",
            [$toUserId]);
        if ($link === null) { return; }
        $dt = date('d.m H:i', strtotime((string)$event['starts_at']));
        self::send((int)$link['chat_id'],
            '📅 <b>' . ($when === 'week' ? 'Через неделю' : 'Завтра') . '</b> — ' . e((string)$event['title_ru']) . "\n"
            . '🗓 ' . $dt . ' UTC' . (!empty($event['city']) ? ' · ' . e((string)$event['city']) : '') . "\n"
            . self::site('events/' . $event['slug']));
    }
}
