<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Cache;
use App\Core\Logger;

/**
 * FIDS — онлайн-табло рейсов (в.279, 281): SkyLink API, бесплатный тариф
 * RapidAPI (1000 запр./мес). Ключ задаётся в админке → Интеграции.
 * Кэш 5 минут (спецификация), деградация на протухший снимок.
 */
final class FidsService
{
    public const TTL = 300; // 5 минут

    /**
     * @param string $type departure|arrival
     * @return array{ok:bool,error?:string,icao:string,type:string,flights:list<array<string,mixed>>}
     */
    public static function board(string $icao, string $type = 'departure'): array
    {
        $icao = strtoupper(preg_replace('~[^A-Za-z0-9]~', '', $icao) ?? '');
        $type = $type === 'arrival' ? 'arrival' : 'departure';
        if (strlen($icao) !== 4) {
            return ['ok' => false, 'error' => 'icao', 'icao' => $icao, 'type' => $type, 'flights' => []];
        }
        $key = (string)setting('skylink_api_key', '');
        if ($key === '') {
            return ['ok' => false, 'error' => 'no_key', 'icao' => $icao, 'type' => $type, 'flights' => []];
        }

        $ck = 'fids_' . strtolower($icao) . '_' . $type;
        $hit = Cache::get($ck);
        if (is_array($hit) && (time() - (int)($hit['_ts'] ?? 0)) <= self::TTL) {
            unset($hit['_ts']);
            return $hit;
        }

        $base = rtrim((string)setting('skylink_api_base', 'https://skylinkapi.com/v2'), '/');
        $url = $base . '/schedules/' . rawurlencode($icao) . '?type=' . $type;
        $ch = curl_init($url);
        if ($ch === false) {
            return ['ok' => false, 'error' => 'source', 'icao' => $icao, 'type' => $type, 'flights' => []];
        }
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 12,
            CURLOPT_CONNECTTIMEOUT => 7,
            CURLOPT_USERAGENT      => 'VladAero-Portal/0.5',
            CURLOPT_HTTPHEADER     => [
                'Authorization: Bearer ' . $key,
                'Accept: application/json',
                'X-Service: skylink',
                'X-Target-URL: https://skylinkapi.com',
            ],
        ]);
        $body = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $err  = curl_error($ch);
        curl_close($ch);
        if ($body === false || $code !== 200) {
            Logger::warning('FIDS: SkyLink недоступен', ['url' => $url, 'code' => $code, 'error' => $err]);
            if (is_array($hit)) { // ленивое обновление (в.83)
                unset($hit['_ts']);
                return $hit;
            }
            return ['ok' => false, 'error' => 'source', 'icao' => $icao, 'type' => $type, 'flights' => []];
        }
        $json = json_decode((string)$body, true);
        $rows = is_array($json) ? ($json['data'] ?? $json['flights'] ?? $json['schedules'] ?? []) : [];

        $flights = [];
        foreach ((array)$rows as $f) {
            if (!is_array($f)) { continue; }
            $flights[] = [
                'flight'  => (string)($f['flight']['iataNumber'] ?? $f['flight_iata'] ?? $f['flightNumber'] ?? $f['number'] ?? '—'),
                'airline' => (string)($f['airline']['name'] ?? $f['airline_name'] ?? ''),
                'dest'    => (string)($f['arrival']['iataCode'] ?? $f['departure']['iataCode'] ?? $f['destination'] ?? ''),
                'sched'   => (string)($f['departure']['scheduledTime'] ?? $f['arrival']['scheduledTime'] ?? $f['scheduled_time'] ?? ''),
                'est'     => (string)($f['departure']['estimatedTime'] ?? $f['arrival']['estimatedTime'] ?? ''),
                'status'  => (string)($f['status'] ?? ''),
                'terminal'=> (string)($f['departure']['terminal'] ?? $f['arrival']['terminal'] ?? ''),
                'gate'    => (string)($f['departure']['gate'] ?? $f['arrival']['gate'] ?? ''),
                'delay'   => (int)($f['departure']['delay'] ?? $f['arrival']['delay'] ?? 0),
            ];
        }
        $out = ['ok' => true, 'icao' => $icao, 'type' => $type, 'flights' => array_slice($flights, 0, 60)];
        Cache::set($ck, $out + ['_ts' => time()], self::TTL + 900);
        return $out;
    }
}
