<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Cache;
use App\Core\Database;
use App\Models\Photo;

/**
 * Реестр инструментов ИИ (в.156–158, 274, 276–277):
 * 20 публичных для виджета + 30 агентских для Супер-Агента = 50.
 * kind: local — исполняется на сервере без LLM; llm — шаблон-подсказка для модели;
 * admin — локальный инструмент с правами администратора.
 */
final class AiToolkit
{
    /** @return array<string, array{cat:string,title:string,desc:string,kind:string,args:string}> */
    public static function tools(bool $admin = false): array
    {
        $list = [
            // ---------- 20 публичных (в.276, порядок спецификации) ----------
            'firecrawl_web_search' => ['cat' => 'web', 'title' => 'Web Search', 'desc' => 'веб-поиск по интернету (Firecrawl; нужен ключ в админке)', 'kind' => 'local', 'args' => '{"q":"запрос"}'],
            'firecrawl_fetch_url'  => ['cat' => 'web', 'title' => 'Fetch URL', 'desc' => 'загрузить страницу по URL и получить её текст (Firecrawl)', 'kind' => 'local', 'args' => '{"url":"https://…"}'],
            'fids_board'        => ['cat' => 'live', 'title' => 'Live Airport FIDS Board', 'desc' => 'онлайн-табло рейсов', 'kind' => 'local', 'args' => '{"icao":"UUEE","type":"departure"}'],
            'radar_track'       => ['cat' => 'live', 'title' => 'Live Flight Radar Tracker', 'desc' => 'позиция борта по callsign/регистрации (ADS-B)', 'kind' => 'local', 'args' => '{"callsign":"AFL123"}'],
            'metar_taf'         => ['cat' => 'wx', 'title' => 'METAR/TAF Weather Decoder', 'desc' => 'погода аэродрома с расшифровкой', 'kind' => 'local', 'args' => '{"icao":"UUEE"}'],
            'crosswind_calc'    => ['cat' => 'nav', 'title' => 'Runway Crosswind Calculator', 'desc' => 'встречная/боковая составляющие ветра', 'kind' => 'local', 'args' => '{"rwy":25,"wind_dir":280,"wind_kt":12}'],
            'unit_convert'      => ['cat' => 'nav', 'title' => 'Unit Converter', 'desc' => 'kt↔км/ч, ft↔m, lb↔kg, FL, гПа↔inHg', 'kind' => 'local', 'args' => '{"value":450,"from":"kt","to":"kmh"}'],
            'gc_ete'            => ['cat' => 'nav', 'title' => 'Great Circle & ETE', 'desc' => 'ортодромия, время полёта, топливо', 'kind' => 'local', 'args' => '{"from":"UUEE","to":"ULLI","gs_kt":450}'],
            'fuel_planning'     => ['cat' => 'nav', 'title' => 'Fuel & Enroute Planning', 'desc' => 'расчёт потребного топлива с резервом', 'kind' => 'local', 'args' => '{"distance_nm":500,"consumption_kg_h":2500,"gs_kt":450}'],
            'icao_resolver'     => ['cat' => 'data', 'title' => 'ICAO/IATA Code Resolver', 'desc' => 'коды и данные аэропортов', 'kind' => 'local', 'args' => '{"query":"Шереметьево"}'],
            'squawk_decoder'    => ['cat' => 'data', 'title' => 'Squawk Emergency Decoder', 'desc' => 'значения кодов ответчика', 'kind' => 'local', 'args' => '{"code":"7700"}'],
            'webcams_finder'    => ['cat' => 'live', 'title' => 'Airport Webcams Finder', 'desc' => 'живые камеры аэропортов', 'kind' => 'local', 'args' => '{"icao":"KSPB"}'],
            'liveatc_scanner'   => ['cat' => 'live', 'title' => 'LiveATC Radio Scanner', 'desc' => 'частоты и каналы УВД аэропорта', 'kind' => 'local', 'args' => '{"icao":"UUEE"}'],
            'golden_hour'       => ['cat' => 'nav', 'title' => 'Golden Hour Calculator', 'desc' => 'восход/закат/золотой час для споттинга', 'kind' => 'local', 'args' => '{"lat":55.97,"lon":37.41,"date":"2026-09-10"}'],
            'registration_lookup' => ['cat' => 'data', 'title' => 'Registration & MSN Lookup', 'desc' => 'борта по регистрации в базе портала', 'kind' => 'local', 'args' => '{"reg":"RA-"}'],
            'notam_parse'       => ['cat' => 'wx', 'title' => 'NOTAM Parser', 'desc' => 'разбор извещения (Q-код, секции)', 'kind' => 'local', 'args' => '{"text":"Q) LIRR/…"}'],
            'qnh_converter'     => ['cat' => 'nav', 'title' => 'Altimeter QNH/QFE/inHg', 'desc' => 'пересчёт давлений и высот', 'kind' => 'local', 'args' => '{"qnh_hpa":1013,"elev_ft":600}'],
            'sim_mod_checker'   => ['cat' => 'llm', 'title' => 'Sim Mod Compatibility', 'desc' => 'совместимость сим-аддонов (экспертиза модели)', 'kind' => 'llm', 'args' => '{}'],
            'qrh_assistant'     => ['cat' => 'llm', 'title' => 'QRH Checklist Assistant', 'desc' => 'помощь по картам контрольных проверок', 'kind' => 'llm', 'args' => '{}'],
            'tldr_summarizer'   => ['cat' => 'llm', 'title' => 'TL;DR Summarizer', 'desc' => 'сжатие статьи/документа', 'kind' => 'llm', 'args' => '{}'],
            // ---------- 30 агентских (в.161–162, 271–272, 277) ----------
            'search_aircraft'   => ['cat' => 'data', 'title' => 'Поиск самолётов', 'desc' => 'по названию/ICAO/ТТХ в энциклопедии', 'kind' => 'local', 'args' => '{"q":"Ту-154"}'],
            'search_airports'   => ['cat' => 'data', 'title' => 'Поиск аэропортов', 'desc' => 'ICAO/IATA/город/ВПП', 'kind' => 'local', 'args' => '{"q":"Рим"}'],
            'search_articles'   => ['cat' => 'data', 'title' => 'Поиск статей', 'desc' => 'энциклопедия и новости', 'kind' => 'local', 'args' => '{"q":"радар"}'],
            'flight_compensation' => ['cat' => 'nav', 'title' => 'Flight Compensation', 'desc' => 'экспресс-расчёт компенсации EC 261/2004', 'kind' => 'local', 'args' => '{"distance_km":1500,"delay_h":3}'],
            'descent_tod'       => ['cat' => 'nav', 'title' => 'Descent / TOD', 'desc' => 'точка начала снижения и V/S', 'kind' => 'local', 'args' => '{"alt_ft":35000,"gs_kt":450}'],
            'admin_create_aircraft' => ['cat' => 'admin', 'title' => 'Черновик карточки ВС', 'desc' => 'генерирует карточку с ТТХ (статус: черновик)', 'kind' => 'admin', 'args' => '{"name":"Ту-204"}'],
            'admin_update_aircraft' => ['cat' => 'admin', 'title' => 'Правка карточки ВС', 'desc' => 'предлагает изменения ТТХ к применению', 'kind' => 'llm', 'args' => '{"slug":"tu-154m"}'],
            'admin_manage_airport'  => ['cat' => 'admin', 'title' => 'Аэропорт: данные', 'desc' => 'предложение по ВПП/частотам/координатам', 'kind' => 'llm', 'args' => '{"icao":"UUEE"}'],
            'admin_manage_airline'  => ['cat' => 'admin', 'title' => 'Авиакомпании: справочник', 'desc' => 'флот и ливреи (предложение)', 'kind' => 'llm', 'args' => '{}'],
            'admin_create_article'  => ['cat' => 'admin', 'title' => 'Черновик статьи', 'desc' => 'генерирует статью блочными блоками', 'kind' => 'admin', 'args' => '{"title":"История Ту-154"}'],
            'admin_update_article'  => ['cat' => 'admin', 'title' => 'Правка статьи', 'desc' => 'редактура текста/структуры (предложение)', 'kind' => 'llm', 'args' => '{"slug":"…"}'],
            'admin_manage_events'   => ['cat' => 'admin', 'title' => 'Календарь событий', 'desc' => 'события: ближайшие, ожидает публикации', 'kind' => 'admin', 'args' => '{}'],
            'admin_screen_photos'   => ['cat' => 'admin', 'title' => 'Очередь скрининга', 'desc' => 'сводка очереди фото', 'kind' => 'admin', 'args' => '{}'],
            'admin_manage_users'    => ['cat' => 'admin', 'title' => 'Пользователи: сводка', 'desc' => 'активность и топ участников', 'kind' => 'admin', 'args' => '{}'],
            'admin_moderate_comments' => ['cat' => 'admin', 'title' => 'Комментарии: очередь', 'desc' => 'карантин мат-фильтра и последние', 'kind' => 'admin', 'args' => '{}'],
            'admin_manage_clubs'    => ['cat' => 'admin', 'title' => 'Клубы: сводка', 'desc' => 'клубы, участники, ожидает одобрения', 'kind' => 'admin', 'args' => '{}'],
            'system_doctor'     => ['cat' => 'admin', 'title' => 'System Self-Healing', 'desc' => 'диагностика таблиц/кэша/медиа/логов', 'kind' => 'admin', 'args' => '{}'],
            'batch_generate'    => ['cat' => 'admin', 'title' => 'Batch Content Creation', 'desc' => 'пакет черновиков по списку моделей', 'kind' => 'admin', 'args' => '{"items":["Ту-204","Ил-96-300"]}'],
            'stats_report'      => ['cat' => 'admin', 'title' => 'Аналитический отчёт', 'desc' => 'ключевые метрики портала', 'kind' => 'admin', 'args' => '{}'],
            'cache_clear'       => ['cat' => 'admin', 'title' => 'Очистка кэша', 'desc' => 'файловый кэш портала', 'kind' => 'admin', 'args' => '{}'],
            'find_broken_links' => ['cat' => 'admin', 'title' => 'Битые ссылки/фото', 'desc' => 'проверка путей медиа в контенте', 'kind' => 'admin', 'args' => '{}'],
            'optimize_tables'   => ['cat' => 'admin', 'title' => 'OPTIMIZE TABLE', 'desc' => 'обслуживание таблиц проекта', 'kind' => 'admin', 'args' => '{}'],
            'db_schema_overview' => ['cat' => 'admin', 'title' => 'Обзор схемы БД', 'desc' => 'таблицы и счётчики', 'kind' => 'admin', 'args' => '{}'],
            'seo_audit'         => ['cat' => 'admin', 'title' => 'SEO-аудит', 'desc' => 'рекомендации по разделам', 'kind' => 'llm', 'args' => '{}'],
            'content_ideas'     => ['cat' => 'admin', 'title' => 'Идеи контента', 'desc' => 'план материалов на месяц', 'kind' => 'llm', 'args' => '{}'],
            'translation_helper' => ['cat' => 'admin', 'title' => 'Перевод материалов', 'desc' => 'RU↔EN авиатексты', 'kind' => 'llm', 'args' => '{}'],
            'fact_check_specs'  => ['cat' => 'admin', 'title' => 'Фактчек ТТХ', 'desc' => 'проверка характеристик', 'kind' => 'llm', 'args' => '{}'],
            'plagiarism_scan'   => ['cat' => 'admin', 'title' => 'Проверка текста', 'desc' => 'оригинальность и перефраз', 'kind' => 'llm', 'args' => '{}'],
            'moderation_summary' => ['cat' => 'admin', 'title' => 'Сводка модерации', 'desc' => 'статусы фото/очередь', 'kind' => 'admin', 'args' => '{}'],
        ];
        return $admin ? $list : array_filter($list, static fn(array $t): bool => $t['cat'] !== 'admin');
    }

    /** Исполнение локального инструмента (без LLM). @return array{tool:string,data:mixed} */
    public static function execute(string $tool, array $args, bool $admin = false): array
    {
        $data = match ($tool) {
            'firecrawl_web_search' => self::firecrawl('search', ['q' => (string)($args['q'] ?? ''), 'limit' => 5]),
            'firecrawl_fetch_url'  => self::firecrawl('scrape', ['url' => (string)($args['url'] ?? '')]),
            'fids_board'        => FidsService::board((string)($args['icao'] ?? ''), (string)($args['type'] ?? 'departure')),
            'radar_track'       => self::radarTrack((string)($args['callsign'] ?? ($args['reg'] ?? ''))),
            'metar_taf'         => ['metar' => WxService::metar((string)($args['icao'] ?? '')), 'taf' => WxService::taf((string)($args['icao'] ?? ''))],
            'crosswind_calc'    => self::crosswind($args),
            'unit_convert'      => self::unitConvert($args),
            'gc_ete'            => self::gcEte($args),
            'fuel_planning'     => self::fuelPlanning($args),
            'icao_resolver'     => self::resolveAirport((string)($args['query'] ?? ($args['icao'] ?? ''))),
            'squawk_decoder'    => self::squawk((string)($args['code'] ?? '')),
            'webcams_finder'    => WxService::webcams((string)($args['icao'] ?? '')),
            'liveatc_scanner'   => self::liveatc((string)($args['icao'] ?? '')),
            'golden_hour'       => self::goldenHour($args),
            'registration_lookup' => Database::i()->all('SELECT id, registration, title, status FROM `{p}photos` WHERE registration LIKE ? LIMIT 10', ['%' . (string)($args['reg'] ?? '') . '%']),
            'notam_parse'       => self::decodeNotam((string)($args['text'] ?? '')),
            'qnh_converter'     => self::qnh($args),
            'search_aircraft'   => self::searchAircraft((string)($args['q'] ?? '')),
            'search_airports'   => self::resolveAirport((string)($args['q'] ?? '')),
            'search_articles'   => self::searchArticles((string)($args['q'] ?? '')),
            'flight_compensation' => self::compensation($args),
            'descent_tod'       => self::tod($args),
            'admin_screen_photos', 'moderation_summary' => Photo::counts() + ['queue' => array_slice(array_map(static fn($p) => ['id' => $p['id'], 'reg' => $p['registration'], 'title' => $p['title']], Photo::queue('pending', 10)), 0, 10)],
            'admin_manage_users' => Database::i()->all('SELECT username, role, rank, reputation, created_at FROM `{p}users` ORDER BY reputation DESC LIMIT 10'),
            'admin_manage_events' => [
                'upcoming' => Database::i()->all('SELECT slug, title_ru, type, starts_at, city FROM `{p}events` WHERE status = "published" AND starts_at >= NOW() ORDER BY starts_at LIMIT 10'),
                'pending' => Database::i()->all('SELECT slug, title_ru, starts_at FROM `{p}events` WHERE status = "pending" ORDER BY starts_at LIMIT 10'),
                'total_published' => (int)Database::i()->val('SELECT COUNT(*) FROM `{p}events` WHERE status = "published"'),
            ],
            'admin_moderate_comments' => [
                'pending' => Database::i()->all('SELECT c.id, c.entity_type, c.entity_id, c.body, u.username FROM `{p}comments` c JOIN `{p}users` u ON u.id = c.user_id WHERE c.status = "pending" ORDER BY c.id DESC LIMIT 10'),
                'counts' => Database::i()->all('SELECT status, COUNT(*) n FROM `{p}comments` GROUP BY status'),
            ],
            'admin_manage_clubs' => [
                'approved' => Database::i()->all('SELECT c.slug, c.title, c.kind, (SELECT COUNT(*) FROM `{p}club_members` m WHERE m.club_id = c.id) members FROM `{p}clubs` c WHERE c.status = "approved" ORDER BY members DESC LIMIT 10'),
                'pending' => Database::i()->all('SELECT c.slug, c.title, u.username owner FROM `{p}clubs` c JOIN `{p}users` u ON u.id = c.owner_id WHERE c.status = "pending" LIMIT 10'),
            ],
            'system_doctor'     => self::systemDoctor(),
            'stats_report'      => self::statsReport(),
            'cache_clear'       => ['cleared' => \App\Core\Cache::clear()],
            'optimize_tables'   => self::optimizeTables(),
            'db_schema_overview' => self::schemaOverview(),
            'find_broken_links' => self::brokenLinks(),
            default             => ['note' => "Инструмент «{$tool}» выполняется моделью как экспертный шаблон"],
        };
        return ['tool' => $tool, 'data' => $data];
    }

    /* ===================== Live-источники ===================== */

    private static function radarTrack(string $cs): array
    {
        $cs = trim($cs);
        if ($cs === '') { return ['error' => 'укажите callsign или регистрацию']; }
        $key = 'adsb_cs_' . md5($cs);
        $hit = Cache::get($key);
        if (is_array($hit)) { return $hit; }
        $proxyBase = rtrim((string)setting('tg_api_base', 'https://telegram.v7755837.deno.net'), '/');
        $url = str_contains($proxyBase, 'deno') ? ($proxyBase . '/v2/callsign/' . rawurlencode($cs)) : ('https://api.adsb.lol/v2/callsign/' . rawurlencode($cs));
        $ch = curl_init($url);
        if ($ch === false) { return ['error' => 'cURL недоступен']; }
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 8,
            CURLOPT_USERAGENT => 'VladAero/0.6',
            CURLOPT_HTTPHEADER => [
                'X-Service: adsb',
                'X-Target-URL: https://api.adsb.lol',
            ],
        ]);
        $body = (string)curl_exec($ch);
        curl_close($ch);
        $json = json_decode($body, true);
        $out = ['source' => 'adsb.lol', 'results' => []];
        foreach ((array)($json['ac'] ?? []) as $a) {
            $out['results'][] = [
                'callsign' => $a['flight'] ?? '', 'reg' => $a['r'] ?? '', 'type' => $a['t'] ?? '',
                'alt_ft' => $a['alt_baro'] ?? null, 'gs_kt' => $a['gs'] ?? null, 'track' => $a['track'] ?? null,
                'lat' => $a['lat'] ?? null, 'lon' => $a['lon'] ?? null, 'squawk' => $a['squawk'] ?? '',
            ];
        }
        if ($out['results'] === []) {
            $out['note'] = 'борт не виден в сети adsb.lol прямо сейчас (илиcallsign указан неверно)';
        }
        Cache::set($key, $out, 30);
        return $out;
    }

    private static function firecrawl(string $mode, array $args): array
    {
        $key = (string)setting('firecrawl_api_key', '');
        if ($key === '') {
            return ['error' => 'no_key', 'note' => 'Ключ Firecrawl не задан (Админка → Настройки → Интеграции). Отвечай по своим знаниям и честно отметь, что живой поиск недоступен.'];
        }
        $q = (string)($args['q'] ?? $args['query'] ?? '');
        $url = (string)($args['url'] ?? '');
        $base = rtrim((string)setting('firecrawl_api_base', 'https://api.firecrawl.dev/v1'), '/');
        $ck = 'fc_' . $mode . '_' . md5($base . '|' . $q . '|' . $url . '|' . ($mode === 'search' ? 'l5' : ''));
        $hit = Cache::get($ck);
        if (is_array($hit)) { return $hit; }
        $ch = curl_init($base . '/' . ($mode === 'search' ? 'search' : 'scrape'));
        if ($ch === false) { return ['error' => 'curl']; }
        $payload = $mode === 'search'
            ? ['query' => $q, 'limit' => max(1, min(8, (int)($args['limit'] ?? 5)))]
            : ['url' => $url, 'formats' => ['markdown']];
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 20,
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . $key,
                'Content-Type: application/json',
                'X-Service: firecrawl',
                'X-Target-URL: https://api.firecrawl.dev',
            ],
            CURLOPT_POST => true, CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE),
        ]);
        $body = (string)curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);
        $json = json_decode($body, true);
        if ($code !== 200) { return ['error' => 'http ' . $code, 'note' => 'Firecrawl ответил кодом ' . $code . ' (проверьте ключ/лимит тарифа).']; }
        if ($mode === 'search') {
            $out = ['results' => array_map(static fn($r) => ['title' => $r['title'] ?? '', 'url' => $r['url'] ?? '', 'snippet' => $r['description'] ?? ''], (array)($json['data'] ?? []))];
            Cache::set($ck, $out, 900); // 15 минут
            return $out;
        }
        $d = $json['data'] ?? [];
        $out = ['url' => $d['metadata']['sourceURL'] ?? $url, 'markdown' => mb_substr((string)($d['markdown'] ?? ''), 0, 6000)];
        Cache::set($ck, $out, 1800); // 30 минут
        return $out;
    }

    private static function liveatc(string $icao): array
    {
        $icao = strtoupper(preg_replace('~[^a-z0-9]~i', '', $icao) ?? '');
        $chs = ['twr' => 'TWR — вышка', 'app' => 'APP — подход', 'gnd' => 'GND — руление', 'dep' => 'DEP — выход', 'atis' => 'ATIS'];
        $out = ['icao' => $icao, 'channels' => []];
        foreach ($chs as $k => $t) {
            $out['channels'][] = ['name' => $t, 'pls' => 'https://www.liveatc.net/play/' . $icao . '_' . $k . '.pls'];
        }
        $out['note'] = 'Прямые потоки LiveATC закрыты Cloudflare: открывайте .pls во внешнем плеере (VLC и т.п.)';
        return $out;
    }

    /* ===================== Расчёты ===================== */

    private static function crosswind(array $a): array
    {
        $rwy = (int)($a['rwy'] ?? 0);
        $dir = (int)($a['wind_dir'] ?? 0);
        $kt  = (float)($a['wind_kt'] ?? 0);
        $hdg = ($rwy % 36) * 10;
        $ang = ($dir - $hdg + 540) % 360 - 180;
        return [
            'runway_heading' => $hdg,
            'headwind_kt' => round($kt * cos(deg2rad($ang)), 1),
            'crosswind_kt' => round($kt * sin(deg2rad($ang)), 1),
            'crosswind_from' => sin(deg2rad($ang)) > 0 ? 'right' : 'left',
        ];
    }

    private static function unitConvert(array $a): array
    {
        $v = (float)($a['value'] ?? 0);
        $units = [
            'kt' => 1.852, 'kmh' => 1, 'mph' => 1.609344, 'ms' => 3.6,
            'ft' => 0.3048, 'm' => 1, 'nm' => 1852, 'km' => 1000, 'mi' => 1609.344,
            'lb' => 0.45359237, 'kg' => 1,
            'hpa' => 1, 'inhg' => 33.8639, 'mmhg' => 1.333224,
        ];
        $from = strtolower((string)($a['from'] ?? '')); $to = strtolower((string)($a['to'] ?? ''));
        if (!isset($units[$from], $units[$to])) { return ['error' => 'неизвестные единицы: ' . $from . '→' . $to]; }
        return ['value' => $v, 'from' => $from, 'to' => $to, 'result' => round($v * $units[$from] / $units[$to], 3)];
    }

    private static function airportCoords(string $code): ?array
    {
        $row = Database::i()->one('SELECT lat, lng, icao, name_ru FROM `{p}airports` WHERE icao = ? OR iata = ? LIMIT 1', [$code, $code]);
        return $row ?: null;
    }

    private static function gcEte(array $a): array
    {
        $A = self::airportCoords(strtoupper((string)($a['from'] ?? '')));
        $B = self::airportCoords(strtoupper((string)($a['to'] ?? '')));
        if (!$A || !$B) { return ['error' => 'аэропорт не найден в каталоге портала (доступен каталог из админки)', 'from' => $a['from'] ?? null, 'to' => $a['to'] ?? null]; }
        $φ1 = deg2rad((float)$A['lat']); $φ2 = deg2rad((float)$B['lat']);
        $Δφ = $φ2 - $φ1; $Δλ = deg2rad((float)$B['lng'] - (float)$A['lng']);
        $d = 2 * asin(sqrt(pow(sin($Δφ / 2), 2) + cos($φ1) * cos($φ2) * pow(sin($Δλ / 2), 2)));
        $nm = $d * 3440.065;
        $gs = max(1, (float)($a['gs_kt'] ?? 450));
        $h = $nm / $gs;
        return [
            'from' => $A['icao'] . ' ' . $A['name_ru'], 'to' => $B['icao'] . ' ' . $B['name_ru'],
            'distance_nm' => round($nm), 'distance_km' => round($nm * 1.852),
            'ete' => gmdate('G:i', (int)round($h * 3600)) . ' ч:м при GS ' . $gs . ' kt',
            'course_true' => round((rad2deg(atan2(sin(deg2rad((float)$B['lng'] - (float)$A['lng'])) * cos($φ2), cos($φ1) * sin($φ2) - sin($φ1) * cos($φ2) * cos(deg2rad((float)$B['lng'] - (float)$A['lng'])))) + 360) % 360),
        ];
    }

    private static function fuelPlanning(array $a): array
    {
        $nm = (float)($a['distance_nm'] ?? 0);
        $gs = max(1, (float)($a['gs_kt'] ?? 450));
        $kg = max(0.1, (float)($a['consumption_kg_h'] ?? 2500));
        $h = $nm / $gs;
        $trip = $h * $kg;
        return [
            'trip_time_h' => round($h, 2), 'trip_fuel_kg' => round($trip),
            'reserve_30min_kg' => round($kg * 0.5), 'alternate_45min_kg' => round($kg * 0.75),
            'total_with_reserves_kg' => round($trip + $kg * 1.25),
            'note' => 'оценка: расход на крейсере, без такса/набора; континентальный резерв 30+45 мин',
        ];
    }

    private static function tod(array $a): array
    {
        $alt = (float)($a['alt_ft'] ?? 35000);
        $gs  = max(1, (float)($a['gs_kt'] ?? 450));
        $fl340 = $alt - 3000; // до 3000 ft AGL
        $dist = $fl340 / 1000 * 3; // эмпирика 3 nm на 1000 футов
        return [
            'descent_from_ft' => $alt, 'to_ft' => 3000,
            'tod_distance_nm' => round($dist),
            'tod_time_min' => round($dist / $gs * 60),
            'vs_fpm_3deg' => round($gs * 101.27 * tan(deg2rad(3))),
        ];
    }

    private static function compensation(array $a): array
    {
        $km = (int)($a['distance_km'] ?? 0);
        $delay = (float)($a['delay_h'] ?? 0);
        if ($delay < 3) { return ['compensation_eur' => 0, 'note' => 'задержка менее 3 часов — компенсация EC 261/2004 не положена']; }
        $base = $km <= 1500 ? 250 : ($km <= 3500 ? 400 : 600);
        if ($delay >= 5) { $base = $km <= 1500 ? 250 : ($km <= 3500 ? 400 : 600); }
        return [
            'distance_km' => $km, 'delay_h' => $delay,
            'compensation_eur' => $base,
            'note' => 'экспресс-оценка EC 261/2004 (внутри ЕС и авиакомпании ЕС); при задержке 3–4 ч на дальних маршрутах сумма может снижаться вдвое',
        ];
    }

    private static function qnh(array $a): array
    {
        $qnh = (float)($a['qnh_hpa'] ?? 1013.25);
        $elev = (float)($a['elev_ft'] ?? 0);
        return [
            'qnh_hpa' => round($qnh, 2), 'qnh_inhg' => round($qnh * 0.02953, 2), 'qnh_mmhg' => round($qnh * 0.750062, 1),
            'qfe_hpa' => round($qnh - $elev * 0.027, 1),
            'pressure_alt_ft' => round($elev + (1013.25 - $qnh) * 27),
            'qfe_note' => 'QFE ≈ QNH − высота×0.027 гПа/фут (барометрическая аппроксимация)',
        ];
    }

    private static function squawk(string $code): array
    {
        $map = [
            '7500' => 'незаконное вмешательство (захват)',
            '7600' => 'потеря радиосвязи',
            '7700' => 'общая авария',
            '7000' => 'VFR, Европа',
            '1200' => 'VFR, США',
            '2000' => 'IFR в контролируемом пространстве без указания',
            '0033' => 'парашютные работы',
        ];
        $code = preg_replace('~\D~', '', $code) ?? '';
        return ['code' => $code, 'meaning' => $map[$code] ?? 'стандартный код, особых значений нет'];
    }

    /** Восход/закат/золотой час (NOAA Solar Approximation) */
    private static function goldenHour(array $a): array
    {
        $lat = (float)($a['lat'] ?? 0);
        $lon = (float)($a['lon'] ?? 0);
        $date = (string)($a['date'] ?? date('Y-m-d'));
        $ts = strtotime($date . ' 12:00 UTC') ?: time();
        $n = gmdate('z', $ts) + 0.5;
        $decl = 0.409 * sin(2 * M_PI / 365 * ($n - 81));
        $cosH = -tan($lat * M_PI / 180) * tan($decl);
        if ($cosH > 1) { return ['error' => 'полярная ночь']; }
        if ($cosH < -1) { return ['error' => 'полярный день']; }
        $H = acos($cosH) * 12 / M_PI; // полудуга в часах
        $solarNoon = 12 - $lon / 15;
        $sr = $solarNoon - $H; $ss = $solarNoon + $H;
        $fmt = static fn(float $h) => sprintf('%02d:%02d', (int)floor($h), (int)round(fmod($h, 1) * 60));
        return [
            'date' => $date, 'lat' => $lat, 'lon' => $lon,
            'sunrise_utc' => $fmt($sr), 'sunset_utc' => $fmt($ss),
            'golden_hour_am_utc' => $fmt($sr) . '–' . $fmt($sr + 1),
            'golden_hour_pm_utc' => $fmt($ss - 1) . '–' . $fmt($ss),
            'note' => 'времена UTC, точность ±5 минут',
        ];
    }

    /* ===================== Данные портала ===================== */

    private static function resolveAirport(string $q): array
    {
        $like = '%' . $q . '%';
        return Database::i()->all(
            'SELECT icao, iata, name_ru, city_ru, country_code, elevation_ft FROM `{p}airports`
             WHERE icao LIKE ? OR iata LIKE ? OR name_ru LIKE ? OR city_ru LIKE ? LIMIT 8',
            [$like, $like, $like, $like]
        );
    }

    private static function searchAircraft(string $q): array
    {
        $like = '%' . $q . '%';
        return Database::i()->all(
            'SELECT slug, name_ru, icao_code, category, manufacturer FROM `{p}aircraft`
             WHERE name_ru LIKE ? OR name_en LIKE ? OR icao_code LIKE ? OR manufacturer LIKE ? LIMIT 10',
            [$like, $like, $like, $like]
        );
    }

    private static function searchArticles(string $q): array
    {
        $like = '%' . $q . '%';
        return Database::i()->all(
            "SELECT slug, title_ru FROM `{p}articles`
             WHERE status = 'published' AND (title_ru LIKE ? OR excerpt_ru LIKE ?) LIMIT 10",
            [$like, $like]
        );
    }

    /** NOTAM-декодер (используется и /tools) */
    public static function decodeNotam(string $text): array
    {
        $out = ['sections' => [], 'q' => [], 'coords' => '', 'schedule' => ''];
        if (preg_match_all('~([A-G]\))\s*(.*?)(?=(?:\s[A-G]\))|$)~us', $text, $mm, PREG_SET_ORDER)) {
            foreach ($mm as $m) { $out['sections'][$m[1]] = trim($m[2]); }
        }
        if ($out['sections'] === []) { $out['sections']['E)'] = $text; }
        $qLine = '';
        if (preg_match('~Q\)\s*(.+)$~im', $text, $qm)) { $qLine = preg_replace('~\s+~', '', trim($qm[1])); }
        if ($qLine !== '' && preg_match('~^([A-Z]{4})/([A-Z]+)/([A-Z0-9]+)/([A-Z0-9]+)/(\d{4})/(\d{4})/([0-9NEWS]+)~', $qLine, $q)) {
            $out['q'] = ['fir' => $q[1], 'code' => $q[2], 'fl' => $q[4], 'from' => $q[5], 'to' => $q[6]];
        }
        if (preg_match('~(\d{2})(\d{2})N(\d{3})(\d{2})E?W?(\d{3})~', $text, $c)) {
            $out['coords'] = sprintf('%s.%s°N %s.%s°, радиус %d км', $c[1], $c[2], $c[3], $c[4], (int)$c[5]);
        }
        $fmt = static fn(string $t) => preg_match('~^\d{10}$~', $t)
            ? substr($t, 4, 2) . '.' . substr($t, 2, 2) . '.' . substr($t, 0, 2) . ' ' . substr($t, 6, 2) . ':' . substr($t, 8, 2) . ' UTC' : $t;
        if (isset($out['sections']['B)'], $out['sections']['C)'])) {
            $out['schedule'] = 'с ' . $fmt($out['sections']['B)']) . ' по ' . $fmt($out['sections']['C)']);
        }
        return $out;
    }

    /* ===================== Административные ===================== */

    private static function systemDoctor(): array
    {
        $tables = ['settings', 'users', 'audit_log', 'aircraft', 'airlines', 'airports', 'articles', 'photos', 'events', 'notifications', 'ai_requests', 'ai_chats', 'ai_chat_messages', 'tg_links', 'media', 'blocks', 'block_drafts', 'comments', 'versus_votes', 'clubs', 'club_members', 'lessons', 'lesson_progress', 'bookmarks', 'event_attendees', 'author_follows', 'dm', 'spot_points', 'push_subscriptions'];
        $prefix = Database::i()->t('users');
        $tpos = substr($prefix, 0, strrpos($prefix, 'users'));
        $existing = [];
        try {
            foreach ($tables as $t) {
                $c = Database::i()->val("SELECT COUNT(*) FROM `{$tpos}{$t}`");
                $existing[$t] = $c !== null ? (int)$c : 'MISSING';
            }
        } catch (\Throwable $e) {
            $existing['error'] = $e->getMessage();
        }
        $cacheFiles = 0; $logErrors = 0; $mediaOrphans = 0;
        foreach (glob(VA_ROOT . '/cache/*.cache') ?: [] as $f) { $cacheFiles++; }
        foreach (glob(VA_ROOT . '/uploads/media/*/*') ?: [] as $f) {
            $rel = str_replace(VA_ROOT . '/', '', $f);
            if (str_ends_with($rel, '_t.webp')) { continue; }
            $used = Database::i()->val('SELECT COUNT(*) FROM `{p}media` WHERE path = ?', [$rel]);
            if (!(int)$used) { $mediaOrphans++; }
        }
        foreach (file(VA_ROOT . '/logs/app.log', FILE_IGNORE_NEW_LINES) ?: [] as $line) {
            if (str_contains($line, 'ERROR')) { $logErrors++; }
        }
        return [
            'tables' => $existing,
            'cache_files' => $cacheFiles,
            'log_errors_total' => $logErrors,
            'media_orphans' => $mediaOrphans,
            'php' => PHP_VERSION,
            'fix_hint' => 'кэш чистится инструментом cache_clear; сироты в медиатеке удаляются в /admin/media',
        ];
    }

    private static function statsReport(): array
    {
        $one = static fn(string $sql) => (int)(Database::i()->val($sql) ?? 0);
        return [
            'users' => $one('SELECT COUNT(*) FROM `{p}users`'),
            'aircraft' => $one('SELECT COUNT(*) FROM `{p}aircraft`'),
            'airports' => $one('SELECT COUNT(*) FROM `{p}airports`'),
            'articles_published' => $one("SELECT COUNT(*) FROM `{p}articles` WHERE status='published'"),
            'photos_approved' => $one("SELECT COUNT(*) FROM `{p}photos` WHERE status='approved'"),
            'photos_pending' => $one("SELECT COUNT(*) FROM `{p}photos` WHERE status='pending'"),
            'ai_requests_24h' => $one('SELECT COUNT(*) FROM `{p}ai_requests` WHERE created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)'),
            'ai_tokens_24h' => $one('SELECT COALESCE(SUM(prompt_tokens+completion_tokens),0) FROM `{p}ai_requests` WHERE created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)'),
        ];
    }

    private static function optimizeTables(): array
    {
        $out = [];
        foreach (['users', 'aircraft', 'airports', 'articles', 'photos', 'media', 'blocks', 'ai_requests'] as $t) {
            try { Database::i()->run("OPTIMIZE TABLE `{p}{$t}`"); $out[$t] = 'ok'; }
            catch (\Throwable $e) { $out[$t] = 'skip'; }
        }
        return ['optimized' => $out];
    }

    private static function schemaOverview(): array
    {
        $out = [];
        foreach (['users', 'aircraft', 'airports', 'articles', 'photos', 'media', 'blocks', 'ai_requests', 'tg_links'] as $t) {
            $out[$t] = (int)(Database::i()->val("SELECT COUNT(*) FROM `{p}{$t}`") ?? 0);
        }
        return $out;
    }

    private static function brokenLinks(): array
    {
        $broken = [];
        foreach (Database::i()->all("SELECT id, slug, hero_photo FROM `{p}aircraft` WHERE hero_photo IS NOT NULL AND hero_photo != '' LIMIT 200") as $a) {
            if (!is_file(VA_ROOT . '/' . $a['hero_photo'])) { $broken[] = ['type' => 'aircraft hero', 'id' => $a['id'], 'slug' => $a['slug'], 'path' => $a['hero_photo']]; }
        }
        foreach (Database::i()->all("SELECT id, filename FROM `{p}photos` LIMIT 500") as $p) {
            if (!is_file(VA_ROOT . '/' . $p['filename'])) { $broken[] = ['type' => 'photo', 'id' => $p['id'], 'path' => $p['filename']]; }
        }
        return ['broken' => $broken, 'count' => count($broken)];
    }
}
