<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Database;

/**
 * Универсальное хранилище блоков (в.108: блоки везде, не только в статьях).
 * Любая сущность (aircraft, article, airport, event…) получает свой набор блоков.
 */
final class Blocks
{
    public const ENTITIES = ['aircraft', 'article', 'airport', 'event'];

    /** Декодированные блоки сущности (null — никогда не сохранялись) */
    public static function get(string $entity, int $entityId): ?array
    {
        $row = Database::i()->one(
            'SELECT blocks FROM `{p}blocks` WHERE entity = ? AND entity_id = ?',
            [$entity, $entityId]
        );
        if ($row === null) {
            return null;
        }
        return \App\Core\BlockRenderer::decode((string)$row['blocks']);
    }

    /** Готовый HTML блоков сущности ('' если блоков нет) */
    public static function render(string $entity, int $entityId): string
    {
        return \App\Core\BlockRenderer::renderList(self::get($entity, $entityId));
    }

    public static function set(string $entity, int $entityId, string $blocksJson, ?int $userId): void
    {
        // нормализуем через декодер: только известные типы
        $blocks = \App\Core\BlockRenderer::decode($blocksJson) ?? [];
        Database::i()->run(
            'REPLACE INTO `{p}blocks` (entity, entity_id, blocks, updated_at, updated_by) VALUES (?, ?, ?, NOW(), ?)',
            [$entity, $entityId, json_encode($blocks, JSON_UNESCAPED_UNICODE), $userId]
        );
        // сохранили — черновик больше не нужен
        self::discardDraft($entity, $entityId, $userId);
    }

    public static function delete(string $entity, int $entityId): void
    {
        Database::i()->run('DELETE FROM `{p}blocks` WHERE entity = ? AND entity_id = ?', [$entity, $entityId]);
    }

    /** Черновик с автосохранением (в.115) */
    public static function saveDraft(string $entity, int $entityId, ?int $userId, string $blocksJson): void
    {
        if ($userId === null || $entityId <= 0) {
            return;
        }
        Database::i()->run(
            'REPLACE INTO `{p}block_drafts` (entity, entity_id, user_id, blocks, updated_at) VALUES (?, ?, ?, ?, NOW())',
            [$entity, $entityId, $userId, substr($blocksJson, 0, 2000000)]
        );
    }

    public static function getDraft(string $entity, int $entityId, ?int $userId): ?array
    {
        if ($userId === null || $entityId <= 0) {
            return null;
        }
        $row = Database::i()->one(
            'SELECT blocks, updated_at FROM `{p}block_drafts` WHERE entity = ? AND entity_id = ? AND user_id = ?',
            [$entity, $entityId, $userId]
        );
        return $row === null ? null : ['blocks' => (string)$row['blocks'], 'updated_at' => (string)$row['updated_at']];
    }

    public static function discardDraft(string $entity, int $entityId, ?int $userId): void
    {
        if ($userId === null) {
            return;
        }
        Database::i()->run(
            'DELETE FROM `{p}block_drafts` WHERE entity = ? AND entity_id = ? AND user_id = ?',
            [$entity, $entityId, $userId]
        );
    }
}
