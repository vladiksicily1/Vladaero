<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Cache;
use App\Core\Database;

/**
 * Настройки сайта (key-value) с файловым кэшем и значениями по умолчанию.
 */
final class Setting
{
    private const CACHE_KEY = 'settings.all';
    private const CACHE_TTL = 120;

    private static ?array $all = null;

    /** Значения по умолчанию (используются, если ключа нет в БД) */
    public const DEFAULTS = [
        'site_name'            => 'VladAero',
        'tagline'              => 'Авиационный портал',
        'default_theme'        => 'dark',
        'default_lang'         => 'ru',
        'maintenance'          => '0',
        'maintenance_text'     => '',
        'registration_enabled' => '1',
        'logo'                 => 'assets/images/logo.png',
        'favicon'              => 'assets/images/favicon.png',
        'hero_image'           => '',
        'hero_title'           => 'Небо ближе, чем кажется',
        'hero_sub'             => 'Энциклопедия авиации, живой радар, споттинг и ИИ-штурман — всё в одном портале',
        // ИИ (вопросы 151–152)
        'ai_base_url'          => '',
        'ai_api_key'           => '',
        'ai_model'             => '',
        'ai_temperature'       => '0.7',
        'ai_system_prompt'     => 'Ты — VladAero Copilot, авиационный консультант портала VladAero. Отвечай точно и по делу, на языке пользователя. Авиационную фразеологию ICAO оставляй на английском с пояснением на русском.',
        'ai_limit_guest'       => '15',
        'ai_limit_user'        => '100',
        // Интеграции
        'telegram_bot_token'   => '',
        'telegram_bot_username'=> 'vladaero_bot',
        'tg_api_base'          => 'https://telegram.v7755837.deno.net',
        'tg_api_proxy'         => '',
        'turnstile_site_key'   => '',
        'turnstile_secret_key' => '',
        'cron_key'             => '',
        'media_watermark'      => '1',
        'skylink_api_key'      => '',
        'skylink_api_base'     => 'https://skylinkapi.com/v2',
        'webcam_custom'        => '',
        'firecrawl_api_key'    => '',
        'tg_webhook_secret'    => '',
    ];

    /** @return array<string,string> */
    public static function all(): array
    {
        if (self::$all !== null) {
            return self::$all;
        }
        self::$all = Cache::remember(self::CACHE_KEY, self::CACHE_TTL, static function (): array {
            $rows = Database::i()->all('SELECT k, v FROM `{p}settings`');
            return array_column($rows, 'v', 'k');
        });
        return self::$all;
    }

    public static function get(string $key, mixed $default = null): mixed
    {
        $all = self::all();
        return $all[$key] ?? $default;
    }

    public static function set(string $key, string $value): void
    {
        Database::i()->run(
            'REPLACE INTO `{p}settings` (k, v) VALUES (?, ?)',
            [$key, $value]
        );
        Cache::delete(self::CACHE_KEY);
        self::$all = null;
    }

    public static function setMany(array $pairs): void
    {
        foreach ($pairs as $k => $v) {
            self::set((string)$k, (string)$v);
        }
    }

    public static function flushCache(): void
    {
        Cache::delete(self::CACHE_KEY);
        self::$all = null;
    }
}
