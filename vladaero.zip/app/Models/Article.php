<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Database;

/**
 * Статьи и новости (блочный контент — в таблице blocks, в.108).
 */
final class Article
{
    public const STATUSES = ['draft', 'review', 'published'];

    public static function find(int $id): ?array
    {
        return Database::i()->one('SELECT * FROM `{p}articles` WHERE id = ?', [$id]);
    }

    public static function findBySlug(string $slug): ?array
    {
        return Database::i()->one('SELECT * FROM `{p}articles` WHERE slug = ?', [$slug]);
    }

    /** Опубликованные (публичная часть) */
    public static function published(int $page = 1, int $size = 10, string $q = ''): array
    {
        $where = "a.status = 'published'";
        $params = [];
        if ($q !== '') {
            $where .= ' AND (a.title_ru LIKE ? OR a.title_en LIKE ? OR a.excerpt_ru LIKE ?)';
            $like = '%' . $q . '%';
            array_push($params, $like, $like, $like);
        }
        $total = (int)(Database::i()->val("SELECT COUNT(*) FROM `{p}articles` a WHERE $where", $params) ?? 0);
        $offset = max(0, ($page - 1) * $size);
        $params[] = $size;
        $params[] = $offset;
        $rows = Database::i()->all(
            "SELECT a.*, u.username AS author FROM `{p}articles` a
             LEFT JOIN `{p}users` u ON u.id = a.author_id
             WHERE $where ORDER BY a.published_at DESC, a.id DESC LIMIT ? OFFSET ?",
            $params
        );
        return ['rows' => $rows, 'total' => $total];
    }

    /** Все статьи (админка) */
    public static function adminSearch(string $q = '', string $status = '', int $limit = 30, int $offset = 0): array
    {
        $where = ['1=1'];
        $params = [];
        if ($q !== '') {
            $where[] = '(title_ru LIKE ? OR slug LIKE ?)';
            $like = '%' . $q . '%';
            array_push($params, $like, $like);
        }
        if (in_array($status, self::STATUSES, true)) {
            $where[] = 'status = ?';
            $params[] = $status;
        }
        $w = implode(' AND ', $where);
        $total = (int)(Database::i()->val("SELECT COUNT(*) FROM `{p}articles` WHERE $w", $params) ?? 0);
        $params[] = $limit;
        $params[] = $offset;
        $rows = Database::i()->all(
            "SELECT a.*, u.username AS author FROM `{p}articles` a
             LEFT JOIN `{p}users` u ON u.id = a.author_id
             WHERE $w ORDER BY a.id DESC LIMIT ? OFFSET ?",
            $params
        );
        return ['rows' => $rows, 'total' => $total];
    }

    public static function create(array $data): int
    {
        $data['created_at'] = date('Y-m-d H:i:s');
        return Database::i()->insert('articles', $data);
    }

    public static function updateById(int $id, array $data): void
    {
        $data['updated_at'] = date('Y-m-d H:i:s');
        Database::i()->update('articles', $data, ['id' => $id]);
    }

    public static function deleteById(int $id): void
    {
        Database::i()->run('DELETE FROM `{p}articles` WHERE id = ?', [$id]);
        \App\Models\Blocks::delete('article', $id);
    }

    public static function incrementViews(int $id): void
    {
        Database::i()->run('UPDATE `{p}articles` SET views = views + 1 WHERE id = ?', [$id]);
    }

    public static function uniqueSlug(string $base, ?int $ignoreId = null): string
    {
        $slug = $base;
        $i = 1;
        while (self::slugTaken($slug, $ignoreId)) {
            $slug = $base . '-' . (++$i);
        }
        return $slug;
    }

    private static function slugTaken(string $slug, ?int $ignoreId): bool
    {
        $row = Database::i()->one('SELECT id FROM `{p}articles` WHERE slug = ?', [$slug]);
        return $row !== null && (int)$row['id'] !== $ignoreId;
    }
}
