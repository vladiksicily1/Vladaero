<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Database;

/**
 * Аэропорты (в.10, 33): каталог + блоки контента.
 */
final class Airport
{
    public static function find(int $id): ?array
    {
        return Database::i()->one('SELECT * FROM `{p}airports` WHERE id = ?', [$id]);
    }

    public static function findByIcao(string $icao): ?array
    {
        return Database::i()->one('SELECT * FROM `{p}airports` WHERE icao = ?', [strtoupper($icao)]);
    }

    /** @return array{rows:list<array>,total:int} */
    public static function search(string $q = '', int $limit = 30, int $offset = 0): array
    {
        $where = ['1=1'];
        $params = [];
        if ($q !== '') {
            $where[] = '(icao LIKE ? OR iata LIKE ? OR name_ru LIKE ? OR name_en LIKE ? OR city_ru LIKE ? OR city_en LIKE ?)';
            $like = '%' . $q . '%';
            array_push($params, $like, $like, $like, $like, $like, $like);
        }
        $w = implode(' AND ', $where);
        $total = (int)(Database::i()->val("SELECT COUNT(*) FROM `{p}airports` WHERE $w", $params) ?? 0);
        $params[] = $limit;
        $params[] = $offset;
        $rows = Database::i()->all(
            "SELECT * FROM `{p}airports` WHERE $w ORDER BY icao LIMIT ? OFFSET ?",
            $params
        );
        return ['rows' => $rows, 'total' => $total];
    }

    public static function create(array $data): int
    {
        return Database::i()->insert('airports', $data);
    }

    public static function updateById(int $id, array $data): void
    {
        Database::i()->update('airports', $data, ['id' => $id]);
    }

    public static function deleteById(int $id): void
    {
        Database::i()->run('DELETE FROM `{p}airports` WHERE id = ?', [$id]);
        \App\Models\Blocks::delete('airport', $id);
    }

    public static function uniqueIcao(string $icao, ?int $ignoreId = null): string
    {
        $row = self::findByIcao($icao);
        if ($row !== null && (int)$row['id'] !== $ignoreId) {
            throw new \RuntimeException('Аэропорт с ICAO ' . $icao . ' уже есть в каталоге');
        }
        return strtoupper($icao);
    }
}
