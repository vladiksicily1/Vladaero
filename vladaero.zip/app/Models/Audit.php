<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Auth;
use App\Core\Database;
use App\Core\Request;

/**
 * Журнал действий (Audit Log, вопрос 109): все изменения админов и модераторов.
 */
final class Audit
{
    public static function log(string $action, string $entity = '', ?int $entityId = null, array $details = []): void
    {
        try {
            Database::i()->insert('audit_log', [
                'user_id'   => Auth::id(),
                'action'    => substr($action, 0, 64),
                'entity'    => substr($entity, 0, 32),
                'entity_id' => $entityId,
                'details'   => $details ? json_encode($details, JSON_UNESCAPED_UNICODE) : null,
                'ip'        => Request::ip(),
                'created_at'=> date('Y-m-d H:i:s'),
            ]);
        } catch (\Throwable $e) {
            \App\Core\Logger::error('Audit log failed: ' . $e->getMessage());
        }
    }

    /** @return array<int,array<string,mixed>> */
    public static function recent(int $limit = 12): array
    {
        return Database::i()->all(
            'SELECT a.*, u.username FROM `{p}audit_log` a
             LEFT JOIN `{p}users` u ON u.id = a.user_id
             ORDER BY a.id DESC LIMIT ' . (int)$limit
        );
    }
}
