<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Database;

/**
 * Пользователи.
 */
final class User
{
    public static function find(int $id): ?array
    {
        return Database::i()->one('SELECT * FROM `{p}users` WHERE id = ?', [$id]);
    }

    public static function findByLogin(string $login): ?array
    {
        return Database::i()->one(
            'SELECT * FROM `{p}users` WHERE username = ? OR email = ? LIMIT 1',
            [$login, $login]
        );
    }

    public static function create(array $data): int
    {
        $data += [
            'role'             => 'user',
            'rank'             => 'cadet',
            'reputation'       => 0,
            'status'           => 'active',
            'failed_attempts'  => 0,
            'created_at'       => date('Y-m-d H:i:s'),
        ];
        return Database::i()->insert('users', $data);
    }

    public static function count(): int
    {
        return (int)(Database::i()->val('SELECT COUNT(*) FROM `{p}users`') ?? 0);
    }

    public static function countSince(string $date): int
    {
        return (int)(Database::i()->val(
            'SELECT COUNT(*) FROM `{p}users` WHERE created_at >= ?', [$date]
        ) ?? 0);
    }

    /** @return array<int,array<string,mixed>> */
    public static function search(string $q = '', int $limit = 30, int $offset = 0): array
    {
        $where = '1=1';
        $params = [];
        if ($q !== '') {
            $where = '(username LIKE ? OR email LIKE ?)';
            $like = '%' . $q . '%';
            $params = [$like, $like];
        }
        $params[] = $limit;
        $params[] = $offset;
        return Database::i()->all(
            "SELECT id, username, email, role, rank, reputation, status, created_at, last_seen
             FROM `{p}users` WHERE $where
             ORDER BY id DESC LIMIT ? OFFSET ?",
            $params
        );
    }

    public static function countFiltered(string $q = ''): int
    {
        if ($q === '') {
            return self::count();
        }
        $like = '%' . $q . '%';
        return (int)(Database::i()->val(
            'SELECT COUNT(*) FROM `{p}users` WHERE username LIKE ? OR email LIKE ?',
            [$like, $like]
        ) ?? 0);
    }

    /** Регистрации по дням для графика (последние N дней) */
    public static function perDay(int $days = 14): array
    {
        $rows = Database::i()->all(
            "SELECT DATE(created_at) d, COUNT(*) c FROM `{p}users`
             WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL ? DAY)
             GROUP BY DATE(created_at)",
            [$days]
        );
        return array_column($rows, 'c', 'd');
    }
}
