<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Database;

/**
 * Веб-уведомления (va_notifications): личная лента пользователя.
 * Telegram-дубли — TelegramService (по notify_flags).
 */
final class Notification
{
    public static function push(int $userId, string $type, array $payload = []): void
    {
        if ($userId === 0) { return; }
        Database::i()->insert('notifications', [
            'user_id' => $userId,
            'type' => mb_substr($type, 0, 48),
            'payload' => json_encode($payload, JSON_UNESCAPED_UNICODE),
            'created_at' => date('Y-m-d H:i:s'),
        ]);
    }

    public static function unreadCount(int $userId): int
    {
        return (int)Database::i()->val(
            'SELECT COUNT(*) FROM `{p}notifications` WHERE user_id = ? AND read_at IS NULL', [$userId]);
    }

    /** @return array<int,array<string,mixed>> */
    public static function latest(int $userId, int $limit = 30): array
    {
        return Database::i()->all(
            'SELECT * FROM `{p}notifications` WHERE user_id = ? ORDER BY id DESC LIMIT ' . max(1, min(100, $limit)),
            [$userId]);
    }

    public static function markAllRead(int $userId): void
    {
        Database::i()->run(
            'UPDATE `{p}notifications` SET read_at = NOW() WHERE user_id = ? AND read_at IS NULL', [$userId]);
    }
}
