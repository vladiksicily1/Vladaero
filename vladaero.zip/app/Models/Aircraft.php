<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Database;

/**
 * Каталог авиатехники (вопросы 6–9): поиск, фильтры по ТТХ и классификации,
 * сортировка, пагинация. specs — JSON с двухуровневыми ТТХ (в.7).
 */
final class Aircraft
{
    public const CATEGORIES = ['civil', 'military', 'ga', 'historic', 'uav'];
    public const STATUSES = ['active', 'stored', 'retired', 'prototype'];

    /** Группы подробных ТТХ: ключ → [заголовок lang, [поля => единица]] */
    public const SPEC_GROUPS = [
        'dim'  => ['ac.specs.dim', [
            'length_m' => 'm', 'wingspan_m' => 'm', 'height_m' => 'm', 'wing_area_m2' => 'm2',
        ]],
        'mass' => ['ac.specs.mass', [
            'mtow_kg' => 'kg', 'mlw_kg' => 'kg', 'empty_kg' => 'kg', 'fuel_kg' => 'kg',
        ]],
        'eng'  => ['ac.specs.eng', [
            'engines' => '', 'thrust_kn' => 'kN',
        ]],
        'fly'  => ['ac.specs.fly', [
            'max_speed_kmh' => 'kmh', 'cruise_speed_kmh' => 'kmh', 'range_km' => 'km',
            'ceiling_m' => 'm', 'takeoff_run_m' => 'm',
        ]],
        'crew' => ['ac.specs.crew', [
            'pax' => '', 'crew' => '',
        ]],
    ];

    /** Поля краткой сводки (в.227: 4 главных ТТХ) */
    public const SUMMARY_FIELDS = ['cruise_speed_kmh', 'range_km', 'ceiling_m', 'pax'];

    public static function find(int $id): ?array
    {
        $row = Database::i()->one('SELECT * FROM `{p}aircraft` WHERE id = ?', [$id]);
        return $row === null ? null : self::hydrate($row);
    }

    public static function findBySlug(string $slug): ?array
    {
        $row = Database::i()->one('SELECT * FROM `{p}aircraft` WHERE slug = ?', [$slug]);
        return $row === null ? null : self::hydrate($row);
    }

    /**
     * Поиск с фильтрами (в.8): ТТХ, классификация, коды ICAO/IATA.
     * @return array{rows:list<array>,total:int}
     */
    public static function search(array $f, int $page = 1, int $size = 12): array
    {
        $where = ['1=1'];
        $params = [];

        $q = trim((string)($f['q'] ?? ''));
        if ($q !== '') {
            // Двуязычный поиск + коды (в.98): «Боинг», «Boeing», «B738», «Ил-76»
            $like = '%' . str_replace(' ', '%', $q) . '%';
            $where[] = '(a.name_ru LIKE ? OR a.name_en LIKE ? OR a.icao_code LIKE ? OR a.iata_code LIKE ? OR a.manufacturer LIKE ?)';
            array_push($params, $like, $like, $like, $like, $like);
        }
        $cat = (string)($f['category'] ?? '');
        if (in_array($cat, self::CATEGORIES, true)) {
            $where[] = 'a.category = ?';
            $params[] = $cat;
        }
        $mfr = (string)($f['manufacturer'] ?? '');
        if ($mfr !== '') {
            $where[] = 'a.manufacturer = ?';
            $params[] = $mfr;
        }
        $country = (string)($f['country'] ?? '');
        if ($country !== '') {
            $where[] = 'a.country LIKE ?';
            $params[] = '%' . $country . '%';
        }
        $status = (string)($f['status'] ?? '');
        if (in_array($status, self::STATUSES, true)) {
            $where[] = 'a.status = ?';
            $params[] = $status;
        }
        // Эпоха по году первого полёта (в.8): диапазоны [от, до)
        $eras = [
            'pre40'  => ['1000-01-01', '1940-01-01'],
            '4070'   => ['1940-01-01', '1970-01-01'],
            '7090'   => ['1970-01-01', '1990-01-01'],
            '9010'   => ['1990-01-01', '2010-01-01'],
            'post10' => ['2010-01-01', '2100-01-01'],
        ];
        $era = (string)($f['era'] ?? '');
        if (isset($eras[$era])) {
            $where[] = 'a.first_flight >= ? AND a.first_flight < ?';
            $params[] = $eras[$era][0];
            $params[] = $eras[$era][1];
        }
        // Фильтры по ТТХ из JSON specs (в.8)
        $minRange = (int)($f['min_range'] ?? 0);
        if ($minRange > 0) {
            $where[] = "CAST(JSON_EXTRACT(a.specs, '$.range_km') AS UNSIGNED) >= ?";
            $params[] = $minRange;
        }
        $minPax = (int)($f['min_pax'] ?? 0);
        if ($minPax > 0) {
            $where[] = "CAST(JSON_EXTRACT(a.specs, '$.pax') AS UNSIGNED) >= ?";
            $params[] = $minPax;
        }

        $sorts = [
            'name'  => 'a.name_ru ASC',
            'new'   => 'a.first_flight DESC',
            'views' => 'a.views DESC, a.id DESC',
        ];
        $order = $sorts[(string)($f['sort'] ?? 'name')] ?? $sorts['name'];
        $w = implode(' AND ', $where);

        $total = (int)(Database::i()->val("SELECT COUNT(*) FROM `{p}aircraft` a WHERE $w", $params) ?? 0);
        $offset = max(0, ($page - 1) * $size);
        $params[] = $size;
        $params[] = $offset;
        $rows = Database::i()->all(
            "SELECT a.* FROM `{p}aircraft` a WHERE $w ORDER BY $order LIMIT ? OFFSET ?",
            $params
        );
        return ['rows' => array_map(self::hydrate(...), $rows), 'total' => $total];
    }

    public static function count(): int
    {
        return (int)(Database::i()->val('SELECT COUNT(*) FROM `{p}aircraft`') ?? 0);
    }

    /** @return list<string> уникальные производители для фильтра */
    public static function manufacturers(): array
    {
        $rows = Database::i()->all(
            "SELECT DISTINCT manufacturer FROM `{p}aircraft`
             WHERE manufacturer IS NOT NULL AND manufacturer <> '' ORDER BY manufacturer"
        );
        return array_column($rows, 'manufacturer');
    }

    public static function uniqueSlug(string $base, ?int $ignoreId = null): string
    {
        $slug = $base;
        $i = 1;
        while (self::slugTaken($slug, $ignoreId)) {
            $slug = $base . '-' . (++$i);
        }
        return $slug;
    }

    private static function slugTaken(string $slug, ?int $ignoreId): bool
    {
        $row = Database::i()->one('SELECT id FROM `{p}aircraft` WHERE slug = ?', [$slug]);
        return $row !== null && (int)$row['id'] !== $ignoreId;
    }

    public static function create(array $data): int
    {
        $data['created_at'] = date('Y-m-d H:i:s');
        return Database::i()->insert('aircraft', $data);
    }

    public static function updateById(int $id, array $data): void
    {
        $data['updated_at'] = date('Y-m-d H:i:s');
        Database::i()->update('aircraft', $data, ['id' => $id]);
    }

    public static function deleteById(int $id): void
    {
        Database::i()->run('DELETE FROM `{p}aircraft` WHERE id = ?', [$id]);
        \App\Models\Blocks::delete('aircraft', $id);
    }

    public static function incrementViews(int $id): void
    {
        Database::i()->run('UPDATE `{p}aircraft` SET views = views + 1 WHERE id = ?', [$id]);
    }

    /** Декодирует specs-JSON в массив */
    private static function hydrate(array $row): array
    {
        $row['specs'] = is_string($row['specs'] ?? null) ? (json_decode($row['specs'], true) ?: []) : ($row['specs'] ?? []);
        return $row;
    }
}
