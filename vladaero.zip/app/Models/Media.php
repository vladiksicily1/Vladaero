<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Database;

/**
 * Медиатека.
 */
final class Media
{
    public const KINDS = ['image', 'video', 'audio', 'panorama', 'model3d', 'file'];

    public static function find(int $id): ?array
    {
        return Database::i()->one('SELECT * FROM `{p}media` WHERE id = ?', [$id]);
    }

    /** @return array{rows:list<array>,total:int} */
    public static function search(string $q = '', string $kind = '', int $limit = 40, int $offset = 0): array
    {
        $where = ['1=1'];
        $params = [];
        if ($q !== '') {
            $where[] = '(original_name LIKE ? OR alt LIKE ? OR credit LIKE ?)';
            $like = '%' . $q . '%';
            array_push($params, $like, $like, $like);
        }
        if (in_array($kind, self::KINDS, true)) {
            $where[] = 'kind = ?';
            $params[] = $kind;
        }
        $w = implode(' AND ', $where);
        $total = (int)(Database::i()->val("SELECT COUNT(*) FROM `{p}media` WHERE $w", $params) ?? 0);
        $params[] = $limit;
        $params[] = $offset;
        $rows = Database::i()->all(
            "SELECT * FROM `{p}media` WHERE $w ORDER BY id DESC LIMIT ? OFFSET ?",
            $params
        );
        return ['rows' => $rows, 'total' => $total];
    }

    public static function count(): int
    {
        return (int)(Database::i()->val('SELECT COUNT(*) FROM `{p}media`') ?? 0);
    }

    public static function deleteById(int $id): void
    {
        $row = self::find($id);
        if ($row !== null) {
            \App\Services\MediaService::deleteFiles($row);
            Database::i()->run('DELETE FROM `{p}media` WHERE id = ?', [$id]);
        }
    }

    public static function updateMeta(int $id, string $alt, string $credit, string $license): void
    {
        Database::i()->update('media', [
            'alt'     => substr($alt, 0, 255),
            'credit'  => substr($credit, 0, 190),
            'license' => substr($license, 0, 64),
        ], ['id' => $id]);
    }
}
