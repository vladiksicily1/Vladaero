<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Database;

/**
 * Споттерское фото (в.11–14): гибридная публикация —
 * новичок через скрининг, проверенный автор сразу.
 */
final class Photo
{
    public const STATUSES = ['pending', 'approved', 'rejected'];
    public const LICENSES = ['ARR', 'CC-BY', 'CC-BY-NC', 'CC0'];

    /** Готовые причины отказа скринера (в.107) */
    public const REJECT_REASONS = [
        'Шум / низкое разрешение',
        'Смаз, шевелёнка',
        'Наклон горизонта',
        'Композиция / обрезка',
        'Дубликат',
        'Не проходит по качеству',
        'Авторские права / чужое фото',
    ];

    private const SELECT = 'SELECT p.*, u.username AS author, a.slug AS ac_slug, a.name_ru AS ac_name,
            ap.icao AS ap_icao, ap.name_ru AS ap_name
        FROM `{p}photos` p
        LEFT JOIN `{p}users` u ON u.id = p.user_id
        LEFT JOIN `{p}aircraft` a ON a.id = p.aircraft_id
        LEFT JOIN `{p}airports` ap ON ap.id = p.airport_id';

    /** Публичная лента (только approved) с фильтрами и сортировкой */
    public static function listing(array $f = [], int $page = 1, int $size = 24): array
    {
        $where = "p.status = 'approved'";
        $params = [];
        if (!empty($f['aircraft_id'])) { $where .= ' AND p.aircraft_id = ?'; $params[] = (int)$f['aircraft_id']; }
        if (!empty($f['airport_id']))  { $where .= ' AND p.airport_id = ?';  $params[] = (int)$f['airport_id']; }
        if (!empty($f['user_id']))     { $where .= ' AND p.user_id = ?';     $params[] = (int)$f['user_id']; }
        if (!empty($f['registration'])) { $where .= ' AND p.registration LIKE ?'; $params[] = '%' . $f['registration'] . '%'; }

        $order = match ($f['sort'] ?? 'new') {
            'top'   => 'p.likes DESC, p.id DESC',
            'views' => 'p.views DESC, p.id DESC',
            default => 'p.id DESC',
        };

        $total = (int)(Database::i()->val("SELECT COUNT(*) FROM `{p}photos` p WHERE $where", $params) ?? 0);
        $pages = max(1, (int)ceil($total / $size));
        $page  = max(1, min($page, $pages));
        $off   = ($page - 1) * $size;
        $items = Database::i()->all(self::SELECT . " WHERE $where ORDER BY $order LIMIT $size OFFSET $off", $params);
        return ['items' => $items, 'total' => $total, 'pages' => $pages, 'page' => $page];
    }

    /** Топ недели (в.14) */
    public static function topWeek(int $limit = 3): array
    {
        return Database::i()->all(
            self::SELECT . " WHERE p.status = 'approved' AND p.created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
             ORDER BY p.likes DESC, p.views DESC LIMIT " . (int)$limit
        );
    }

    public static function find(int $id): ?array
    {
        return Database::i()->one(self::SELECT . ' WHERE p.id = ?', [$id]);
    }

    /** Видно публично, если approved; владелец видит любые свои (превью скрининга) */
    public static function findVisible(int $id, ?int $viewerId, bool $staff = false): ?array
    {
        $row = self::find($id);
        if ($row === null) { return null; }
        if ($row['status'] === 'approved' || $staff || ((int)$viewerId === (int)$row['user_id'])) {
            return $row;
        }
        return null;
    }

    public static function create(array $row): int
    {
        $id = Database::i()->insert('photos', [
            'user_id'      => $row['user_id'],
            'aircraft_id'  => $row['aircraft_id'] ?: null,
            'airport_id'   => $row['airport_id'] ?: null,
            'registration' => $row['registration'] ?: null,
            'title'        => $row['title'] ?: null,
            'license'      => in_array($row['license'], self::LICENSES, true) ? $row['license'] : 'ARR',
            'filename'     => $row['filename'],
            'original_name'=> $row['original_name'] ?? null,
            'exif'         => $row['exif'] ?? null,
            'status'       => in_array($row['status'], self::STATUSES, true) ? $row['status'] : 'pending',
            'taken_at'     => $row['taken_at'] ?: null,
            'created_at'   => date('Y-m-d H:i:s'),
        ]);
        return $id;
    }

    /** Вердикт скринера (в.11, 107) */
    public static function setStatus(int $id, string $status, string $reason = ''): bool
    {
        if (!in_array($status, self::STATUSES, true)) { return false; }
        Database::i()->run(
            'UPDATE `{p}photos` SET status = ?, reject_reason = ? WHERE id = ?',
            [$status, $reason !== '' ? $reason : null, $id]
        );
        return true;
    }

    public static function incViews(int $id): void
    {
        Database::i()->run('UPDATE `{p}photos` SET views = views + 1 WHERE id = ?', [$id]);
    }

    public static function like(int $id): void
    {
        Database::i()->run('UPDATE `{p}photos` SET likes = likes + 1 WHERE id = ?', [$id]);
    }

    /** Очередь скрининга: сначала pending */
    public static function queue(string $status = 'pending', int $limit = 60): array
    {
        $status = in_array($status, self::STATUSES, true) ? $status : 'pending';
        return Database::i()->all(self::SELECT . " WHERE p.status = ? ORDER BY p.id DESC LIMIT " . (int)$limit, [$status]);
    }

    /** Счётчики для табов скрининга */
    public static function counts(): array
    {
        $rows = Database::i()->all('SELECT status, COUNT(*) c FROM `{p}photos` GROUP BY status');
        $out = ['pending' => 0, 'approved' => 0, 'rejected' => 0];
        foreach ($rows as $r) { $out[$r['status']] = (int)$r['c']; }
        return $out;
    }
}
