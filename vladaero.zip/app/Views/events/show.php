<?php /** Карточка события (в.57): «Я пойду», календари, участники, медиа-хаб */ ?>
<section class="ac-layout narrow">
    <div class="page-head">
        <h1>📅 <?= e($ev['title_ru']) ?></h1>
    </div>

    <div class="panel" style="padding:22px">
        <div class="ev-meta">
            <span><i class="ev-type ev-<?= e($ev['type']) ?>"><?= e($typeLabel) ?></i></span>
            <span>🗓 <b><?= e(date('d.m.Y H:i', strtotime((string)$ev['starts_at']))) ?> UTC</b>
                <?= $ev['ends_at'] ? '— ' . e(date('d.m H:i', strtotime((string)$ev['ends_at']))) : '' ?></span>
            <?php if ($ev['city'] || $ev['country_code']): ?>
            <span>📍 <?= e(trim($ev['city'] . ($ev['venue'] ? ' · ' . $ev['venue'] : '') . ', ' . $ev['country_code'], ', ')) ?></span>
            <?php endif; ?>
        </div>

        <?php if (trim((string)$ev['description_ru']) !== ''): ?>
        <div class="ev-desc"><?= nl2br(e($ev['description_ru'])) ?></div>
        <?php endif; ?>
        <?php if ($ev['url']): ?>
        <p>🔗 <a href="<?= e($ev['url']) ?>" rel="noopener nofollow" target="_blank"><?= e($ev['url']) ?></a></p>
        <?php endif; ?>

        <div class="ev-actions">
            <form method="post" action="<?= url('/events/' . $ev['slug'] . '/attend') ?>" class="inline">
                <?= csrf_field() ?>
                <button class="btn <?= $going ? '' : 'btn-primary' ?>" type="submit">
                    <?= $going ? '✓ ' . e(__('ev.you_going')) : '👍 ' . e(__('ev.i_will_go')) ?>
                </button>
            </form>
            <a class="btn" href="<?= url('/events/' . $ev['slug'] . '/ics') ?>" download>🗓 .ics</a>
            <a class="btn" href="<?= e($gcal) ?>" target="_blank" rel="noopener">Google Calendar</a>
        </div>

        <h3 class="side-title" style="margin-top:22px">👥 <?= e(__('ev.attendees')) ?> (<?= count($attendees) ?>)</h3>
        <?php if ($attendees === []): ?>
            <p class="muted small"><?= e(__('ev.no_attendees')) ?></p>
        <?php else: ?>
            <div class="ev-attendees">
                <?php foreach ($attendees as $a): ?>
                <span class="chip"><span class="avatar avatar--sm"><?= e(mb_strtoupper(mb_substr($a['username'], 0, 1))) ?></span><?= e($a['username']) ?></span>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        <p class="muted small"><?= e(__('ev.reminder_hint')) ?></p>
    </div>

    <?php if ($photos !== []): ?>
    <div class="panel" style="padding:22px;margin-top:18px">
        <h3 class="side-title">🖼 <?= e(__('ev.media_hub')) ?></h3>
        <div class="ev-photos">
            <?php foreach ($photos as $ph): ?>
            <a href="<?= url('/gallery/' . $ph['id']) ?>" class="ev-ph">
                <img src="<?= e(url('uploads/media/' . rawurlencode((string)$ph['filename']))) ?>" alt="<?= e($ph['title'] ?: $ph['registration']) ?>" loading="lazy">
            </a>
            <?php endforeach; ?>
        </div>
        <p class="muted small"><?= e(__('ev.media_hint')) ?></p>
    </div>
    <?php endif; ?>

    <?= \App\Core\View::partial('partials/comments', [
        'cType' => 'event',
        'cId' => (int)$ev['id'],
        'cTree' => \App\Services\CommentService::tree('event', (int)$ev['id'], \App\Core\Auth::id() ?? 0),
        'cBack' => '/events/' . $ev['slug'],
    ]) ?>
</section>
