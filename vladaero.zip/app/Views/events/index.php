<?php /** Календарь событий (в.56–60): карта с пинами + фильтры */ ?>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<section class="ac-layout">
    <div class="page-head">
        <h1>📅 <?= e(__('ev.title')) ?></h1>
        <a class="btn btn-primary" href="<?= url('/events/create') ?>">＋ <?= e(__('ev.create')) ?></a>
    </div>
    <p class="muted"><?= e(__('ev.intro')) ?></p>

    <form class="ev-filters panel" method="get" action="<?= url('/events') ?>">
        <select name="type">
            <option value=""><?= e(__('ev.all_types')) ?></option>
            <?php foreach ($types as $k => $t): ?>
            <option value="<?= e($k) ?>" <?= $filters['type'] === $k ? 'selected' : '' ?>><?= e($t) ?></option>
            <?php endforeach; ?>
        </select>
        <select name="country">
            <option value=""><?= e(__('ev.all_countries')) ?></option>
            <?php foreach ($countries as $c): ?>
            <option value="<?= e($c['country_code']) ?>" <?= $filters['country'] === $c['country_code'] ? 'selected' : '' ?>><?= e($c['country_code']) ?> (<?= (int)$c['n'] ?>)</option>
            <?php endforeach; ?>
        </select>
        <label class="chk"><input type="checkbox" name="past" value="1" <?= $filters['past'] ? 'checked' : '' ?>> <?= e(__('ev.past')) ?></label>
        <button class="btn" type="submit">⌕</button>
    </form>

    <div class="panel ev-map-wrap">
        <div id="evMap" class="ev-map"></div>
    </div>

    <div class="ev-grid">
        <?php foreach ($events as $ev): ?>
        <a class="ev-card panel" href="<?= url('/events/' . $ev['slug']) ?>">
            <div class="ev-date">
                <b><?= e(date('d', strtotime((string)$ev['starts_at']))) ?></b>
                <span><?= e(__('common.month_' . (int)date('n', strtotime((string)$ev['starts_at'])))) ?></span>
            </div>
            <div class="ev-info">
                <b class="ev-title"><?= e($ev['title_ru']) ?></b>
                <div class="muted small">
                    <i class="ev-type ev-<?= e($ev['type']) ?>"><?= e(__('ev.type_' . $ev['type'])) ?></i>
                    · <?= e(date('H:i', strtotime((string)$ev['starts_at']))) ?> UTC
                    <?php if ($ev['city']): ?> · 📍 <?= e(trim($ev['city'] . ($ev['country_code'] ? ', ' . $ev['country_code'] : ''))) ?><?php endif; ?>
                </div>
                <div class="small muted">👥 <?= (int)$ev['attendees'] ?> <?= e(__('ev.going_count')) ?>
                    <?php if (in_array((int)$ev['id'], $myEvents ?? [], true)): ?><i class="tag-soon">✓ <?= e(__('ev.you_going')) ?></i><?php endif; ?>
                </div>
            </div>
        </a>
        <?php endforeach; ?>
        <?php if ($events === []): ?>
        <div class="panel muted"><?= e(__('ev.empty')) ?></div>
        <?php endif; ?>
    </div>
</section>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
window.addEventListener('load', function () {
    var el = document.getElementById('evMap');
    if (!el || typeof L === 'undefined') { return; }
    var base = document.documentElement.getAttribute('data-base') || '';
    var map = L.map(el, { scrollWheelZoom: false, worldCopyJump: true }).setView([48, 20], 2);
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 10, attribution: '© OpenStreetMap'
    }).addTo(map);
    var pins = <?= json_encode(array_values(array_filter(array_map(static fn($e) => $e['lat'] !== null ? [
        'lat' => (float)$e['lat'], 'lng' => (float)$e['lng'],
        'title' => $e['title_ru'], 'url' => url('/events/' . $e['slug']),
        'date' => substr((string)$e['starts_at'], 0, 10),
    ] : null, $events))), JSON_UNESCAPED_UNICODE) ?>;
    pins.forEach(function (p) {
        L.marker([p.lat, p.lng]).addTo(map).bindPopup(
            '<b><a href="' + p.url + '">' + p.title + '</a></b><br>' + p.date
        );
    });
});
</script>
