<?php /** Создание встречи/выезда (в.57) — на модерацию */ ?>
<section class="ac-layout narrow">
    <div class="page-head"><h1>＋ <?= e(__('ev.create')) ?></h1></div>
    <div class="panel" style="padding:22px">
        <p class="muted"><?= e(__('ev.create_intro')) ?></p>
        <form method="post" action="<?= url('/events/create') ?>" class="stack-form">
            <?= csrf_field() ?>
            <label class="f"><?= e(__('ev.f_title')) ?><input name="title" required maxlength="220"></label>
            <div class="form-row">
                <label class="f"><?= e(__('ev.f_type')) ?>
                    <select name="type">
                        <?php foreach ($types as $k => $t): ?><option value="<?= e($k) ?>"><?= e($t) ?></option><?php endforeach; ?>
                    </select>
                </label>
                <label class="f"><?= e(__('ev.f_starts')) ?><input type="datetime-local" name="starts" required></label>
                <label class="f"><?= e(__('ev.f_ends')) ?><input type="datetime-local" name="ends"></label>
            </div>
            <div class="form-row">
                <label class="f"><?= e(__('ev.f_country')) ?><input name="country" maxlength="2" placeholder="RU"></label>
                <label class="f"><?= e(__('ev.f_city')) ?><input name="city" maxlength="120"></label>
                <label class="f"><?= e(__('ev.f_venue')) ?><input name="venue" maxlength="190"></label>
            </div>
            <div class="form-row">
                <label class="f"><?= e(__('ev.f_lat')) ?><input name="lat" inputmode="decimal" placeholder="55.97"></label>
                <label class="f"><?= e(__('ev.f_lng')) ?><input name="lng" inputmode="decimal" placeholder="37.41"></label>
            </div>
            <label class="f"><?= e(__('ev.f_desc')) ?><textarea name="description" rows="5" maxlength="5000"></textarea></label>
            <label class="f">URL<input name="url" maxlength="255" placeholder="https://…"></label>
            <button class="btn btn-primary" type="submit">✈ <?= e(__('ev.submit')) ?></button>
        </form>
    </div>
</section>
