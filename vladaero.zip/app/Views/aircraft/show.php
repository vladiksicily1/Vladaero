<?php /** Карточка самолёта: двухуровневые ТТХ (в.6–7), Schema.org (в.103), хлебные крошки (в.100) */
$unitLabel = static fn(string $u): string => $u === '' ? '' : ' ' . __($u);
$jsonLd = [
    '@context'   => 'https://schema.org',
    '@type'      => 'Product',
    'name'       => $ac['name_ru'],
    'category'   => __('ac.category.' . $ac['category']),
    'brand'      => ['@type' => 'Brand', 'name' => (string)($ac['manufacturer'] ?? '')],
    'additionalProperty' => [],
];
foreach ($summary as $k => $v) {
    $jsonLd['additionalProperty'][] = ['@type' => 'PropertyValue', 'name' => __('spec.' . $k), 'value' => $v];
}
?>
<section class="page-head">
    <nav class="crumbs" aria-label="Breadcrumb">
        <a href="<?= url('/') ?>"><?= e(__('nav.home')) ?></a><span>›</span>
        <a href="<?= url('/aircraft') ?>"><?= e(__('nav.encyclopedia')) ?></a><span>›</span><span><?= e($ac['name_ru']) ?></span>
    </nav>
    <script type="application/ld+json"><?= json_encode($jsonLd, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?></script>
</section>

<section class="ac-hero">
    <?php if (!empty($ac['hero_photo'])): ?>
        <img class="ac-hero__img" src="<?= e(url($ac['hero_photo'])) ?>" alt="<?= e($ac['name_ru']) ?>">
    <?php else: ?>
        <div class="ac-hero__img ac-hero__img--sil"><?= \App\Core\View::partial('partials/silhouette') ?></div>
    <?php endif; ?>
    <div class="ac-hero__info">
        <div class="ac-hero__codes">
            <span class="ac-badge ac-badge--<?= e($ac['status']) ?>"><?= e(__('ac.status.' . $ac['status'])) ?></span>
            <?php if ($ac['icao_code']): ?><span class="chip mono"><?= e($ac['icao_code']) ?></span><?php endif; ?>
            <?php if ($ac['iata_code']): ?><span class="chip mono"><?= e($ac['iata_code']) ?></span><?php endif; ?>
            <span class="chip"><?= e(__('ac.category.' . $ac['category'])) ?></span>
        </div>
        <h1><?= e($ac['name_ru']) ?></h1>
        <?php if ($ac['name_en']): ?><div class="muted"><?= e($ac['name_en']) ?></div><?php endif; ?>
        <div class="ac-hero__facts muted">
            <?php if ($ac['manufacturer']): ?><span>🏭 <?= e($ac['manufacturer']) ?></span><?php endif; ?>
            <?php if ($ac['country']): ?><span>📍 <?= e($ac['country']) ?></span><?php endif; ?>
            <?php if ($ac['first_flight']): ?><span>🛫 <?= e(__('ac.first_flight')) ?>: <?= e(date('d.m.Y', strtotime((string)$ac['first_flight']))) ?></span><?php endif; ?>
            <span>👁 <?= (int)$ac['views'] ?></span>
        </div>
        <?php if ($summary !== []): ?>
            <div class="ac-summary">
                <?php foreach ($summary as $k => $v): ?>
                    <div class="stat"><b><?= e(number_format((float)$v, 0, '', ' ')) ?></b>
                        <span><?= e(__('spec.' . $k)) ?><?= in_array($k, ['cruise_speed_kmh'], true) ? ', ' . e(__('u.kmh')) : ($k === 'range_km' ? ', ' . e(__('u.km')) : ($k === 'ceiling_m' ? ', ' . e(__('u.m')) : '')) ?></span></div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</section>

<div class="ac-layout">
    <div class="ac-main">
        <?php if (!empty($ac['description_ru'])): ?>
            <div class="panel">
                <div class="panel-head"><h3><?= e(__('ac.history')) ?></h3></div>
                <div class="article-text"><?= nl2br(e($ac['description_ru'])) ?></div>
            </div>
        <?php endif; ?>

        <?php $blocksHtml = \App\Models\Blocks::render('aircraft', (int)$ac['id']); ?>
        <?php if ($blocksHtml !== ''): ?>
            <?= $blocksHtml ?>
        <?php endif; ?>

        <div class="panel">
            <div class="panel-head"><h3><?= e(__('ac.specs.detailed')) ?> <span class="muted small">(для профи и симмеров, в.7)</span></h3></div>
            <?php $any = false; ?>
            <?php foreach ($groups as [$groupLabel, $fields]): ?>
                <?php $rows = array_filter($fields, static fn($u, $f) => isset($specs[$f]) && $specs[$f] !== '', ARRAY_FILTER_USE_BOTH); ?>
                <?php if ($rows === []) { continue; } $any = true; ?>
                <h4 class="spec-group"><?= e(__($groupLabel)) ?></h4>
                <div class="kv">
                    <?php foreach ($rows as $f => $u): ?>
                        <div class="kv-row"><span><?= e(__('spec.' . $f)) ?><?= $u !== '' ? ' (' . e(__($u)) . ')' : '' ?></span>
                            <b class="mono"><?= e(is_float($specs[$f]) && $specs[$f] == (int)$specs[$f] ? number_format((int)$specs[$f], 0, '', ' ') : (string)$specs[$f]) ?></b></div>
                    <?php endforeach; ?>
                </div>
            <?php endforeach; ?>
            <?php if (!$any): ?><p class="muted pad"><?= e(__('ac.specs.empty')) ?></p><?php endif; ?>
        </div>

        <div class="stub-grid">
            <div class="panel stub"><h3>🎭 <?= e(__('ac.mods')) ?></h3><p class="muted">Дерево модификаций и вариантов — <span class="tag-soon">v0.2</span></p></div>
            <div class="panel stub"><h3>▣ <?= e(__('ac.gallery')) ?></h3><p class="muted">Фотогалерея модели и ливрей — споттерская загрузка в <span class="tag-soon">v0.3</span></p></div>
            <div class="panel stub"><h3>⟠ 3D / Cockpit View</h3><p class="muted">GLB-просмотрщик и 360° панорамы кабин — <span class="tag-soon">v0.3</span></p></div>
            <div class="panel stub"><h3>⚠ <?= e(__('ac.safety')) ?></h3><p class="muted">Список происшествий и safety record — <span class="tag-soon">v0.4</span></p></div>
        </div>
    </div>

    <aside class="ac-side">
        <div class="panel">
            <div class="panel-head"><h3><?= e(__('ac.specs.summary')) ?></h3></div>
            <div class="kv">
                <div class="kv-row"><span>ICAO / IATA</span><b class="mono"><?= e($ac['icao_code'] ?: '—') ?> / <?= e($ac['iata_code'] ?: '—') ?></b></div>
                <div class="kv-row"><span><?= e(__('ac.manufacturer')) ?></span><b><?= e($ac['manufacturer'] ?: '—') ?></b></div>
                <div class="kv-row"><span><?= e(__('ac.country')) ?></span><b><?= e($ac['country'] ?: '—') ?></b></div>
                <div class="kv-row"><span><?= e(__('ac.first_flight')) ?></span><b class="mono"><?= e($ac['first_flight'] ? date('d.m.Y', strtotime((string)$ac['first_flight'])) : '—') ?></b></div>
            </div>
        </div>
        <div class="panel">
            <div class="panel-head"><h3><?= e(__('common.actions')) ?></h3></div>
            <div class="quick-actions">
                <button class="btn btn--ghost" type="button" disabled>⚖ <?= e(__('nav.compare')) ?> <span class="tag-soon">v0.3</span></button>
                <button class="btn btn--ghost" type="button" disabled>◎ <?= e(__('ac.track_live')) ?> <span class="tag-soon">v0.3</span></button>
                <a class="btn btn--ghost" href="<?= url('/aircraft') ?>">← <?= e(__('ac.catalog_title')) ?></a>
            </div>
        </div>
    </aside>
</div>

<?= \App\Core\View::partial('partials/bookmark', ['bmType' => 'aircraft', 'bmId' => (int)$ac['id'], 'bmBack' => '/aircraft/' . $ac['slug']]) ?>
<?= \App\Core\View::partial('partials/comments', [
    'cType' => 'aircraft',
    'cId' => (int)$ac['id'],
    'cTree' => \App\Services\CommentService::tree('aircraft', (int)$ac['id'], \App\Core\Auth::id() ?? 0),
    'cBack' => '/aircraft/' . $ac['slug'],
]) ?>
