<?php /** Каталог авиатехники: фильтры (в.8) + сетка карточек (в.227) */
$catChips = ['' => 'Все'] + array_combine(
    \App\Models\Aircraft::CATEGORIES,
    array_map(static fn($c) => __('ac.category.' . $c), \App\Models\Aircraft::CATEGORIES)
);
$qs = static function (array $override = []) use ($filters): string {
    $p = array_merge($filters, $override);
    unset($p['page']);
    return url('/aircraft') . '?' . http_build_query(array_filter($p, static fn($v) => $v !== '' && $v !== null && $v !== 0));
};
?>
<section class="page-head">
    <nav class="crumbs" aria-label="Breadcrumb">
        <a href="<?= url('/') ?>"><?= e(__('nav.home')) ?></a><span>›</span><span><?= e(__('nav.encyclopedia')) ?></span>
    </nav>
    <h1><?= e(__('ac.catalog_title')) ?></h1>
    <p class="muted"><?= str_replace(':n', '<b class="t-ok">' . (int)$total . '</b>', e(__('ac.found'))) ?></p>
</section>

<form method="get" action="<?= url('/aircraft') ?>" class="filter-bar">
    <input type="search" name="q" value="<?= e($filters['q']) ?>" placeholder="<?= e(__('ac.search_ph')) ?>…" class="filter-q">
    <select name="category">
        <?php foreach ($catChips as $k => $label): ?>
            <option value="<?= e($k) ?>" <?= $filters['category'] === $k ? 'selected' : '' ?>><?= e($label) ?></option>
        <?php endforeach; ?>
    </select>
    <select name="manufacturer">
        <option value=""><?= e(__('ac.manufacturer')) ?>: <?= e(__('common.any')) ?></option>
        <?php foreach ($manufacturers as $m): ?>
            <option value="<?= e($m) ?>" <?= $filters['manufacturer'] === $m ? 'selected' : '' ?>><?= e($m) ?></option>
        <?php endforeach; ?>
    </select>
    <select name="era">
        <option value=""><?= e(__('ac.era')) ?>: <?= e(__('common.any')) ?></option>
        <?php foreach (['pre40' => 'До 1940-х', '4070' => '1940–1969', '7090' => '1970–1989', '9010' => '1990–2009', 'post10' => 'После 2010'] as $k => $label): ?>
            <option value="<?= e($k) ?>" <?= $filters['era'] === $k ? 'selected' : '' ?>><?= e($label) ?></option>
        <?php endforeach; ?>
    </select>
    <select name="status">
        <option value=""><?= e(__('common.status')) ?>: <?= e(__('common.any')) ?></option>
        <?php foreach (\App\Models\Aircraft::STATUSES as $s): ?>
            <option value="<?= e($s) ?>" <?= $filters['status'] === $s ? 'selected' : '' ?>><?= e(__('ac.status.' . $s)) ?></option>
        <?php endforeach; ?>
    </select>
    <select name="sort">
        <?php foreach (['name' => __('ac.sort.name'), 'new' => __('ac.sort.new'), 'views' => __('ac.sort.views')] as $k => $label): ?>
            <option value="<?= e($k) ?>" <?= $filters['sort'] === $k ? 'selected' : '' ?>><?= e(__('ac.sort.' . ($k === 'name' ? 'name' : $k))) ?></option>
        <?php endforeach; ?>
    </select>
    <details class="filter-more">
        <summary>⚙ <?= e(__('ac.specs.summary')) ?></summary>
        <div class="filter-tth">
            <label><?= e(__('ac.range')) ?> ≥ <input type="number" name="min_range" min="0" step="100" value="<?= (int)$filters['min_range'] ?: '' ?>" placeholder="<?= e(__('u.km')) ?>"></label>
            <label><?= e(__('ac.pax')) ?> ≥ <input type="number" name="min_pax" min="0" step="1" value="<?= (int)$filters['min_pax'] ?: '' ?>"></label>
            <input type="text" name="country" value="<?= e($filters['country']) ?>" placeholder="<?= e(__('ac.country')) ?>">
        </div>
    </details>
    <button class="btn btn--primary" type="submit">⌕ <?= e(__('common.search')) ?></button>
</form>

<?php if ($rows === []): ?>
    <div class="empty-state">
        <div class="hangar">🛫</div>
        <h2><?= e(__('ac.empty')) ?></h2>
        <p class="muted"><?= e(__('ac.empty_sub')) ?></p>
        <a class="btn btn--ghost" href="<?= url('/') ?>">← <?= e(__('common.home')) ?></a>
    </div>
<?php else: ?>
<div class="ac-grid">
    <?php foreach ($rows as $a): $s = is_array($a['specs']) ? $a['specs'] : []; ?>
        <a class="ac-card" href="<?= url('/aircraft/' . $a['slug']) ?>">
            <div class="ac-card__top">
                <span class="ac-badge ac-badge--<?= e($a['status']) ?>"><?= e(__('ac.status.' . $a['status'])) ?></span>
                <?php if (!empty($a['icao_code'])): ?><span class="mono muted"><?= e($a['icao_code']) ?></span><?php endif; ?>
            </div>
            <?php if (!empty($a['hero_photo'])): ?>
                <img class="ac-card__img" src="<?= e(url($a['hero_photo'])) ?>" alt="<?= e($a['name_ru']) ?>" loading="lazy">
            <?php else: ?>
                <div class="ac-card__img ac-card__img--sil">
                    <?= \App\Core\View::partial('partials/silhouette') ?>
                </div>
            <?php endif; ?>
            <h3 class="ac-card__name"><?= e($a['name_ru']) ?></h3>
            <div class="muted small"><?= e($a['manufacturer'] ?: __('ac.category.' . $a['category'])) ?><?= $a['first_flight'] ? ' · ' . e(date('Y', strtotime((string)$a['first_flight']))) : '' ?></div>
            <div class="ac-mini">
                <?php foreach (['cruise_speed_kmh' => 'u.kmh', 'range_km' => 'u.km', 'ceiling_m' => 'u.m', 'pax' => ''] as $k => $u): ?>
                    <div><b><?= isset($s[$k]) && $s[$k] !== '' ? e(number_format((float)$s[$k], 0, '', ' ')) : '—' ?></b><span><?= e(__($k === 'pax' ? 'ac.pax_short' : 'spec_short.' . $k)) ?><?= $u ? ' ' . e(__($u)) : '' ?></span></div>
                <?php endforeach; ?>
            </div>
            <div class="ac-card__foot">
                <span class="tag-ver">3D · <?= e(__('common.soon')) ?></span>
                <span class="muted small">▣ 0</span>
                <span class="muted small">👁 <?= (int)$a['views'] ?></span>
            </div>
        </a>
    <?php endforeach; ?>
</div>

<?php if ($pages > 1): ?>
    <div class="pager">
        <?php for ($p = 1; $p <= $pages; $p++): ?>
            <a class="pg <?= $p === $page ? 'is-active' : '' ?>" href="<?= $qs(['page' => $p]) ?>"><?= $p ?></a>
        <?php endfor; ?>
    </div>
<?php endif; ?>
<?php endif; ?>
