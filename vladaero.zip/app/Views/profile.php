<?php /** Личный кабинет (в.26): статистика, ранг, ангар, школа, уведомления */ ?>
<section class="ac-layout">
    <div class="page-head">
        <h1>◉ <?= e(__('profile.title')) ?> — <?= e($user['username']) ?></h1>
        <form method="post" action="<?= url('/logout') ?>" class="inline"><?= csrf_field() ?>
            <button class="btn" type="submit"><?= e(__('common.logout')) ?></button>
        </form>
    </div>

    <div class="profile-top">
        <div class="panel profile-rank">
            <span class="avatar avatar--big"><?= e(mb_strtoupper(mb_substr((string)$user['username'], 0, 1))) ?></span>
            <div>
                <div class="rank-badge"><?= $rank['badge'] ?> <b><?= e($rank['title']) ?></b></div>
                <div class="muted small"><?= (int)$rank['points'] ?> <?= e(__('profile.points')) ?>
                    <?php if ($rank['next']): ?> · <?= e(__('profile.next_rank', ['s' => $rank['next']['title']])) ?>: <?= (int)$rank['next']['points'] ?><?php endif; ?>
                </div>
                <div class="progress"><i style="width: <?= $rank['next'] ? min(100, (int)round($rank['points'] / max(1, $rank['next']['points']) * 100)) : 100 ?>%"></i></div>
            </div>
        </div>
        <div class="panel profile-stats">
            <div><b><?= (int)$stats['photos'] ?></b><span><?= e(__('profile.st_photos')) ?></span></div>
            <?php if ($stats['photos_pending'] > 0): ?><div class="muted small"><?= e(__('profile.st_pending')) ?>: <?= (int)$stats['photos_pending'] ?></div><?php endif; ?>
            <div><b><?= (int)$stats['articles'] ?></b><span><?= e(__('profile.st_articles')) ?></span></div>
            <div><b><?= (int)$stats['comments'] ?></b><span><?= e(__('profile.st_comments')) ?></span></div>
            <div><b><?= (int)$stats['likes'] ?></b><span>♥</span></div>
        </div>
    </div>

    <?php if ($badges !== []): ?>
    <div class="panel" style="padding:16px 22px">
        <h3 class="side-title">🏅 <?= e(__('profile.badges')) ?></h3>
        <div class="badge-row">
            <?php foreach ($badges as $b): ?>
            <span class="chip" title="<?= e($b[2]) ?>"><b><?= $b[0] ?></b> <?= e($b[1]) ?></span>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>

    <?php if ($hangar !== []): ?>
    <div class="panel" style="padding:16px 22px">
        <h3 class="side-title">✈ <?= e(__('profile.hangar')) ?></h3>
        <div class="hangar-grid">
            <?php foreach ($hangar as $a): ?>
            <a class="chip chip--ac" href="<?= url('/aircraft/' . $a['slug']) ?>">
                ✈ <b><?= e($a['name_ru']) ?></b> <span class="muted small"><?= e($a['icao_code']) ?></span>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>

    <div class="profile-cols">
        <div class="panel" style="padding:16px 22px">
            <h3 class="side-title">🎓 <?= e(__('profile.school')) ?></h3>
            <?php if ($lessons === []): ?>
            <p class="muted small"><?= e(__('profile.school_empty')) ?> <a href="<?= url('/school') ?>"><?= e(__('school.title')) ?> →</a></p>
            <?php else: ?>
            <?php foreach ($lessons as $l): ?>
            <div class="kv-row"><a href="<?= url('/school/' . $l['slug']) ?>"><?= e($l['title_ru']) ?></a> <i class="tag-soon">✓ <?= (int)$l['quiz_score'] ?>%</i></div>
            <?php endforeach; ?>
            <?php endif; ?>

            <h3 class="side-title" style="margin-top:16px">☰ <?= e(__('profile.clubs')) ?></h3>
            <?php if ($clubs === []): ?>
            <p class="muted small"><?= e(__('profile.clubs_empty')) ?> <a href="<?= url('/clubs') ?>"><?= e(__('clubs.title')) ?> →</a></p>
            <?php else: ?>
            <?php foreach ($clubs as $c): ?>
            <div class="kv-row"><a href="<?= url('/clubs/' . $c['slug']) ?>"><?= e($c['title']) ?></a></div>
            <?php endforeach; ?>
            <?php endif; ?>

            <?php if ($bmArticles !== [] || $bmAirports !== []): ?>
            <h3 class="side-title" style="margin-top:16px">🔖 <?= e(__('profile.bookmarks')) ?></h3>
            <?php foreach ($bmArticles as $a): ?>
            <div class="kv-row">▤ <a href="<?= url('/articles/' . $a['slug']) ?>"><?= e($a['title_ru']) ?></a></div>
            <?php endforeach; ?>
            <?php foreach ($bmAirports as $a): ?>
            <div class="kv-row">⬡ <a href="<?= url('/airports/' . $a['icao']) ?>"><?= e($a['icao']) ?></a> <span class="muted small"><?= e($a['name_ru']) ?></span></div>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <div class="panel" style="padding:16px 22px" id="notifications">
            <h3 class="side-title">🔔 <?= e(__('profile.notifications')) ?>
                <?php if ($unread > 0): ?><i class="tag-soon"><?= (int)$unread ?></i><?php endif; ?>
                <?php if ($notifs !== []): ?>
                <form method="post" action="<?= url('/profile/notifications/read') ?>" class="inline">
                    <?= csrf_field() ?><button class="link-btn small" type="submit"><?= e(__('profile.read_all')) ?></button>
                </form>
                <?php endif; ?>
            </h3>
            <?php if ($notifs === []): ?>
            <p class="muted small"><?= e(__('profile.no_notifications')) ?></p>
            <?php else: ?>
            <?php foreach ($notifs as $n): $p = json_decode((string)$n['payload'], true) ?: []; ?>
            <div class="ntf <?= $n['read_at'] ? '' : 'is-unread' ?>">
                <?php if (($n['type'] ?? '') === 'comment_reply'): ?>
                    💬 <b><?= e((string)($p['from'] ?? '')) ?></b> <?= e(__('profile.ntf_reply')) ?>
                    <div class="muted small">«<?= e((string)($p['excerpt'] ?? '')) ?>»</div>
                    <?php if (!empty($p['url'])): ?><a class="small" href="<?= e(str_starts_with((string)$p['url'], 'http') ? $p['url'] : url((string)$p['url'])) ?>"><?= e(__('profile.open')) ?> →</a><?php endif; ?>
                <?php elseif (($n['type'] ?? '') === 'event_going'): ?>
                    📅 <?= e(__('profile.ntf_going')) ?>: <b><?= e((string)($p['event'] ?? '')) ?></b>
                <?php else: ?>
                    ◉ <?= e($n['type']) ?>
                <?php endif; ?>
                <time class="muted small"><?= e(substr((string)$n['created_at'], 0, 16)) ?></time>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>

            <h3 class="side-title" style="margin-top:16px">✈ Telegram</h3>
            <div class="push-panel" style="margin-top:10px">
                <button class="btn" type="button" id="pushBtn"
                        data-public="<?= e((string)setting('push_vapid_public', '')) ?>">
                    <?= e(__('push.profile_btn')) ?>
                </button>
                <span class="muted small" id="pushState"></span>
            </div>
            <script>
            (function () {
                var btn = document.getElementById('pushBtn'), st = document.getElementById('pushState');
                if (!('serviceWorker' in navigator) || !('PushManager' in window)) { st.textContent = '— браузер без Web Push'; return; }
                function b64u(s) { s = s.replace(/-/g,'+').replace(/_/g,'/'); while (s.length % 4) { s += '='; }
                    var raw = atob(s), u8 = new Uint8Array(raw.length);
                    for (var i = 0; i < raw.length; i++) { u8[i] = raw.charCodeAt(i); } return u8; }
                function send(sub) {
                    return fetch('<?= url('/push/subscribe') ?>', {
                        method: 'POST', credentials: 'include',
                        headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': document.querySelector('meta[name=va-csrf]').content },
                        body: JSON.stringify(sub.toJSON())
                    });
                }
                navigator.serviceWorker.ready.then(function (reg) {
                    return reg.pushManager.getSubscription().then(function (sub) {
                        if (sub) {
                            btn.textContent = '<?= e(__('push.profile_on')) ?>';
                            btn.onclick = function () {
                                sub.unsubscribe().then(function () {
                                    return fetch('<?= url('/push/unsubscribe') ?>', {
                                        method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json' },
                                        body: JSON.stringify({ endpoint: sub.endpoint })
                                    });
                                }).then(function () { btn.textContent = '<?= e(__('push.profile_btn')) ?>'; st.textContent = '— отписано'; });
                            };
                            return;
                        }
                        btn.onclick = function () {
                            if (!btn.dataset.public) { st.textContent = '<?= e(__('push.fail')) ?>'; return; }
                            Notification.requestPermission().then(function (p) {
                                if (p !== 'granted') { st.textContent = '<?= e(__('push.denied')) ?>'; return; }
                                navigator.serviceWorker.ready.then(function (reg) {
                                    return reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64u(btn.dataset.public) });
                                }).then(send).then(function () { st.textContent = '✓'; btn.textContent = '<?= e(__('push.profile_on')) ?>'; })
                                  .catch(function () { st.textContent = '<?= e(__('push.fail')) ?>'; });
                            });
                        };
                    });
                });
            })();
            </script>
            <?php if ($tg !== null): ?>
            <p class="small">✓ <?= e(__('tg.linked')) ?>: <b>@<?= e($tg['username']) ?></b></p>
            <?php else: ?>
            <p class="muted small"><?= e(__('profile.tg_hint')) ?> <a href="<?= url('/telegram') ?>"><?= e(__('tg.title')) ?> →</a></p>
            <?php endif; ?>
        </div>
    </div>
</section>
