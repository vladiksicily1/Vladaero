<?php /** Лётная школа (в.24): программа по уровням + прогресс */ ?>
<section class="ac-layout">
    <div class="page-head">
        <h1>🎓 <?= e(__('school.title')) ?></h1>
        <?php if ($total > 0): ?>
        <div class="school-progress">
            <span class="muted small"><?= e(__('school.progress')) ?>: <b><?= (int)$done ?>/<?= (int)$total ?></b></span>
            <div class="progress"><i style="width: <?= (int)round($done / max(1, $total) * 100) ?>%"></i></div>
        </div>
        <?php endif; ?>
    </div>
    <p class="muted"><?= e(__('school.intro')) ?></p>

    <?php foreach ($levels as $lk => [$ico, $lt, $ld]): ?>
        <?php if (empty($byLevel[$lk])) { continue; } ?>
        <div class="school-level">
            <h2 class="side-title"><?= $ico ?> <?= e($lt) ?> <span class="muted small">— <?= e($ld) ?></span></h2>
            <div class="school-grid">
                <?php foreach ($byLevel[$lk] as $l): ?>
                <a class="panel school-card <?= $l['passed'] !== null ? 'is-done' : '' ?>" href="<?= url('/school/' . $l['slug']) ?>">
                    <?php if ($l['passed'] !== null): ?><i class="tag-soon school-done">✓ <?= (int)$l['passed'] ?>%</i><?php endif; ?>
                    <b><?= e($l['title_ru']) ?></b>
                    <p class="muted small"><?= e($l['summary_ru']) ?></p>
                    <span class="school-go"><?= $l['passed'] !== null ? e(__('school.review')) : e(__('school.start')) ?> →</span>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endforeach; ?>
</section>
