<?php /** Урок школы (в.24): блоки + тест с серверной проверкой */
$quizResult = $_SESSION['_quiz_result'] ?? null;
if (is_array($quizResult) && ($quizResult['slug'] ?? '') === $lesson['slug']) {
    unset($_SESSION['_quiz_result']);
}
?>
<section class="ac-layout narrow">
    <div class="page-head">
        <h1>🎓 <?= e($lesson['title_ru']) ?></h1>
        <div class="muted small"><?= $levelMeta[0] ?> <?= e($levelMeta[1]) ?><?= $passed !== null ? ' · ✓ ' . e(__('school.passed_at', ['d' => $passed])) : '' ?></div>
    </div>

    <?php if (trim((string)$lesson['summary_ru']) !== ''): ?>
    <p class="lead muted"><?= e($lesson['summary_ru']) ?></p>
    <?php endif; ?>

    <article class="lesson-body">
        <?= $bodyHtml ?>
    </article>

    <?php if (!empty($quiz['questions'])): ?>
    <section class="panel quiz-panel" id="quiz" style="padding:22px">
        <h3 class="side-title">✱ <?= e(__('school.quiz_title')) ?></h3>
        <p class="muted small"><?= e(__('school.quiz_hint')) ?></p>

        <?php if (is_array($quizResult)): ?>
        <div class="callout <?= $quizResult['passed'] ? 'is-success' : 'is-warning' ?> mb">
            <b><?= $quizResult['passed'] ? '✓ ' . e(__('school.quiz_passed', ['%d' => $quizResult['score']])) : '✕ ' . e(__('school.quiz_failed', ['%d' => $quizResult['score']])) ?></b>
            — <?= (int)$quizResult['correct'] ?>/<?= (int)$quizResult['total'] ?>
        </div>
        <?php endif; ?>

        <form method="post" action="<?= url('/school/' . $lesson['slug'] . '/quiz') ?>">
            <?= csrf_field() ?>
            <?php foreach ($quiz['questions'] as $i => $q): ?>
            <fieldset class="quiz-q">
                <legend><?= (int)($i + 1) ?>. <?= e($q['q']) ?></legend>
                <?php foreach ($q['options'] as $oi => $opt): ?>
                <?php
                    $res = is_array($quizResult) ? ($quizResult['results'][$i] ?? null) : null;
                    $cls = '';
                    if (is_array($res)) {
                        if ($oi === (int)$q['correct']) { $cls = 'is-right'; }
                        elseif ($oi === (int)$res['given']) { $cls = 'is-wrong'; }
                    }
                ?>
                <label class="quiz-opt <?= $cls ?>">
                    <input type="radio" name="q[<?= (int)$i ?>]" value="<?= (int)$oi ?>" required>
                    <?= e($opt) ?>
                    <?php if (is_array($res) && $oi === (int)$q['correct']): ?><span class="quiz-explain">— <?= e((string)$q['explain']) ?></span><?php endif; ?>
                </label>
                <?php endforeach; ?>
            </fieldset>
            <?php endforeach; ?>
            <button class="btn btn-primary" type="submit">✈ <?= e(__('school.quiz_submit')) ?></button>
        </form>
    </section>
    <?php endif; ?>

    <nav class="lesson-nav">
        <?php if ($prev): ?><a class="btn" href="<?= url('/school/' . $prev['slug']) ?>">← <?= e($prev['title_ru']) ?></a><?php endif; ?>
        <a class="btn" href="<?= url('/school') ?>">🎓 <?= e(__('school.title')) ?></a>
        <?php if ($next): ?><a class="btn" href="<?= url('/school/' . $next['slug']) ?>"><?= e($next['title_ru']) ?> →</a><?php endif; ?>
    </nav>
</section>
