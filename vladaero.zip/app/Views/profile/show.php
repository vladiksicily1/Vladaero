<?php /** Публичный профиль автора (v0.8.1) */ ?>
<section class="ac-layout">
    <div class="page-head">
        <h1>👤 <?= e($u['username']) ?></h1>
        <?php if (!$isMe && \App\Core\Auth::check()): ?>
        <button class="btn <?= $following ? '' : 'btn-primary' ?> follow-btn" data-author="<?= (int)$u['id'] ?>">
            <?= $following ? '✓ ' . e(__('feed.following')) : '＋ ' . e(__('feed.follow')) ?>
        </button>
        <?php elseif (\App\Core\Auth::check()): ?>
        <a class="btn" href="<?= url('/im/' . $u['id']) ?>">✉ <?= e(__('dm.write')) ?></a>
        <?php endif; ?>
    </div>
    <div class="panel prof-card">
        <div class="prof-stats">
            <span>⭐ <?= e($rank['title'] ?? '') ?></span>
            <span>👥 <?= e(__('feed.followers')) ?>: <b><?= (int)$followers ?></b></span>
            <span>📝 <?= (int)count($articles) ?></span>
            <span>📷 <?= (int)$photos ?></span>
            <span class="muted">с <?= e(date('d.m.Y', strtotime((string)$u['created_at']))) ?></span>
        </div>
    </div>
    <?php if (!empty($va['flights'])): ?>
    <?php $vh = intdiv((int)$va['total_min'], 60); $vm = (int)$va['total_min'] % 60; ?>
    <div class="panel prof-card" style="margin-top:14px">
        <h2 class="form-h" style="margin-top:0">✈ Налёт ВАК (PIREP)</h2>
        <div class="prof-stats">
            <span>🕐 <b><?= $vh ?> ч <?= $vm ?> мин</b></span>
            <span>🗒 Полётов: <b><?= (int)$va['flights'] ?></b></span>
            <?php if (!empty($va['aircraft'])): ?>
            <?php $top = (array)$va['aircraft'][0]; ?>
            <span>🏆 Чаще всего: <?= e($top['aircraft']) ?> <b>(<?= intdiv((int)$top['t'],60) ?> ч)</b></span>
            <?php endif; ?>
        </div>
        <?php if (!empty($va['recent'])): ?>
        <table class="table" style="margin-top:10px">
            <thead><tr><th>Маршрут</th><th>ВС</th><th>Налёт</th><th>Дата</th></tr></thead>
            <tbody>
            <?php foreach ((array)$va['recent'] as $f): ?>
                <tr>
                    <td><?= e($f['route']) ?></td>
                    <td><?= e($f['aircraft']) ?></td>
                    <td><?= intdiv((int)$f['duration_min'],60) ?> ч <?= (int)$f['duration_min'] % 60 ?> мин</td>
                    <td class="muted"><?= e(date('d.m.Y', strtotime((string)$f['created_at']))) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
    <?php endif; ?>
    <h3 class="form-h"><?= e(__('feed.author_articles')) ?></h3>
    <?php foreach ($articles as $art): ?>
    <div class="panel feed-item">
        <div class="feed-item-head">
            <b><a href="<?= url('/articles/' . $art['slug']) ?>"><?= e($art['title_ru']) ?></a></b>
            <span class="muted small"><?= e(date('d.m.Y', strtotime((string)$art['published_at']))) ?> · 👁 <?= (int)$art['views'] ?></span>
        </div>
        <p class="muted"><?= e(mb_substr((string)$art['excerpt_ru'], 0, 180)) ?></p>
    </div>
    <?php endforeach; ?>
    <?php if ($articles === []): ?><div class="panel muted"><?= e(__('feed.no_articles')) ?></div><?php endif; ?>
</section>
<script>
(function () {
    var b = document.querySelector('.follow-btn');
    if (!b) { return; }
    b.addEventListener('click', function () {
        var fd = new FormData();
        fd.append('_token', document.querySelector('meta[name=va-csrf]').content);
        fetch('<?= url('/profile/follow') ?>/<?= (int)$u['id'] ?>', {
            method: 'POST', body: fd,
            headers: { 'X-CSRF-Token': document.querySelector('meta[name=va-csrf]').content, 'X-Requested-With': 'XMLHttpRequest' }
        }).then(function (r) { return r.json(); }).then(function (j) {
            if (j.ok) {
                b.textContent = j.following ? '✓ <?= e(__('feed.following')) ?>' : '＋ <?= e(__('feed.follow')) ?>';
                b.classList.toggle('btn-primary', !j.following);
            }
        });
    });
})();
</script>
