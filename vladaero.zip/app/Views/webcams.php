<?php
/**
 * Живые веб-камеры аэропортов (в.278): сеть AviationWX + свои камеры.
 * @var string $icao @var array{net:list,array{custom:list} $cams @var array $net @var array $airports
 */
?>
<section class="ac-layout">
    <div class="page-head">
        <div>
            <h1>◉ <?= e(__('cam.title')) ?></h1>
            <p class="muted"><?= e(__('cam.sub')) ?> · AviationWX.org</p>
        </div>
    </div>

    <form class="gal-filters" method="get" action="<?= e(url('/webcams')) ?>">
        <input type="text" name="icao" maxlength="4" placeholder="ICAO / FAA" value="<?= e($icao) ?>"
               style="text-transform:uppercase;width:130px">
        <button class="btn btn-primary" type="submit">⌕</button>
        <?php if ($airports !== []): ?>
        <select onchange="if(this.value)location='<?= e(url('/webcams?icao=')) ?>'+this.value">
            <option value=""><?= e(__('cam.from_catalog')) ?></option>
            <?php foreach ($airports as $ap): ?>
            <option value="<?= e(strtoupper($ap['icao'])) ?>"><?= e(strtoupper($ap['icao'])) ?> — <?= e($ap['name_ru']) ?></option>
            <?php endforeach; ?>
        </select>
        <?php endif; ?>
    </form>

    <?php if ($icao === ''): ?>
    <p class="muted"><?= e(__('cam.pick_hint')) ?></p>
    <?php endif; ?>

    <?php if (($cams['net'] ?? []) !== [] || ($cams['custom'] ?? []) !== []): ?>
    <div class="cam-grid">
        <?php foreach ($cams['net'] as $c): ?>
        <figure class="cam-card">
            <img src="<?= e($c['img']) ?>" alt="<?= e($c['name']) ?>" loading="lazy" referrerpolicy="no-referrer">
            <figcaption>
                <b><?= e($c['name']) ?></b>
                <span class="muted"><?= (int)$c['heading'] ?>° · ⟳ <?= (int)$c['refresh'] ?>s · <?= e($icao) ?></span>
            </figcaption>
        </figure>
        <?php endforeach; ?>
        <?php foreach ($cams['custom'] as $c): ?>
        <figure class="cam-card">
            <img src="<?= e($c['img']) ?>" alt="<?= e($c['name']) ?>" loading="lazy" referrerpolicy="no-referrer">
            <figcaption><b><?= e($c['name']) ?></b><span class="muted"><?= e($icao) ?></span></figcaption>
        </figure>
        <?php endforeach; ?>
    </div>
    <?php elseif ($icao !== ''): ?>
    <div class="empty">
        <div class="empty-ico">◉</div>
        <h2><?= e(__('cam.none')) ?></h2>
        <p class="muted"><?= e(__('cam.none_sub')) ?></p>
    </div>
    <?php endif; ?>

    <h2 class="side-title" style="margin-top:26px"><?= e(__('cam.network')) ?></h2>
    <div class="cam-chips">
        <?php foreach ($net as $a): ?>
        <a class="wx-chip <?= strcasecmp($a['icao'] ?: $a['id'], $icao) === 0 ? 'is-cur' : '' ?>"
           href="<?= e(url('/webcams?icao=' . strtoupper($a['icao'] ?: $a['id']))) ?>"
           title="<?= e($a['name']) ?>"><?= e(strtoupper($a['icao'] ?: $a['id'])) ?></a>
        <?php endforeach; ?>
    </div>
</section>
