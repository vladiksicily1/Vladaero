<?php /** Офлайн-страница PWA (в.73) — кэшируется сервис-воркером */ ?>
<section class="ac-layout narrow">
    <div class="panel" style="padding:34px;text-align:center">
        <div style="font-size:44px">✈</div>
        <h1><?= e(__('pwa.offline_title')) ?></h1>
        <p class="muted"><?= e(__('pwa.offline_text')) ?></p>
        <p><a class="btn btn-primary" href="<?= url('/') ?>"><?= e(__('pwa.back_home')) ?></a></p>
        <p class="muted small"><?= e(__('pwa.offline_cached')) ?></p>
    </div>
</section>
