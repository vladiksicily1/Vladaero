<?php
/**
 * Галерея споттинга — лента (в.11–14).
 * @var array $items @var array $top @var array $filters @var array $airports
 * @var int $total @var int $pages @var int $page
 */
$thumb = static function (string $fn): string {
    $t = preg_replace('~\.\w+$~', '_t.webp', $fn);
    return is_file(VA_ROOT . '/' . $t) ? $t : $fn;
};
$qs = static function (array $patch) use ($filters): string {
    $q = array_merge(array_filter([
        'aircraft' => $filters['aircraft_id'] ?: null,
        'airport'  => $filters['airport_id'] ?: null,
        'reg'      => $filters['registration'] ?: null,
        'sort'     => $filters['sort'] !== 'new' ? $filters['sort'] : null,
    ]), $patch);
    return $q !== [] ? '?' . http_build_query($q) : '';
};
?>
<section class="ac-layout">
    <div class="page-head">
        <div>
            <h1><?= e(__('gal.title')) ?></h1>
            <p class="muted"><?= e(__('gal.section_sub')) ?> · <?= (int)$total ?></p>
        </div>
        <a class="btn btn-primary" href="<?= e(url('/gallery/upload')) ?>">⤒ <?= e(__('gal.upload')) ?></a>
    </div>

    <?php if ($top !== []): ?>
    <div class="gal-top">
        <h2 class="side-title">★ <?= e(__('gal.top_week')) ?></h2>
        <div class="gal-top-grid">
            <?php foreach ($top as $t): ?>
            <a class="gal-top-card" href="<?= e(url('/gallery/' . $t['id'])) ?>">
                <img src="<?= e(url($thumb($t['filename']))) ?>" alt="<?= e($t['title'] ?? $t['registration'] ?? '') ?>" loading="lazy">
                <span class="gal-top-lbl">
                    <b><?= e($t['title'] ?? ($t['registration'] ?: '—')) ?></b>
                    <i>♥ <?= (int)$t['likes'] ?> · <?= e($t['author'] ?? '') ?></i>
                </span>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>

    <form class="gal-filters" method="get" action="<?= e(url('/gallery')) ?>">
        <input type="search" name="reg" placeholder="<?= e(__('gal.f_reg')) ?>" value="<?= e($filters['registration']) ?>">
        <select name="airport">
            <option value=""><?= e(__('gal.f_airport_any')) ?></option>
            <?php foreach ($airports as $ap): ?>
            <option value="<?= (int)$ap['id'] ?>" <?= $filters['airport_id'] === (int)$ap['id'] ? 'selected' : '' ?>><?= e($ap['icao']) ?> — <?= e($ap['name_ru']) ?></option>
            <?php endforeach; ?>
        </select>
        <select name="sort">
            <option value="new" <?= $filters['sort'] === 'new' ? 'selected' : '' ?>><?= e(__('gal.sort_new')) ?></option>
            <option value="top" <?= $filters['sort'] === 'top' ? 'selected' : '' ?>><?= e(__('gal.sort_top')) ?></option>
            <option value="views" <?= $filters['sort'] === 'views' ? 'selected' : '' ?>><?= e(__('gal.sort_views')) ?></option>
        </select>
        <button class="btn" type="submit"><?= e(__('common.search')) ?></button>
    </form>

    <?php if ($items === []): ?>
    <div class="empty">
        <div class="empty-ico">▣</div>
        <h2><?= e(__('gal.empty')) ?></h2>
        <p class="muted"><?= e(__('gal.empty_sub')) ?></p>
    </div>
    <?php else: ?>
    <div class="gal-grid">
        <?php foreach ($items as $p): ?>
        <a class="gal-card" href="<?= e(url('/gallery/' . $p['id'])) ?>" data-lightbox>
            <img src="<?= e(url($thumb($p['filename']))) ?>" alt="<?= e($p['title'] ?? $p['registration'] ?? 'spotting photo') ?>" loading="lazy">
            <span class="gal-meta">
                <b><?= e($p['registration'] ?: ($p['title'] ?: '—')) ?></b>
                <i><?= e(trim(($p['ap_icao'] ? $p['ap_icao'] . ' · ' : '') . ($p['author'] ?? ''))) ?></i>
            </span>
            <?php if ((int)$p['likes'] > 0): ?><span class="gal-likes">♥ <?= (int)$p['likes'] ?></span><?php endif; ?>
        </a>
        <?php endforeach; ?>
    </div>

    <?php if ($pages > 1): ?>
    <nav class="pager">
        <?php for ($i = 1; $i <= $pages; $i++): ?>
        <a class="<?= $i === $page ? 'is-cur' : '' ?>" href="<?= e(url('/gallery' . $qs(['page' => $i]))) ?>"><?= $i ?></a>
        <?php endfor; ?>
    </nav>
    <?php endif; ?>
    <?php endif; ?>
</section>
