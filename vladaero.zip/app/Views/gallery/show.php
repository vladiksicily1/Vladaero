<?php
/**
 * Карточка споттерского фото (в.12–13): EXIF, автор, лицензия, Schema.org ImageObject.
 * @var array $p @var array $exif
 */
$thumb = preg_replace('~\.\w+$~', '_t.webp', $p['filename']);
$statusBadge = ['pending' => __('art.status.draft'), 'rejected' => __('gal.rejected'), 'approved' => ''];
?>
<section class="ac-layout ph-page">
    <?php if ($p['status'] !== 'approved'): ?>
    <div class="callout is-warning mb"><?= e(__('gal.preview_note')) ?><?= $p['status'] === 'rejected' && $p['reject_reason'] ? ' — ' . e($p['reject_reason']) : '' ?></div>
    <?php endif; ?>

    <div class="ph-wrap">
        <figure class="ph-figure" oncontextmenu="return false">
            <a href="<?= e(url($p['filename'])) ?>" data-lightbox>
                <img src="<?= e(url($p['filename'])) ?>" alt="<?= e($p['title'] ?? $p['registration'] ?? 'spotting photo') ?>" id="phImg">
            </a>
            <figcaption class="muted"><?= e($p['original_name'] ?? '') ?></figcaption>
        </figure>

        <aside class="ph-side">
            <h1><?= e($p['title'] ?? '') ?: e($p['registration'] ?: __('gal.photo')) ?></h1>
            <?php if ($p['registration']): ?><div class="ph-reg">✈ <?= e($p['registration']) ?></div><?php endif; ?>

            <dl class="kv">
                <div><dt><?= e(__('gal.author')) ?></dt><dd><?= e($p['author'] ?? '—') ?></dd></div>
                <?php if ($p['ac_slug']): ?>
                <div><dt><?= e(__('gal.aircraft')) ?></dt><dd><a href="<?= e(url('/aircraft/' . $p['ac_slug'])) ?>"><?= e($p['ac_name']) ?></a></dd></div>
                <?php endif; ?>
                <?php if ($p['ap_icao']): ?>
                <div><dt><?= e(__('ap.section')) ?></dt><dd><a href="<?= e(url('/airports/' . strtolower($p['ap_icao']))) ?>"><?= e($p['ap_icao']) ?> — <?= e($p['ap_name']) ?></a></dd></div>
                <?php endif; ?>
                <div><dt><?= e(__('gal.taken')) ?></dt><dd><?= e($p['taken_at'] ?: substr((string)$p['created_at'], 0, 10)) ?></dd></div>
                <div><dt><?= e(__('gal.license')) ?></dt><dd><?= e($p['license'] ?: 'ARR') ?></dd></div>
            </dl>

            <?php if ($exif !== []): ?>
            <h3 class="side-title"><?= e(__('gal.exif')) ?></h3>
            <dl class="kv kv-small">
                <?php foreach (['camera' => __('gal.ex_camera'), 'lens' => __('gal.ex_lens'), 'focal' => __('gal.ex_focal'), 'fnumber' => __('gal.ex_fnum'), 'exposure' => __('gal.ex_exp'), 'iso' => 'ISO'] as $k => $lbl): ?>
                <?php if (!empty($exif[$k])): ?><div><dt><?= e($lbl) ?></dt><dd><?= e((string)$exif[$k]) ?></dd></div><?php endif; ?>
                <?php endforeach; ?>
            </dl>
            <?php endif; ?>

            <div class="ph-actions">
                <button class="btn btn-primary" id="phLike" data-id="<?= (int)$p['id'] ?>">♥ <span id="phLikes"><?= (int)$p['likes'] ?></span></button>
                <span class="muted">👁 <?= (int)$p['views'] ?></span>
                <a class="btn" href="<?= e(url('/gallery')) ?>">← <?= e(__('common.back')) ?></a>
            </div>
        </aside>
    </div>
</section>

<script type="application/ld+json">
<?= json_encode([
    '@context' => 'https://schema.org',
    '@type' => 'ImageObject',
    'contentUrl' => url($p['filename']),
    'thumbnailUrl' => url(is_file(VA_ROOT . '/' . $thumb) ? $thumb : $p['filename']),
    'name' => $p['title'] ?? $p['registration'] ?? 'spotting photo',
    'creator' => ['@type' => 'Person', 'name' => $p['author'] ?? ''],
    'license' => $p['license'] ?: 'ARR',
    'uploadDate' => substr((string)$p['created_at'], 0, 10),
], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) ?>
</script>
<script>
document.getElementById('phLike').addEventListener('click', function () {
    fetch('<?= e(url('/gallery/' . $p['id'] . '/like')) ?>', {
        method: 'POST',
        headers: { 'X-Requested-With': 'XMLHttpRequest', 'X-CSRF-Token': (document.querySelector('meta[name="va-csrf"]') || {}).content || '' }
    }).then(function (r) { return r.json(); }).then(function (r) {
        if (r.ok) { document.getElementById('phLikes').textContent = r.likes; }
    }).catch(function () {});
});
</script>

<?= \App\Core\View::partial('partials/comments', [
    'cType' => 'photo',
    'cId' => (int)$p['id'],
    'cTree' => \App\Services\CommentService::tree('photo', (int)$p['id'], \App\Core\Auth::id() ?? 0),
    'cBack' => '/gallery/' . (int)$p['id'],
]) ?>
