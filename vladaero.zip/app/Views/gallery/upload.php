<?php
/**
 * Загрузка споттерского фото (в.11–13): метаданные + файл (обработка MediaService).
 * @var array $airports @var array $aircrafts @var bool $trusted
 */
?>
<section class="ac-layout narrow">
    <div class="page-head"><h1>⤒ <?= e(__('gal.upload')) ?></h1></div>

    <?php if (!$trusted): ?>
    <div class="callout is-info mb"><?= e(__('gal.screening_note')) ?></div>
    <?php else: ?>
    <div class="callout is-success mb"><?= e(__('gal.trusted_note')) ?></div>
    <?php endif; ?>

    <form class="form" method="post" action="<?= e(url('/gallery/upload')) ?>" enctype="multipart/form-data">
        <?= csrf_field() ?>

        <label class="field">
            <span><?= e(__('gal.file')) ?> <em class="req">*</em></span>
            <input type="file" name="file" accept="image/*,.zip,application/zip" required>
            <small class="muted"><?= e(__('gal.file_hint')) ?></small>
        </label>

        <label class="field">
            <span><?= e(__('gal.f_title')) ?></span>
            <input type="text" name="title" maxlength="220" placeholder="Закат на 25L">
        </label>

        <div class="grid-2">
            <label class="field">
                <span><?= e(__('gal.f_reg')) ?></span>
                <input type="text" name="registration" maxlength="20" placeholder="RA-85816" style="text-transform:uppercase">
            </label>
            <label class="field">
                <span><?= e(__('gal.f_taken')) ?></span>
                <input type="date" name="taken_at">
            </label>
        </div>

        <div class="grid-2">
            <label class="field">
                <span><?= e(__('gal.f_aircraft')) ?></span>
                <select name="aircraft_id">
                    <option value=""><?= e(__('common.any')) ?></option>
                    <?php foreach ($aircrafts as $a): ?>
                    <option value="<?= (int)$a['id'] ?>"><?= e($a['name_ru']) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label class="field">
                <span><?= e(__('gal.f_airport')) ?></span>
                <select name="airport_id">
                    <option value=""><?= e(__('common.any')) ?></option>
                    <?php foreach ($airports as $ap): ?>
                    <option value="<?= (int)$ap['id'] ?>"><?= e($ap['icao']) ?> — <?= e($ap['name_ru']) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
        </div>

        <label class="field">
            <span><?= e(__('gal.license')) ?></span>
            <select name="license_idx">
                <option value="1">All rights reserved (ARR)</option>
                <option value="2">CC BY</option>
                <option value="3">CC BY-NC</option>
                <option value="4">CC0</option>
            </select>
            <small class="muted"><?= e(__('gal.license_hint')) ?></small>
        </label>

        <button class="btn btn-primary" type="submit"><?= e(__('gal.upload')) ?></button>
    </form>
</section>
