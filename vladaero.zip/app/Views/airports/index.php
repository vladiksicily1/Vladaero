<?php /** Каталог аэропортов (в.10) */ ?>
<section class="page-head">
    <nav class="crumbs"><a href="<?= url('/') ?>"><?= e(__('nav.home')) ?></a><span>›</span><span><?= e(__('ap.section')) ?></span></nav>
    <h1><?= e(__('ap.section')) ?></h1>
    <form method="get" action="<?= url('/airports') ?>" class="filter-bar">
        <input type="search" name="q" value="<?= e($q) ?>" placeholder="UUEE, SVO, Шереметьево, Москва…" class="filter-q">
        <button class="btn btn--primary" type="submit">⌕</button>
    </form>
</section>

<?php if ($rows === []): ?>
    <div class="empty-state"><div class="hangar">🛫</div><h2><?= e(__('ap.empty')) ?></h2>
        <p class="muted"><?= e(__('ap.empty_sub')) ?></p></div>
<?php else: ?>
<div class="ap-grid">
    <?php foreach ($rows as $p): ?>
        <a class="ap-card" href="<?= url('/airports/' . $p['icao']) ?>">
            <b class="mono ap-icao"><?= e($p['icao']) ?></b>
            <span class="ap-iata mono"><?= e($p['iata'] ?: '—') ?></span>
            <h3><?= e($p['name_ru']) ?></h3>
            <div class="muted small"><?= e($p['city_ru'] ?: $p['city_en'] ?: '') ?><?= $p['country_code'] ? ' · ' . e($p['country_code']) : '' ?></div>
        </a>
    <?php endforeach; ?>
</div>
<?php if ($pages > 1): ?>
    <div class="pager"><?php for ($p2 = 1; $p2 <= $pages; $p2++): ?><a class="pg <?= $p2 === $page ? 'is-active' : '' ?>" href="<?= url('/airports') ?>?q=<?= urlencode($q) ?>&amp;page=<?= $p2 ?>"><?= $p2 ?></a><?php endfor; ?></div>
<?php endif; ?>
<?php endif; ?>
