<?php /** Карточка аэропорта (в.10, 33) + блоки */ ?>
<section class="page-head">
    <nav class="crumbs"><a href="<?= url('/') ?>"><?= e(__('nav.home')) ?></a><span>›</span>
        <a href="<?= url('/airports') ?>"><?= e(__('ap.section')) ?></a><span>›</span><span class="mono"><?= e($ap['icao']) ?></span></nav>
    <h1><span class="mono t-ok"><?= e($ap['icao']) ?></span> · <?= e($ap['name_ru']) ?></h1>
    <?php if ($ap['name_en']): ?><div class="muted"><?= e($ap['name_en']) ?></div><?php endif; ?>
</section>

<div class="ac-layout">
    <div class="ac-main">
        <?= $blocksHtml !== '' ? $blocksHtml : '<div class="panel"><p class="muted pad">' . e(__('ap.no_blocks')) . '</p></div>' ?>
    </div>
    <aside class="ac-side">
        <div class="panel">
            <div class="panel-head"><h3><?= e(__('ap.info')) ?></h3></div>
            <div class="kv">
                <div class="kv-row"><span>ICAO / IATA</span><b class="mono"><?= e($ap['icao']) ?> / <?= e($ap['iata'] ?: '—') ?></b></div>
                <div class="kv-row"><span><?= e(__('ap.city')) ?></span><b><?= e($ap['city_ru'] ?: '—') ?></b></div>
                <div class="kv-row"><span><?= e(__('ac.country')) ?></span><b class="mono"><?= e($ap['country_code'] ?: '—') ?></b></div>
                <div class="kv-row"><span>Elevation</span><b class="mono"><?= $ap['elevation_ft'] !== null ? (int)$ap['elevation_ft'] . ' ft' : '—' ?></b></div>
                <div class="kv-row"><span>Coordinates</span><b class="mono"><?= $ap['lat'] !== null ? e(number_format((float)$ap['lat'], 4, '.', '')) . ', ' . e(number_format((float)$ap['lng'], 4, '.', '')) : '—' ?></b></div>
                <div class="kv-row"><span>Timezone</span><b class="mono"><?= e($ap['timezone'] ?: '—') ?></b></div>
            </div>
            <?php if ($ap['website']): ?><a class="btn btn--ghost btn--sm" href="<?= e($ap['website']) ?>" target="_blank" rel="noopener">↗ <?= e(__('ap.website')) ?></a><?php endif; ?>
        </div>
        <div class="panel">
            <div class="panel-head"><h3><?= e(__('ap.live')) ?></h3></div>
            <div class="quick-actions">
                <a class="btn btn--ghost" href="<?= e(url('/weather?icao=' . strtoupper($ap['icao']))) ?>">☁ METAR / TAF</a>
                <a class="btn btn--ghost" href="<?= e(url('/fids?icao=' . strtoupper($ap['icao']))) ?>">▦ <?= e(__('fids.title')) ?></a>
                <a class="btn btn--ghost" href="<?= e(url('/webcams?icao=' . strtoupper($ap['icao']))) ?>">◉ <?= e(__('cam.title')) ?></a>
                <a class="btn btn--ghost" href="<?= e(url('/radar')) ?>">◎ <?= e(__('nav.radar')) ?></a>
            </div>
        </div>
    </aside>
</div>

<?= \App\Core\View::partial('partials/bookmark', ['bmType' => 'airport', 'bmId' => (int)$ap['id'], 'bmBack' => '/airports/' . $ap['icao']]) ?>
