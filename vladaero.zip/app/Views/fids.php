<?php
/**
 * FIDS — онлайн-табло (в.279): вылеты/прилёты, фильтры, связь с радаром.
 * @var string $icao @var string $type @var array $airports @var bool $hasKey
 */
?>
<section class="ac-layout">
    <div class="page-head">
        <div>
            <h1>⌗ <?= e(__('fids.title')) ?></h1>
            <p class="muted"><?= e(__('fids.sub')) ?> · SkyLink API · 5 мин</p>
        </div>
    </div>

    <form class="gal-filters" method="get" action="<?= e(url('/fids')) ?>">
        <input type="text" name="icao" maxlength="4" placeholder="ICAO" value="<?= e($icao) ?>"
               style="text-transform:uppercase;width:110px">
        <select name="type">
            <option value="departure" <?= $type === 'departure' ? 'selected' : '' ?>><?= e(__('fids.departures')) ?></option>
            <option value="arrival" <?= $type === 'arrival' ? 'selected' : '' ?>><?= e(__('fids.arrivals')) ?></option>
        </select>
        <button class="btn btn-primary" type="submit"><?= e(__('common.search')) ?></button>
    </form>

    <?php if (!$hasKey): ?>
    <div class="callout is-warning mb">
        <?= e(__('fids.nokey')) ?>
    </div>
    <?php endif; ?>

    <div class="fids-board" id="fidsBoard"
         data-icao="<?= e($icao) ?>" data-type="<?= e($type) ?>" data-haskey="<?= $hasKey ? '1' : '0' ?>">
        <input type="search" id="fidsFilter" class="fids-filter" placeholder="<?= e(__('fids.filter_ph')) ?>">
        <div class="fids-table-wrap">
            <table class="fids-table">
                <thead>
                <tr>
                    <th><?= e(__('fids.flight')) ?></th>
                    <th><?= e(__('fids.airline')) ?></th>
                    <th><?= e($type === 'arrival' ? __('fids.from') : __('fids.to')) ?></th>
                    <th><?= e(__('fids.time')) ?></th>
                    <th><?= e(__('fids.term')) ?></th>
                    <th><?= e(__('fids.gate')) ?></th>
                    <th><?= e(__('common.status')) ?></th>
                    <th></th>
                </tr>
                </thead>
                <tbody id="fidsRows">
                <tr><td colspan="8" class="muted fids-empty"><?= e($icao === '' ? __('fids.pick') : __('fids.loading')) ?></td></tr>
                </tbody>
            </table>
        </div>
    </div>
</section>
<script>
window.VA_L_FIDS = {
    nokey: <?= json_encode(__('fids.nokey_js')) ?>, empty: <?= json_encode(__('fids.empty')) ?>,
    no_match: <?= json_encode(__('fids.no_match')) ?>, src_err: <?= json_encode(__('fids.src_err')) ?>,
    radar: <?= json_encode(__('nav.radar')) ?>,
    st_scheduled: <?= json_encode(__('fids.st_scheduled')) ?>, st_delayed: <?= json_encode(__('fids.st_delayed')) ?>,
    st_departed: <?= json_encode(__('fids.st_departed')) ?>, st_enroute: <?= json_encode(__('fids.st_enroute')) ?>,
    st_landed: <?= json_encode(__('fids.st_landed')) ?>, st_cancelled: <?= json_encode(__('fids.st_cancelled')) ?>,
    st_boarding: <?= json_encode(__('fids.st_boarding')) ?>
};
</script>
<script src="<?= e(asset('js/fids.js')) ?>" defer></script>
