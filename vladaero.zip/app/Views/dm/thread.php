<?php /** Личные сообщения: переписка (v0.8.1) */ ?>
<section class="ac-layout">
    <div class="page-head">
        <h1>✉ <a href="<?= url('/im') ?>"><?= e(__('dm.title')) ?></a> → <?= e($peer['login']) ?></h1>
    </div>
    <div class="panel dm-thread" id="dmThread">
        <?php foreach ($msgs as $m): ?>
        <div class="dm-msg<?= (int)$m['from_user'] === (int)\App\Core\Auth::id() ? ' dm-mine' : '' ?>">
            <div class="dm-bubble"><?= nl2br(e($m['body'])) ?></div>
            <div class="muted small"><?= e(date('d.m H:i', strtotime((string)$m['created_at']))) ?>
                <?= $m['read_at'] !== null ? ' ✓✓' : '' ?></div>
        </div>
        <?php endforeach; ?>
        <?php if ($msgs === []): ?><p class="muted"><?= e(__('dm.no_msgs')) ?></p><?php endif; ?>
    </div>
    <form method="post" action="<?= url('/im/' . $peer['id']) ?>" class="panel dm-form">
        <?= csrf_field() ?>
        <textarea name="body" rows="3" maxlength="4000" required placeholder="<?= e(__('dm.placeholder')) ?>"></textarea>
        <button class="btn btn-primary" type="submit">➤ <?= e(__('dm.send')) ?></button>
    </form>
    <script>document.getElementById('dmThread').scrollTop = 1e6;</script>
</section>
