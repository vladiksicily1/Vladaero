<?php /** Личные сообщения: список диалогов (v0.8.1) */ ?>
<section class="ac-layout">
    <div class="page-head">
        <h1>✉ <?= e(__('dm.title')) ?></h1>
    </div>
    <div class="panel dm-list">
        <?php foreach ($dialogs as $d): ?>
        <a class="dm-row<?= $d['unread'] > 0 ? ' dm-unread' : '' ?>" href="<?= url('/im/' . $d['peer']['id']) ?>">
            <span class="dm-peer"><?= e($d['peer']['login']) ?></span>
            <span class="dm-preview muted"><?= $d['mine'] ? '→ ' : '' ?><?= e(mb_substr((string)$d['last']['body'], 0, 60)) ?></span>
            <span class="dm-meta small muted"><?= e(date('d.m H:i', strtotime((string)$d['last']['created_at']))) ?>
                <?= $d['unread'] > 0 ? '<i class="dm-badge">' . (int)$d['unread'] . '</i>' : '' ?></span>
        </a>
        <?php endforeach; ?>
        <?php if ($dialogs === []): ?>
        <p class="muted"><?= e(__('dm.empty_list')) ?></p>
        <?php endif; ?>
    </div>
</section>
