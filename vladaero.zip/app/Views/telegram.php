<?php
/**
 * Привязка Telegram-профиля (в.116): код → /start КОД боту @vladaero_bot.
 * @var string $code @var string $bot @var array|null $linked
 */
$bot = $bot !== '' ? $bot : 'vladaero_bot';
$cmds = [
    ['/wx UUEE', __('tg.c_wx')], ['/metar UUEE', __('tg.c_metar')], ['/taf UUEE', __('tg.c_taf')],
    ['/fids UUEE', __('tg.c_fids')], ['/notam UUEE', __('tg.c_notam')], ['/track AFL123', __('tg.c_track')],
    ['/airport UUEE', __('tg.c_airport')], ['/aircraft Ту-204', __('tg.c_aircraft')], ['/random', __('tg.c_random')],
    ['/quiz', __('tg.c_quiz')], ['/sq 7700', __('tg.c_sq')], ['/xwind 25 280/12', __('tg.c_xwind')],
    ['/news', __('tg.c_news')], ['/help', __('tg.c_help')],
];
?>
<section class="ac-layout narrow">
    <div class="page-head"><h1>✈ <?= e(__('tg.title')) ?></h1></div>

    <?php if (($linked['username'] ?? '') !== ''): ?>
    <div class="callout is-success mb">
        ✓ <?= e(__('tg.linked')) ?>: <b>@<?= e($linked['username']) ?></b> (<?= e(substr((string)$linked['created_at'], 0, 10)) ?>)
    </div>
    <?php endif; ?>

    <div class="panel" style="padding:22px">
        <p class="muted"><?= e(__('tg.intro')) ?></p>
        <a class="btn btn-primary tg-deeplink" href="https://t.me/<?= e($bot) ?>?start=<?= e($code) ?>" target="_blank" rel="noopener">
            ✈ <?= e(__('tg.open_tg')) ?> @<?= e($bot) ?>
        </a>
        <p class="muted small" style="margin-top:10px"><?= e(__('tg.or_code')) ?>:</p>
        <div class="tg-code-wrap">
            <div class="tg-code mono" id="tgCode">/start <?= e($code) ?></div>
            <button class="btn btn-primary" id="tgCopy" type="button"><?= e(__('tg.copy')) ?></button>
        </div>
        <p class="muted small"><?= e(__('tg.expire')) ?></p>

        <h3 class="side-title" style="margin-top:20px"><?= e(__('tg.commands')) ?></h3>
        <dl class="kv tg-cmds">
            <?php foreach ($cmds as [$c, $d]): ?>
            <div><dt class="mono"><?= e($c) ?></dt><dd><?= e($d) ?></dd></div>
            <?php endforeach; ?>
        </dl>
        <p class="muted small"><?= e(__('tg.smart_hint')) ?></p>
    </div>
</section>
<script>
document.getElementById('tgCopy').addEventListener('click', function () {
    var t = document.getElementById('tgCode').textContent;
    navigator.clipboard && navigator.clipboard.writeText(t);
    this.textContent = '✓';
});
</script>
