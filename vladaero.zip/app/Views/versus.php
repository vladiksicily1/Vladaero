<?php
/**
 * Versus — сравнение до 4 бортов (в.51–55).
 * @var array $fleet @var array $rows @var bool $crossClass @var string $shareUrl
 * @var array $catalog @var array $slugs
 */
$palette = ['#48CAE4', '#FFB454', '#3FBF7F', '#FF6B6B'];
$axisKeys = ['cruise_speed_kmh', 'range_km', 'ceiling_m', 'pax'];
$axisLbl  = [__('vs.ax_speed'), __('vs.ax_range'), __('vs.ax_ceiling'), __('vs.ax_pax')];

$specOf = static function (array $ac, string $field): ?float {
    $s = is_string($ac['specs']) ? (json_decode($ac['specs'], true) ?? []) : ($ac['specs'] ?? []);
    $v = $s[$field] ?? null;
    return is_numeric($v) ? (float)$v : null;
};
$axisMax = [];
foreach ($axisKeys as $k) {
    $axisMax[$k] = 0;
    foreach ($fleet as $ac) { $axisMax[$k] = max($axisMax[$k], $specOf($ac, $k) ?? 0); }
}
?>
<section class="ac-layout">
    <div class="page-head">
        <div>
            <h1>⚖ Versus — <?= e(__('vs.title')) ?></h1>
            <p class="muted"><?= e(__('vs.sub')) ?></p>
        </div>
    </div>

    <form class="vs-pick" method="get" action="<?= e(url('/versus')) ?>">
        <?php for ($i = 0; $i < 4; $i++): $cur = $slugs[$i] ?? ''; ?>
        <select name="<?= 'abcd'[$i] ?>" <?= $i > 1 ? '' : '' ?>>
            <option value=""><?= e($i === 0 ? __('vs.pick_first') : __('vs.pick_next')) ?></option>
            <?php foreach ($catalog as $a): ?>
            <option value="<?= e($a['slug']) ?>" <?= $cur === $a['slug'] ? 'selected' : '' ?>><?= e($a['name_ru']) ?></option>
            <?php endforeach; ?>
        </select>
        <?php endfor; ?>
        <button class="btn btn-primary" type="submit">⚖ <?= e(__('vs.compare')) ?></button>
    </form>

    <?php if (count($fleet) < 2): ?>
    <div class="empty">
        <div class="empty-ico">⚖</div>
        <h2><?= e(__('vs.need_two')) ?></h2>
        <p class="muted"><?= e(__('vs.need_two_sub')) ?></p>
    </div>
    <?php else: ?>

    <?php if ($crossClass): ?>
    <div class="callout is-warning mb"><?= e(__('vs.cross_class')) ?></div>
    <?php endif; ?>

    <div class="vs-grid">
        <div class="vs-panel">
            <h2 class="side-title"><?= e(__('vs.chart')) ?></h2>
            <svg viewBox="0 0 320 260" class="vs-radar" role="img" aria-label="radar chart">
                <?php
                $cx = 160; $cy = 128; $R = 92;
                $pt = static function (int $i, float $v) use ($cx, $cy, $R): array {
                    $ang = -M_PI / 2 + $i * M_PI / 2;   // ось 0 — вверх, далее по часовой
                    return [$cx + $R * $v * cos($ang), $cy + $R * $v * sin($ang)];
                };
                // сетка
                for ($ring = 1; $ring <= 4; $ring++):
                    $pts = [];
                    for ($i = 0; $i < 4; $i++) { [$x, $y] = $pt($i, $ring / 4); $pts[] = $x . ',' . $y; }
                ?>
                <polygon points="<?= implode(' ', $pts) ?>" class="vs-ring"/>
                <?php endfor; ?>
                <?php foreach ($fleet as $fi => $ac):
                    $vals = []; $any = false;
                    foreach ($axisKeys as $i => $k) {
                        $v = $specOf($ac, $k);
                        $n = $axisMax[$k] > 0 && $v !== null ? max(0.04, $v / $axisMax[$k]) : 0.04;
                        if ($v !== null && $v > 0) { $any = true; }
                        $vals[] = $pt($i, $n);
                    }
                    if (!$any) { continue; }
                    $pts = implode(' ', array_map(static fn($p) => $p[0] . ',' . $p[1], $vals));
                ?>
                <polygon points="<?= $pts ?>" class="vs-area" style="--c: <?= $palette[$fi] ?>"/>
                <?php endforeach; ?>
                <?php foreach ($axisLbl as $i => $lbl): [$x, $y] = $pt($i, 1.22); ?>
                <text x="<?= $x ?>" y="<?= $y ?>" class="vs-axis" text-anchor="middle" dominant-baseline="middle"><?= e($lbl) ?></text>
                <?php endforeach; ?>
            </svg>
            <div class="vs-legend">
                <?php foreach ($fleet as $fi => $ac): ?>
                <span><i style="--c: <?= $palette[$fi] ?>"></i><?= e($ac['name_ru']) ?></span>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="vs-panel">
            <h2 class="side-title"><?= e(__('vs.dims')) ?></h2>
            <div class="vs-dims">
                <?php
                $maxLen = 0; $maxSpan = 0;
                foreach ($fleet as $ac) { $maxLen = max($maxLen, $specOf($ac, 'length_m') ?? 0); $maxSpan = max($maxSpan, $specOf($ac, 'wingspan_m') ?? 0); }
                ?>
                <?php foreach (['length_m' => __('vs.m_length'), 'wingspan_m' => __('vs.m_wingspan')] as $dimK => $dimLbl):
                    $dm = $dimK === 'length_m' ? $maxLen : $maxSpan; ?>
                    <div class="vs-dim">
                        <div class="vs-dim-lbl"><?= e($dimLbl) ?></div>
                        <?php foreach ($fleet as $fi => $ac): $v = $specOf($ac, $dimK); $w = $dm > 0 && $v ? round($v / $dm * 100) : 4; ?>
                        <div class="vs-dim-row">
                            <span class="vs-dim-name" title="<?= e($ac['name_ru']) ?>"><?= e(mb_substr($ac['name_ru'], 0, 18)) ?></span>
                            <span class="vs-dim-bar" style="width: <?= $w ?>%; --c: <?= $palette[$fi] ?>"></span>
                            <span class="vs-dim-val"><?= $v ? e(number_format($v, 1)) . ' м' : '—' ?></span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php endforeach; ?>
            </div>

            <h2 class="side-title" style="margin-top:18px">🔗 <?= e(__('vs.share')) ?></h2>
            <div class="vs-share">
                <input type="text" readonly value="<?= e($shareUrl) ?>" id="vsUrl" onfocus="this.select()">
                <button class="btn" type="button" id="vsCopy"><?= e(__('vs.copy')) ?></button>
            </div>
            <p class="muted small"><?= e(__('vs.battle_soon')) ?></p>
        </div>
    </div>

    <div class="vs-table-wrap">
        <table class="vs-table">
            <thead>
                <tr>
                    <th></th>
                    <?php foreach ($fleet as $fi => $ac): ?>
                    <th style="--c: <?= $palette[$fi] ?>">
                        <a href="<?= e(url('/aircraft/' . $ac['slug'])) ?>"><?= e($ac['name_ru']) ?></a>
                        <small class="muted"><?= e(\App\Models\Aircraft::CATEGORIES[$ac['category']] ?? $ac['category']) ?></small>
                    </th>
                    <?php endforeach; ?>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <th><?= e($r['label']) ?></th>
                    <?php
                    $worst = null;
                    if (count($fleet) > 1) {
                        $nums = array_filter($r['vals'], static fn($v) => $v !== null && $v > 0);
                        if (count($nums) > 1) { $worst = array_search(min($nums), $r['vals'], true); }
                    }
                    ?>
                    <?php foreach ($r['vals'] as $i => $v): ?>
                    <td class="<?= $i === $r['best'] ? 'is-best' : ($i === $worst ? 'is-worst' : '') ?>">
                        <?php if ($v === null): ?><span class="muted">—</span>
                        <?php else: ?>
                        <span class="vs-val"><?= e(number_format($v, $v == (int)$v ? 0 : 1)) ?> <small><?= e($r['unit']) ?></small></span>
                        <span class="vs-bar" style="width: <?= $r['max'] > 0 ? round($v / $r['max'] * 100) : 0 ?>%"></span>
                        <?php if ($i === $r['best'] && count($fleet) > 1): ?><i class="vs-flag">▲</i><?php endif; ?>
                        <?php endif; ?>
                    </td>
                    <?php endforeach; ?>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>

    <?php if ($battle !== null): ?>
    <div class="panel battle-panel" id="battle" style="padding:22px">
        <h3 class="side-title">⚖ <?= e(__('vs.battle_title')) ?></h3>
        <p class="muted small"><?= e(__('vs.battle_hint')) ?></p>
        <?php if (\App\Core\Auth::check()): ?>
        <div class="battle-vote">
            <form method="post" action="<?= url('/versus/vote') ?>" class="inline">
                <?= csrf_field() ?>
                <input type="hidden" name="a" value="<?= (int)$battle['a'] ?>">
                <input type="hidden" name="b" value="<?= (int)$battle['b'] ?>">
                <input type="hidden" name="w" value="<?= (int)$battle['a'] ?>">
                <button class="btn <?= $battle['my'] === $battle['a'] ? 'btn-primary' : '' ?>" type="submit">✈ <?= e($fleet[0]['name_ru']) ?></button>
            </form>
            <form method="post" action="<?= url('/versus/vote') ?>" class="inline">
                <?= csrf_field() ?>
                <input type="hidden" name="a" value="<?= (int)$battle['a'] ?>">
                <input type="hidden" name="b" value="<?= (int)$battle['b'] ?>">
                <input type="hidden" name="w" value="<?= (int)$battle['b'] ?>">
                <button class="btn <?= $battle['my'] === $battle['b'] ? 'btn-primary' : '' ?>" type="submit">✈ <?= e($fleet[1]['name_ru']) ?></button>
            </form>
        </div>
        <?php else: ?>
        <p class="muted small"><?= e(__('vs.battle_need_login')) ?> <a href="<?= url('/login') ?>"><?= e(__('common.login')) ?></a></p>
        <?php endif; ?>
        <div class="battle-bar" title="<?= (int)$battle['votesA'] ?> : <?= (int)$battle['votesB'] ?>">
            <i class="battle-a" style="width: <?= (int)$battle['pctA'] ?>%"></i>
            <span class="battle-pct"><?= (int)$battle['pctA'] ?>% · <?= (int)$battle['total'] ?> 🗳 · <?= (int)(100 - $battle['pctA']) ?>%</span>
        </div>
        <div class="battle-names small">
            <b><?= e($fleet[0]['name_ru']) ?></b><b><?= e($fleet[1]['name_ru']) ?></b>
        </div>
    </div>

    <?= \App\Core\View::partial('partials/comments', [
        'cType' => 'battle',
        'cId' => \App\Services\CommentService::battleId((int)$fleet[0]['id'], (int)$fleet[1]['id']),
        'cTree' => \App\Services\CommentService::tree('battle', \App\Services\CommentService::battleId((int)$fleet[0]['id'], (int)$fleet[1]['id']), \App\Core\Auth::id() ?? 0),
        'cBack' => '/versus/' . rawurlencode($fleet[0]['slug']) . '-vs-' . rawurlencode($fleet[1]['slug']),
    ]) ?>
    <?php endif; ?>
</section>
<script>
document.getElementById('vsCopy') && document.getElementById('vsCopy').addEventListener('click', function () {
    var i = document.getElementById('vsUrl'); i.select();
    navigator.clipboard && navigator.clipboard.writeText(i.value);
    this.textContent = '✓';
});
</script>
