<?php /** Клубы (в.27) */ ?>
<section class="ac-layout">
    <div class="page-head">
        <h1>☰ <?= e(__('clubs.title')) ?></h1>
        <a class="btn btn-primary" href="<?= url('/clubs/create') ?>">＋ <?= e(__('clubs.create')) ?></a>
    </div>
    <p class="muted"><?= e(__('clubs.intro')) ?></p>

    <div class="club-grid">
        <?php foreach ($clubs as $c): ?>
        <div class="panel club-card">
            <div class="club-head">
                <b class="club-title"><a href="<?= url('/clubs/' . $c['slug']) ?>"><?= e($c['title']) ?></a></b>
                <i class="tag-soon"><?= e($kinds[$c['kind']] ?? $c['kind']) ?></i>
            </div>
            <p class="club-desc"><?= e(mb_substr((string)$c['description'], 0, 160)) ?><?= mb_strlen((string)$c['description']) > 160 ? '…' : '' ?></p>
            <div class="club-foot muted small">
                👥 <?= (int)$c['members'] ?> · ☰ <?= e($c['owner']) ?>
                <?php if ($c['joined']): ?><i class="tag-soon">✓ <?= e(__('clubs.member')) ?></i><?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
        <?php if ($clubs === []): ?>
        <div class="panel muted"><?= e(__('clubs.empty')) ?></div>
        <?php endif; ?>
    </div>
</section>
