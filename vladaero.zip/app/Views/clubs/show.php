<?php /** Страница клуба (в.27): участники, стена обсуждения */ ?>
<section class="ac-layout narrow">
    <div class="page-head">
        <h1>☰ <?= e($club['title']) ?></h1>
        <form method="post" action="<?= url('/clubs/' . $club['slug'] . '/toggle') ?>" class="inline">
            <?= csrf_field() ?>
            <button class="btn <?= $joined ? '' : 'btn-primary' ?>" type="submit">
                <?= $joined ? '✕ ' . e(__('clubs.leave')) : '＋ ' . e(__('clubs.join')) ?>
            </button>
        </form>
    </div>

    <div class="panel" style="padding:22px">
        <div class="ev-meta">
            <span><i class="tag-soon"><?= e($kindLabel) ?></i></span>
            <span>☰ <?= e(__('clubs.owner')) ?>: <b><?= e($club['owner']) ?></b></span>
            <span>👥 <?= count($members) ?></span>
        </div>
        <div class="ev-desc"><?= nl2br(e($club['description'])) ?></div>

        <h3 class="side-title">👥 <?= e(__('clubs.members')) ?></h3>
        <div class="ev-attendees">
            <?php foreach ($members as $m): ?>
            <span class="chip"><span class="avatar avatar--sm"><?= e(mb_strtoupper(mb_substr($m['username'], 0, 1))) ?></span><?= e($m['username']) ?></span>
            <?php endforeach; ?>
        </div>
    </div>

    <?= \App\Core\View::partial('partials/comments', [
        'cType' => 'club',
        'cId' => (int)$club['id'],
        'cTree' => \App\Services\CommentService::tree('club', (int)$club['id'], \App\Core\Auth::id() ?? 0),
        'cBack' => '/clubs/' . $club['slug'],
    ]) ?>
</section>
