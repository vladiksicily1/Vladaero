<?php /** Создание клуба (в.27) — на модерацию */ ?>
<section class="ac-layout narrow">
    <div class="page-head"><h1>＋ <?= e(__('clubs.create')) ?></h1></div>
    <div class="panel" style="padding:22px">
        <p class="muted"><?= e(__('clubs.create_intro')) ?></p>
        <form method="post" action="<?= url('/clubs/create') ?>" class="stack-form">
            <?= csrf_field() ?>
            <label class="f"><?= e(__('clubs.f_title')) ?><input name="title" required maxlength="190"></label>
            <label class="f"><?= e(__('clubs.f_kind')) ?>
                <select name="kind">
                    <?php foreach ($kinds as $k => $t): ?><option value="<?= e($k) ?>"><?= e($t) ?></option><?php endforeach; ?>
                </select>
            </label>
            <label class="f"><?= e(__('clubs.f_desc')) ?><textarea name="description" rows="5" required maxlength="3000"></textarea></label>
            <button class="btn btn-primary" type="submit">✈ <?= e(__('clubs.submit')) ?></button>
        </form>
    </div>
</section>
