<?php /** Зоны ожидания (в.49): калькулятор входа + схема зоны на SVG */ ?>
<section class="ac-layout">
    <div class="page-head"><h1>⌖ <?= e(__('holding.title')) ?></h1></div>
    <p class="muted"><?= e(__('holding.intro')) ?></p>

    <div class="hold-grid">
        <div class="panel">
            <h3 class="form-h">Параметры</h3>
            <div class="form-grid">
                <label class="field"><span>Inbound course (°)</span>
                    <input type="number" id="hInb" min="0" max="359" value="270"></label>
                <label class="field"><span>Магнитный курс самолёта (°)</span>
                    <input type="number" id="hHdg" min="0" max="359" value="200"></label>
                <label class="field"><span>Развороты</span>
                    <select id="hTurn" class="input"><option value="right">правые (стандарт)</option><option value="left">левые</option></select></label>
                <label class="field"><span>Скорость (kt)</span>
                    <input type="number" id="hSpd" min="100" max="600" value="230"></label>
            </div>
            <div id="hVerdict" class="hold-verdict"></div>
        </div>
        <div class="panel hold-map-box">
            <svg id="holdSvg" viewBox="0 0 460 360" width="100%"></svg>
            <p class="muted small">Схема учебная (protected airspace, 4 nm от линии) — не для навигационного использования.</p>
        </div>
    </div>
</section>
<script>
(function () {
    var inb = document.getElementById('hInb'), hdg = document.getElementById('hHdg'),
        turn = document.getElementById('hTurn'), spd = document.getElementById('hSpd'),
        verdict = document.getElementById('hVerdict'), svg = document.getElementById('holdSvg');
    var NS = 'http://www.w3.org/2000/svg';
    function el(t, attrs, txt) {
        var e = document.createElementNS(NS, t);
        for (var k in attrs) { e.setAttribute(k, attrs[k]); }
        if (txt) { e.textContent = txt; }
        return e;
    }
    function angDiff(a, b) { return ((a - b + 540) % 360) - 180; }

    function entryType(inbC, hdgC, side) {
        // угол входа относительно inbound: до 70° — прямой, 70–110 — снаружи (teardrop), остальное — обратный (parallel)
        var off = angDiff(hdgC, inbC);
        if (side === 'left') { off = -off; }
        var a = (off + 360) % 360;
        if (a <= 70) { return { key: 'direct', name: 'Прямой (№1)', hint: 'Вход в круг с курсом, близким к inbound: заходите сразу в зону.' }; }
        if (a <= 180) { return { key: 'teardrop', name: 'С носка (teardrop, №2)', hint: 'Отлетите от fix под ~30° от outbound, затем разворот в круг.' }; }
        return { key: 'parallel', name: 'Обратный (parallel, №3)', hint: 'Пролетите курс, обратный inbound, затем разворот на 210° в зону.' };
    }

    function draw() {
        var i = (+inb.value || 0), h = (+hdg.value || 0), side = turn.value, v = Math.max(100, +spd.value || 230);
        var t = entryType(i, h, side);
        var r = Math.round(0.032 * v * v / 100); // грубый радиус разворота (сотни метров) — для подписи
        verdict.innerHTML = '<b>' + t.name + '</b><p class="muted small">' + t.hint + '</p>' +
            '<p class="small">Outbound: <b>' + (((i + 180) % 360 + 360) % 360).toFixed(0) + '°</b> · разворот ' + (side === 'right' ? 'правый' : 'левый') +
            ' · R≈' + r + '00 м на ' + v + ' kt · 1 min legs (до FL140)</p>';

        // схема: inbound снизу вверх к fix, зона сверху
        var cx = 230, fy = 300, topY = 90, w = 150 * (side === 'right' ? 1 : -1);
        var rot = function (x, y) { // повернуть всю картинку так, чтобы inbound смотрел на курс i вверх
            var a = (-90 - i) * Math.PI / 180, dx = x - cx, dy = y - fy;
            return [cx + dx * Math.cos(a) - dy * Math.sin(a), fy + dx * Math.sin(a) + dy * Math.cos(a)];
        };
        var line = function (pts, color, dash, wid) {
            var d = pts.map(function (p, k) { var q = rot(p[0], p[1]); return (k ? 'L' : 'M') + q[0].toFixed(1) + ' ' + q[1].toFixed(1); }).join(' ');
            svg.appendChild(el('path', { d: d, fill: 'none', stroke: color, 'stroke-width': wid || 2.2, 'stroke-dasharray': dash || 'none' }));
        };
        var text = function (p, s, color, anchor) {
            var q = rot(p[0], p[1]);
            var t2 = el('text', { x: q[0], y: q[1], fill: color || '#DFF6FF', 'font-size': 12, 'text-anchor': anchor || 'middle' }, s);
            svg.appendChild(t2);
        };
        svg.innerHTML = '';
        // protective zone (упрощённо)
        line([[cx - w - 40, fy], [cx - w - 40, topY], [cx + w + 40, topY], [cx + w + 40, fy]], 'rgba(72,202,228,.35)', '6 6', 1.4);
        // racetrack
        line([[cx, fy], [cx, topY + 30]], '#48CAE4');
        line([[cx, topY + 30], [cx + w, topY], [cx + w, topY - 20]], '#48CAE4', 'none', 2.6);
        line([[cx + w, topY - 20], [cx + w, topY - 45], [cx, topY - 30]], '#48CAE4');
        // inbound arrow (курс i)
        line([[cx, fy + 70], [cx, fy]], '#FF6B57', 'none', 2.2);
        text([cx + 16, fy + 60], 'IN ' + i.toFixed(0) + '°', '#FF9B8C', 'start');
        // самолёт: линия курса h
        var rad = (i + angDiff(h, i)) * Math.PI / 180;
        line([[cx - Math.sin(rad) * 110, fy + 40 + Math.cos(rad) * 0], [cx, fy + 40]], 'rgba(223,246,255,.8)', '4 4', 1.6);
        text([cx + 12, fy + 92], 'HDG ' + h.toFixed(0) + '°', '#DFF6FF', 'start');
        // fix
        svg.appendChild(el('circle', { cx: cx, cy: fy, r: 4.5, fill: '#FFD166' }));
        text([cx - 14, fy + 4], 'FIX', '#FFD166', 'end');
        // подпись стороны
        text([cx + w * 0.9, topY - 55], side === 'right' ? 'правые развороты' : 'левые развороты', 'rgba(223,246,255,.75)');
        // тип входа на схеме
        text([cx, 40], t.name, '#48CAE4');
    }
    [inb, hdg, turn, spd].forEach(function (x) { x.addEventListener('input', draw); x.addEventListener('change', draw); });
    draw();
})();
</script>
