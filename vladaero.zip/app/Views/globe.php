<?php /** 3D-глобус (в.88): без внешних библиотек, чистый canvas */ ?>
<section class="ac-layout">
    <div class="page-head">
        <h1>◐ <?= e(__('globe.title')) ?></h1>
        <div class="ev-filters">
            <label class="chk"><input type="checkbox" id="glRot" checked> <?= e(__('globe.rotate')) ?></label>
            <button class="btn btn--sm" type="button" id="glHome">⌂</button>
        </div>
    </div>
    <p class="muted"><?= e(__('globe.intro')) ?></p>
    <div class="panel globe-wrap">
        <canvas id="globe" width="900" height="620"></canvas>
        <div class="globe-legend muted small">
            <span><i class="gl-dot gl-ap"></i> <?= e(__('globe.airports')) ?> <b id="glApN"></b></span>
            <span><i class="gl-dot gl-ev"></i> <?= e(__('globe.events')) ?> <b id="glEvN"></b></span>
        </div>
    </div>
</section>
<script>
(function () {
    var cv = document.getElementById('globe'), ctx = cv.getContext('2d');
    var AP = <?= json_encode(array_map(static fn($a) => [
        'icao' => $a['icao'], 'name' => $a['name_ru'],
        'lat' => (float)$a['lat'], 'lng' => (float)$a['lng'],
    ], $airports), JSON_UNESCAPED_UNICODE) ?>;
    var EV = <?= json_encode(array_map(static fn($e) => [
        'title' => $e['title_ru'], 'slug' => $e['slug'],
        'lat' => (float)$e['lat'], 'lng' => (float)$e['lng'],
        'date' => substr((string)$e['starts_at'], 0, 10),
    ], $events), JSON_UNESCAPED_UNICODE) ?>;
    document.getElementById('glApN').textContent = AP.length;
    document.getElementById('glEvN').textContent = EV.length;

    var rotY = -0.6, rotX = 0.45, auto = true, R = 0, cx = 0, cy = 0;
    function resize() {
        var w = cv.parentNode.clientWidth - 2;
        cv.width = w; cv.height = Math.max(360, Math.min(620, Math.round(w * 0.62)));
        R = Math.min(cv.width, cv.height) / 2 - 30;
        cx = cv.width / 2; cy = cv.height / 2;
    }
    window.addEventListener('resize', resize); resize();

    function proj(latDeg, lngDeg) {
        var la = latDeg * Math.PI / 180, lo = lngDeg * Math.PI / 180 + rotY;
        var x = Math.cos(la) * Math.sin(lo);
        var y = Math.sin(la);
        var z = Math.cos(la) * Math.cos(lo);
        // наклон оси
        var y2 = y * Math.cos(rotX) - z * Math.sin(rotX);
        var z2 = y * Math.sin(rotX) + z * Math.cos(rotX);
        return { x: cx + x * R, y: cy - y2 * R, z: z2, front: z2 >= 0 };
    }

    var hover = null, mouse = null;
    function tick() {
        if (auto && !mouse) { rotY += 0.0022; }
        ctx.clearRect(0, 0, cv.width, cv.height);

        // сфера
        var g = ctx.createRadialGradient(cx - R * 0.35, cy - R * 0.4, R * 0.1, cx, cy, R);
        g.addColorStop(0, '#16263f'); g.addColorStop(1, '#0B132B');
        ctx.beginPath(); ctx.arc(cx, cy, R, 0, 7); ctx.fillStyle = g; ctx.fill();
        ctx.lineWidth = 1.2; ctx.strokeStyle = 'rgba(72,202,228,.55)'; ctx.stroke();

        // сетка меридианов/параллелей (только видимая половина)
        ctx.strokeStyle = 'rgba(72,202,228,.14)'; ctx.lineWidth = 1;
        for (var lo = -180; lo < 180; lo += 30) {
            ctx.beginPath(); var started = false;
            for (var la = -90; la <= 90; la += 4) {
                var p = proj(la, lo);
                if (p.front) { started ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y); started = true; } else { started = false; }
            }
            ctx.stroke();
        }
        for (var la = -60; la <= 60; la += 30) {
            ctx.beginPath(); started = false;
            for (var lo = -180; lo <= 180; lo += 4) {
                var p = proj(la, lo);
                if (p.front) { started ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y); started = true; } else { started = false; }
            }
            ctx.stroke();
        }

        // дуги маршрутов между первыми аэропортами (до 8)
        var pts = AP.slice(0, 8).map(function (a) { return proj(a.lat, a.lng); });
        ctx.lineWidth = 1.4;
        for (var i = 0; i < pts.length - 1; i++) {
            if (!pts[i].front || !pts[i + 1].front) { continue; }
            var mx = (pts[i].x + pts[i + 1].x) / 2, my = (pts[i].y + pts[i + 1].y) / 2;
            var dx = mx - cx, dy = my - cy, d = Math.sqrt(dx * dx + dy * dy) || 1;
            mx += dx / d * R * 0.25; my += dy / d * R * 0.25;
            ctx.beginPath(); ctx.strokeStyle = 'rgba(0,119,182,.5)';
            ctx.moveTo(pts[i].x, pts[i].y); ctx.quadraticCurveTo(mx, my, pts[i + 1].x, pts[i + 1].y); ctx.stroke();
        }

        // аэропорты
        AP.forEach(function (a) {
            var p = proj(a.lat, a.lng);
            if (!p.front) { return; }
            ctx.beginPath(); ctx.arc(p.x, p.y, 2.6, 0, 7);
            ctx.fillStyle = 'rgba(72,202,228,.9)'; ctx.fill();
        });

        // события (пульс)
        var t = Date.now() / 700;
        EV.forEach(function (e) {
            var p = proj(e.lat, e.lng);
            if (!p.front) { return; }
            var pulse = 3 + 2.5 * (0.5 + 0.5 * Math.sin(t));
            ctx.beginPath(); ctx.arc(p.x, p.y, pulse + 3, 0, 7);
            ctx.fillStyle = 'rgba(255,107,87,.18)'; ctx.fill();
            ctx.beginPath(); ctx.arc(p.x, p.y, 3, 0, 7);
            ctx.fillStyle = '#FF6B57'; ctx.fill();
        });

        // курсор-подсказка
        if (hover) {
            var items = hover === 'ev' ? EV : AP;
            for (var k = 0; k < items.length; k++) {
                var p2 = proj(items[k].lat, items[k].lng);
                if (!p2.front) { continue; }
                if (Math.abs(p2.x - mouse.x) < 7 && Math.abs(p2.y - mouse.y) < 7) {
                    var label = hover === 'ev'
                        ? '📅 ' + items[k].title + ' · ' + items[k].date
                        : '⬡ ' + items[k].icao + ' — ' + items[k].name;
                    ctx.font = '12px system-ui, sans-serif';
                    var w = ctx.measureText(label).width + 14;
                    var bx = Math.min(cv.width - w - 6, Math.max(6, p2.x + 10));
                    var by = Math.max(20, p2.y - 28);
                    ctx.fillStyle = 'rgba(11,19,43,.92)';
                    ctx.strokeStyle = 'rgba(72,202,228,.5)';
                    ctx.beginPath(); ctx.roundRect(bx, by, w, 22, 6); ctx.fill(); ctx.stroke();
                    ctx.fillStyle = '#DFF6FF'; ctx.fillText(label, bx + 7, by + 15);
                    break;
                }
            }
        }
        requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);

    // взаимодействие
    var drag = null;
    cv.addEventListener('mousedown', function (e) { drag = { x: e.offsetX, y: e.offsetY }; });
    cv.addEventListener('mousemove', function (e) {
        mouse = { x: e.offsetX, y: e.offsetY };
        hover = e.shiftKey ? 'ev' : 'ap';
        if (drag) {
            rotY += (e.offsetX - drag.x) * 0.006;
            rotX = Math.max(-1.35, Math.min(1.35, rotX + (e.offsetY - drag.y) * 0.005));
            drag = { x: e.offsetX, y: e.offsetY };
        }
    });
    cv.addEventListener('mouseleave', function () { drag = null; mouse = null; });
    cv.addEventListener('mouseup', function () { drag = null; });
    cv.addEventListener('touchstart', function (e) { drag = { x: e.touches[0].clientX, y: e.touches[0].clientY }; }, { passive: true });
    cv.addEventListener('touchmove', function (e) {
        if (!drag) { return; }
        rotY += (e.touches[0].clientX - drag.x) * 0.006;
        rotX = Math.max(-1.35, Math.min(1.35, rotX + (e.touches[0].clientY - drag.y) * 0.005));
        drag = { x: e.touches[0].clientX, y: e.touches[0].clientY };
    }, { passive: true });
    cv.addEventListener('touchend', function () { drag = null; });
    document.getElementById('glRot').addEventListener('change', function () { auto = this.checked; });
    document.getElementById('glHome').addEventListener('click', function () { rotY = -0.6; rotX = 0.45; });
})();
</script>
