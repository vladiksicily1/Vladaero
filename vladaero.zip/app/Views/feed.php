<?php /** Лента подписок (v0.8.1) */ ?>
<section class="ac-layout">
    <div class="page-head">
        <h1>≑ <?= e(__('feed.title')) ?></h1>
    </div>
    <p class="muted"><?= e(__('feed.intro')) ?></p>

    <div class="feed-grid">
        <div class="feed-main">
            <?php foreach ($feed as $f): ?>
            <div class="panel feed-item">
                <div class="feed-item-head">
                    <b><a href="<?= url('/articles/' . $f['slug']) ?>"><?= e($f['title_ru']) ?></a></b>
                    <span class="muted small"><?= e(date('d.m.Y H:i', strtotime((string)$f['published_at']))) ?></span>
                </div>
                <p class="muted"><?= e(mb_substr((string)$f['excerpt_ru'], 0, 200)) ?></p>
                <div class="muted small">
                    ✍ <a href="<?= url('/profile/' . $f['author_id']) ?>"><?= e($f['author']) ?></a>
                    · 👁 <?= (int)$f['views'] ?>
                </div>
            </div>
            <?php endforeach; ?>
            <?php if ($feed === []): ?>
            <div class="panel muted"><?= e(__('feed.empty')) ?></div>
            <?php endif; ?>
        </div>
        <aside class="feed-side">
            <div class="panel">
                <h3 class="form-h"><?= e(__('feed.authors')) ?></h3>
                <?php foreach ($authors as $a): ?>
                <div class="feed-author">
                    <a href="<?= url('/profile/' . $a['id']) ?>"><?= e($a['login']) ?></a>
                    <span class="muted small">· <?= (int)$a['pub'] ?></span>
                </div>
                <?php endforeach; ?>
                <?php if ($authors === []): ?><p class="muted small"><?= e(__('feed.no_authors')) ?></p><?php endif; ?>
            </div>
        </aside>
    </div>
</section>
