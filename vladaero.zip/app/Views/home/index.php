<?php /** Главная страница: hero (в.226), статистика, карта модулей */ ?>

<section class="hero<?= ($site['hero_image'] ?? '') !== '' ? ' hero--image' : '' ?>"
    <?= ($site['hero_image'] ?? '') !== '' ? 'style="background-image:url(\'' . e(url($site['hero_image'])) . '\')"' : '' ?>>
    <div class="hero-inner">
        <span class="hero-badge">VLADAERO · АВИАЦИОННЫЙ ПОРТАЛ · v<?= VA_VERSION ?></span>
        <h1 class="hero-title"><?= e($site['hero_title'] ?? 'Небо ближе, чем кажется') ?></h1>
        <p class="hero-sub"><?= e($site['hero_sub'] ?? '') ?></p>
        <div class="hero-actions">
            <a class="btn btn--primary" href="<?= url('/aircraft') ?>">✈ <?= e(__('home.hero_cta1')) ?></a>
            <a class="btn btn--ghost" href="#">◎ <?= e(__('home.hero_cta2')) ?> <i class="tag-soon">v0.3</i></a>
        </div>
    </div>
    <div class="hero-sweep" aria-hidden="true"></div>
</section>

<section class="stats-strip">
    <div class="stat"><b id="stat-users"><?= (int)$stats['users'] ?></b><span><?= e(__('home.stats.users')) ?></span></div>
    <div class="stat"><b><?= (int)$stats['aircraft'] ?></b><span><?= e(__('home.stats.aircraft')) ?></span></div>
    <div class="stat"><b><?= (int)$stats['airports'] ?></b><span><?= e(__('home.stats.airports')) ?></span></div>
    <div class="stat"><b><?= (int)$stats['photos'] ?></b><span><?= e(__('home.stats.photos')) ?></span></div>
    <div class="stat"><b><?= (int)$stats['articles'] ?></b><span><?= e(__('home.stats.articles')) ?></span></div>
</section>

<section class="section">
    <h2 class="section-title"><?= e(__('home.modules')) ?></h2>
    <div class="modules-grid">
        <div class="module-card">
            <div class="module-ico">✈</div>
            <h3><?= e(__('nav.encyclopedia')) ?></h3>
            <p>Каталог бортов с ТТХ, модификациями, 3D-моделями и историей (в.6–9).</p>
            <span class="tag-ver">v0.2</span>
        </div>
        <div class="module-card">
            <div class="module-ico">◎</div>
            <h3><?= e(__('nav.radar')) ?></h3>
            <p>OpenSky + Leaflet, 2D/3D треки, алерты Squawk 7700, playback (в.16–20).</p>
            <span class="tag-ver">v0.3</span>
        </div>
        <div class="module-card">
            <div class="module-ico">▣</div>
            <h3><?= e(__('nav.gallery')) ?></h3>
            <p>Споттинг со скринингом, EXIF, водяными знаками и «Фото дня» (в.11–15).</p>
            <span class="tag-ver">v0.3</span>
        </div>
        <div class="module-card">
            <div class="module-ico">☁</div>
            <h3><?= e(__('nav.weather')) ?></h3>
            <p>METAR/TAF/NOTAM с авто-расшифровкой и брифингами (NOAA AWC).</p>
            <span class="tag-ver">v0.4</span>
        </div>
        <div class="module-card">
            <div class="module-ico">✦</div>
            <h3><?= e(__('nav.ai')) ?></h3>
            <p>AI-виджет с 20 инструментами, Firecrawl, SSE-стриминг и reasoning (в.151–160).</p>
            <span class="tag-ver">v0.5</span>
        </div>
        <div class="module-card">
            <div class="module-ico">✈</div>
            <h3>Telegram-бот</h3>
            <p>Вход по коду, /metar, /track, Mini App и уведомления (в.116–120, 241–265).</p>
            <span class="tag-ver">v0.5</span>
        </div>
        <div class="module-card">
            <div class="module-ico">⌗</div>
            <h3><?= e(__('nav.calculators')) ?></h3>
            <p>Конвертеры, кроссвинд, центровка, ортодромия, компенсации (в.46–50).</p>
            <span class="tag-ver">v0.4</span>
        </div>
        <div class="module-card">
            <div class="module-ico">✱</div>
            <h3>Лётная школа и викторины</h3>
            <p>Уроки VFR/IFR, чек-листы, QRH, «Угадай борт» (в.21–25, 61–65).</p>
            <span class="tag-ver">v0.6</span>
        </div>
    </div>
</section>

<section class="section">
    <h2 class="section-title"><?= e(__('home.stack')) ?></h2>
    <div class="chips">
        <span class="chip">PHP 8.1+ · MVC без зависимостей</span>
        <span class="chip">MySQL utf8mb4 + префиксы таблиц</span>
        <span class="chip">Leaflet.js / OpenStreetMap</span>
        <span class="chip">Three.js (GLB/glTF)</span>
        <span class="chip">SSE-стриминг ИИ</span>
        <span class="chip">Telegram Webhook</span>
        <span class="chip">OpenSky · NOAA AWC · LiveATC</span>
        <span class="chip">PWA</span>
    </div>
</section>
