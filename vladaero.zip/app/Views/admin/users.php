<?php /** Пользователи: роли, баны (в.29) */ ?>
<div class="panel">
    <div class="panel-head">
        <h3><?= e(__('admin.users')) ?> — <?= (int)$total ?></h3>
        <form method="get" action="<?= url('/admin/users') ?>" class="inline search-mini">
            <input type="search" name="q" value="<?= e($q) ?>" placeholder="Логин или email…">
            <button class="btn btn--ghost btn--sm" type="submit">⌕</button>
        </form>
    </div>
    <div class="table-wrap">
        <table class="table">
            <thead><tr><th>ID</th><th>Пользователь</th><th>Роль</th><th>Ранг</th><th>Реп.</th><th>Статус</th><th>Регистрация</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($users as $u): $self = (int)$u['id'] === \App\Core\Auth::id(); ?>
                <tr>
                    <td class="mono muted">#<?= (int)$u['id'] ?></td>
                    <td>
                        <b><?= e($u['username']) ?></b>
                        <div class="muted small"><?= e($u['email']) ?></div>
                    </td>
                    <td>
                        <?php if ($u['role'] === 'admin' || $self): ?>
                            <span class="role-badge role-admin"><?= e(__('role.' . $u['role'])) ?></span>
                        <?php else: ?>
                            <form method="post" action="<?= url('/admin/users/' . (int)$u['id'] . '/role') ?>" class="inline">
                                <?= csrf_field() ?>
                                <select name="role" onchange="this.form.submit()">
                                    <?php foreach (\App\Core\Auth::ROLES as $r): ?>
                                        <option value="<?= e($r) ?>" <?= $u['role'] === $r ? 'selected' : '' ?>><?= e(__('role.' . $r)) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </form>
                        <?php endif; ?>
                    </td>
                    <td><span class="rank"><?= e(__('rank.' . $u['rank'])) ?></span></td>
                    <td class="mono"><?= (int)$u['reputation'] ?></td>
                    <td><?= $u['status'] === 'banned'
                        ? '<span class="t-danger">забанен</span>'
                        : '<span class="t-ok">активен</span>' ?></td>
                    <td class="mono muted"><?= e($u['created_at']) ?></td>
                    <td>
                        <?php if (!$self && $u['role'] !== 'admin'): ?>
                            <?php if ($u['status'] === 'banned'): ?>
                                <form method="post" action="<?= url('/admin/users/' . (int)$u['id'] . '/unban') ?>" class="inline"><?= csrf_field() ?>
                                    <button class="btn btn--ghost btn--sm" type="submit">разбан</button></form>
                            <?php else: ?>
                                <form method="post" action="<?= url('/admin/users/' . (int)$u['id'] . '/ban') ?>" class="inline"
                                      data-confirm="Заблокировать пользователя <?= e($u['username']) ?>?"><?= csrf_field() ?>
                                    <button class="btn btn--danger btn--sm" type="submit">бан</button></form>
                            <?php endif; ?>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php if ($pages > 1): ?>
        <div class="pager">
            <?php for ($p = 1; $p <= $pages; $p++): ?>
                <a class="pg <?= $p === $page ? 'is-active' : '' ?>"
                   href="<?= url('/admin/users') ?>?q=<?= urlencode($q) ?>&amp;page=<?= $p ?>"><?= $p ?></a>
            <?php endfor; ?>
        </div>
    <?php endif; ?>
</div>
