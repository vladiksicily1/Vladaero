<?php /** Дашборд NOC (в.110, 234) */ ?>

<div class="widget-grid">
    <div class="widget"><span class="w-label"><?= e(__('home.stats.users')) ?></span><b class="w-value"><?= (int)$m['users_total'] ?></b><span class="w-delta">+<?= (int)$m['users_new_7d'] ?> / 7 дн</span></div>
    <div class="widget"><span class="w-label">Фото в очереди</span><b class="w-value"><?= (int)$m['photos_pending'] ?></b><span class="w-delta muted">скрининг v0.3</span></div>
    <div class="widget"><span class="w-label">Фото принято</span><b class="w-value"><?= (int)$m['photos_approved'] ?></b><span class="w-delta muted">v0.3</span></div>
    <div class="widget"><span class="w-label"><?= e(__('home.stats.articles')) ?></span><b class="w-value"><?= (int)$m['articles'] ?></b><span class="w-delta muted">v0.2</span></div>
    <div class="widget"><span class="w-label"><?= e(__('home.stats.aircraft')) ?></span><b class="w-value"><?= (int)$m['aircraft'] ?></b><span class="w-delta muted">v0.2</span></div>
    <div class="widget"><span class="w-label"><?= e(__('home.stats.airports')) ?></span><b class="w-value"><?= (int)$m['airports'] ?></b><span class="w-delta muted">v0.2</span></div>
    <div class="widget"><span class="w-label">ИИ-запросы / 7 дн</span><b class="w-value"><?= (int)$m['ai_requests_7d'] ?></b><span class="w-delta muted">v0.5</span></div>
    <div class="widget"><span class="w-label">База данных</span><b class="w-value"><?= e(number_format($m['db_size_mb'], 1)) ?><small> МБ</small></b><span class="w-delta">кэш <?= e(bytes((int)$m['cache_size'])) ?> · лог <?= e(bytes((int)$m['log_size'])) ?></span></div>
</div>

<div class="panel-row">
    <div class="panel panel--wide">
        <div class="panel-head">
            <h3>Активность (14 дней)</h3>
            <span class="legend"><i class="lg lg--users"></i> регистрации <i class="lg lg--ai"></i> ИИ-запросы</span>
        </div>
        <div class="chart-box"><canvas id="dashChart" height="220"
            data-chart='<?= e(json_encode($chart, JSON_UNESCAPED_UNICODE)) ?>'></canvas></div>
    </div>
    <div class="panel">
        <div class="panel-head"><h3>Быстрые действия</h3></div>
        <div class="quick-actions">
            <form method="post" action="<?= url('/admin/maintenance') ?>"><?= csrf_field() ?>
                <button class="btn <?= $m['maintenance'] ? 'btn--danger' : 'btn--ghost' ?>" type="submit">
                    <?= $m['maintenance'] ? '⛔ Выключить обслуживание' : '🛠 Включить обслуживание' ?>
                </button>
            </form>
            <form method="post" action="<?= url('/admin/clear-cache') ?>"><?= csrf_field() ?>
                <button class="btn btn--ghost" type="submit"> ⟳ Очистить кэш</button>
            </form>
            <a class="btn btn--ghost" href="<?= url('/admin/system/backup') ?>">⤓ Скачать SQL-дамп</a>
            <a class="btn btn--ghost" href="<?= url('/admin/settings/ai') ?>">✦ Настроить ИИ</a>
        </div>
        <div class="panel-note muted">
            Статус: <?= $m['maintenance'] ? '<b class="t-warn">обслуживание</b>' : '<b class="t-ok">номинальный</b>' ?> ·
            Супер-Агент (50 tools) — <span class="tag-soon">v0.5</span>
        </div>
    </div>
</div>

<div class="panel">
    <div class="panel-head"><h3>Журнал действий (Audit Log, в.109)</h3>
        <a class="link" href="<?= url('/admin/logs') ?>">logs →</a>
    </div>
    <?php if ($audit === []): ?>
        <p class="muted pad">Пока пусто — действия появятся после первой настройки.</p>
    <?php else: ?>
    <div class="table-wrap">
        <table class="table">
            <thead><tr><th>Время</th><th>Пользователь</th><th>Действие</th><th>Объект</th><th>IP</th></tr></thead>
            <tbody>
            <?php foreach ($audit as $a): ?>
                <tr>
                    <td class="mono"><?= e($a['created_at']) ?></td>
                    <td><?= e($a['username'] ?? 'система') ?></td>
                    <td><span class="mono"><?= e($a['action']) ?></span></td>
                    <td><?= e($a['entity']) ?><?= $a['entity_id'] !== null ? ' #' . (int)$a['entity_id'] : '' ?></td>
                    <td class="mono muted"><?= e($a['ip']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>
