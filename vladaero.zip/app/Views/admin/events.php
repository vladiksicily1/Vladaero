<?php /** Календарь: модерация + создание (в.56–60) */ ?>
<div class="panel">
    <div class="panel-head">
        <h3>📅 <?= e(__('admin.events')) ?><?php if ($pending > 0): ?> <i class="tag-soon"><?= (int)$pending ?> pending</i><?php endif; ?></h3>
        <div>
            <a class="btn btn--sm <?= $status === 'all' ? 'btn-primary' : 'btn--ghost' ?>" href="<?= url('/admin/events') ?>">all</a>
            <a class="btn btn--sm <?= $status === 'pending' ? 'btn-primary' : 'btn--ghost' ?>" href="<?= url('/admin/events?status=pending') ?>">pending</a>
            <a class="btn btn--sm <?= $status === 'published' ? 'btn-primary' : 'btn--ghost' ?>" href="<?= url('/admin/events?status=published') ?>">published</a>
        </div>
    </div>
    <div class="table-wrap">
        <table class="table">
            <thead><tr><th>ID</th><th>Событие</th><th>Тип</th><th>Даты</th><th>Место</th><th>Автор</th><th>👥</th><th>Статус</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <td><?= (int)$r['id'] ?></td>
                    <td><a href="<?= url('/events/' . $r['slug']) ?>"><b><?= e($r['title_ru']) ?></b></a></td>
                    <td class="small"><?= e($r['type']) ?></td>
                    <td class="small"><?= e(substr((string)$r['starts_at'], 0, 16)) ?></td>
                    <td class="small"><?= e(trim(($r['city'] ?? '') . ' ' . ($r['country_code'] ?? ''))) ?></td>
                    <td class="small"><?= e($r['author'] ?: '—') ?></td>
                    <td><?= (int)$r['attendees'] ?></td>
                    <td><i class="tag-soon"><?= e($r['status']) ?></i></td>
                    <td class="actions">
                        <?php if ($r['status'] !== 'published'): ?>
                        <form method="post" action="<?= url('/admin/events/' . $r['id'] . '/status') ?>" class="inline"><?= csrf_field() ?><input type="hidden" name="to" value="published"><button class="btn btn--sm" type="submit">✓</button></form>
                        <?php endif; ?>
                        <form method="post" action="<?= url('/admin/events/' . $r['id'] . '/delete') ?>" class="inline"><?= csrf_field() ?><button class="btn btn--sm btn--ghost" type="submit" onclick="return confirm('Удалить?')">🗑</button></form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="panel" style="margin-top:16px;padding:18px">
    <h3 class="side-title">＋ Новое событие</h3>
    <form method="post" action="<?= url('/admin/events/create') ?>" class="stack-form">
        <?= csrf_field() ?>
        <label class="f">Название<input name="title" required maxlength="220"></label>
        <div class="form-row">
            <label class="f">Тип
                <select name="type"><?php foreach ($types as $t): ?><option value="<?= e($t) ?>"><?= e($t) ?></option><?php endforeach; ?></select>
            </label>
            <label class="f">Начало (UTC)<input type="datetime-local" name="starts" required></label>
            <label class="f">Конец<input type="datetime-local" name="ends"></label>
        </div>
        <div class="form-row">
            <label class="f">Страна<input name="country" maxlength="2" placeholder="RU"></label>
            <label class="f">Город<input name="city" maxlength="120"></label>
            <label class="f">Место<input name="venue" maxlength="190"></label>
        </div>
        <div class="form-row">
            <label class="f">Широта<input name="lat" inputmode="decimal"></label>
            <label class="f">Долгота<input name="lng" inputmode="decimal"></label>
            <label class="f">URL<input name="url" placeholder="https://…"></label>
        </div>
        <label class="f">Описание<textarea name="description" rows="3"></textarea></label>
        <button class="btn btn-primary" type="submit">Сохранить</button>
    </form>
</div>
