<?php /** Система: бэкапы, диагностика, сброс (в.126, 149) */ ?>

<div class="panel-row">
    <div class="panel">
        <div class="panel-head"><h3>Диагностика</h3></div>
        <div class="kv">
            <div class="kv-row"><span>Версия VladAero</span><b class="mono">v<?= e($info['version']) ?></b></div>
            <div class="kv-row"><span>PHP</span><b class="mono"><?= e($info['php']) ?> (<?= e($info['sapi']) ?>)</b></div>
            <div class="kv-row"><span>ОС</span><b class="mono"><?= e($info['os']) ?></b></div>
            <div class="kv-row"><span>MySQL / MariaDB</span><b class="mono"><?= e($info['mysql']) ?></b></div>
            <div class="kv-row"><span>Таблиц проекта (префикс «<?= e($info['prefix']) ?>»)</span><b class="mono"><?= (int)$info['tables'] ?></b></div>
            <div class="kv-row"><span>Размер БД</span><b class="mono"><?= e(number_format((float)$info['db_size_mb'], 2)) ?> МБ</b></div>
            <div class="kv-row"><span>Кэш / лог</span><b class="mono"><?= e(bytes((int)$info['cache_size'])) ?> / <?= e(bytes((int)$info['log_size'])) ?></b></div>
            <div class="kv-row"><span>Cron</span><b class="mono">* * * * * php <?= e(VA_ROOT) ?>/cron.php</b></div>
        </div>
    </div>

    <div class="panel">
        <div class="panel-head"><h3>Резервные копии (в.126)</h3></div>
        <p class="muted pad-b"><?= e(__('system.backup_hint')) ?></p>
        <a class="btn btn--primary" href="<?= url('/admin/system/backup') ?>">⤓ <?= e(__('system.backup')) ?></a>
        <div class="panel-note muted">
            Архив фото (uploads/) в ZIP — <span class="tag-soon">v0.2</span>.
            System Self-Healing Супер-Агента — <span class="tag-soon">v0.5</span> (в.277).
        </div>
    </div>
</div>

<div class="panel panel--danger">
    <div class="panel-head"><h3>⚠ <?= e(__('system.danger')) ?></h3></div>
    <div class="danger-grid">
        <div>
            <h4><?= e(__('system.drop_title')) ?></h4>
            <p class="muted"><?= e(__('system.drop_hint')) ?></p>
            <form method="post" action="<?= url('/admin/system/drop-tables') ?>" class="inline-form"
                  data-confirm="ВНИМАНИЕ: будут удалены ВСЕ таблицы VladAero. Продолжить?">
                <?= csrf_field() ?>
                <input type="text" name="confirm" placeholder="УДАЛИТЬ" required autocomplete="off">
                <button class="btn btn--danger" type="submit"><?= e(__('system.confirm')) ?></button>
            </form>
        </div>
        <div>
            <h4><?= e(__('system.update_zip')) ?></h4>
            <p class="muted">Загрузка новой версии ZIP и обновление с сохранением данных — <span class="tag-soon"><?= e(__('system.update_soon')) ?></span> (в.149).</p>
            <button class="btn btn--ghost" type="button" disabled>⤒ Обновить из ZIP</button>
        </div>
    </div>
</div>
