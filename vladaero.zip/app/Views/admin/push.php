<?php /** Админ: Web Push (v0.8.1) */ ?>
<section class="ac-layout">
    <div class="page-head"><h1>🔔 Web Push</h1></div>

    <div class="panel">
        <h3 class="form-h">Статус</h3>
        <p>
            VAPID: <?= $enabled ? '<i class="tag-soon" style="background:#1b7f4d">включён</i>' : '<i class="tag-soon">ключи не заданы</i>' ?>
            · Подписок: <b><?= (int)$subs ?></b>
            <?= $enabled ? '· Public: <code class="small">' . e(mb_substr($public, 0, 32)) . '…</code>' : '' ?>
        </p>
        <?php if (!$enabled): ?>
        <form method="post" action="<?= url('/admin/push/genkeys') ?>" class="inline">
            <?= csrf_field() ?>
            <label class="field"><span>mailto-контакт (VAPID subject)</span>
                <input type="text" name="subject" value="<?= e($subject !== '' ? $subject : 'mailto:admin@vladaero.local') ?>"></label>
            <button class="btn btn-primary" type="submit">⚙ Сгенерировать ключи</button>
        </form>
        <?php else: ?>
        <form method="post" action="<?= url('/admin/push/test') ?>" class="inline">
            <?= csrf_field() ?>
            <select name="scope" class="input"><option value="me">только мне</option><option value="all">всем подпискам</option></select>
            <button class="btn btn-primary" type="submit">📣 Отправить тестовый пуш</button>
        </form>
        <?php endif; ?>
        <p class="muted small">Пуши уходят без payload: service worker сам подтягивает текст последнего уведомления
            из <code>/api/push/pending</code>. Пользователи включают уведомления кнопкой в профиле.</p>
    </div>
</section>
