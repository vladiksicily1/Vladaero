<?php
/**
 * Супер-Агент (в.161–162, 271–272, 277): чат с 50 инструментами,
 * System Doctor, пакетная генерация, дашборд токенов (в.177).
 * @var array $state @var array $byDay @var array $lastChats @var array $totals
 */
$maxDay = max(1, max(array_map(static fn($r) => (int)$r['c'], $byDay ?: [['c' => 1]])));
?>
<div class="admin-page">
    <div class="page-head">
        <div>
            <h1>✱ <?= e(__('agent.title')) ?></h1>
            <p class="muted"><?= e(__('agent.sub')) ?> · <?= e($state['model'] ?: '—') ?> · <?= count($state['catalog']) ?> tools</p>
        </div>
    </div>

    <?php if (!$state['enabled']): ?>
    <div class="callout is-warning mb"><?= e(__('ai.not_configured')) ?></div>
    <?php endif; ?>

    <div class="agent-grid">
        <div class="panel agent-chat">
            <div class="agent-msgs" id="agMsgs">
                <div class="aiw-msg is-ai"><div class="aiw-bubble"><?= e(__('agent.hello')) ?></div></div>
            </div>
            <div class="aiw-input">
                <textarea id="agText" rows="2" placeholder="<?= e(__('agent.placeholder')) ?>"></textarea>
                <button class="btn btn-primary" id="agSend">➤</button>
            </div>
        </div>

        <div class="agent-side">
            <div class="panel">
                <div class="panel-head"><h3>📊 <?= e(__('agent.usage')) ?></h3></div>
                <div class="agent-totals">
                    <div><b><?= (int)$totals['requests'] ?></b><span><?= e(__('agent.t_requests')) ?></span></div>
                    <div><b><?= number_format((float)$totals['tokens'], 0, ',', ' ') ?></b><span><?= e(__('agent.t_tokens')) ?></span></div>
                    <div><b><?= (int)$totals['tools'] ?></b><span><?= e(__('agent.t_tools')) ?></span></div>
                </div>
                <div class="agent-chart">
                    <?php foreach ($byDay as $d): ?>
                    <div class="agent-bar" title="<?= e($d['d']) ?>: <?= (int)$d['c'] ?>" style="height: <?= max(4, (int)round((int)$d['c'] / $maxDay * 64)) ?>px"></div>
                    <?php endforeach; ?>
                    <?php if ($byDay === []): ?><span class="muted small"><?= e(__('agent.no_usage')) ?></span><?php endif; ?>
                </div>
                <div class="panel-head" style="margin-top:14px"><h3>🕘 <?= e(__('agent.last')) ?></h3></div>
                <table class="vs-table">
                    <?php foreach ($lastChats as $c): ?>
                    <tr><td class="muted mono"><?= e(substr((string)$c['created_at'], 5, 11)) ?></td>
                        <td><?= e($c['username'] ?? 'гость') ?> · <?= e($c['model']) ?></td>
                        <td class="muted"><?= (int)$c['tool_calls'] ?>⚙</td></tr>
                    <?php endforeach; ?>
                </table>
            </div>

            <div class="panel">
                <div class="panel-head"><h3>🩺 <?= e(__('agent.doctor')) ?></h3></div>
                <button class="btn" id="agDoctor" type="button">▶ System Doctor</button>
                <pre class="agent-pre" id="agDoctorOut" hidden></pre>
            </div>

            <div class="panel">
                <div class="panel-head"><h3>📦 <?= e(__('agent.batch')) ?></h3></div>
                <textarea id="agBatchItems" rows="3" placeholder="<?= e(__('agent.batch_ph')) ?>"></textarea>
                <div class="tool-row">
                    <select id="agBatchKind">
                        <option value="aircraft"><?= e(__('agent.b_aircraft')) ?></option>
                        <option value="article"><?= e(__('agent.b_article')) ?></option>
                    </select>
                    <button class="btn btn-primary" id="agBatch" type="button"><?= e(__('agent.b_go')) ?></button>
                </div>
                <div id="agBatchOut"></div>
            </div>
        </div>
    </div>

    <div class="panel" style="margin-top:16px">
        <div class="panel-head"><h3>🧰 <?= e(__('agent.catalog')) ?> (<?= count($state['catalog']) ?>)</h3></div>
        <div class="agent-tools">
            <?php foreach ($state['catalog'] as $id => $t): ?>
            <div class="agent-tool" data-tool="<?= e($id) ?>">
                <b><?= e($t['title']) ?></b>
                <span class="muted"><?= e($t['desc']) ?></span>
                <code class="mono"><?= e($id) ?></code>
                <i class="tag-soon"><?= e($t['kind'] === 'local' ? 'live' : ($t['kind'] === 'admin' ? 'admin' : 'llm')) ?></i>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<script>
(function () {
    var csrf = (document.querySelector('meta[name="va-csrf"]') || {}).content || '';
    var base = (document.querySelector('meta[name="va-base"]') || {}).content || '';
    base = base.replace(/\/$/, '');

    function el(tag, cls, html) { var d = document.createElement(tag); if (cls) d.className = cls; if (html !== undefined) d.innerHTML = html; return d; }
    function esc(s) { return String(s == null ? '' : s).replace(/</g, '&lt;').replace(/\n/g, '<br>'); }

    var msgs = document.getElementById('agMsgs');
    function addMsg(role) {
        var wrap = el('div', 'aiw-msg ' + (role === 'user' ? 'is-user' : 'is-ai'));
        var b = el('div', 'aiw-bubble', role === 'user' ? '' : '…');
        wrap.appendChild(b); msgs.appendChild(wrap); msgs.scrollTop = msgs.scrollHeight;
        return b;
    }

    function sseChat(text) {
        var bubble = addMsg('ai');
        bubble.innerHTML = '';
        var out = '';
        var rbox = null;
        fetch(base + '/admin/agent/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf, 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'text/event-stream' },
            body: JSON.stringify({ messages: [{ role: 'user', content: text }] })
        }).then(function (r) { return r.body.getReader(); }).then(function (rd) {
            var dec = new TextDecoder(), buf = '';
            function frame(chunk) {
                buf += chunk;
                var parts = buf.split('\n\n'); buf = parts.pop() || '';
                parts.forEach(function (p) {
                    var ev = '', da = '';
                    p.split('\n').forEach(function (l) {
                        if (l.indexOf('event:') === 0) ev = l.slice(6).trim();
                        if (l.indexOf('data:') === 0) da += l.slice(5).trim();
                    });
                    handle(ev, da);
                });
            }
            function handle(ev, da) {
                var d; try { d = JSON.parse(da); } catch (e) { d = {}; }
                if (ev === 'delta') { out += d; bubble.innerHTML = esc(out); }
                else if (ev === 'reasoning') {
                    if (!rbox) { rbox = el('details', 'aiw-reasoning'); rbox.innerHTML = '<summary>💭 reasoning</summary><div></div>'; bubble.parentNode.insertBefore(rbox, bubble); }
                    rbox.querySelector('div').innerHTML += esc(d);
                } else if (ev === 'tool_call') { bubble.appendChild(el('div', 'aiw-tool', '⚙ ' + (d.tool || '') + '…')); }
                else if (ev === 'tool_result') { bubble.appendChild(el('div', 'aiw-tool is-ok', '⚙ ' + (d.tool || '') + ' ✓')); }
                else if (ev === 'error') { bubble.appendChild(el('div', 'callout is-bad', '✕ ' + esc(d.message))); }
                msgs.scrollTop = msgs.scrollHeight;
            }
            function pump() { rd.read().then(function (x) { if (x.done) return; frame(dec.decode(x.value)); pump(); }); }
            pump();
        }).catch(function () { bubble.innerHTML = '✕ сети'; });
    }

    var txt = document.getElementById('agText');
    var agSendBtn = document.getElementById('agSend');
    function send() { var v = txt.value.trim(); if (!v) return; addMsg('user').innerHTML = esc(v); txt.value = ''; sseChat(v); }
    if (agSendBtn) agSendBtn.addEventListener('click', send);
    if (txt) txt.addEventListener('keydown', function (e) { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } });

    // System Doctor
    document.getElementById('agDoctor').addEventListener('click', function () {
        var out = document.getElementById('agDoctorOut');
        out.hidden = false; out.textContent = '…';
        fetch(base + '/admin/agent/tool', {
            method: 'POST', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf },
            body: JSON.stringify({ tool: 'system_doctor', args: {} })
        }).then(function (r) { return r.json(); }).then(function (r) { out.textContent = JSON.stringify(r.data, null, 2); })
          .catch(function () { out.textContent = '✕'; });
    });

    // Пакетная генерация (в.272)
    document.getElementById('agBatch').addEventListener('click', function () {
        var items = document.getElementById('agBatchItems').value.split('\n').map(function (s) { return s.trim(); }).filter(Boolean).slice(0, 8);
        var kind = document.getElementById('agBatchKind').value;
        var out = document.getElementById('agBatchOut');
        if (!items.length) return;
        out.innerHTML = '<div class="muted">⏳ ' + items.length + '…</div>';
        fetch(base + '/admin/agent/batch', {
            method: 'POST', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf },
            body: JSON.stringify({ items: items, kind: kind })
        }).then(function (r) { return r.json(); }).then(function (r) {
            out.innerHTML = '';
            (r.drafts || []).forEach(function (d) {
                var row = el('div', 'agent-draft');
                row.innerHTML = '<b>' + esc(d.item) + '</b> ' + (d.ok ? '<span class="vs-flag">✓ JSON</span>' : '<span class="is-bad">✕</span>');
                if (d.ok) {
                    var btn = el('button', 'btn btn--sm', '<?= e(__('agent.apply')) ?>');
                    btn.addEventListener('click', function () {
                        fetch(base + '/admin/agent/apply', {
                            method: 'POST', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf },
                            body: JSON.stringify({ kind: kind, data: d.data })
                        }).then(function (x) { return x.json(); }).then(function (x) {
                            btn.textContent = x.ok ? '✓ #' + x.id : '✕';
                            if (x.ok) btn.outerHTML = '<a class="btn btn--sm" href="' + x.url + '">→</a>';
                        });
                    });
                    row.appendChild(btn);
                }
                out.appendChild(row);
            });
        }).catch(function () { out.innerHTML = '✕'; });
    });

    // Клик по инструменту — подставить шаблон в чат
    document.querySelectorAll('.agent-tool').forEach(function (t) {
        t.addEventListener('click', function () {
            txt.value = 'Вызови инструмент ' + t.dataset.tool + ' и объясни результат.';
            txt.focus();
        });
    });
})();
</script>
