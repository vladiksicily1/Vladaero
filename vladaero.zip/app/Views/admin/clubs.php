<?php /** Клубы: модерация (в.27, 162) */ ?>
<div class="panel">
    <div class="panel-head">
        <h3>☰ <?= e(__('admin.clubs')) ?><?php if ($pending > 0): ?> <i class="tag-soon"><?= (int)$pending ?> pending</i><?php endif; ?></h3>
        <div>
            <a class="btn btn--sm <?= $status === 'all' ? 'btn-primary' : 'btn--ghost' ?>" href="<?= url('/admin/clubs') ?>">all</a>
            <a class="btn btn--sm <?= $status === 'pending' ? 'btn-primary' : 'btn--ghost' ?>" href="<?= url('/admin/clubs?status=pending') ?>">pending</a>
            <a class="btn btn--sm <?= $status === 'approved' ? 'btn-primary' : 'btn--ghost' ?>" href="<?= url('/admin/clubs?status=approved') ?>">approved</a>
        </div>
    </div>
    <div class="table-wrap">
        <table class="table">
            <thead><tr><th>ID</th><th>Клуб</th><th>Тема</th><th>Владелец</th><th>👥</th><th>Статус</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <td><?= (int)$r['id'] ?></td>
                    <td><b><?= e($r['title']) ?></b><div class="muted small"><?= e(mb_substr((string)$r['description'], 0, 120)) ?></div></td>
                    <td class="small"><?= e($r['kind']) ?></td>
                    <td class="small"><?= e($r['owner']) ?></td>
                    <td><?= (int)$r['members'] ?></td>
                    <td><i class="tag-soon"><?= e($r['status']) ?></i></td>
                    <td class="actions">
                        <?php if ($r['status'] !== 'approved'): ?>
                        <form method="post" action="<?= url('/admin/clubs/' . $r['id'] . '/status') ?>" class="inline"><?= csrf_field() ?><input type="hidden" name="to" value="approved"><button class="btn btn--sm" type="submit">✓</button></form>
                        <?php endif; ?>
                        <form method="post" action="<?= url('/admin/clubs/' . $r['id'] . '/delete') ?>" class="inline"><?= csrf_field() ?><button class="btn btn--sm btn--ghost" type="submit" onclick="return confirm('Удалить?')">🗑</button></form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
