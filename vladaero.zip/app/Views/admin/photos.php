<?php
/**
 * Экран скринера (в.107): очередь фото, горячие клавиши A/R, 100% зум, причины отказа.
 * @var string $tab @var array $items @var array $counts @var array $reasons
 */
$thumb = static function (string $fn): string {
    $t = preg_replace('~\.\w+$~', '_t.webp', $fn);
    return is_file(VA_ROOT . '/' . $t) ? $t : $fn;
};
?>
<div class="admin-page">
    <div class="page-head">
        <div>
            <h1>▤ <?= e(__('ph.screen.title')) ?></h1>
            <p class="muted"><?= e(__('ph.screen.sub')) ?></p>
        </div>
        <label class="radar-chk" style="color:var(--tx)">
            <input type="checkbox" id="scrZoom100"> <?= e(__('ph.screen.zoom100')) ?>
        </label>
    </div>

    <nav class="scr-tabs">
        <a href="<?= e(url('/admin/photos?tab=pending')) ?>" class="<?= $tab === 'pending' ? 'is-cur' : '' ?>">
            <?= e(__('ph.screen.queue')) ?> <b><?= (int)$counts['pending'] ?></b></a>
        <a href="<?= e(url('/admin/photos?tab=approved')) ?>" class="<?= $tab === 'approved' ? 'is-cur' : '' ?>">
            ✓ <?= e(__('ph.screen.approved')) ?> <b><?= (int)$counts['approved'] ?></b></a>
        <a href="<?= e(url('/admin/photos?tab=rejected')) ?>" class="<?= $tab === 'rejected' ? 'is-cur' : '' ?>">
            ✕ <?= e(__('ph.screen.rejected')) ?> <b><?= (int)$counts['rejected'] ?></b></a>
        <span class="scr-keys muted"><?= e(__('ph.screen.hotkeys')) ?></span>
    </nav>

    <?php if ($items === []): ?>
    <div class="empty"><div class="empty-ico">✓</div><h2><?= e(__('ph.screen.empty')) ?></h2></div>
    <?php else: ?>
    <div class="scr-list" id="scrList">
        <?php foreach ($items as $p): ?>
        <article class="scr-card" data-id="<?= (int)$p['id'] ?>">
            <div class="scr-img" data-src="<?= e(url($p['filename'])) ?>">
                <img src="<?= e(url($thumb($p['filename']))) ?>" alt="">
            </div>
            <div class="scr-meta">
                <b><?= e($p['title'] ?: ($p['registration'] ?: '—')) ?></b>
                <span class="muted">
                    <?= e(__('gal.author')) ?>: <?= e($p['author'] ?? '—') ?>
                    · <?= e($p['registration'] ?: '—') ?>
                    <?= $p['ap_icao'] ? ' · ' . e($p['ap_icao']) : '' ?>
                    · <?= e(substr((string)$p['created_at'], 0, 16)) ?>
                </span>
                <select class="scr-reason" data-reason>
                    <?php foreach ($reasons as $r): ?>
                    <option value="<?= e($r) ?>"><?= e($r) ?></option>
                    <?php endforeach; ?>
                </select>
                <div class="scr-actions">
                    <button class="btn btn-primary" data-verdict="approved">A — <?= e(__('ph.screen.approve')) ?></button>
                    <button class="btn btn-danger" data-verdict="rejected">R — <?= e(__('ph.screen.reject')) ?></button>
                </div>
            </div>
        </article>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>

<script>
(function () {
    var csrf = (document.querySelector('meta[name="va-csrf"]') || {}).content || '';
    var zoom = document.getElementById('scrZoom100');
    zoom && zoom.addEventListener('change', function () {
        document.body.classList.toggle('scr-zoom', zoom.checked);
    });

    function verdict(card, status) {
        var reason = (card.querySelector('[data-reason]') || {}).value || '';
        var fd = new FormData();
        fd.append('_token', csrf);
        fd.append('status', status);
        fd.append('reason', reason);
        fetch('<?= e(url('/admin/photos')) ?>/' + card.dataset.id + '/verdict', {
            method: 'POST', body: fd,
            headers: { 'X-CSRF-Token': csrf, 'X-Requested-With': 'XMLHttpRequest' }
        }).then(function (r) { return r.json(); }).then(function (r) {
            if (r.ok) { card.classList.add('is-done'); setTimeout(function () { card.remove(); }, 350); }
        }).catch(function () {});
    }

    document.querySelectorAll('.scr-card [data-verdict]').forEach(function (b) {
        b.addEventListener('click', function () { verdict(b.closest('.scr-card'), b.dataset.verdict); });
    });

    // Горячие клавиши: A/R — первый кадр очереди (в.107)
    document.addEventListener('keydown', function (e) {
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT' || e.target.tagName === 'TEXTAREA') return;
        var card = document.querySelector('.scr-card:not(.is-done)');
        if (!card) return;
        if (e.key === 'a' || e.key === 'A' || e.key === 'ф' || e.key === 'Ф') { verdict(card, 'approved'); }
        if (e.key === 'r' || e.key === 'R' || e.key === 'к' || e.key === 'К') { verdict(card, 'rejected'); }
    });

    // 100% зум: открываем оригинал в природном размере
    document.querySelectorAll('.scr-img').forEach(function (d) {
        d.addEventListener('click', function () {
            var w = window.open(d.dataset.src, '_blank');
            void w;
        });
    });
})();
</script>
