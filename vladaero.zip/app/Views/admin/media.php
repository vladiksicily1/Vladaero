<?php /** Медиатека: браузер + загрузка (в.12–15, 79, 84) */ ?>
<div class="panel">
    <div class="panel-head">
        <h3><?= e(__('media.title')) ?> — <?= (int)$total ?></h3>
        <form method="get" action="<?= url('/admin/media') ?>" class="inline">
            <select name="kind" onchange="this.form.submit()">
                <option value=""><?= e(__('common.any')) ?></option>
                <?php foreach (\App\Models\Media::KINDS as $k): ?>
                    <option value="<?= e($k) ?>" <?= $kind === $k ? 'selected' : '' ?>><?= e(__('media.kind.' . $k)) ?></option>
                <?php endforeach; ?>
            </select>
            <input type="search" name="q" value="<?= e($q) ?>" placeholder="<?= e(__('common.search')) ?>…" class="search-mini-input">
            <button class="btn btn--ghost btn--sm" type="submit">⌕</button>
        </form>
    </div>

    <div class="media-uploader" id="mediaUploader">
        <div class="drop" id="mediaDrop">
            <b>⤒ Перетащите файлы сюда</b> или кликните для выбора<br>
            <span class="muted small">Изображения (JPG/PNG/WebP/GIF), видео, аудио, PDF/ZIP, .glb — до 25 МБ. Превью 480px и водяной знак ставятся автоматически (в.84, в.13).</span>
            <input type="file" id="mediaFile" multiple accept="image/*,video/*,audio/*,.pdf,.zip,.glb,.gltf" class="hidden">
        </div>
        <div class="status" id="mediaUpStatus"></div>
        <p class="muted small"><?= e(__('media.zip_hint')) ?> <?= e(__('media.b64_hint')) ?></p>
    </div>
    <script>
    (function () {
        var drop = document.getElementById('mediaDrop');
        var inp = document.getElementById('mediaFile');
        var status = document.getElementById('mediaUpStatus');
        var fileN = 0, skipN = 0;
        var csrf = (document.querySelector('meta[name="va-csrf"]') || {}).content || '';
        var base = (document.querySelector('meta[name="va-base"]') || {}).content || '';
        base = base.replace(/\/$/, '');
        if (!drop) return;
        drop.addEventListener('click', function () { inp.click(); });
        ['dragenter', 'dragover'].forEach(function (ev) { drop.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.add('hover'); }); });
        ['dragleave', 'drop'].forEach(function (ev) { drop.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.remove('hover'); }); });
        drop.addEventListener('drop', function (e) { if (e.dataTransfer.files.length) upload(e.dataTransfer.files); });
        inp.addEventListener('change', function () { upload(inp.files); });
        function upload(files) {
            var queue = Array.prototype.slice.call(files);
            var done = 0, okN = 0;
            status.className = 'status wait';
            next();
            function next() {
                if (queue.length === 0) {
                    status.className = okN ? 'status good' : 'status err';
                    status.textContent = fileN + ' файл(ов) загружено' + (done - okN ? ', ошибок: ' + (done - okN) : '') + (skipN ? ', пропущено: ' + skipN : '') + ' — обновляю…';
                    if (okN) setTimeout(function () { location.reload(); }, 900);
                    return;
                }
                var f = queue.shift();
                status.textContent = '⤒ ' + f.name + '…';
                var fd = new FormData();
                fd.append('file', f);
                fd.append('_token', csrf);
                fetch(base + '/admin/media/upload', { method: 'POST', body: fd, headers: { 'X-CSRF-Token': csrf, 'X-Requested-With': 'XMLHttpRequest' } })
                    .then(function (r) { return r.json(); })
                    .then(function (r) { done++; if (r.ok) { okN++; fileN += (r.count || 1); skipN += (r.skipped || []).length; } else status.textContent = '✕ ' + f.name + ': ' + (r.error || 'ошибка'); next(); })
                    .catch(function (e) { done++; status.className = 'status err'; status.textContent = '✕ ' + f.name + ': ' + (e.message || 'сеть/сервер'); next(); });
            }
        }
    })();
    </script>

    <?php if ($rows === []): ?>
        <p class="muted pad"><?= e(__('media.empty')) ?></p>
    <?php else: ?>
    <div class="media-grid" id="mediaGrid">
        <?php foreach ($rows as $m): ?>
            <div class="media-card" data-id="<?= (int)$m['id'] ?>">
                <div class="media-thumb">
                    <?php if ($m['kind'] === 'image'): ?>
                        <img src="<?= e(url($m['thumb_path'] ?: $m['path'])) ?>" alt="<?= e($m['alt']) ?>" loading="lazy">
                    <?php else: ?>
                        <span class="media-kind-ico"><?= e(['video' => '▶', 'audio' => '♪', 'model3d' => '⟠', 'panorama' => '◐', 'file' => '⤓', 'image' => '🖼'][$m['kind']] ?? '⤓') ?></span>
                    <?php endif; ?>
                    <span class="media-kind"><?= e(__('media.kind.' . $m['kind'])) ?></span>
                </div>
                <div class="media-meta">
                    <b class="small" title="<?= e($m['original_name']) ?>"><?= e(mb_substr((string)$m['original_name'], 0, 26)) ?></b>
                    <span class="muted small"><?= e(bytes((int)$m['size'])) ?><?= $m['width'] ? ' · ' . (int)$m['width'] . '×' . (int)$m['height'] : '' ?></span>
                    <input type="text" class="media-path mono" value="<?= e($m['path']) ?>" readonly title="Клик — копировать путь">
                </div>
                <div class="media-actions">
                    <button class="btn btn--ghost btn--sm" type="button" data-copy="<?= e($m['path']) ?>">⧉ путь</button>
                    <form method="post" action="<?= url('/admin/media/' . (int)$m['id'] . '/delete') ?>" class="inline" data-confirm="Удалить файл из медиатеки?">
                        <?= csrf_field() ?><button class="btn btn--danger btn--sm" type="submit">✕</button>
                    </form>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>
