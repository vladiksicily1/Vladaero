<?php /** Админ-панель Telegram-бота (в.269) */ ?>
<div class="widget-grid">
    <div class="widget"><span class="w-label">Привязано профилей</span><b class="w-value"><?= (int)$linked ?></b></div>
    <div class="widget"><span class="w-label">Активных сегодня</span><b class="w-value"><?= (int)$active_today ?></b></div>
    <div class="widget"><span class="w-label">Сообщений сегодня</span><b class="w-value"><?= (int)$msg_today ?></b></div>
    <div class="widget"><span class="w-label">Сообщений / 7 дн</span><b class="w-value"><?= (int)$msg_week ?></b></div>
</div>

<div class="panel-row">
    <div class="panel panel--wide">
        <div class="panel-head">
            <h3>Статус Webhook</h3>
        </div>
        <?php if (empty($webhook)): ?>
            <p class="muted pad">Не удалось получить статус (проверьте токен в настройках).</p>
        <?php else: ?>
        <div class="prof-stats" style="padding:14px 18px">
            <span>URL: <code><?= e((string)($webhook['url'] ?? '—')) ?></code></span>
            <span>SSL: <?= (!empty($webhook['has_custom_certificate']) ? '<b class="t-ok">собственный</b>' : '<b class="t-ok">Telegram</b>') ?></span>
            <span>Ошибок: <b class="<?= ($webhook['last_error_date'] ?? '') !== '' ? 't-warn' : '' ?>"><?= (int)($webhook['pending_update_count'] ?? 0) ?></b></span>
            <?php if (isset($webhook['last_error_date'])): ?>
            <span class="muted">Последняя ошибка: <?= e($webhook['last_error_date']) ?> — <?= e(mb_substr((string)($webhook['last_error_message'] ?? ''), 0, 120)) ?></span>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        <div style="padding:10px 18px;display:flex;gap:10px;align-items:center">
            <a class="btn btn--ghost btn--sm" href="<?= url('/admin/settings/integrations') ?>">⚙ Настройки Telegram</a>
            <form method="post" action="<?= url('/admin/telegram/setwebhook') ?>" class="inline" data-confirm="Установить/переустановить Webhook?">
                <?= csrf_field() ?>
                <button class="btn btn--ghost btn--sm" type="submit">↻ Установить Webhook</button>
            </form>
        </div>
    </div>

    <div class="panel">
        <div class="panel-head"><h3>Топ команд / 7 дн</h3></div>
        <?php if ($top_cmds === []): ?>
            <p class="muted pad">Пока нет данных — команды появятся после первых входящих сообщений.</p>
        <?php else: ?>
        <table class="table" style="width:100%">
            <thead><tr><th>Команда</th><th>Запросов</th></tr></thead>
            <tbody>
            <?php foreach ($top_cmds as $c): ?>
            <tr><td><code>/<?= e((string)$c['command']) ?></code></td><td><?= (int)$c['c'] ?></td></tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
</div>

<div class="panel">
    <div class="panel-head"><h3>Последняя активность (30)</h3></div>
    <?php if ($recent === []): ?>
        <p class="muted pad">Нет записей — ждём первый входящий апдейт от Telegram.</p>
    <?php else: ?>
    <div class="table-wrap">
    <table class="table" style="width:100%">
        <thead><tr><th>Время</th><th>Чат</th><th>Направление</th><th>Тип</th><th>Команда</th><th>Дл.</th></tr></thead>
        <tbody>
        <?php foreach ($recent as $r): ?>
        <tr>
            <td class="muted"><?= e(date('H:i', strtotime((string)$r['created_at']))) ?></td>
            <td><code><?= (int)$r['chat_id'] ?></code></td>
            <td><?= $r['direction'] === 'in' ? '← вход' : '→ исх.' ?></td>
            <td><?= e((string)($r['kind'] ?? '—')) ?></td>
            <td><?= $r['command'] !== '' ? '<code>/' . e((string)$r['command']) . '</code>' : '—' ?></td>
            <td><?= (int)$r['length'] ?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
    <?php endif; ?>
</div>

<div class="panel">
    <div class="panel-head"><h3>📢 Сервисное объявление (broadcast)</h3></div>
    <p class="muted" style="padding:0 18px 8px">Отправить текстовое сообщение всем привязанным пользователям.</p>
    <form method="post" action="<?= url('/admin/telegram/broadcast') ?>" style="padding:0 18px 18px" data-confirm="Отправить объявление всем привязанным?">
        <?= csrf_field() ?>
        <textarea name="text" rows="3" class="input" style="width:100%;resize:vertical" placeholder="Текст объявления…" required maxlength="3500"></textarea>
        <div style="margin-top:10px;display:flex;gap:10px;align-items:center">
            <button class="btn" type="submit">📢 Отправить <?= (int)$linked ?> пользователям</button>
        </div>
    </form>
</div>