<?php /** Журнал ошибок logs/app.log (в.127) */ ?>
<div class="panel">
    <div class="panel-head">
        <h3>logs/app.log · <?= e(bytes((int)$size)) ?></h3>
        <div class="inline">
            <a class="btn btn--ghost btn--sm" href="<?= url('/admin/logs/download') ?>">⤓ Скачать</a>
            <form method="post" action="<?= url('/admin/logs/clear') ?>" class="inline" data-confirm="Очистить журнал ошибок?">
                <?= csrf_field() ?>
                <button class="btn btn--danger btn--sm" type="submit">Очистить</button>
            </form>
        </div>
    </div>
    <?php if ($lines === []): ?>
        <p class="muted pad">Журнал пуст — сбоев не зафиксировано. Отличная погода! ☀</p>
    <?php else: ?>
        <div class="log-view mono"><?php foreach ($lines as $ln): ?><div class="log-line"><?= e($ln) ?></div><?php endforeach; ?></div>
    <?php endif; ?>
</div>
