<?php /** Админ: список авиатехники (в.6–9) */ ?>
<div class="panel">
    <div class="panel-head">
        <h3><?= e(__('admin.aircraft')) ?> — <?= (int)$total ?></h3>
        <div class="inline">
            <form method="get" action="<?= url('/admin/aircraft') ?>" class="inline search-mini">
                <input type="search" name="q" value="<?= e($q) ?>" placeholder="<?= e(__('ac.search_ph')) ?>…">
                <button class="btn btn--ghost btn--sm" type="submit">⌕</button>
            </form>
            <a class="btn btn--primary btn--sm" href="<?= url('/admin/aircraft/new') ?>">+ <?= e(__('ac.add')) ?></a>
        </div>
    </div>
    <?php if ($rows === []): ?>
        <p class="muted pad"><?= e(__('ac.empty_admin')) ?></p>
    <?php else: ?>
    <div class="table-wrap">
        <table class="table">
            <thead><tr><th>ID</th><th>Название</th><th>ICAO/IATA</th><th>Категория</th><th>Статус</th><th>Первый полёт</th><th>👁</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($rows as $a): ?>
                <tr>
                    <td class="mono muted">#<?= (int)$a['id'] ?></td>
                    <td>
                        <a href="<?= url('/aircraft/' . $a['slug']) ?>" target="_blank" rel="noopener"><b><?= e($a['name_ru']) ?></b></a>
                        <div class="muted small"><?= e($a['slug']) ?><?= $a['name_en'] ? ' · ' . e($a['name_en']) : '' ?></div>
                    </td>
                    <td class="mono"><?= e($a['icao_code'] ?: '—') ?> / <?= e($a['iata_code'] ?: '—') ?></td>
                    <td><?= e(__('ac.category.' . $a['category'])) ?></td>
                    <td><span class="ac-badge ac-badge--<?= e($a['status']) ?>"><?= e(__('ac.status.' . $a['status'])) ?></span></td>
                    <td class="mono muted"><?= e($a['first_flight'] ?: '—') ?></td>
                    <td class="mono"><?= (int)$a['views'] ?></td>
                    <td>
                        <div class="inline">
                            <a class="btn btn--ghost btn--sm" href="<?= url('/admin/aircraft/' . (int)$a['id'] . '/edit') ?>">✎</a>
                            <form method="post" action="<?= url('/admin/aircraft/' . (int)$a['id'] . '/delete') ?>" class="inline"
                                  data-confirm="Удалить карточку «<?= e($a['name_ru']) ?>»?"><?= csrf_field() ?>
                                <button class="btn btn--danger btn--sm" type="submit">✕</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
    <?php if ($pages > 1): ?>
        <div class="pager">
            <?php for ($p = 1; $p <= $pages; $p++): ?>
                <a class="pg <?= $p === $page ? 'is-active' : '' ?>" href="<?= url('/admin/aircraft') ?>?q=<?= urlencode($q) ?>&amp;page=<?= $p ?>"><?= $p ?></a>
            <?php endfor; ?>
        </div>
    <?php endif; ?>
</div>
