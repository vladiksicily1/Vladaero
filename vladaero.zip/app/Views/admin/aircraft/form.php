<?php /** Админ: форма карточки борта (в.6–7: ТТХ, двухуровневость) */
$v = static fn(string $k, string $d = '') => e($ac[$k] ?? $d);
$specVal = static fn(string $k) => e((string)($specs[$k] ?? ''));
?>
<form method="post" enctype="multipart/form-data"
      action="<?= url('/admin/aircraft/' . ($ac !== null ? (int)$ac['id'] . '/update' : 'create')) ?>"
      class="panel form">
    <?= csrf_field() ?>
    <div class="panel-head">
        <h3><?= $ac !== null ? e(__('ac.edit')) . ': ' . e($ac['name_ru']) : e(__('ac.add')) ?></h3>
        <?php if ($ac !== null): ?>
            <a class="btn btn--ghost btn--sm" href="<?= url('/aircraft/' . $ac['slug']) ?>" target="_blank" rel="noopener">↗ <?= e(__('common.view')) ?></a>
        <?php endif; ?>
    </div>

    <div class="form-grid">
        <label class="field"><span>Название (рус.) *</span>
            <input type="text" name="name_ru" value="<?= $v('name_ru') ?>" required maxlength="190"></label>
        <label class="field"><span>Название (англ.)</span>
            <input type="text" name="name_en" value="<?= $v('name_en') ?>" maxlength="190"></label>
        <label class="field"><span>Slug (ЧПУ, в.101)</span>
            <input type="text" name="slug" value="<?= $v('slug') ?>" placeholder="авто из названия" maxlength="150"></label>
        <label class="field"><span>Код ICAO типа</span>
            <input type="text" name="icao_code" value="<?= $v('icao_code') ?>" placeholder="B738" maxlength="8" pattern="[A-Za-z0-9]{2,8}"></label>
        <label class="field"><span>Код IATA типа</span>
            <input type="text" name="iata_code" value="<?= $v('iata_code') ?>" placeholder="737" maxlength="4" pattern="[A-Za-z0-9]{2,4}"></label>
        <label class="field"><span>Категория</span>
            <select name="category">
                <?php foreach (\App\Models\Aircraft::CATEGORIES as $c): ?>
                    <option value="<?= e($c) ?>" <?= ($ac['category'] ?? 'civil') === $c ? 'selected' : '' ?>><?= e(__('ac.category.' . $c)) ?></option>
                <?php endforeach; ?>
            </select></label>
        <label class="field"><span>Производитель</span>
            <input type="text" name="manufacturer" value="<?= $v('manufacturer') ?>" placeholder="Boeing / ОАК / Sukhoi" maxlength="120"></label>
        <label class="field"><span>Страна</span>
            <input type="text" name="country" value="<?= $v('country') ?>" placeholder="США / Россия" maxlength="120"></label>
        <label class="field"><span>Первый полёт</span>
            <input type="date" name="first_flight" value="<?= $v('first_flight') ?>"></label>
        <label class="field"><span>Статус борта (в.227)</span>
            <select name="status">
                <?php foreach (\App\Models\Aircraft::STATUSES as $s): ?>
                    <option value="<?= e($s) ?>" <?= ($ac['status'] ?? 'active') === $s ? 'selected' : '' ?>><?= e(__('ac.status.' . $s)) ?></option>
                <?php endforeach; ?>
            </select></label>
    </div>

    <label class="field"><span>Краткое описание (для поиска и SEO, в.6)</span>
        <textarea name="description_ru" rows="3"><?= $v('description_ru') ?></textarea></label>

    <h4 class="form-h"><?= e(__('ac.specs.detailed')) ?> <span class="muted">(JSON specs — двухуровневый вид, в.7)</span></h4>
    <?php foreach ($groups as [$groupLabel, $fields]): ?>
        <div class="spec-edit-group">
            <div class="spec-edit-title"><?= e(__($groupLabel)) ?></div>
            <div class="form-grid">
                <?php foreach ($fields as $f => $u): ?>
                    <label class="field"><span><?= e(__('spec.' . $f)) ?><?= $u !== '' ? ', ' . e(__($u)) : '' ?></span>
                        <input type="text" inputmode="decimal" name="<?= e($f) ?>" value="<?= $specVal($f) ?>"
                               <?= $f === 'engines' ? 'placeholder="2 × ТРДД CFM LEAP-1A"' : '' ?>>
                    </label>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endforeach; ?>

    <div class="panel">
        <div class="panel-head"><h3>▦ Материалы о борте (блоки — в.108, 111)</h3></div>
        <?php require VA_APP . '/Views/partials/blocks-editor.php'; ?>
    </div>

    <div class="actions-row">
        <button class="btn btn--primary" type="submit"> <?= e(__('common.save')) ?></button>
        <a class="btn btn--ghost" href="<?= url('/admin/aircraft') ?>"><?= e(__('common.cancel')) ?></a>
    </div>
</form>
