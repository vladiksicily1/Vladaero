<?php /** Лётная школа: CRUD уроков (в.24) */
$editing = $editing ?? false;
$lesson = $lesson ?? null;
?>
<div class="panel">
    <div class="panel-head">
        <h3>🎓 <?= e(__('admin.lessons')) ?></h3>
        <a class="btn btn--sm btn-primary" href="<?= url('/admin/lessons/new') ?>">＋ урок</a>
    </div>
    <div class="table-wrap">
        <table class="table">
            <thead><tr><th>ID</th><th>Урок</th><th>Уровень</th><th>sort</th><th>Сдало</th><th>Публ.</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <td><?= (int)$r['id'] ?></td>
                    <td><a href="<?= url('/school/' . $r['slug']) ?>"><b><?= e($r['title_ru']) ?></b></a><div class="muted small mono"><?= e($r['slug']) ?></div></td>
                    <td class="small"><?= e($r['level']) ?></td>
                    <td><?= (int)($r['sort'] ?? 0) ?></td>
                    <td><?= (int)($r['passed_n'] ?? 0) ?></td>
                    <td><?= !empty($r['published']) ? '✓' : '—' ?></td>
                    <td class="actions">
                        <a class="btn btn--sm btn--ghost" href="<?= url('/admin/lessons/' . $r['id'] . '/edit') ?>">✎</a>
                        <form method="post" action="<?= url('/admin/lessons/' . $r['id'] . '/delete') ?>" class="inline"><?= csrf_field() ?><button class="btn btn--sm btn--ghost" type="submit" onclick="return confirm('Удалить урок?')">🗑</button></form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="panel" style="margin-top:16px;padding:18px">
    <h3 class="side-title"><?= $editing ? '✎ ' . e(($lesson['title_ru'] ?? '')) : '＋ Новый урок' ?></h3>
    <form method="post" action="<?= $editing ? url('/admin/lessons/' . $lesson['id'] . '/update') : url('/admin/lessons/create') ?>" class="stack-form">
        <?= csrf_field() ?>
        <div class="form-row">
            <label class="f">Название<input name="title" required maxlength="220" value="<?= e((string)($lesson['title_ru'] ?? '')) ?>"></label>
            <label class="f">Slug<input name="slug" maxlength="190" value="<?= e((string)($lesson['slug'] ?? '')) ?>"></label>
        </div>
        <div class="form-row">
            <label class="f">Уровень
                <select name="level">
                    <?php foreach ($levels as $lv): ?>
                    <option value="<?= e($lv) ?>" <?= ($lesson['level'] ?? '') === $lv ? 'selected' : '' ?>><?= e($lv) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label class="f">Sort<input name="sort" inputmode="numeric" value="<?= e((string)($lesson['sort'] ?? '100')) ?>"></label>
            <label class="f">Публикация
                <select name="published">
                    <option value="1" <?= (int)($lesson['published'] ?? 1) === 1 ? 'selected' : '' ?>>опубликован</option>
                    <option value="0" <?= (int)($lesson['published'] ?? 1) === 0 ? 'selected' : '' ?>>черновик</option>
                </select>
            </label>
        </div>
        <label class="f">Краткое описание<input name="summary" maxlength="500" value="<?= e((string)($lesson['summary_ru'] ?? '')) ?>"></label>
        <label class="f">Тело урока — блоки JSON (как у статей: text, heading, list, callout, quote, code, metar…)
            <textarea name="body_json" rows="10" class="mono" placeholder='[{"t":"heading","d":{"text":"Раздел"}},{"t":"text","d":{"text":"Абзац"}}]'><?= e((string)($lesson['body_json'] ?? '')) ?></textarea>
        </label>
        <label class="f">Тест — JSON: {"pass":70,"questions":[{"q":"…","options":["A","B"],"correct":0,"explain":"…"}]}
            <textarea name="quiz_json" rows="6" class="mono" placeholder='{"pass":70,"questions":[…]}'><?= e((string)($lesson['quiz_json'] ?? '')) ?></textarea>
        </label>
        <button class="btn btn-primary" type="submit">Сохранить</button>
    </form>
</div>
