<?php /** Настройки: вкладки Общее / Интеграции / ИИ / Лимиты (в.152, 151, 221–222) */
$tabs = [
    'general'      => __('settings.general'),
    'integrations' => __('settings.integrations'),
    'ai'           => __('settings.ai'),
    'limits'       => __('settings.limits'),
];
?>
<div class="tab-nav">
    <?php foreach ($tabs as $key => $label): ?>
        <a class="tab <?= $tab === $key ? 'is-active' : '' ?>" href="<?= url('/admin/settings/' . $key) ?>"><?= e($label) ?></a>
    <?php endforeach; ?>
</div>

<?php if ($tab === 'general'): ?>
<div class="panel">
    <form method="post" action="<?= url('/admin/settings/general') ?>" enctype="multipart/form-data" class="form">
        <?= csrf_field() ?>
        <div class="form-grid">
            <label class="field"><span><?= e(__('settings.site_name')) ?></span>
                <input type="text" name="site_name" value="<?= e($site['site_name']) ?>" required></label>
            <label class="field"><span><?= e(__('settings.tagline')) ?></span>
                <input type="text" name="tagline" value="<?= e($site['tagline']) ?>"></label>
            <label class="field"><span><?= e(__('settings.timezone')) ?></span>
                <select name="timezone">
                    <?php $cur = $site['timezone'] ?? 'Europe/Moscow'; ?>
                    <?php foreach (['Europe/Moscow','Europe/Kaliningrad','Europe/Samara','Europe/Kyiv','Europe/Minsk','Europe/Riga','Europe/Berlin','Europe/Rome','Europe/London','UTC','Asia/Almaty','Asia/Novosibirsk','Asia/Vladivostok'] as $tz): ?>
                        <option value="<?= e($tz) ?>" <?= $tz === $cur ? 'selected' : '' ?>><?= e($tz) ?></option>
                    <?php endforeach; ?>
                </select></label>
            <label class="field"><span><?= e(__('settings.hero_title')) ?></span>
                <input type="text" name="hero_title" value="<?= e($site['hero_title']) ?>"></label>
        </div>
        <label class="field"><span><?= e(__('settings.hero_sub')) ?></span>
            <textarea name="hero_sub" rows="2"><?= e($site['hero_sub']) ?></textarea></label>

        <div class="upload-row">
            <label class="field"><span><?= e(__('settings.logo')) ?></span>
                <input type="file" name="logo" accept="image/png,image/svg+xml,image/jpeg,image/webp">
                <img class="up-preview" src="<?= e(url($site['logo'])) ?>" alt="logo"></label>
            <label class="field"><span><?= e(__('settings.favicon')) ?></span>
                <input type="file" name="favicon" accept="image/png,image/svg+xml,image/x-icon">
                <img class="up-preview" src="<?= e(url($site['favicon'])) ?>" alt="favicon"></label>
            <label class="field"><span><?= e(__('settings.hero_image')) ?></span>
                <input type="file" name="hero_image" accept="image/png,image/jpeg,image/webp">
                <span class="muted">PNG/JPG/WebP до 8 МБ · обложка главной (в.226)</span></label>
        </div>
        <button class="btn btn--primary" type="submit"> <?= e(__('common.save')) ?></button>
    </form>
</div>

<?php elseif ($tab === 'integrations'): ?>
<div class="panel">
    <form method="post" action="<?= url('/admin/settings/integrations') ?>" class="form">
        <?= csrf_field() ?>
        <div class="form-grid">
            <label class="field"><span><?= e(__('settings.tg_token')) ?></span>
                <input type="text" name="telegram_bot_token" value="<?= e($site['telegram_bot_token']) ?>" placeholder="123456:ABC-DEF..." autocomplete="off">
                <span class="muted">Webhook-бот: вход по коду, /metar, /track, уведомления (v0.5)</span></label>
            <label class="field"><span><?= e(__('settings.tg_username')) ?></span>
                <input type="text" name="telegram_bot_username" value="<?= e($site['telegram_bot_username']) ?>" placeholder="VladAeroBot"></label>
            <label class="field"><span>Telegram API Base URL</span>
                <input type="text" name="tg_api_base" value="<?= e($site['tg_api_base'] ?? 'https://telegram.v7755837.deno.net') ?>" placeholder="https://telegram.v7755837.deno.net">
                <span class="muted">Базовый URL Telegram & Unified Deno API Proxy (по умолчанию <code>https://telegram.v7755837.deno.net</code>)</span></label>
            <label class="field"><span>Telegram API прокси <span class="muted">(в.285)</span></span>
                <input type="text" name="tg_api_proxy" value="<?= e($site['tg_api_proxy'] ?? '') ?>" placeholder="http://user:pass@proxy:port">
                <span class="muted">Если сервер не может достучаться напрямую — укажите исходящий HTTP/SOCKS прокси.</span></label>
        </div>

        <h4 class="form-h">🎤 Распознавание голоса — AssemblyAI <span class="muted">в.262</span></h4>
        <div class="form-grid">
            <label class="field"><span>AssemblyAI API Key</span>
                <input type="text" name="tg_stt_api_key" value="<?= e($site['tg_stt_api_key'] ?? '') ?>" autocomplete="off" placeholder="YOUR_API_KEY">
                <span class="muted">Получите ключ бесплатно на <a href="https://assemblyai.com/dashboard/signup" target="_blank" rel="noopener">assemblyai.com</a> (бесплатные кредиты на старте). Голосовые сообщения в боте распознаются через этот ключ.</span></label>
        </div>
        <h4 class="form-h"><?= e(__('settings.turnstile')) ?> <span class="muted">(в.69)</span></h4>
        <div class="form-grid">
            <label class="field"><span><?= e(__('settings.ts_site')) ?></span>
                <input type="text" name="turnstile_site_key" value="<?= e($site['turnstile_site_key']) ?>"></label>
            <label class="field"><span><?= e(__('settings.ts_secret')) ?></span>
                <input type="text" name="turnstile_secret_key" value="<?= e($site['turnstile_secret_key']) ?>"></label>
        </div>

        <h4 class="form-h">✈ SkyLink API <span class="muted">FIDS / NOTAM</span></h4>
        <div class="form-grid">
            <label class="field"><span><?= e(__('settings.skylink_key')) ?></span>
                <input type="text" name="skylink_api_key" value="<?= e($site['skylink_api_key'] ?? '') ?>" autocomplete="off" placeholder="ключ RapidAPI (бесплатный тариф)">
                <span class="muted"><?= e(__('settings.skylink_hint')) ?></span></label>
            <label class="field"><span><?= e(__('settings.skylink_base')) ?></span>
                <input type="url" name="skylink_api_base" value="<?= e($site['skylink_api_base'] ?? 'https://skylinkapi.com/v2') ?>"></label>
        </div>

        <h4 class="form-h">🔍 Firecrawl <span class="muted">web search / fetch для ИИ</span></h4>
        <div class="form-grid">
            <label class="field"><span><?= e(__('settings.firecrawl_key')) ?></span>
                <input type="text" name="firecrawl_api_key" value="<?= e($site['firecrawl_api_key'] ?? '') ?>" autocomplete="off" placeholder="fc-…">
                <span class="muted"><?= e(__('settings.firecrawl_hint')) ?></span></label>
            <label class="field"><span><?= e(__('settings.firecrawl_base')) ?></span>
                <input type="text" name="firecrawl_api_base" value="<?= e($site['firecrawl_api_base'] ?? 'https://api.firecrawl.dev/v1') ?>" placeholder="https://api.firecrawl.dev/v1">
                <span class="muted">API base: облачный Firecrawl или self-hosted инстанс</span></label>
        </div>

        <h4 class="form-h">◉ <?= e(__('cam.custom_title')) ?></h4>
        <label class="field"><span><?= e(__('cam.custom_field')) ?></span>
            <textarea name="webcam_custom" rows="4" placeholder="UUEE|Перрон терминала B|https://example.com/frame.jpg"><?= e($site['webcam_custom'] ?? '') ?></textarea>
            <span class="muted"><?= e(__('cam.custom_hint')) ?></span></label>

        <button class="btn btn--primary" type="submit"><?= e(__('common.save')) ?></button>
    </form>
    <form method="post" action="<?= url('/admin/telegram/setwebhook') ?>" class="inline" style="margin-top:12px">
        <?= csrf_field() ?>
        <button class="btn" type="submit">⚙ setWebhook</button>
        <span class="muted mono small">…/tg/webhook?key=<?= e(substr((string)($site['tg_webhook_secret'] ?? ''), 0, 8)) ?>…</span>
    </form>
</div>

<?php elseif ($tab === 'ai'): ?>
<div class="panel">
    <form method="post" action="<?= url('/admin/settings/ai') ?>" class="form">
        <?= csrf_field() ?>
        <div class="form-grid">
            <label class="field"><span><?= e(__('settings.ai_base_url')) ?></span>
                <input type="url" id="ai-base-url" name="ai_base_url" value="<?= e($site['ai_base_url']) ?>"
                       placeholder="https://api.openai.com/v1" required>
                <span class="muted">Любой OpenAI-совместимый провайдер (в.151): OpenAI, DeepSeek, Ollama, OpenRouter…</span></label>
            <label class="field"><span><?= e(__('settings.ai_model')) ?></span>
                <input type="text" id="ai-model" name="ai_model" value="<?= e($site['ai_model']) ?>" placeholder="gpt-4o-mini" list="modelList">
                <datalist id="modelList"></datalist>
                <button class="btn btn--ghost btn--sm" type="button" id="fetchModels">⟳ <?= e(__('settings.ai_fetch')) ?></button>
                <span class="muted" id="fetchStatus"></span></label>
        </div>
        <div class="form-grid">
            <label class="field"><span><?= e(__('settings.ai_api_key')) ?></span>
                <input type="password" id="ai-key" name="ai_api_key" autocomplete="new-password" placeholder="<?= e(__('settings.ai_api_key_keep')) ?>">
            </label>
            <label class="field"><span><?= e(__('settings.ai_temp')) ?>: <b id="tempVal"><?= e($site['ai_temperature']) ?></b></span>
                <input type="range" name="ai_temperature" min="0" max="2" step="0.1" value="<?= e($site['ai_temperature']) ?>" oninput="document.getElementById('tempVal').textContent=this.value"></label>
        </div>
        <label class="field"><span><?= e(__('settings.ai_prompt')) ?></span>
            <textarea name="ai_system_prompt" rows="4"><?= e($site['ai_system_prompt']) ?></textarea></label>
        <button class="btn btn--primary" type="submit"><?= e(__('common.save')) ?></button>
    </form>
    <div class="panel-note muted">
        Чат с SSE-стримингом, reasoning-блоками и 20 инструментами виджета (Firecrawl Search/Fetch,
        METAR, радар, FIDS…) — <span class="tag-soon">v0.5</span>. Пока доступна проверка ключа кнопкой Fetch /v1/models.
    </div>
</div>

<?php else: /* limits */ ?>
<div class="panel">
    <form method="post" action="<?= url('/admin/settings/limits') ?>" class="form">
        <?= csrf_field() ?>
        <div class="form-grid">
            <label class="field"><span><?= e(__('settings.ai_guest')) ?></span>
                <input type="number" name="ai_limit_guest" min="0" value="<?= e($site['ai_limit_guest']) ?>"></label>
            <label class="field"><span><?= e(__('settings.ai_user')) ?></span>
                <input type="number" name="ai_limit_user" min="0" value="<?= e($site['ai_limit_user']) ?>"></label>
        </div>
        <label class="field field--check"><input type="checkbox" name="registration_enabled" value="1"
            <?= ($site['registration_enabled'] ?? '1') === '1' ? 'checked' : '' ?>> <?= e(__('settings.registration')) ?></label>
        <label class="field"><span>Текст заглушки обслуживания (в.129)</span>
            <textarea name="maintenance_text" rows="2"><?= e($site['maintenance_text']) ?></textarea></label>
        <button class="btn btn--primary" type="submit"><?= e(__('common.save')) ?></button>
    </form>
</div>
<?php endif; ?>
