<?php /** Админ: форма статьи с блочным редактором (в.108–115) */
$v = static fn(string $k, string $d = '') => e($a[$k] ?? $d);
?>
<form method="post" action="<?= url('/admin/articles/' . ($a !== null ? (int)$a['id'] . '/update' : 'create')) ?>" class="form">
    <div class="panel form">
        <?= csrf_field() ?>
        <div class="panel-head"><h3><?= $a !== null ? e(__('art.edit')) . ': ' . e($a['title_ru']) : e(__('art.add')) ?></h3></div>
        <div class="form-grid">
            <label class="field"><span>Заголовок (рус.) *</span>
                <input type="text" name="title_ru" value="<?= $v('title_ru') ?>" required maxlength="220"></label>
            <label class="field"><span>Заголовок (англ.)</span>
                <input type="text" name="title_en" value="<?= $v('title_en') ?>" maxlength="220"></label>
            <label class="field"><span>Slug (ЧПУ)</span>
                <input type="text" name="slug" value="<?= $v('slug') ?>" placeholder="авто из заголовка" maxlength="190"></label>
            <label class="field"><span>Статус</span>
                <select name="status">
                    <?php foreach (\App\Models\Article::STATUSES as $s): ?>
                        <option value="<?= e($s) ?>" <?= ($a['status'] ?? 'draft') === $s ? 'selected' : '' ?>><?= e(__('art.status.' . $s)) ?></option>
                    <?php endforeach; ?>
                </select></label>
        </div>
        <label class="field"><span>Краткое описание (для списков и SEO)</span>
            <textarea name="excerpt_ru" rows="2"><?= $v('excerpt_ru') ?></textarea></label>
    </div>

    <div class="panel">
        <?php require VA_APP . '/Views/partials/blocks-editor.php'; ?>
    </div>

    <div class="actions-row">
        <button class="btn btn--primary" type="submit"> <?= e(__('common.save')) ?></button>
        <a class="btn btn--ghost" href="<?= url('/admin/articles') ?>"><?= e(__('common.cancel')) ?></a>
    </div>
</form>
