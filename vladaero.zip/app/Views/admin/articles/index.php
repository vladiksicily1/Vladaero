<?php /** Админ: статьи */ ?>
<div class="panel">
    <div class="panel-head">
        <h3><?= e(__('admin.articles')) ?> — <?= (int)$total ?></h3>
        <div class="inline">
            <form method="get" action="<?= url('/admin/articles') ?>" class="inline">
                <select name="status" onchange="this.form.submit()">
                    <option value=""><?= e(__('common.any')) ?></option>
                    <?php foreach (\App\Models\Article::STATUSES as $s): ?>
                        <option value="<?= e($s) ?>" <?= $status === $s ? 'selected' : '' ?>><?= e(__('art.status.' . $s)) ?></option>
                    <?php endforeach; ?>
                </select>
                <input type="search" name="q" value="<?= e($q) ?>" placeholder="<?= e(__('common.search')) ?>…">
                <button class="btn btn--ghost btn--sm" type="submit">⌕</button>
            </form>
            <a class="btn btn--primary btn--sm" href="<?= url('/admin/articles/new') ?>">+ <?= e(__('art.add')) ?></a>
        </div>
    </div>
    <?php if ($rows === []): ?>
        <p class="muted pad"><?= e(__('art.empty_admin')) ?></p>
    <?php else: ?>
    <div class="table-wrap">
        <table class="table">
            <thead><tr><th>ID</th><th>Заголовок</th><th>Статус</th><th>Автор</th><th>Публикация</th><th>👁</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($rows as $a): ?>
                <tr>
                    <td class="mono muted">#<?= (int)$a['id'] ?></td>
                    <td><b><?= e($a['title_ru']) ?></b><div class="muted small">/articles/<?= e($a['slug']) ?></div></td>
                    <td><span class="ac-badge ac-badge--<?= $a['status'] === 'published' ? 'active' : ($a['status'] === 'review' ? 'prototype' : 'retired') ?>"><?= e(__('art.status.' . $a['status'])) ?></span></td>
                    <td><?= e($a['author'] ?? '—') ?></td>
                    <td class="mono muted"><?= e($a['published_at'] ?: '—') ?></td>
                    <td class="mono"><?= (int)$a['views'] ?></td>
                    <td>
                        <div class="inline">
                            <a class="btn btn--ghost btn--sm" href="<?= url('/admin/articles/' . (int)$a['id'] . '/edit') ?>">✎</a>
                            <?php if ($a['status'] === 'published'): ?>
                                <a class="btn btn--ghost btn--sm" href="<?= url('/articles/' . $a['slug']) ?>" target="_blank" rel="noopener">↗</a>
                            <?php endif; ?>
                            <form method="post" action="<?= url('/admin/articles/' . (int)$a['id'] . '/delete') ?>" class="inline" data-confirm="Удалить статью «<?= e($a['title_ru']) ?>»?"><?= csrf_field() ?>
                                <button class="btn btn--danger btn--sm" type="submit">✕</button></form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
    <?php if ($pages > 1): ?>
        <div class="pager"><?php for ($p = 1; $p <= $pages; $p++): ?><a class="pg <?= $p === $page ? 'is-active' : '' ?>" href="<?= url('/admin/articles') ?>?q=<?= urlencode($q) ?>&amp;status=<?= e($status) ?>&amp;page=<?= $p ?>"><?= $p ?></a><?php endfor; ?></div>
    <?php endif; ?>
</div>
