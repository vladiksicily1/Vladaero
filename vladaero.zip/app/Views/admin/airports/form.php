<?php /** Админ: форма аэропорта + блоки (в.10, 33, 108) */
$v = static fn(string $k, string $d = '') => e($ap[$k] ?? $d);
?>
<form method="post" action="<?= url('/admin/airports/' . ($ap !== null ? (int)$ap['id'] . '/update' : 'create')) ?>" class="form">
    <div class="panel form">
        <?= csrf_field() ?>
        <div class="panel-head"><h3><?= $ap !== null ? e(__('ap.edit')) . ': ' . e($ap['name_ru']) : e(__('ap.add')) ?></h3></div>
        <div class="form-grid">
            <label class="field"><span>ICAO *</span>
                <input type="text" name="icao" value="<?= $v('icao') ?>" required maxlength="6" pattern="[A-Za-z]{4}" title="4 латинские буквы"></label>
            <label class="field"><span>IATA</span>
                <input type="text" name="iata" value="<?= $v('iata') ?>" maxlength="4"></label>
            <label class="field"><span>Название (рус.) *</span>
                <input type="text" name="name_ru" value="<?= $v('name_ru') ?>" required maxlength="190"></label>
            <label class="field"><span>Название (англ.)</span>
                <input type="text" name="name_en" value="<?= $v('name_en') ?>" maxlength="190"></label>
            <label class="field"><span>Город (рус.)</span>
                <input type="text" name="city_ru" value="<?= $v('city_ru') ?>" maxlength="120"></label>
            <label class="field"><span>Город (англ.)</span>
                <input type="text" name="city_en" value="<?= $v('city_en') ?>" maxlength="120"></label>
            <label class="field"><span>Код страны (ISO, 2 буквы)</span>
                <input type="text" name="country_code" value="<?= $v('country_code') ?>" maxlength="2" pattern="[A-Za-z]{2}"></label>
            <label class="field"><span>Широта (lat)</span>
                <input type="text" inputmode="decimal" name="lat" value="<?= $v('lat') ?>" placeholder="55.9726"></label>
            <label class="field"><span>Долгота (lng)</span>
                <input type="text" inputmode="decimal" name="lng" value="<?= $v('lng') ?>" placeholder="37.4146"></label>
            <label class="field"><span>Высота, фут</span>
                <input type="number" name="elevation_ft" value="<?= $v('elevation_ft') ?>"></label>
            <label class="field"><span>Часовой пояс</span>
                <input type="text" name="timezone" value="<?= $v('timezone') ?>" placeholder="Europe/Moscow" maxlength="64"></label>
            <label class="field"><span>Сайт</span>
                <input type="url" name="website" value="<?= $v('website') ?>" maxlength="255"></label>
        </div>
    </div>

    <div class="panel">
        <?php require VA_APP . '/Views/partials/blocks-editor.php'; ?>
    </div>

    <div class="actions-row">
        <button class="btn btn--primary" type="submit"> <?= e(__('common.save')) ?></button>
        <a class="btn btn--ghost" href="<?= url('/admin/airports') ?>"><?= e(__('common.cancel')) ?></a>
    </div>
</form>
