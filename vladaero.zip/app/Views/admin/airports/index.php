<?php /** Админ: аэропорты */ ?>
<div class="panel">
    <div class="panel-head">
        <h3><?= e(__('admin.airports')) ?> — <?= (int)$total ?></h3>
        <div class="inline">
            <form method="get" action="<?= url('/admin/airports') ?>" class="inline">
                <input type="search" name="q" value="<?= e($q) ?>" placeholder="ICAO, город…">
                <button class="btn btn--ghost btn--sm" type="submit">⌕</button>
            </form>
            <a class="btn btn--primary btn--sm" href="<?= url('/admin/airports/new') ?>">+ <?= e(__('ap.add')) ?></a>
        </div>
    </div>
    <?php if ($rows === []): ?>
        <p class="muted pad"><?= e(__('ap.empty_admin')) ?></p>
    <?php else: ?>
    <div class="table-wrap">
        <table class="table">
            <thead><tr><th>ICAO</th><th>IATA</th><th>Название</th><th>Город</th><th>Страна</th><th>Координаты</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($rows as $p): ?>
                <tr>
                    <td class="mono"><b><?= e($p['icao']) ?></b></td>
                    <td class="mono muted"><?= e($p['iata'] ?: '—') ?></td>
                    <td><a href="<?= url('/airports/' . $p['icao']) ?>" target="_blank" rel="noopener"><?= e($p['name_ru']) ?></a></td>
                    <td><?= e($p['city_ru'] ?: '—') ?></td>
                    <td class="mono"><?= e($p['country_code'] ?: '—') ?></td>
                    <td class="mono muted"><?= $p['lat'] !== null ? e(number_format((float)$p['lat'], 4, '.', '')) . ', ' . e(number_format((float)$p['lng'], 4, '.', '')) : '—' ?></td>
                    <td>
                        <div class="inline">
                            <a class="btn btn--ghost btn--sm" href="<?= url('/admin/airports/' . (int)$p['id'] . '/edit') ?>">✎</a>
                            <form method="post" action="<?= url('/admin/airports/' . (int)$p['id'] . '/delete') ?>" class="inline" data-confirm="Удалить аэропорт <?= e($p['icao']) ?>?"><?= csrf_field() ?>
                                <button class="btn btn--danger btn--sm" type="submit">✕</button></form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
    <?php if ($pages > 1): ?>
        <div class="pager"><?php for ($p = 1; $p <= $pages; $p++): ?><a class="pg <?= $p === $page ? 'is-active' : '' ?>" href="<?= url('/admin/airports') ?>?q=<?= urlencode($q) ?>&amp;page=<?= $p ?>"><?= $p ?></a><?php endfor; ?></div>
    <?php endif; ?>
</div>
