<?php /** Админ: модерация споттинг-точек (v0.8.1) */ ?>
<section class="ac-layout">
    <div class="page-head"><h1>📍 Споттинг-точки</h1></div>
    <div class="tabs">
        <?php foreach (['pending' => 'На модерации', 'published' => 'Опубликованные', 'rejected' => 'Отклонённые'] as $t => $label): ?>
        <a class="tab<?= $tab === $t ? ' active' : '' ?>" href="<?= url('/admin/spots?tab=' . $t) ?>"><?= e($label) ?> (<?= (int)$counts[$t] ?>)</a>
        <?php endforeach; ?>
    </div>
    <div class="panel">
        <?php foreach ($points as $p): ?>
        <div class="spot-admin-row" data-id="<?= (int)$p['id'] ?>">
            <div>
                <b><?= e($p['title_ru']) ?></b> <i class="tag-soon"><?= e($p['icao']) ?></i>
                <span class="muted small">· <?= e($p['author'] ?? 'система/демо') ?> · <?= e($p['lat']) ?>, <?= e($p['lng']) ?></span>
                <p class="muted small"><?= e(mb_substr((string)$p['description_ru'], 0, 200)) ?></p>
            </div>
            <div class="spot-admin-acts">
                <?php if ($p['status'] !== 'published'): ?>
                <button class="btn btn--sm btn-primary act" data-status="published">✓ Опубликовать</button>
                <?php endif; ?>
                <?php if ($p['status'] !== 'rejected'): ?>
                <button class="btn btn--sm act" data-status="rejected">✕ Отклонить</button>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
        <?php if ($points === []): ?><p class="muted">Пусто.</p><?php endif; ?>
    </div>
</section>
<script>
document.querySelectorAll('.spot-admin-acts .act').forEach(function (b) {
    b.addEventListener('click', function () {
        var row = b.closest('.spot-admin-row');
        var fd = new FormData();
        fd.append('status', b.dataset.status);
        fetch('<?= url('/admin/spots') ?>/' + row.dataset.id + '/decide', {
            method: 'POST', body: fd,
            headers: { 'X-CSRF-Token': document.querySelector('meta[name=va-csrf]').content, 'X-Requested-With': 'XMLHttpRequest' }
        }).then(function (r) { return r.json(); }).then(function (j) { if (j.ok) { row.remove(); } });
    });
});
</script>
