<?php /** Модерация комментариев (в.194, 29) */ ?>
<div class="panel">
    <div class="panel-head">
        <h3>💬 <?= e(__('admin.comments')) ?> — <?= (int)$counts['all'] ?></h3>
        <div>
            <a class="btn btn--sm <?= $status === 'all' ? 'btn-primary' : 'btn--ghost' ?>" href="<?= url('/admin/comments') ?>">all</a>
            <a class="btn btn--sm <?= $status === 'pending' ? 'btn-primary' : 'btn--ghost' ?>" href="<?= url('/admin/comments?status=pending') ?>">pending (<?= (int)$counts['pending'] ?>)</a>
            <a class="btn btn--sm <?= $status === 'approved' ? 'btn-primary' : 'btn--ghost' ?>" href="<?= url('/admin/comments?status=approved') ?>">approved</a>
            <a class="btn btn--sm <?= $status === 'rejected' ? 'btn-primary' : 'btn--ghost' ?>" href="<?= url('/admin/comments?status=rejected') ?>">rejected</a>
        </div>
    </div>
    <div class="table-wrap">
        <table class="table">
            <thead><tr><th>ID</th><th>Автор</th><th>Где</th><th>Текст</th><th>Статус</th><th>Дата</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <td><?= (int)$r['id'] ?></td>
                    <td><b><?= e($r['username']) ?></b></td>
                    <td class="mono small"><?= e($r['entity_type'] . '#' . $r['entity_id']) ?></td>
                    <td><?= e(mb_substr((string)$r['body'], 0, 160)) ?></td>
                    <td><i class="tag-soon"><?= e($r['status']) ?></i></td>
                    <td class="muted small"><?= e(substr((string)$r['created_at'], 0, 16)) ?></td>
                    <td class="actions">
                        <?php if ($r['status'] !== 'approved'): ?>
                        <form method="post" action="<?= url('/admin/comments/' . $r['id'] . '/status') ?>" class="inline"><?= csrf_field() ?><input type="hidden" name="to" value="approved"><button class="btn btn--sm" type="submit">✓</button></form>
                        <?php endif; ?>
                        <?php if ($r['status'] !== 'rejected'): ?>
                        <form method="post" action="<?= url('/admin/comments/' . $r['id'] . '/status') ?>" class="inline"><?= csrf_field() ?><input type="hidden" name="to" value="rejected"><button class="btn btn--sm btn--ghost" type="submit">✕</button></form>
                        <?php endif; ?>
                        <form method="post" action="<?= url('/admin/comments/' . $r['id'] . '/delete') ?>" class="inline"><?= csrf_field() ?><button class="btn btn--sm btn--ghost" type="submit" onclick="return confirm('Удалить?')">🗑</button></form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
