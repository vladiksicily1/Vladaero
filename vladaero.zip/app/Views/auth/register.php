<?php /** Регистрация (в.66) */
$oldUsername = $_SESSION['_old']['username'] ?? '';
$oldEmail = $_SESSION['_old']['email'] ?? '';
unset($_SESSION['_old']);
?>
<div class="auth-card">
    <h1 class="auth-title"><?= e(__('auth.register_title')) ?></h1>
    <form method="post" action="<?= url('/register') ?>" class="form">
        <?= csrf_field() ?>
        <label class="field">
            <span><?= e(__('auth.username')) ?></span>
            <input type="text" name="username" required minlength="3" maxlength="32"
                   pattern="[A-Za-z0-9_]{3,32}" value="<?= e($oldUsername) ?>"
                   autocomplete="username">
        </label>
        <label class="field">
            <span><?= e(__('auth.email')) ?></span>
            <input type="email" name="email" required value="<?= e($oldEmail) ?>"
                   autocomplete="email">
        </label>
        <label class="field">
            <span><?= e(__('auth.password')) ?></span>
            <input type="password" name="password" id="reg-password" required autocomplete="new-password">
            <div class="strength"><div id="strengthBar"></div></div>
            <small class="muted"><?= e(__('validate.password')) ?></small>
        </label>
        <label class="field">
            <span><?= e(__('auth.password2')) ?></span>
            <input type="password" name="password2" required autocomplete="new-password">
        </label>
        <button class="btn btn--primary btn--block" type="submit"><?= e(__('common.register')) ?> →</button>
    </form>
    <p class="auth-alt"><?= e(__('auth.have_account')) ?> <a href="<?= url('/login') ?>"><?= e(__('common.login')) ?></a></p>
    <p class="auth-hint">Email используется только для входа — без рассылок и SMTP (в.218)</p>
</div>
