<?php /** Вход (в.66): логин/email + пароль ИЛИ Telegram-код */ ?>
<div class="auth-card">
    <h1 class="auth-title"><?= e(__('auth.login_title')) ?></h1>
    <form method="post" action="<?= url('/login') ?>" class="form">
        <?= csrf_field() ?>
        <label class="field">
            <span><?= e(__('auth.username')) ?> / Email</span>
            <input type="text" name="login" required autofocus autocomplete="username">
        </label>
        <label class="field">
            <span><?= e(__('auth.password')) ?></span>
            <input type="password" name="password" required autocomplete="current-password">
        </label>
        <button class="btn btn--primary btn--block" type="submit"><?= e(__('common.login')) ?> →</button>
    </form>

    <div class="auth-divider">или</div>

    <form method="post" action="<?= url('/login/tg') ?>" class="form">
        <?= csrf_field() ?>
        <label class="field">
            <span>🔑 <?= e(__('auth.tg_title')) ?></span>
            <input type="text" name="tg_code" inputmode="numeric" autocomplete="one-time-code" placeholder="000000">
        </label>
        <button class="btn btn--ghost btn--block" type="submit"><?= e(__('auth.tg_enter')) ?></button>
    </form>
    <p class="auth-hint"><?= e(__('auth.tg_how')) ?> <b>/login</b> — <a href="<?= e('https://t.me/' . (setting('telegram_bot_username', 'vladaero_bot'))) ?>" target="_blank" rel="noopener">@<?= e(setting('telegram_bot_username', 'vladaero_bot')) ?></a></p>

    <p class="auth-alt"><?= e(__('auth.no_account')) ?> <a href="<?= url('/register') ?>"><?= e(__('common.register')) ?></a></p>
    <p class="auth-hint"><?= e(__('auth.forgot')) ?></p>
</div>
