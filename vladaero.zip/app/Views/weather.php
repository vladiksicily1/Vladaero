<?php
/**
 * Авиационная погода (в.47, 283–295): METAR/TAF с авторасшифровкой.
 * @var string $icao @var array $metar @var array $taf @var array $airports @var bool $hasKey
 */
$catColors = ['VFR' => 'is-ok', 'MVFR' => 'is-warn', 'IFR' => 'is-bad', 'LIFR' => 'is-bad'];
?>
<section class="ac-layout">
    <div class="page-head">
        <div>
            <h1>☁ <?= e(__('wx.title')) ?></h1>
            <p class="muted"><?= e(__('wx.sub')) ?> · NOAA AWC</p>
        </div>
        <form class="gal-filters" method="get" action="<?= e(url('/weather')) ?>" style="margin:0">
            <input type="text" name="icao" maxlength="4" placeholder="ICAO" value="<?= e($icao) ?>"
                   style="text-transform:uppercase;width:110px" autofocus>
            <button class="btn btn-primary" type="submit">⌕</button>
        </form>
    </div>

    <?php if (!empty($metar['ok'])): ?>
    <div class="wx-grid">
        <div class="panel wx-metar">
            <div class="panel-head">
                <h3>METAR <span class="mono"><?= e($metar['icao']) ?></span></h3>
                <?php if ($metar['fltcat'] !== ''): ?>
                <span class="wx-cat <?= $catColors[$metar['fltcat']] ?? '' ?>"><?= e($metar['fltcat']) ?></span>
                <?php endif; ?>
            </div>
            <div class="wx-raw mono"><?= e($metar['raw']) ?></div>
            <div class="wx-tts">
                <button class="btn btn--sm" type="button" id="ttsBtn" data-icao="<?= e($metar['icao']) ?>"><?= e(__('tts.play')) ?></button>
                <span class="muted small" id="ttsState"></span>
            </div>
            <dl class="kv">
                <?php foreach ($metar['dec'] as $lbl => $val): ?>
                <div><dt><?= e(__('wx.k_' . $lbl)) ?></dt><dd><?= e((string)$val) ?></dd></div>
                <?php endforeach; ?>
            </dl>
            <p class="muted small"><?= e(__('wx.obs')) ?>: <?= e($metar['obs']) ?><?= $metar['stale'] ? ' · ' . e(__('radar.stale_short')) : '' ?></p>
        </div>

        <div class="panel wx-taf">
            <div class="panel-head"><h3>TAF <span class="mono"><?= e($taf['icao'] ?: $metar['icao']) ?></span></h3></div>
            <?php if (!empty($taf['ok'])): ?>
            <div class="wx-taf-groups">
                <?php foreach ($taf['groups'] as $g): ?>
                <div class="wx-taf-g">
                    <div class="wx-taf-lbl"><?= e($g['label']) ?></div>
                    <?php if ($g['hints'] !== ''): ?><div class="wx-taf-hints">⚠ <?= e($g['hints']) ?></div><?php endif; ?>
                    <div class="mono small muted"><?= e($g['raw']) ?></div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <p class="muted"><?= e(__('wx.no_taf')) ?></p>
            <?php endif; ?>
        </div>
    </div>

    <div class="panel wx-notam" id="wxNotam" data-icao="<?= e($metar['icao']) ?>">
        <div class="panel-head"><h3>⚠ NOTAM</h3></div>
        <div class="wx-notam-body muted"><?= e($hasKey ? __('wx.notam_loading') : __('wx.notam_nokey')) ?></div>
    </div>
    <?php else: ?>
    <div class="empty">
        <div class="empty-ico">☁</div>
        <h2><?= e(__('wx.not_found')) ?></h2>
        <p class="muted"><?= e(__('wx.not_found_sub')) ?></p>
    </div>
    <?php endif; ?>

    <?php if ($airports !== []): ?>
    <p class="muted small" style="margin-top:16px"><?= e(__('wx.from_catalog')) ?>:
        <?php foreach (array_slice($airports, 0, 12) as $ap): ?>
        <a class="wx-chip" href="<?= e(url('/weather?icao=' . strtoupper($ap['icao']))) ?>"><?= e(strtoupper($ap['icao'])) ?></a>
        <?php endforeach; ?>
    </p>
    <?php endif; ?>
</section>
<script>
window.VA_L_WX = {
    nokey: <?= json_encode(__('wx.notam_nokey')) ?>,
    no_notams: <?= json_encode(__('wx.no_notams')) ?>
};
</script>
<script src="<?= e(asset('js/wx.js')) ?>" defer></script>
<script>
(function () {
    var btn = document.getElementById('ttsBtn'), st = document.getElementById('ttsState');
    if (!btn || !('speechSynthesis' in window)) { if (btn) { btn.style.display = 'none'; } return; }
    var speaking = false;
    btn.addEventListener('click', function () {
        if (speaking) { window.speechSynthesis.cancel(); return; }
        var parts = [];
        document.querySelectorAll('.wx-metar dl.kv > div').forEach(function (row) {
            var k = row.querySelector('dt'), v = row.querySelector('dd');
            if (k && v) { parts.push(k.textContent.trim() + ' — ' + v.textContent.trim() + '.'); }
        });
        var text = 'Погода ' + btn.dataset.icao + '. ' + parts.join(' ');
        var u = new SpeechSynthesisUtterance(text);
        u.lang = 'ru-RU'; u.rate = 1.0;
        var ru = window.speechSynthesis.getVoices().filter(function (v2) { return /^ru/i.test(v2.lang); })[0];
        if (ru) { u.voice = ru; }
        u.onend = function () { speaking = false; btn.innerHTML = <?= json_encode(__('tts.play'), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>; st.textContent = ''; };
        u.onerror = function () { speaking = false; st.textContent = ''; };
        speaking = true;
        btn.innerHTML = <?= json_encode(__('tts.stop'), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>;
        window.speechSynthesis.speak(u);
        st.textContent = '(озвучка браузером, RU)';
    });
})();
</script>
