<?php
/**
 * Полноэкранный радар — Cockpit Fullscreen Mode (в.230).
 * Standalone-страница без каркаса сайта. Leaflet + Canvas (в.86, 90).
 * @var string $cs предзаданный фильтр по callsign (?cs=)
 */
$lang = function (string $k): string {
    return __($k);
};
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex">
<title><?= e(__('radar.title')) ?> — <?= e(setting('site_name', 'VladAero')) ?></title>
<link rel="icon" href="<?= e(asset('assets/images/favicon.png')) ?>">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
      integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin="">
<link rel="stylesheet" href="<?= e(asset('assets/css/app.css')) ?>">
<style>
  html, body { margin: 0; height: 100%; background: #06090f; overflow: hidden; }
  #vaRadarApp { position: fixed; inset: 0; }
</style>
</head>
<body>
<div id="vaRadarApp">
  <div id="vaMap"></div>

  <header class="radar-hud" id="vaHud">
    <div class="radar-hud-top">
      <div class="radar-brand">
        <img src="<?= e(asset('assets/images/logo.png')) ?>" alt="">
        <div>
          <b><?= e(__('radar.title')) ?></b>
          <span class="radar-src" id="vaSrc">—</span>
        </div>
      </div>
      <div class="radar-counters">
        <span class="radar-cnt"><b id="vaCnt">0</b> <?= e(__('radar.aircraft')) ?></span>
        <span class="radar-cnt muted" id="vaStale" hidden><?= e(__('radar.stale')) ?></span>
      </div>
      <button class="radar-btn" id="vaFsBtn" title="F">⛶ <?= e(__('radar.fullscreen')) ?></button>
    </div>

    <div class="radar-filters">
      <input type="search" id="vaFltCs" placeholder="<?= e(__('radar.f_cs')) ?>" value="<?= e($cs ?? '') ?>">
      <input type="number" id="vaFltAltMin" placeholder="<?= e(__('radar.f_altmin')) ?>" min="0" step="500">
      <input type="number" id="vaFltAltMax" placeholder="<?= e(__('radar.f_altmax')) ?>" min="0" step="500">
      <label class="radar-chk"><input type="checkbox" id="vaFltAlert"> <?= e(__('radar.f_alert')) ?></label>
      <label class="radar-chk"><input type="checkbox" id="vaFltGround" checked> <?= e(__('radar.f_ground')) ?></label>
      <div class="radar-layers">
        <button class="radar-lbtn is-on" data-tiles="dark">Dark</button>
        <button class="radar-lbtn" data-tiles="sat">SAT</button>
        <button class="radar-lbtn" data-tiles="osm">OSM</button>
      </div>
    </div>

    <div class="radar-legend">
      <i style="--c:#3FBF7F"></i>&lt;3000 м
      <i style="--c:#48CAE4"></i>3–9 км
      <i style="--c:#A78BFA"></i>&gt;9 км
      <i style="--c:#FF5C5C"></i><?= e(__('radar.emg')) ?>
    </div>
  </header>

  <aside class="radar-card" id="vaCard" hidden>
    <button class="radar-card-x" id="vaCardX">✕</button>
    <div class="radar-card-cs" id="vcCs">—</div>
    <div class="radar-card-sub" id="vcSub"></div>
    <dl class="radar-tel">
      <div><dt>FL</dt><dd id="vcAlt">—</dd></div>
      <div><dt><?= e(__('radar.gs')) ?></dt><dd id="vcGs">—</dd></div>
      <div><dt><?= e(__('radar.trk')) ?></dt><dd id="vcTrk">—</dd></div>
      <div><dt><?= e(__('radar.vr')) ?></dt><dd id="vcVr">—</dd></div>
      <div class="radar-tel-wide"><dt>Squawk</dt><dd id="vcSq">—</dd></div>
    </dl>
    <div class="radar-card-actions" id="vcActs"></div>
  </aside>

  <div class="radar-toasts" id="vaToasts"></div>
  <div class="radar-hint muted"><?= e(__('radar.hint')) ?></div>
</div>

<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
        integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>
<script>
window.VA_L = {
    open_card:   <?= json_encode(__('radar.open_card')) ?>,
    open_gallery:<?= json_encode(__('radar.open_gallery')) ?>,
    stale:       <?= json_encode(__('radar.stale_short')) ?>,
    emg7700:     <?= json_encode(__('radar.emg7700')) ?>,
    emg7600:     <?= json_encode(__('radar.emg7600')) ?>,
    emg7500:     <?= json_encode(__('radar.emg7500')) ?>
};
</script>
<script src="<?= e(asset('assets/js/radar.js')) ?>"></script>
</body>
</html>
