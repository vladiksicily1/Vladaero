<?php /** 503: режим регламентных работ (в.129) */ ?>
<section class="err-page">
    <div class="hangar" aria-hidden="true">🛠</div>
    <h1 class="err-code">503</h1>
    <h2 class="err-title"><?= e(__('err.503')) ?></h2>
    <p class="err-sub"><?= e(($site['maintenance_text'] ?? '') !== '' ? $site['maintenance_text'] : __('err.503_sub')) ?></p>
</section>
