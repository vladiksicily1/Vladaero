<?php /** 403: нет допуска */ ?>
<section class="err-page">
    <h1 class="err-code">403</h1>
    <h2 class="err-title"><?= e(__('err.403')) ?></h2>
    <p class="err-sub"><?= e(__('err.403_sub')) ?></p>
    <div class="err-actions">
        <a class="btn btn--primary" href="<?= url('/') ?>">← <?= e(__('common.home')) ?></a>
    </div>
</section>
