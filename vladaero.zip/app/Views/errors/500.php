<?php /** 500: «Отказ систем» (в.128) */ ?>
<section class="err-page">
    <div class="master-caution">MASTER CAUTION</div>
    <h1 class="err-code">500</h1>
    <h2 class="err-title"><?= e(__('err.500')) ?></h2>
    <p class="err-sub"><?= e(__('err.500_sub')) ?></p>
    <div class="err-actions">
        <a class="btn btn--primary" href="<?= url('/') ?>">← <?= e(__('common.home')) ?></a>
    </div>
</section>
