<?php /** 404: «Борт не найден на радаре» (в.128) */ ?>
<section class="err-page">
    <div class="err-radar" aria-hidden="true"><div class="err-sweep"></div><span class="err-dot"></span></div>
    <h1 class="err-code">404</h1>
    <h2 class="err-title"><?= e(__('err.404')) ?></h2>
    <p class="err-sub"><?= e(__('err.404_sub')) ?></p>
    <form class="err-search" onsubmit="return false">
        <input type="search" placeholder="<?= e(__('common.search')) ?> (в.96–98)…" disabled>
        <button class="btn btn--ghost" type="button" title="v0.2">⌕</button>
    </form>
    <div class="err-actions">
        <a class="btn btn--primary" href="<?= url('/') ?>">← <?= e(__('common.home')) ?></a>
        <a class="btn btn--ghost" href="<?= url('/login') ?>"><?= e(__('common.login')) ?></a>
    </div>
</section>
