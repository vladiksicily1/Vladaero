<?php /** Карта споттинг-точек (v0.8.1) */ ?>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<section class="ac-layout">
    <div class="page-head">
        <h1>📍 <?= e(__('spots.title')) ?></h1>
        <div class="ev-filters">
            <select id="spotIcao" class="input">
                <option value=""><?= e(__('spots.all')) ?></option>
                <?php foreach ($airports as $a): $n = 0; foreach ($withPoints as $w) { if ($w['icao'] === $a['icao']) { $n = (int)$w['n']; } } ?>
                <option value="<?= e($a['icao']) ?>"<?= $icao === $a['icao'] ? ' selected' : '' ?>><?= e($a['icao']) ?> — <?= e($a['name_ru']) ?> (<?= $n ?>)</option>
                <?php endforeach; ?>
            </select>
        </div>
    </div>
    <p class="muted"><?= e(__('spots.intro')) ?></p>

    <div class="panel spots-map-wrap"><div id="spotsMap"></div></div>

    <div class="spot-grid">
        <?php foreach ($points as $p): ?>
        <div class="panel spot-card" data-icao="<?= e($p['icao']) ?>">
            <div class="spot-head"><b><?= e($p['title_ru']) ?></b><i class="tag-soon"><?= e($p['icao']) ?></i></div>
            <p class="muted"><?= e(mb_substr((string)$p['description_ru'], 0, 180)) ?><?= mb_strlen((string)$p['description_ru']) > 180 ? '…' : '' ?></p>
            <?php if (!empty($p['light_hint'])): ?><div class="muted small">☀ <?= e($p['light_hint']) ?></div><?php endif; ?>
            <div class="muted small">_gps: <?= e($p['lat'] . ', ' . $p['lng']) ?></div>
        </div>
        <?php endforeach; ?>
        <?php if ($points === []): ?><div class="panel muted"><?= e(__('spots.empty')) ?></div><?php endif; ?>
    </div>

    <?php if (\App\Core\Auth::check()): ?>
    <details class="panel spot-form-box">
        <summary><b>＋ <?= e(__('spots.add')) ?></b></summary>
        <form method="post" action="<?= url('/spots/add') ?>" class="spot-form">
            <?= csrf_field() ?>
            <div class="form-grid">
                <label class="field"><span>ICAO *</span><input type="text" name="icao" maxlength="4" required placeholder="UUEE"></label>
                <label class="field"><span><?= e(__('spots.f_title')) ?> *</span><input type="text" name="title" maxlength="160" required></label>
                <label class="field"><span>Lat *</span><input type="text" name="lat" id="spotLat" required placeholder="55.9841"></label>
                <label class="field"><span>Lng *</span><input type="text" name="lng" id="spotLng" required placeholder="37.4167"></label>
            </div>
            <label class="field"><span><?= e(__('spots.f_desc')) ?> *</span><textarea name="description" rows="3" maxlength="4000" required></textarea></label>
            <label class="field"><span><?= e(__('spots.f_light')) ?></span><input type="text" name="light_hint" maxlength="240" placeholder="<?= e(__('spots.f_light_ph')) ?>"></label>
            <button class="btn btn-primary" type="submit"><?= e(__('spots.submit')) ?></button>
            <span class="muted small"><?= e(__('spots.moderation')) ?></span>
        </form>
    </details>
    <?php endif; ?>
</section>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
(function () {
    var PTS = <?= json_encode(array_map(static fn($p) => [
        'icao' => $p['icao'], 'title' => $p['title_ru'], 'desc' => mb_substr((string)$p['description_ru'], 0, 200),
        'light' => (string)($p['light_hint'] ?? ''), 'lat' => (float)$p['lat'], 'lng' => (float)$p['lng'],
    ], $points), JSON_UNESCAPED_UNICODE) ?>;
    var APS = <?= json_encode(array_map(static fn($a) => [
        'icao' => $a['icao'], 'name' => $a['name_ru'], 'lat' => (float)$a['lat'], 'lng' => (float)$a['lng'],
    ], $airports), JSON_UNESCAPED_UNICODE) ?>;
    var map = L.map('spotsMap', { scrollWheelZoom: false }).setView([48, 20], 3);
    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; OpenStreetMap, &copy; CARTO', maxZoom: 18
    }).addTo(map);
    var group = [];
    APS.forEach(function (a) {
        if (!PTS.some(function (p) { return p.icao === a.icao; })) { return; }
        L.circleMarker([a.lat, a.lng], { radius: 7, color: '#48CAE4', fillOpacity: 0.25 })
            .addTo(map).bindPopup('<b>' + a.icao + '</b> — ' + a.name);
        group.push([a.lat, a.lng]);
    });
    PTS.forEach(function (p) {
        L.marker([p.lat, p.lng], { title: p.title })
            .addTo(map)
            .bindPopup('<b>' + p.title + '</b><br>' + p.desc + (p.light ? '<br><i>☀ ' + p.light + '</i>' : ''));
        group.push([p.lat, p.lng]);
    });
    if (group.length) { map.fitBounds(group, { padding: [30, 30], maxZoom: 12 }); }
    document.getElementById('spotsMap').addEventListener('click', function (e) {
        var c = e.latlng;
        document.getElementById('spotLat').value = c.lat.toFixed(6);
        document.getElementById('spotLng').value = c.lng.toFixed(6);
    });
    document.getElementById('spotIcao').addEventListener('change', function () {
        window.location = this.value ? '<?= url('/spots') ?>?icao=' + this.value : '<?= url('/spots') ?>';
    });
})();
</script>
