<?php
/** Публичный лейаут: сайдбар (в.99), топбар, мобильная нижняя навигация (в.225) */
$unread_count = 0;
try {
    if (\App\Core\Auth::check()) {
        $unread_count = \App\Models\Notification::unreadCount((int)\App\Core\Auth::id());
    }
} catch (\Throwable $e) {
    // при апгрейде без новых таблиц — не ломаем страницу
}
?>
<!DOCTYPE html>
<html lang="<?= e($locale) ?>" data-theme="dark" data-base="<?= e(VA_URL) ?>" data-search-ph="<?= e(__('search.ph')) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($title ?? ($site['site_name'] ?? 'VladAero')) ?></title>
<meta name="description" content="<?= e($site['tagline'] ?? 'Авиационный портал') ?>">
<meta property="og:site_name" content="<?= e($site['site_name'] ?? 'VladAero') ?>">
<meta property="og:title" content="<?= e($title ?? 'VladAero') ?>">
<meta property="og:type" content="website">
<meta name="va-csrf" content="<?= e(\App\Core\Csrf::token()) ?>">
<link rel="icon" href="<?= e(url($site['favicon'] ?? 'assets/images/favicon.svg')) ?>">
<link rel="manifest" href="<?= url('manifest.json') ?>">
<meta name="theme-color" content="#0B132B">
<link rel="apple-touch-icon" href="<?= url('assets/images/icon-192.png') ?>">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<link rel="sitemap" type="application/xml" href="<?= url('/sitemap.xml') ?>">
<link rel="stylesheet" href="<?= asset('css/app.css') ?>">
</head>
<body>
<div class="app-shell">
    <aside class="sidebar" id="sidebar">
        <a class="brand" href="<?= url('/') ?>">
            <img src="<?= e(url($site['logo'] ?? 'assets/images/logo.svg')) ?>" alt="VladAero" class="brand-logo">
            <span class="brand-name"><?= e($site['site_name'] ?? 'VladAero') ?></span>
        </a>
        <nav class="side-nav">
            <a href="<?= url('/') ?>" class="side-link"><span class="side-ico">◈</span><?= e(__('nav.home')) ?></a>
            <a href="<?= url('/aircraft') ?>" class="side-link"><span class="side-ico">✈</span><?= e(__('nav.encyclopedia')) ?></a>
            <a href="<?= url('/articles') ?>" class="side-link"><span class="side-ico">▤</span><?= e(__('nav.articles')) ?></a>
            <a href="<?= url('/airports') ?>" class="side-link"><span class="side-ico">⬡</span><?= e(__('nav.airports')) ?></a>
            <a href="<?= url('/gallery') ?>" class="side-link"><span class="side-ico">▣</span><?= e(__('nav.gallery')) ?></a>
            <a href="<?= url('/radar') ?>" class="side-link"><span class="side-ico">◎</span><?= e(__('nav.radar')) ?><i class="tag-soon">live</i></a>
            <a href="<?= url('/weather') ?>" class="side-link"><span class="side-ico">☁</span><?= e(__('nav.weather')) ?></a>
            <a href="<?= url('/fids') ?>" class="side-link"><span class="side-ico">▦</span><?= e(__('nav.fids')) ?></a>
            <a href="<?= url('/versus') ?>" class="side-link"><span class="side-ico">⚖</span><?= e(__('nav.compare')) ?></a>
            <a href="<?= url('/tools') ?>" class="side-link"><span class="side-ico">⌗</span><?= e(__('nav.calculators')) ?></a>
            <a href="<?= url('/school') ?>" class="side-link"><span class="side-ico">🎓</span><?= e(__('nav.school')) ?></a>
            <a href="<?= url('/clubs') ?>" class="side-link"><span class="side-ico">☰</span><?= e(__('nav.community')) ?></a>
            <a href="<?= url('/events') ?>" class="side-link"><span class="side-ico">📅</span><?= e(__('nav.events')) ?></a>
            <a href="<?= url('/globe') ?>" class="side-link"><span class="side-ico">◐</span><?= e(__('nav.globe')) ?></a>
            <a href="<?= url('/spots') ?>" class="side-link"><span class="side-ico">📍</span><?= e(__('nav.spots')) ?></a>
            <?php if (\App\Core\Auth::check()): ?>
            <a href="<?= url('/feed') ?>" class="side-link"><span class="side-ico">≑</span><?= e(__('nav.feed')) ?></a>
            <a href="<?= url('/im') ?>" class="side-link"><span class="side-ico">✉</span><?= e(__('nav.im')) ?></a>
            <?php endif; ?>
        </nav>
        <div class="side-foot">
            <button class="ghost-btn" id="themeToggle" type="button" title="Светлая / тёмная тема">◐ <span><?= e(__('common.on')) ?></span></button>
            <button class="ghost-btn" id="soundToggle" type="button" title="Звуки интерфейса (v0.6)">♪</button>
        </div>
    </aside>

    <div class="main-col">
        <header class="topbar">
            <button class="burger" id="burger" type="button" aria-label="Меню">☰</button>
            <button class="searchbar" id="searchTrigger" type="button" title="Ctrl+K — глобальный поиск (v0.2)">
                <span class="searchbar-ico">⌕</span>
                <span><?= e(__('common.search')) ?>…</span>
                <kbd>Ctrl K</kbd>
            </button>
            <div class="topbar-spacer"></div>
            <?php if (($auth_user ?? null) === null): ?>
                <a class="top-btn" href="<?= url('/login') ?>"><?= e(__('common.login')) ?></a>
                <a class="top-btn top-btn--primary" href="<?= url('/register') ?>"><?= e(__('common.register')) ?></a>
            <?php else: ?>
                <a class="top-btn ntf-bell<?= $unread_count > 0 ? ' is-hot' : '' ?>" href="<?= url('/profile#notifications') ?>" title="<?= e(__('profile.notifications')) ?>">
                    🔔<?= $unread_count > 0 ? '<b class="ntf-n">' . (int)$unread_count . '</b>' : '' ?>
                </a>
                <?php if (\App\Core\Auth::isAdmin()): ?>
                    <a class="top-btn" href="<?= url('/admin') ?>">⚑ <?= e(__('nav.admin')) ?></a>
                <?php endif; ?>
                <div class="profile-chip">
                    <span class="avatar"><?= e(mb_strtoupper(mb_substr((string)$auth_user['username'], 0, 1))) ?></span>
                    <a class="profile-name" href="<?= url('/profile') ?>"><?= e($auth_user['username']) ?></a>
                    <span class="role-badge role-<?= e($auth_user['role']) ?>"><?= e(__('role.' . $auth_user['role'])) ?></span>
                    <form method="post" action="<?= url('/logout') ?>" class="inline"><?= csrf_field() ?>
                        <button class="top-btn" type="submit"><?= e(__('common.logout')) ?></button>
                    </form>
                </div>
            <?php endif; ?>
        </header>

        <main class="content">
            <?= $content ?? '' ?>
        </main>

        <footer class="footer">
            <div>© <?= date('Y') ?> <?= e($site['site_name'] ?? 'VladAero') ?> · v<?= VA_VERSION ?> · <span class="muted">для тех, кто любит небо</span></div>
            <div class="muted">PHP <?= PHP_VERSION ?> · MySQL · без SMTP — уведомления только через Telegram (v0.5)</div>
            <div class="footer-atc"><?= \App\Core\View::partial('partials/atc-player') ?></div>
</footer>
    </div>
</div>

<nav class="bottom-nav">
    <a href="<?= url('/') ?>" class="bn-item"><span>◈</span><?= e(__('nav.home')) ?></a>
    <a href="<?= url('/radar') ?>" class="bn-item"><span>◎</span><?= e(__('nav.radar')) ?></a>
    <a href="<?= url('/weather') ?>" class="bn-item"><span>☁</span><?= e(__('nav.weather')) ?></a>
    <a href="<?= url('/school') ?>" class="bn-item"><span>🎓</span><?= e(__('nav.school')) ?></a>
    <a href="<?= $auth_user ? url('/profile') : url('/login') ?>" class="bn-item<?= $auth_user && $unread_count > 0 ? ' has-dot' : '' ?>"><span>◉</span><?= e(__('nav.profile')) ?></a>
</nav>

<div id="toasts"><?= \App\Core\View::partial('partials/flash') ?></div>
<?= \App\Core\View::partial('partials/ai-widget') ?>
<script>
window.VA_L_AI = {
    left: <?= json_encode(__('ai.left')) ?>,
    off: <?= json_encode(__('ai.not_configured')) ?>,
    err: <?= json_encode(__('ai.err_net')) ?>
};
</script>
<script src="<?= asset('js/app.js') ?>" defer></script>
<script src="<?= asset('js/blocks-front.js') ?>" defer></script>
<script src="<?= asset('js/wx.js') ?>" defer></script>
<script src="<?= asset('js/atc-player.js') ?>" defer></script>
<script src="<?= asset('js/ai-widget.js') ?>" defer></script>
<script src="<?= asset('js/pwa.js') ?>" defer></script>
</body>
</html>
