<?php /** Лейаут авторизации: центрированная стеклянная карта */ ?>
<!DOCTYPE html>
<html lang="<?= e($locale) ?>" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($title ?? 'VladAero') ?></title>
<link rel="icon" href="<?= e(url($site['favicon'] ?? 'assets/images/favicon.svg')) ?>">
<link rel="stylesheet" href="<?= asset('css/app.css') ?>">
</head>
<body class="auth-body">
<div class="auth-sky" aria-hidden="true">
    <div class="radar-bg"></div>
</div>
<main class="auth-wrap">
    <a class="auth-brand" href="<?= url('/') ?>">
        <img src="<?= e(url($site['logo'] ?? 'assets/images/logo.svg')) ?>" alt="VladAero">
    </a>
    <?= $content ?? '' ?>
    <p class="auth-copy">© <?= date('Y') ?> <?= e($site['site_name'] ?? 'VladAero') ?> · v<?= VA_VERSION ?></p>
</main>
<div id="toasts"><?= \App\Core\View::partial('partials/flash') ?></div>
<script src="<?= asset('js/app.js') ?>" defer></script>
</body>
</html>
