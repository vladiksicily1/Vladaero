<?php /** Лейаут админки: стиль центра управления полётами / NOC (в.234) */ ?>
<!DOCTYPE html>
<html lang="<?= e($locale) ?>" data-theme="dark" data-base="<?= e(VA_URL) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="robots" content="noindex, nofollow">
<meta name="va-csrf" content="<?= e(\App\Core\Csrf::token()) ?>">
<meta name="va-base" content="<?= e(VA_URL) ?>">
<title><?= e($title ?? 'VladAero Admin') ?></title>
<link rel="icon" href="<?= e(url($site['favicon'] ?? 'assets/images/favicon.svg')) ?>">
<link rel="stylesheet" href="<?= asset('css/app.css') ?>">
</head>
<body class="admin-body">
<div class="admin-shell">
    <aside class="admin-side">
        <a class="brand" href="<?= url('/admin') ?>">
            <img src="<?= e(url($site['logo'] ?? 'assets/images/logo.svg')) ?>" alt="" class="brand-logo">
            <span class="brand-name"><?= e($site['site_name'] ?? 'VladAero') ?> <small>NOC</small></span>
        </a>
        <nav class="side-nav">
            <?php $staffRole = \App\Core\Auth::role(); ?>
            <?php if (in_array($staffRole, ['moderator', 'screener'], true)): ?>
                <?php // Персонал скрининга (в.120) видит только свою зону ?>
                <div class="side-group"><?= e(__('admin.moderation')) ?></div>
                <a href="<?= url('/admin/photos?tab=pending') ?>" class="side-link">▤ <?= e(__('admin.photos')) ?></a>
            <?php else: ?>
            <a href="<?= url('/admin') ?>" class="side-link"><?= e(__('admin.dashboard')) ?></a>
            <a href="<?= url('/admin/aircraft') ?>" class="side-link"><?= e(__('admin.aircraft')) ?></a>
            <a href="<?= url('/admin/articles') ?>" class="side-link"><?= e(__('admin.articles')) ?></a>
            <a href="<?= url('/admin/airports') ?>" class="side-link"><?= e(__('admin.airports')) ?></a>
            <a href="<?= url('/admin/media') ?>" class="side-link"><?= e(__('admin.media')) ?></a>
            <a href="<?= url('/admin/photos?tab=pending') ?>" class="side-link">▤ <?= e(__('admin.photos')) ?> <i class="tag-soon">new</i></a>
            <a href="<?= url('/admin/users') ?>" class="side-link"><?= e(__('admin.users')) ?></a>
            <a href="<?= url('/admin/comments?status=pending') ?>" class="side-link">💬 <?= e(__('admin.comments')) ?></a>
            <a href="<?= url('/admin/events') ?>" class="side-link">📅 <?= e(__('admin.events')) ?></a>
            <a href="<?= url('/admin/clubs') ?>" class="side-link">☰ <?= e(__('admin.clubs')) ?></a>
            <a href="<?= url('/admin/lessons') ?>" class="side-link">🎓 <?= e(__('admin.lessons')) ?></a>
            <a href="<?= url('/admin/agent') ?>" class="side-link">✱ <?= e(__('admin.ai_agent')) ?> <i class="tag-soon">50 tools</i></a>
            <a href="<?= url('/admin/spots?tab=pending') ?>" class="side-link">📍 Споттинг-точки</a>
            <a href="<?= url('/admin/push') ?>" class="side-link">🔔 Web Push</a>
            <a href="<?= url('/admin/telegram') ?>" class="side-link">✈ Telegram</a>
            <a href="<?= url('/admin/settings') ?>" class="side-link"><?= e(__('admin.settings')) ?></a>
            <a href="<?= url('/admin/system') ?>" class="side-link"><?= e(__('admin.system')) ?></a>
            <a href="<?= url('/admin/logs') ?>" class="side-link"><?= e(__('admin.logs')) ?></a>
            <div class="side-group"><?= e(__('admin.content')) ?> / <?= e(__('admin.moderation')) ?></div>
            <?php endif; ?>
        </nav>
        <div class="side-foot">
            <a class="ghost-btn" href="<?= url('/') ?>">← <?= e(__('admin.view_site')) ?></a>
        </div>
    </aside>

    <div class="admin-main">
        <header class="admin-top">
            <div class="admin-crumb"><?= e($title ?? '') ?></div>
            <div class="admin-top-right">
                <?php if (($site['maintenance'] ?? '0') === '1'): ?>
                    <span class="warn-pill">MAINTENANCE ON</span>
                <?php endif; ?>
                <span class="muted">v<?= VA_VERSION ?></span>
                <span class="profile-chip">
                    <span class="avatar"><?= e(mb_strtoupper(mb_substr((string)($auth_user['username'] ?? 'A'), 0, 1))) ?></span>
                    <?= e($auth_user['username'] ?? '') ?>
                </span>
            </div>
        </header>
        <main class="admin-content"><?= $content ?? '' ?></main>
    </div>
</div>
<div id="toasts"><?= \App\Core\View::partial('partials/flash') ?></div>
<script src="<?= asset('js/app.js') ?>" defer></script>
<script src="<?= asset('js/blocks-editor.js') ?>" defer></script>
<script src="<?= asset('js/blocks-front.js') ?>" defer></script>
</body>
</html>
