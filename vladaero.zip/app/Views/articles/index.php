<?php /** Публичный список статей (в.42) */ ?>
<section class="page-head">
    <nav class="crumbs"><a href="<?= url('/') ?>"><?= e(__('nav.home')) ?></a><span>›</span><span><?= e(__('art.section')) ?></span></nav>
    <h1><?= e(__('art.section')) ?></h1>
    <form method="get" action="<?= url('/articles') ?>" class="filter-bar">
        <input type="search" name="q" value="<?= e($q) ?>" placeholder="<?= e(__('common.search')) ?>…" class="filter-q">
        <button class="btn btn--primary" type="submit">⌕</button>
    </form>
</section>

<?php if ($rows === []): ?>
    <div class="empty-state"><div class="hangar">📰</div><h2><?= e(__('art.empty')) ?></h2>
        <p class="muted"><?= e(__('art.empty_sub')) ?></p></div>
<?php else: ?>
<div class="art-grid">
    <?php foreach ($rows as $a): ?>
        <a class="art-card" href="<?= url('/articles/' . $a['slug']) ?>">
            <?php if (!empty($a['cover'])): ?>
                <img class="art-cover" src="<?= e(url($a['cover'])) ?>" alt="<?= e($a['title_ru']) ?>" loading="lazy">
            <?php endif; ?>
            <div class="art-body">
                <h3><?= e($a['title_ru']) ?></h3>
                <?php if ($a['excerpt_ru']): ?><p class="muted"><?= e(mb_substr((string)$a['excerpt_ru'], 0, 160)) ?>…</p><?php endif; ?>
                <div class="muted small mono"><?= e(date('d.m.Y', strtotime((string)($a['published_at'] ?? $a['created_at'])))) ?> · <?= e($a['author'] ?? __('art.editorial')) ?> · 👁 <?= (int)$a['views'] ?></div>
            </div>
        </a>
    <?php endforeach; ?>
</div>
<?php if ($pages > 1): ?>
    <div class="pager"><?php for ($p = 1; $p <= $pages; $p++): ?><a class="pg <?= $p === $page ? 'is-active' : '' ?>" href="<?= url('/articles') ?>?q=<?= urlencode($q) ?>&amp;page=<?= $p ?>"><?= $p ?></a><?php endfor; ?></div>
<?php endif; ?>
<?php endif; ?>
