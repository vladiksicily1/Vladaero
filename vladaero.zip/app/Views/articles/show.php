<?php /** Статья: блочный контент (в.108–115) + NewsArticle (в.103) */ ?>
<section class="page-head">
    <nav class="crumbs"><a href="<?= url('/') ?>"><?= e(__('nav.home')) ?></a><span>›</span>
        <a href="<?= url('/articles') ?>"><?= e(__('art.section')) ?></a><span>›</span><span><?= e(mb_substr($a['title_ru'], 0, 40)) ?></span></nav>
    <script type="application/ld+json"><?= json_encode($jsonLd, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?></script>
</section>

<article class="art-full">
    <?php if ($isPreview): ?>
        <div class="alert alert--warn">👁 Предпросмотр черновика — статья ещё не опубликована</div>
    <?php endif; ?>
    <h1><?= e($a['title_ru']) ?></h1>
    <div class="muted art-meta mono"><?= e(date('d.m.Y H:i', strtotime((string)($a['published_at'] ?? $a['created_at'])))) ?>
        · <?= e($a['author'] ?? __('art.editorial')) ?> · 👁 <?= (int)$a['views'] ?>
        <?php if (\App\Core\Auth::check() && (int)($a['author_id'] ?? 0) > 0 && (int)$a['author_id'] !== (int)\App\Core\Auth::id()): ?>
        <button class="btn btn--sm follow-btn" data-author="<?= (int)$a['author_id'] ?>"><?= $authorFollowing ? '✓ ' . e(__('feed.following')) : '＋ ' . e(__('feed.follow')) ?></button>
        <?php endif; ?>
    </div>
    <?php if (!empty($a['excerpt_ru'])): ?><p class="art-lead muted"><?= e($a['excerpt_ru']) ?></p><?php endif; ?>

    <?= $blocksHtml !== '' ? $blocksHtml : '<p class="muted">' . e(__('art.no_blocks')) . '</p>' ?>
</article>

<?= \App\Core\View::partial('partials/bookmark', ['bmType' => 'article', 'bmId' => (int)$a['id'], 'bmBack' => '/articles/' . $a['slug']]) ?>
<?= \App\Core\View::partial('partials/comments', [
    'cType' => 'article',
    'cId' => (int)$a['id'],
    'cTree' => \App\Services\CommentService::tree('article', (int)$a['id'], \App\Core\Auth::id() ?? 0),
    'cBack' => '/articles/' . $a['slug'],
]) ?>
