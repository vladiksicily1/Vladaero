<?php
/** Универсальный блочный редактор (в.108, 111–115). Подключается в любую форму. */
/** @var string $blockEntity @var int $blockEntityId @var string $blocksJson */
?>
<div class="vabe" id="vabe"
     data-entity="<?= e($blockEntity) ?>"
     data-entity-id="<?= (int)$blockEntityId ?>"
     data-base="<?= e(url('/')) ?>">
    <div class="vabe-head">
        <b>▦ Блочный конструктор</b>
        <span class="muted small">27 типов · блоки доступны для любых разделов</span>
        <span class="vabe-status muted small" id="vabeStatus"></span>
    </div>
    <div class="vabe-draft" id="vabeDraftBanner" hidden></div>
    <div class="vabe-list" id="vabeList"></div>
    <div class="vabe-actions">
        <button type="button" class="btn btn--primary" id="vabeAdd">＋ Добавить блок</button>
        <button type="button" class="btn btn--ghost" id="vabeFromMedia">🖼 Из медиатеки</button>
    </div>
    <input type="hidden" name="blocks_json" id="vabeJson" value="<?= e($blocksJson) ?>">
</div>
