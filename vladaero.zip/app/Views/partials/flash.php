<?php /** Toast-уведомления (в.229) */ ?>
<?php foreach (flashes() as $f): ?>
    <div class="toast toast--<?= e($f['type']) ?>" role="status">
        <span class="toast-msg"><?= $f['msg'] /* экранируется при flash() в контроллерах */ ?></span>
        <button class="toast-x" type="button" aria-label="×">×</button>
    </div>
<?php endforeach; ?>
