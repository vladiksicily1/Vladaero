<?php
/**
 * Плавающий ИИ-виджет (в.159, 273): кнопка-радар, чипсы, тона, SSE-стрим.
 * Подключается в layouts/main.php. Данные — /api/ai/state, /api/ai/chat.
 */
?>
<div class="aiw" id="aiWidget" hidden>
    <div class="aiw-panel">
        <div class="aiw-head">
            <span class="aiw-logo">◎</span>
            <b>VladAero Copilot</b>
            <select id="aiwTone" class="aiw-tone">
                <option value="instructor">✈ <?= e(__('ai.tone_instructor')) ?></option>
                <option value="spotter">▣ <?= e(__('ai.tone_spotter')) ?></option>
                <option value="academic">📖 <?= e(__('ai.tone_academic')) ?></option>
            </select>
            <button class="aiw-x" id="aiwClose">✕</button>
        </div>
        <div class="aiw-chips" id="aiwChips">
            <button data-q="<?= e(__('ai.chip_wx')) ?>">☁ <?= e(__('ai.chip_wx')) ?></button>
            <button data-q="<?= e(__('ai.chip_cmp')) ?>">⚖ <?= e(__('ai.chip_cmp')) ?></button>
            <button data-q="<?= e(__('ai.chip_ttx')) ?>">✈ <?= e(__('ai.chip_ttx')) ?></button>
            <button data-q="<?= e(__('ai.chip_metar')) ?>">⌗ <?= e(__('ai.chip_metar')) ?></button>
        </div>
        <div class="aiw-msgs" id="aiwMsgs">
            <div class="aiw-msg is-ai"><div class="aiw-bubble"><?= e(__('ai.hello')) ?></div></div>
        </div>
        <div class="aiw-input">
            <textarea id="aiwText" rows="1" placeholder="<?= e(__('ai.placeholder')) ?>"></textarea>
            <button class="btn btn-primary" id="aiwSend">➤</button>
        </div>
        <div class="aiw-foot muted" id="aiwFoot"></div>
    </div>
</div>
<button class="aiw-fab" id="aiwFab" title="Ctrl+J — ИИ-штурман" aria-label="<?= e(__('ai.title')) ?>">◎</button>
