<?php
/**
 * Комментарии с ветками (в.27) + форма. Переменные: $cType, $cId, $cTree, $cBack.
 */
?>
<section class="comments" id="comments">
    <h3 class="side-title">💬 <?= e(__('cm.title')) ?> <span class="muted" id="cmCount"><?= count($cTree) ?></span></h3>

    <div class="cm-list">
        <?php if ($cTree === []): ?>
            <p class="muted" id="cmEmpty"><?= e(__('cm.empty')) ?></p>
        <?php endif; ?>
        <?php foreach ($cTree as $root): ?>
            <?= \App\Core\View::partial('partials/comment', ['c' => $root, 'cBack' => $cBack, 'depth' => 0]) ?>
            <?php foreach ($root['children'] ?? [] as $child): ?>
                <?= \App\Core\View::partial('partials/comment', ['c' => $child, 'cBack' => $cBack, 'depth' => 1]) ?>
            <?php endforeach; ?>
        <?php endforeach; ?>
    </div>

    <?php if (\App\Core\Auth::check()): ?>
    <form method="post" action="<?= url('/comments') ?>" class="cm-form">
        <?= csrf_field() ?>
        <input type="hidden" name="type" value="<?= e($cType) ?>">
        <input type="hidden" name="id" value="<?= (int)$cId ?>">
        <input type="hidden" name="back" value="<?= e($cBack) ?>">
        <input type="hidden" name="parent" value="0" id="cmParent">
        <div class="cm-reply-bar" id="cmReplyBar" hidden>
            <span class="muted small" id="cmReplyTo"></span>
            <button type="button" class="link-btn" id="cmCancel">✕ <?= e(__('cm.cancel_reply')) ?></button>
        </div>
        <textarea name="body" rows="3" maxlength="2000" required
                  placeholder="<?= e(__('cm.placeholder')) ?>" id="cmBody"></textarea>
        <button class="btn btn-primary" type="submit">✈ <?= e(__('cm.submit')) ?></button>
    </form>
    <?php else: ?>
    <p class="muted"><?= e(__('cm.need_login')) ?> <a href="<?= url('/login') ?>"><?= e(__('common.login')) ?></a></p>
    <?php endif; ?>
</section>
<script>
(function () {
    var form = document.getElementById('cmBody');
    if (!form) { return; }
    var parent = document.getElementById('cmParent'),
        bar = document.getElementById('cmReplyBar'),
        to = document.getElementById('cmReplyTo');
    document.querySelectorAll('[data-reply]').forEach(function (b) {
        b.addEventListener('click', function () {
            parent.value = b.getAttribute('data-reply');
            to.textContent = '↩ ' + (b.getAttribute('data-name') || '');
            bar.hidden = false;
            document.getElementById('cmBody').focus();
        });
    });
    var cancel = document.getElementById('cmCancel');
    cancel && cancel.addEventListener('click', function () {
        parent.value = '0'; bar.hidden = true;
    });
})();
</script>
