<?php
/** Один комментарий. Переменные: $c, $cBack, $depth. */
/** @var array $c @var string $cBack @var int $depth */
$isPending = ($c['status'] ?? '') === 'pending';
?>
<article class="cm-item <?= $depth > 0 ? 'cm-child' : '' ?> <?= $isPending ? 'cm-pending' : '' ?>" id="comment-<?= (int)$c['id'] ?>">
    <div class="cm-head">
        <span class="avatar avatar--sm"><?= e(mb_strtoupper(mb_substr((string)$c['username'], 0, 1))) ?></span>
        <b><?= e($c['username']) ?></b>
        <?php if (($c['role'] ?? '') === 'admin' || ($c['role'] ?? '') === 'moderator'): ?><i class="role-badge role-<?= e($c['role']) ?>"><?= e(__('role.' . $c['role'])) ?></i><?php endif; ?>
        <time class="muted small"><?= e(substr((string)$c['created_at'], 0, 16)) ?></time>
        <?php if ($isPending): ?><i class="tag-soon"><?= e(__('cm.pending')) ?></i><?php endif; ?>
    </div>
    <div class="cm-body"><?= nl2br(e($c['body'])) ?></div>
    <?php if ($depth === 0 && \App\Core\Auth::check()): ?>
    <button type="button" class="link-btn cm-reply" data-reply="<?= (int)$c['id'] ?>" data-name="<?= e($c['username']) ?>">↩ <?= e(__('cm.reply')) ?></button>
    <?php endif; ?>
</article>
