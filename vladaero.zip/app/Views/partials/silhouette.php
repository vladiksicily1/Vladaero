<?php /** Силуэт самолёта-заглушка (inline SVG) */ ?>
<svg viewBox="0 0 120 60" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" class="silhouette">
  <g fill="currentColor" opacity="0.85">
    <path d="M58 6 L62 6 L61 46 L59 46 Z"/>
    <path d="M60 18 L92 30 L92 33 L61 27 L59 27 L28 33 L28 30 Z"/>
    <path d="M59.5 38 L72 46 L72 48 L60 44 L58 44 L46 48 L46 46 Z"/>
    <path d="M60 44 L61 52 L60 56 L59 52 Z"/>
  </g>
</svg>
