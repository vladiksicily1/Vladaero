<?php
/**
 * Мини-плеер LiveATC в подвале (в.231): выбор аэропорта и канала УВД.
 * Прямые потоки LiveATC закрыты Cloudflare — .pls открывается во внешнем плеере,
 * либо проигрывается прямой URL (поле ниже).
 */
?>
<div class="atc" id="atcPlayer">
    <span class="atc-ico">♪</span>
    <input type="text" id="atcIcao" maxlength="4" placeholder="ICAO" value="UUEE" title="ICAO аэропорта">
    <select id="atcCh">
        <option value="twr">TWR</option>
        <option value="app">APP</option>
        <option value="gnd">GND</option>
        <option value="dep">DEP</option>
        <option value="atis">ATIS</option>
    </select>
    <button class="atc-open" id="atcOpen" title="Открыть поток LiveATC во внешнем плеере">▶ LiveATC</button>
    <span class="atc-sep">|</span>
    <input type="url" id="atcUrl" placeholder="<?= e(__('atc.direct_url')) ?>" class="atc-url">
    <button class="atc-open" id="atcPlay" title="<?= e(__('atc.play_direct')) ?>">▶</button>
    <span class="atc-wave" id="atcWave" hidden><?php for ($i = 0; $i < 12; $i++) : ?><i></i><?php endfor; ?></span>
    <audio id="atcAudio" preload="none"></audio>
</div>
