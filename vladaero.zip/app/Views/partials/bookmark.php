<?php
/**
 * Кнопка закладки (в.26). Переменные: $bmType (aircraft|article|airport), $bmId, $bmBack.
 */
$bmActive = false;
if (\App\Core\Auth::check()) {
    $bmActive = \App\Core\Database::i()->one(
        'SELECT id FROM `{p}bookmarks` WHERE user_id = ? AND entity_type = ? AND entity_id = ?',
        [(int)\App\Core\Auth::id(), $bmType, (int)$bmId]) !== null;
}
?>
<form method="post" action="<?= url('/bookmarks/toggle') ?>" class="inline bm-form">
    <?= csrf_field() ?>
    <input type="hidden" name="type" value="<?= e($bmType) ?>">
    <input type="hidden" name="id" value="<?= (int)$bmId ?>">
    <input type="hidden" name="back" value="<?= e($bmBack) ?>">
    <button class="btn <?= $bmActive ? 'btn-primary' : 'btn--ghost' ?> btn--sm" type="submit" title="<?= e(__('profile.bookmarks')) ?>">
        <?= $bmActive ? '★' : '☆' ?>
    </button>
</form>
