<?php
/**
 * Инструменты пилота (в.46–50): калькуляторы, декодеры, глоссарий.
 * @var array $airports (icao,name_ru,lat,lng) — пресеты ортодромии
 */
?>
<section class="ac-layout">
    <div class="page-head">
        <div>
            <h1>⌗ <?= e(__('tools.title')) ?></h1>
            <p class="muted"><?= e(__('tools.sub')) ?></p>
        </div>
        <div>
            <button class="btn" id="toolShare" type="button">🔗 <?= e(__('tools.share')) ?></button>
            <button class="btn" id="toolPrint" type="button">🖨 <?= e(__('tools.print')) ?></button>
        </div>
    </div>

    <nav class="scr-tabs" id="toolTabs">
        <a href="#calc" class="is-cur">⌗ <?= e(__('tools.tab_calc')) ?></a>
        <a href="#notam">⚠ NOTAM</a>
        <a href="#squawk">◔ Squawk</a>
        <a href="#glossary">📖 <?= e(__('tools.tab_glossary')) ?></a>
        <a href="<?= url('/tools/holding') ?>">⌖ <?= e(__('holding.title')) ?> ↗</a>
    </nav>

    <!-- ======== Калькуляторы (в.46) ======== -->
    <div class="tool-panel" id="panel-calc">
        <div class="tools-grid">

            <div class="panel tool-card" data-calc="conv">
                <div class="panel-head"><h3>⇄ <?= e(__('tools.conv')) ?></h3></div>
                <div class="tool-row">
                    <input type="number" id="cvV" value="100" step="any">
                    <select id="cvFrom"></select>
                    <b>→</b>
                    <select id="cvTo"></select>
                </div>
                <div class="tool-out" id="cvOut">—</div>
            </div>

            <div class="panel tool-card" data-calc="wind">
                <div class="panel-head"><h3>💨 <?= e(__('tools.wind')) ?></h3></div>
                <div class="tool-row">
                    <label><?= e(__('tools.rwy')) ?> <input type="text" id="wdRwy" placeholder="25 / 250" value="25"></label>
                    <label><?= e(__('tools.wdir')) ?> <input type="number" id="wdDir" value="280" min="0" max="360"></label>
                    <label><?= e(__('tools.wspd')) ?> <input type="number" id="wdSpd" value="12" min="0" step="any"></label>
                </div>
                <div class="tool-out" id="wdOut">—</div>
            </div>

            <div class="panel tool-card" data-calc="da">
                <div class="panel-head"><h3>⛰ <?= e(__('tools.da')) ?></h3></div>
                <div class="tool-row">
                    <label><?= e(__('tools.elev')) ?> <input type="number" id="daElev" value="0" step="any"> ft</label>
                    <label><?= e(__('tools.oat')) ?> <input type="number" id="daOat" value="15" step="any"> °C</label>
                    <label>QNH <input type="number" id="daQnh" value="1013" step="any"> hPa</label>
                </div>
                <div class="tool-out" id="daOut">—</div>
            </div>

            <div class="panel tool-card" data-calc="glide">
                <div class="panel-head"><h3>∠ <?= e(__('tools.glide')) ?></h3></div>
                <div class="tool-row">
                    <label>GS <input type="number" id="glGs" value="140" min="0" step="any"> kt</label>
                    <label><?= e(__('tools.angle')) ?> <input type="number" id="glAng" value="3" min="1" max="9" step="0.1">°</label>
                </div>
                <div class="tool-out" id="glOut">—</div>
            </div>

            <div class="panel tool-card tool-card-wide" data-calc="gc">
                <div class="panel-head"><h3>🌍 <?= e(__('tools.gc')) ?></h3></div>
                <div class="tool-row">
                    <label>A
                        <select id="gcA"></select>
                        <input type="number" id="gcAlat" placeholder="lat" step="any">
                        <input type="number" id="gcAlon" placeholder="lon" step="any">
                    </label>
                    <label>B
                        <select id="gcB"></select>
                        <input type="number" id="gcBlat" placeholder="lat" step="any">
                        <input type="number" id="gcBlon" placeholder="lon" step="any">
                    </label>
                    <label>GS <input type="number" id="gcGs" value="450" min="1"> kt</label>
                </div>
                <div class="tool-out" id="gcOut">—</div>
            </div>

            <div class="panel tool-card tool-card-wide" data-calc="wb">
                <div class="panel-head"><h3>⚖ <?= e(__('tools.wb')) ?></h3></div>
                <table class="wb-table">
                    <thead><tr><th><?= e(__('tools.item')) ?></th><th><?= e(__('tools.weight')) ?>, кг</th><th><?= e(__('tools.arm')) ?>, см</th><th></th></tr></thead>
                    <tbody id="wbRows"></tbody>
                    <tfoot>
                    <tr><td colspan="4"><button class="btn" id="wbAdd" type="button">+ <?= e(__('tools.add_row')) ?></button></td></tr>
                    <tr class="wb-total"><td><?= e(__('tools.total')) ?></td><td id="wbTw">0</td><td id="wbCg">—</td><td id="wbTm">0</td></tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>

    <!-- ======== NOTAM (в.47) ======== -->
    <div class="tool-panel" id="panel-notam" hidden>
        <div class="panel">
            <div class="panel-head"><h3>⚠ <?= e(__('tools.notam_decoder')) ?></h3></div>
            <textarea id="ntIn" rows="6" placeholder="LIRR A0123/26 — Q) LIRR/QWXXX/IV/NBO/W /0002/0052/4123N01221E005 …"></textarea>
            <button class="btn btn-primary" id="ntBtn" type="button"><?= e(__('tools.decode')) ?></button>
            <div id="ntOut" class="nt-out"></div>
        </div>
    </div>

    <!-- ======== Squawk ======== -->
    <div class="tool-panel" id="panel-squawk" hidden>
        <div class="panel">
            <div class="panel-head"><h3>◔ <?= e(__('tools.squawk_decoder')) ?></h3></div>
            <div class="tool-row">
                <input type="text" id="sqIn" maxlength="4" placeholder="7700" value="7700" inputmode="numeric">
            </div>
            <div class="tool-out" id="sqOut"></div>
        </div>
    </div>

    <!-- ======== Глоссарий (в.47) ======== -->
    <div class="tool-panel" id="panel-glossary" hidden>
        <div class="panel">
            <input type="search" id="glQ" class="fids-filter" placeholder="<?= e(__('tools.glossary_ph')) ?>">
            <dl class="kv" id="glList"></dl>
        </div>
    </div>
</section>
<script>
window.VA_AIRPORTS = <?= json_encode(array_map(static fn($a) => [
    'i' => strtoupper($a['icao']), 'n' => $a['name_ru'], 'la' => (float)$a['lat'], 'lo' => (float)$a['lng'],
], $airports), JSON_UNESCAPED_UNICODE) ?: '[]' ?>;
</script>
<script>
window.VA_L_TOOLS = {
    share: <?= json_encode(__('tools.share')) ?>, copied: <?= json_encode(__('tools.copied')) ?>,
    manual: <?= json_encode(__('tools.manual')) ?>, headwind: <?= json_encode(__('tools.hw')) ?>,
    tailwind: <?= json_encode(__('tools.tw')) ?>, left: <?= json_encode(__('tools.left')) ?>,
    right: <?= json_encode(__('tools.right')) ?>, course: <?= json_encode(__('tools.course')) ?>,
    item_ph: <?= json_encode(__('tools.item_ph')) ?>, ac_empty: <?= json_encode(__('tools.ac_empty')) ?>,
    pilot: <?= json_encode(__('tools.pilot')) ?>, fuel: <?= json_encode(__('tools.fuel')) ?>
};
window.VA_BASE = <?= json_encode(VA_URL) ?>;
</script>
<script src="<?= e(asset('js/tools.js')) ?>" defer></script>
