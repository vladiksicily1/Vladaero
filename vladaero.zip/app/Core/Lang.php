<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Локализация интерфейса. Старт — русский, структура готова к английскому (вопрос 121).
 */
final class Lang
{
    private static array $dict = [];
    private static string $locale = 'ru';

    public static function init(?string $locale = null): void
    {
        $locale ??= (string)(\App\Models\Setting::all()['default_lang'] ?? 'ru');
        if (!in_array($locale, ['ru', 'en'], true)) {
            $locale = 'ru';
        }
        self::$locale = $locale;
        $file = VA_APP . '/lang/' . $locale . '.php';
        self::$dict = is_file($file) ? (array)require $file : [];
        // Фолбэк на русский для отсутствующих ключей
        if ($locale !== 'ru') {
            $ru = VA_APP . '/lang/ru.php';
            if (is_file($ru)) {
                self::$dict = self::$dict + (array)require $ru;
            }
        }
    }

    public static function locale(): string
    {
        return self::$locale;
    }

    public static function t(string $key, array $replace = []): string
    {
        $s = self::$dict[$key] ?? $key;
        foreach ($replace as $k => $v) {
            $s = str_replace(':' . $k, (string)$v, $s);
        }
        return $s;
    }
}
