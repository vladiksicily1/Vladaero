<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Простой роутер с шаблонами {param}, группами и middleware.
 */
final class Router
{
    /** @var array<int, array{method:string,pattern:string,action:string|callable,middleware:list<string>}> */
    private array $routes = [];
    /** @var array<int, array{prefix:string,middleware:list<string>}> */
    private array $groupStack = [];
    /** Карта middleware: имя → класс */
    private const MIDDLEWARE = [
        'auth'       => \App\Core\Middleware\RequireAuth::class,
        'admin'      => \App\Core\Middleware\RequireAdmin::class,
        'staff'      => \App\Core\Middleware\RequireStaff::class,
    ];

    public function get(string $pattern, string|callable $action): void
    {
        $this->add('GET', $pattern, $action);
    }

    public function post(string $pattern, string|callable $action): void
    {
        $this->add('POST', $pattern, $action);
    }

    private function add(string $method, string $pattern, string|callable $action): void
    {
        $prefix = implode('', array_column($this->groupStack, 'prefix'));
        $middleware = [];
        foreach ($this->groupStack as $g) {
            $middleware = array_merge($middleware, $g['middleware']);
        }
        $this->routes[] = [
            'method'     => $method,
            'pattern'    => rtrim($prefix . '/' . ltrim($pattern, '/'), '/') ?: '/',
            'action'     => $action,
            'middleware' => array_values(array_unique($middleware)),
        ];
    }

    public function group(string $prefix, callable $callback, array $middleware = []): void
    {
        $this->groupStack[] = ['prefix' => '/' . trim($prefix, '/'), 'middleware' => $middleware];
        $callback($this);
        array_pop($this->groupStack);
    }

    public function dispatch(string $method, string $path): void
    {
        foreach ($this->routes as $route) {
            if ($route['method'] !== $method) {
                continue;
            }
            $regex = '#^' . preg_replace('#\{([a-zA-Z_][a-zA-Z0-9_]*)\}#', '(?P<$1>[^/]+)', $route['pattern']) . '$#u';
            if (!preg_match($regex, $path, $m)) {
                continue;
            }
            $params = [];
            foreach ($m as $k => $v) {
                if (!is_int($k)) {
                    $params[] = rawurldecode($v);
                }
            }
            foreach ($route['middleware'] as $name) {
                $class = self::MIDDLEWARE[$name] ?? null;
                if ($class === null) {
                    throw new \RuntimeException("Неизвестный middleware: $name");
                }
                (new $class())->handle();
            }
            $this->invoke($route['action'], $params);
            return;
        }

        http_response_code(404);
        echo View::render('errors/404', [], 'main');
    }

    private function invoke(string|callable $action, array $params): void
    {
        if (is_string($action) && str_contains($action, '@')) {
            [$ctrl, $method] = explode('@', $action, 2);
            $class = 'App\\Controllers\\' . $ctrl;
            if (!class_exists($class)) {
                throw new \RuntimeException("Контроллер не найден: $class");
            }
            $instance = new $class();
            $instance->{$method}(...$params);
            return;
        }
        call_user_func_array($action, $params);
    }
}
