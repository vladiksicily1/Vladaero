<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Рендер шаблонов с лейаутами: app/Views/{view}.php → layouts/{layout}.php
 */
final class View
{
    public static function render(string $view, array $data = [], string $layout = 'main'): string
    {
        $content = self::partial($view, $data);
        $data['content'] = $content;
        return self::partial('layouts/' . $layout, $data);
    }

    /** Частичный шаблон (без лейаута) */
    public static function partial(string $view, array $data = []): string
    {
        $file = VA_APP . '/Views/' . str_replace('.', '/', $view) . '.php';
        if (!is_file($file)) {
            throw new \RuntimeException("Шаблон не найден: $view");
        }

        $data['site'] = self::site();
        $data['auth_user'] = Auth::user();
        $data['locale'] = Lang::locale();

        extract($data, EXTR_SKIP);
        ob_start();
        try {
            require $file;
        } catch (\Throwable $e) {
            ob_end_clean();
            throw $e;
        }
        return (string)ob_get_clean();
    }

    /** Настройки сайта + значения по умолчанию, доступны во всех шаблонах как $site */
    private static function site(): array
    {
        try {
            $all = \App\Models\Setting::all();
        } catch (\Throwable) {
            $all = [];
        }
        return $all + \App\Models\Setting::DEFAULTS;
    }
}
