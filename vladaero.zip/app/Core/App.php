<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Ядро приложения: сессии, обработка ошибок, заголовки безопасности, запуск роутера.
 */
final class App
{
    public function __construct()
    {
        error_reporting(E_ALL);
        ini_set('display_errors', VA_DEBUG ? '1' : '0');
        ini_set('log_errors', '1');
        ini_set('error_log', VA_ROOT . '/logs/php.log');

        set_exception_handler([$this, 'handleException']);
        set_error_handler(static function (int $no, string $str, string $file, int $line): bool {
            if (!(error_reporting() & $no)) {
                return false;
            }
            Logger::log('WARNING', "PHP $no: $str in $file:$line");
            return true;
        });
        register_shutdown_function(static function (): void {
            $e = error_get_last();
            if ($e && in_array($e['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
                Logger::log('ERROR', 'FATAL: ' . $e['message'] . ' in ' . $e['file'] . ':' . $e['line']);
                http_response_code(500);
            }
        });

        $this->startSession();
        $this->sendSecurityHeaders();
        Lang::init();
    }

    public function run(): void
    {
        // Автомиграции БД (в.285): применяет новые migrations/*.sql при обновлении
        try {
            \App\Services\MigrationService::run();
        } catch (\Throwable $e) {
            Logger::log('WARNING', 'MigrationService.run: ' . $e->getMessage());
        }

        // Режим технического обслуживания (вопрос 129): гости видят заглушку, админы проходят
        try {
            $maintenance = (string)setting('maintenance', '0') === '1';
        } catch (\Throwable) {
            $maintenance = false;
        }
        $path = Request::path();
        $isAdminArea = str_starts_with($path, '/admin');
        if ($maintenance && !$isAdminArea && !Auth::isAdmin()) {
            http_response_code(503);
            header('Retry-After: 3600');
            echo View::render('errors/503', [], 'main');
            exit;
        }

        $router = new Router();
        (require VA_APP . '/routes.php')($router);

        try {
            $router->dispatch(Request::method(), $path);
        } catch (\Throwable $e) {
            $this->handleException($e);
        }
    }

    private function startSession(): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            return;
        }
        $secure = str_starts_with(VA_URL, 'https://');
        session_set_cookie_params([
            'lifetime' => 0,
            'path'     => '/',
            'httponly' => true,
            'samesite' => 'Lax',
            'secure'   => $secure,
        ]);
        session_name('VASESS');
        session_start();
    }

    private function sendSecurityHeaders(): void
    {
        if (headers_sent()) {
            return;
        }
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: SAMEORIGIN');
        header('Referrer-Policy: strict-origin-when-cross-origin');
        header("Content-Security-Policy: default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors 'self'; base-uri 'self'; form-action 'self'");
        header('Permissions-Policy: geolocation=(self), microphone=(self), camera=()');
    }

    public function handleException(\Throwable $e): void
    {
        Logger::log('ERROR', get_class($e) . ': ' . $e->getMessage(), [
            'file' => $e->getFile() . ':' . $e->getLine(),
            'url'  => $_SERVER['REQUEST_URI'] ?? '',
        ]);
        http_response_code(500);
        if (VA_DEBUG) {
            echo '<pre style="background:#111;color:#f66;padding:16px;border-radius:8px;font:13px/1.6 monospace">'
                . e(get_class($e) . ': ' . $e->getMessage() . "\n"
                    . $e->getTraceAsString()) . '</pre>';
            exit;
        }
        try {
            echo View::render('errors/500', [], 'main');
        } catch (\Throwable) {
            echo 'Внутренняя ошибка сервера. Подробности в logs/app.log';
        }
        exit;
    }
}
