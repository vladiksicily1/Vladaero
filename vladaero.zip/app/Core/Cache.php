<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Файловый кэш (вопрос 82): подходит для shared-хостинга без Redis.
 */
final class Cache
{
    public static function set(string $key, mixed $value, int $ttl): void
    {
        $file = self::path($key);
        $payload = ['exp' => time() + $ttl, 'v' => $value];
        file_put_contents($file, serialize($payload), LOCK_EX);
    }

    public static function get(string $key, mixed $default = null): mixed
    {
        $file = self::path($key);
        if (!is_file($file)) {
            return $default;
        }
        $raw = @unserialize((string)file_get_contents($file), ['allowed_classes' => false]);
        if (!is_array($raw) || !isset($raw['exp'])) {
            return $default;
        }
        if ((int)$raw['exp'] < time()) {
            @unlink($file);
            return $default;
        }
        return $raw['v'];
    }

    public static function remember(string $key, int $ttl, callable $factory): mixed
    {
        $hit = self::get($key, '__VA_MISS__');
        if ($hit !== '__VA_MISS__') {
            return $hit;
        }
        $value = $factory();
        self::set($key, $value, $ttl);
        return $value;
    }

    public static function delete(string $key): void
    {
        $file = self::path($key);
        if (is_file($file)) {
            @unlink($file);
        }
    }

    /** Полная очистка каталога кэша. Возвращает число удалённых файлов. */
    public static function clear(): int
    {
        $n = 0;
        foreach (glob(self::dir() . '/*.cache') ?: [] as $f) {
            if (@unlink($f)) {
                $n++;
            }
        }
        return $n;
    }

    public static function gc(): void
    {
        foreach (glob(self::dir() . '/*.cache') ?: [] as $f) {
            $raw = @unserialize((string)file_get_contents($f), ['allowed_classes' => false]);
            if (!is_array($raw) || (int)($raw['exp'] ?? 0) < time()) {
                @unlink($f);
            }
        }
    }

    public static function size(): int
    {
        $bytes = 0;
        foreach (glob(self::dir() . '/*.cache') ?: [] as $f) {
            $bytes += (int)filesize($f);
        }
        return $bytes;
    }

    private static function dir(): string
    {
        $dir = VA_ROOT . '/cache';
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }
        return $dir;
    }

    private static function path(string $key): string
    {
        $key = preg_replace('#[^a-zA-Z0-9_-]#', '_', $key) ?: 'k';
        if (strlen($key) > 64) {
            $key = md5($key);
        }
        return self::dir() . '/' . $key . '.cache';
    }
}
