<?php
declare(strict_types=1);

/**
 * VladAero — глобальные хелперы.
 */

function e(null|string|int|float $s): string
{
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

function url(string $path = '/'): string
{
    if (str_starts_with($path, 'http://') || str_starts_with($path, 'https://')) {
        return $path;
    }
    return VA_URL . '/' . ltrim($path, '/');
}

function asset(string $path): string
{
    // cache-busting по времени изменения файла: не даёт браузеру отдавать устаревшие стили/скрипты
    $file = VA_ROOT . '/assets/' . ltrim($path, '/');
    $mtime = is_file($file) ? (string)(int)filemtime($file) : VA_VERSION;
    return url('assets/' . ltrim($path, '/')) . '?v=' . $mtime;
}

function redirect(string $to): never
{
    header('Location: ' . (str_starts_with($to, 'http') ? $to : url($to)));
    exit;
}

function __(string $key, array $replace = []): string
{
    return \App\Core\Lang::t($key, $replace);
}

function flash(string $type, string $message): void
{
    $_SESSION['_flash'][] = ['type' => $type, 'msg' => $message];
}

/** @return array<int, array{type:string,msg:string}> */
function flashes(): array
{
    $f = $_SESSION['_flash'] ?? [];
    unset($_SESSION['_flash']);
    return is_array($f) ? $f : [];
}

function csrf_field(): string
{
    return \App\Core\Csrf::field();
}

function csrf_verify(): void
{
    if (!\App\Core\Csrf::verify()) {
        http_response_code(419);
        exit('CSRF: недействительный токен. Обновите страницу.');
    }
}

function setting(string $key, mixed $default = null): mixed
{
    $all = \App\Models\Setting::all();
    return $all[$key] ?? $default;
}

function client_ip(): string
{
    return \App\Core\Request::ip();
}

function slugify(string $s): string
{
    $translit = [
        'а'=>'a','б'=>'b','в'=>'v','г'=>'g','д'=>'d','е'=>'e','ё'=>'e','ж'=>'zh','з'=>'z','и'=>'i','й'=>'y',
        'к'=>'k','л'=>'l','м'=>'m','н'=>'n','о'=>'o','п'=>'p','р'=>'r','с'=>'s','т'=>'t','у'=>'u','ф'=>'f',
        'х'=>'h','ц'=>'c','ч'=>'ch','ш'=>'sh','щ'=>'sch','ъ'=>'','ы'=>'y','ь'=>'','э'=>'e','ю'=>'yu','я'=>'ya',
    ];
    $s = mb_strtolower($s);
    $s = strtr($s, $translit);
    $s = preg_replace('#[^a-z0-9]+#', '-', $s) ?? '';
    $s = trim($s, '-');
    return $s !== '' ? substr($s, 0, 120) : 'item-' . substr(md5((string)mt_rand()), 0, 6);
}

function bytes(int $n): string
{
    if ($n >= 1048576) {
        return round($n / 1048576, 1) . ' МБ';
    }
    if ($n >= 1024) {
        return round($n / 1024, 1) . ' КБ';
    }
    return $n . ' Б';
}

function abort(int $code, ?string $view = null): never
{
    http_response_code($code);
    $view ??= 'errors/' . $code;
    try {
        echo \App\Core\View::render($view, [], 'main');
    } catch (\Throwable) {
        echo 'Ошибка ' . $code;
    }
    exit;
}

function json_response(mixed $data, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}
