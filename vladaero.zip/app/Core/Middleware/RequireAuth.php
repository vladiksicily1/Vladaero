<?php
declare(strict_types=1);

namespace App\Core\Middleware;

/**
 * Требует авторизации.
 */
final class RequireAuth
{
    public function handle(): void
    {
        if (!\App\Core\Auth::check()) {
            \App\Core\Logger::info('Доступ без авторизации', ['uri' => $_SERVER['REQUEST_URI'] ?? '']);
            flash('warning', __('auth.need_login'));
            redirect('/login');
        }
    }
}
