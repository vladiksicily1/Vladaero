<?php
declare(strict_types=1);

namespace App\Core\Middleware;

/**
 * Требует роли администратора (панель /admin).
 */
final class RequireAdmin
{
    public function handle(): void
    {
        if (!\App\Core\Auth::check()) {
            flash('warning', __('auth.need_login'));
            redirect('/login');
        }
        if (!\App\Core\Auth::isAdmin()) {
            \App\Core\Logger::warning('Попытка входа в админку без прав', [
                'user_id' => \App\Core\Auth::id(),
                'uri'     => $_SERVER['REQUEST_URI'] ?? '',
            ]);
            abort(403);
        }
    }
}
