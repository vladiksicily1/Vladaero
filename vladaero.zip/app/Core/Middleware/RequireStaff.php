<?php
declare(strict_types=1);

namespace App\Core\Middleware;

use App\Core\Auth;

/**
 * Доступ для старшего персонала: админ + модератор + скринер (в.120).
 * Используется разделом скрининга фото (в.107).
 */
final class RequireStaff
{
    public function handle(): void
    {
        if (!Auth::check()) {
            flash('warning', __('auth.need_login'));
            redirect('/login');
        }
        if (!in_array(Auth::role(), ['admin', 'moderator', 'screener'], true)) {
            \App\Core\Logger::warning('Попытка входа в зону скрининга без прав', [
                'user_id' => Auth::id(),
                'uri'     => $_SERVER['REQUEST_URI'] ?? '',
            ]);
            abort(403);
        }
    }
}
