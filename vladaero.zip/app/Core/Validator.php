<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Простой валидатор форм.
 * Правила: required, email, username, password, min:N, max:N, same:field, unique:table,column
 */
final class Validator
{
    private array $errors = [];

    private function __construct(
        private readonly array $data,
        private readonly array $rules
    ) {
        $this->run();
    }

    public static function make(array $data, array $rules): self
    {
        return new self($data, $rules);
    }

    public function fails(): bool
    {
        return $this->errors !== [];
    }

    /** @return array<string,string> поле → первая ошибка */
    public function errors(): array
    {
        return $this->errors;
    }

    public function error(string $field): ?string
    {
        return $this->errors[$field] ?? null;
    }

    private function run(): void
    {
        foreach ($this->rules as $field => $ruleStr) {
            $rules = is_array($ruleStr) ? $ruleStr : explode('|', $ruleStr);
            $value = $this->data[$field] ?? null;
            $isEmpty = $value === null || (is_string($value) && trim($value) === '');

            if (in_array('required', $rules, true) && $isEmpty) {
                $this->addError($field, 'required');
                continue;
            }
            if ($isEmpty) {
                continue; // необязательное пустое поле — пропускаем прочие проверки
            }
            $val = is_string($value) ? trim($value) : $value;

            foreach ($rules as $rule) {
                [$name, $param] = array_pad(explode(':', $rule, 2), 2, null);
                switch ($name) {
                    case 'required': break;
                    case 'email':
                        if (!filter_var((string)$val, FILTER_VALIDATE_EMAIL)) {
                            $this->addError($field, 'email');
                        }
                        break;
                    case 'username':
                        if (!preg_match('/^[A-Za-z0-9_]{3,32}$/u', (string)$val)) {
                            $this->addError($field, 'username');
                        }
                        break;
                    case 'password':
                        if (!preg_match('/^(?=.*[A-Za-z])(?=.*\d).{8,}$/u', (string)$val)) {
                            $this->addError($field, 'password');
                        }
                        break;
                    case 'min':
                        if (mb_strlen((string)$val) < (int)$param) {
                            $this->addError($field, 'min', ['n' => (int)$param]);
                        }
                        break;
                    case 'max':
                        if (mb_strlen((string)$val) > (int)$param) {
                            $this->addError($field, 'max', ['n' => (int)$param]);
                        }
                        break;
                    case 'same':
                        if ((string)$val !== (string)($this->data[$param] ?? '')) {
                            $this->addError($field, 'same');
                        }
                        break;
                    case 'unique':
                        [$table, $column] = array_pad(explode(',', (string)$param, 2), 2, null);
                        $column ??= $field;
                        $row = Database::i()->one(
                            "SELECT id FROM `{p}$table` WHERE `$column` = ? LIMIT 1",
                            [(string)$val]
                        );
                        if ($row !== null) {
                            $this->addError($field, 'unique');
                        }
                        break;
                }
            }
        }
    }

    private function addError(string $field, string $rule, array $repl = []): void
    {
        if (!isset($this->errors[$field])) {
            $this->errors[$field] = __('validate.' . $rule, $repl);
        }
    }
}
