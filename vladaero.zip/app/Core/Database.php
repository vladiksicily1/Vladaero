<?php
declare(strict_types=1);

namespace App\Core;

use PDO;
use PDOStatement;

/**
 * Обёртка PDO: подготовленные выражения, префикс таблиц {p}.
 */
final class Database
{
    private static ?Database $instance = null;
    private PDO $pdo;
    private string $prefix;

    private function __construct()
    {
        $c = require VA_APP . '/config/database.php';
        $this->prefix = (string)($c['prefix'] ?? '');
        $dsn = sprintf(
            'mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4',
            $c['host'], $c['port'] ?? 3306, $c['name']
        );
        $this->pdo = new PDO($dsn, $c['user'], $c['pass'], [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
    }

    public static function i(): self
    {
        return self::$instance ??= new self();
    }

    public static function pdo(): PDO
    {
        return self::i()->pdo;
    }

    /** Полное имя таблицы с префиксом */
    public function t(string $table): string
    {
        return $this->prefix . $table;
    }

    /** Актуальный префикс таблиц */
    public function prefix(): string
    {
        return $this->prefix;
    }

    /** Подстановка префикса {p} в SQL */
    public function q(string $sql): string
    {
        return str_replace('{p}', $this->prefix, $sql);
    }

    public function run(string $sql, array $params = []): PDOStatement
    {
        $st = $this->pdo->prepare($this->q($sql));
        $st->execute($params);
        return $st;
    }

    public function one(string $sql, array $params = []): ?array
    {
        $row = $this->run($sql, $params)->fetch();
        return $row === false ? null : $row;
    }

    public function all(string $sql, array $params = []): array
    {
        return $this->run($sql, $params)->fetchAll();
    }

    public function val(string $sql, array $params = []): mixed
    {
        $v = $this->run($sql, $params)->fetchColumn();
        return $v === false ? null : $v;
    }

    public function insert(string $table, array $data): int
    {
        $cols = array_keys($data);
        $sql = 'INSERT INTO `' . $this->t($table) . '` (`' . implode('`, `', $cols) . '`) VALUES ('
            . implode(', ', array_fill(0, count($cols), '?')) . ')';
        $this->run($sql, array_values($data));
        return (int)$this->pdo->lastInsertId();
    }

    public function update(string $table, array $data, array $where): int
    {
        if ($data === []) {
            return 0;
        }
        $set = [];
        $params = [];
        foreach ($data as $k => $v) {
            $set[] = "`$k` = ?";
            $params[] = $v;
        }
        $cond = [];
        foreach ($where as $k => $v) {
            $cond[] = "`$k` = ?";
            $params[] = $v;
        }
        $sql = 'UPDATE `' . $this->t($table) . '` SET ' . implode(', ', $set)
            . ' WHERE ' . implode(' AND ', $cond);
        return $this->run($sql, $params)->rowCount();
    }

    public function tablesLike(string $prefix): array
    {
        // SHOW TABLES не поддерживает параметры нативной подготовки — экранируем вручную
        $safe = preg_replace('#[^a-zA-Z0-9_]#', '', $prefix);
        $st = $this->pdo->query('SHOW TABLES LIKE ' . $this->pdo->quote($safe . '%'));
        return $st->fetchAll(PDO::FETCH_COLUMN);
    }

    public function sizeMb(): float
    {
        $v = $this->val(
            'SELECT ROUND(SUM(data_length + index_length) / 1048576, 2)
             FROM information_schema.TABLES WHERE table_schema = DATABASE()'
        );
        return (float)($v ?? 0);
    }
}
