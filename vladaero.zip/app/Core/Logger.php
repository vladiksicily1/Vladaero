<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Журнал событий и ошибок: logs/app.log (вопрос 127).
 */
final class Logger
{
    private static function file(): string
    {
        return VA_ROOT . '/logs/app.log';
    }

    public static function log(string $level, string $message, array $context = []): void
    {
        $line = sprintf(
            "[%s] %s: %s %s\n",
            date('Y-m-d H:i:s'),
            strtoupper($level),
            $message,
            $context ? json_encode($context, JSON_UNESCAPED_UNICODE) : ''
        );
        @file_put_contents(self::file(), $line, FILE_APPEND | LOCK_EX);
    }

    public static function info(string $m, array $c = []): void    { self::log('INFO', $m, $c); }
    public static function warning(string $m, array $c = []): void { self::log('WARNING', $m, $c); }
    public static function error(string $m, array $c = []): void   { self::log('ERROR', $m, $c); }
    public static function debug(string $m, array $c = []): void
    {
        if (VA_DEBUG) {
            self::log('DEBUG', $m, $c);
        }
    }

    /** Последние $lines строк лога (для админки) */
    public static function tail(int $lines = 400): array
    {
        $f = self::file();
        if (!is_file($f)) {
            return [];
        }
        $out = [];
        $fp = fopen($f, 'rb');
        if ($fp === false) {
            return [];
        }
        $buf = '';
        $pos = filesize($f);
        $chunk = 8192;
        while ($pos > 0 && count($out) <= $lines) {
            $read = min($chunk, $pos);
            $pos -= $read;
            fseek($fp, $pos);
            $buf = fread($fp, $read) . $buf;
            $parts = explode("\n", $buf);
            $buf = array_shift($parts);
            while (count($parts) > 0 && count($out) < $lines) {
                $l = array_pop($parts);
                if (trim($l) !== '') {
                    $out[] = $l;
                }
            }
        }
        if (trim($buf) !== '' && count($out) < $lines) {
            $out[] = $buf;
        }
        fclose($fp);
        return array_reverse($out);
    }

    public static function clear(): void
    {
        @file_put_contents(self::file(), '');
    }

    public static function size(): int
    {
        $f = self::file();
        return is_file($f) ? (int)filesize($f) : 0;
    }

    /** Ротация: при превышении 20 МБ лог переименовывается в app.log.1 */
    public static function rotateIfNeeded(int $maxBytes = 20971520): bool
    {
        $f = self::file();
        if (is_file($f) && filesize($f) > $maxBytes) {
            @rename($f, $f . '.1');
            return true;
        }
        return false;
    }
}
