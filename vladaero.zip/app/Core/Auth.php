<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Аутентификация: логин/пароль (bcrypt cost 12), троттлинг попыток, роли.
 * Telegram-вход по коду — v0.5 (вопросы 66, 241).
 */
final class Auth
{
    private static ?array $user = null;
    private static bool $resolved = false;

    public const ROLES = ['admin', 'moderator', 'screener', 'editor', 'user'];

    public static function check(): bool
    {
        return self::user() !== null;
    }

    public static function id(): ?int
    {
        $u = self::user();
        return $u ? (int)$u['id'] : null;
    }

    public static function user(): ?array
    {
        if (!self::$resolved) {
            self::$resolved = true;
            $uid = $_SESSION['uid'] ?? null;
            if ($uid !== null) {
                try {
                    self::$user = \App\Models\User::find((int)$uid);
                    if (self::$user !== null && (self::$user['status'] ?? '') === 'banned') {
                        self::logout();
                    }
                } catch (\Throwable) {
                    self::$user = null;
                }
            }
        }
        return self::$user;
    }

    public static function role(): string
    {
        return self::user()['role'] ?? 'guest';
    }

    public static function isAdmin(): bool
    {
        return self::role() === 'admin';
    }

    /** Попытка входа с защитой от перебора (5 ошибок → блокировка на 15 минут) */
    public static function attempt(string $login, string $password): array
    {
        $user = \App\Models\User::findByLogin($login);
        if ($user === null) {
            return ['ok' => false, 'error' => __('auth.failed')];
        }
        if (($user['status'] ?? '') === 'banned') {
            return ['ok' => false, 'error' => __('auth.banned')];
        }
        if (!empty($user['locked_until']) && strtotime((string)$user['locked_until']) > time()) {
            $min = (int)ceil((strtotime((string)$user['locked_until']) - time()) / 60);
            return ['ok' => false, 'error' => sprintf(__('auth.locked'), $min)];
        }

        if (!password_verify($password, (string)$user['password_hash'])) {
            $fails = (int)$user['failed_attempts'] + 1;
            $patch = ['failed_attempts' => $fails];
            if ($fails >= 5) {
                $patch['locked_until'] = date('Y-m-d H:i:s', time() + 900);
            }
            Database::i()->update('users', $patch, ['id' => $user['id']]);
            Logger::warning('Неудачный вход', ['login' => $login, 'ip' => Request::ip()]);
            return ['ok' => false, 'error' => __('auth.failed')];
        }

        Database::i()->update('users', [
            'failed_attempts' => 0,
            'locked_until'    => null,
            'last_seen'       => date('Y-m-d H:i:s'),
        ], ['id' => $user['id']]);

        self::loginUser($user);
        Logger::info('Успешный вход', ['user_id' => $user['id'], 'ip' => Request::ip()]);
        return ['ok' => true];
    }

    public static function loginUser(array $user): void
    {
        session_regenerate_id(true);
        $_SESSION['uid'] = (int)$user['id'];
        self::$user = $user;
        self::$resolved = true;
    }

    public static function logout(): void
    {
        unset($_SESSION['uid']);
        session_regenerate_id(true);
        self::$user = null;
        self::$resolved = true;
    }

    public static function rankLabel(string $rank): string
    {
        return __('rank.' . $rank);
    }
}
