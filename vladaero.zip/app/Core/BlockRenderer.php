<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Универсальный рендер блоков (в.108, 111–114): 27 типов, варианты и стилевые пресеты.
 * Блоки хранятся как JSON-массив: [{"t":"image","v":"wide","p":"hud","d":{...}}, ...]
 * Используется везде: статьи, карточки бортов, аэропорты, события.
 */
final class BlockRenderer
{
    /** Типы с выбором стилевого пресета (в.114: HUD / Warning / Пергамент / Техдокумент) */
    public const PRESETABLE = ['text', 'quote', 'specs_table', 'table', 'timeline', 'callout'];
    public const PRESETS = ['' => '', 'hud' => 'Авиационный HUD', 'warn' => 'Warning / Caution', 'parchment' => 'Исторический пергамент', 'tech' => 'Технический документ'];

    /** Описание типов: иконка, название, варианты — используется редактором и валидатором */
    public const TYPES = [
        // Текст и структура
        'text'         => ['icon' => '¶',  'title' => 'Текст',            'variants' => ['plain' => 'Обычный', 'lead' => 'Лид-абзац', 'small' => 'Сноска']],
        'heading'      => ['icon' => 'H',  'title' => 'Заголовок',        'variants' => ['h2' => 'H2', 'h3' => 'H3', 'h4' => 'H4']],
        'list'         => ['icon' => '≡',  'title' => 'Список',           'variants' => ['ul' => 'Маркированный', 'ol' => 'Нумерованный', 'check' => 'Чек-лист']],
        'table'        => ['icon' => '▦',  'title' => 'Таблица',          'variants' => []],
        'code'         => ['icon' => '⌘',  'title' => 'Код / формула',    'variants' => []],
        'quote'        => ['icon' => '❝', 'title' => 'Цитата',           'variants' => ['plain' => 'Обычная', 'frame' => 'С фото автора']],
        'details'      => ['icon' => '▸',  'title' => 'Спойлер / аккордеон', 'variants' => []],
        'callout'      => ['icon' => '!',  'title' => 'Врезка',           'variants' => ['info' => 'Инфо', 'warning' => 'Caution', 'danger' => 'Warning', 'success' => 'ОК']],
        'divider'      => ['icon' => '—',  'title' => 'Разделитель',      'variants' => ['line' => 'Линия', 'dots' => 'Пунктир', 'ornament' => 'Орнамент']],
        'button'       => ['icon' => '▭',  'title' => 'Кнопка (CTA)',     'variants' => ['primary' => 'Основная', 'ghost' => 'Обводка']],
        // Медиа
        'image'        => ['icon' => '🖼', 'title' => 'Изображение',      'variants' => ['normal' => 'Обычное', 'wide' => 'Широкое', 'side' => 'С обтеканием']],
        'gallery'      => ['icon' => '▣',  'title' => 'Галерея (Masonry)','variants' => ['masonry' => 'Плитки', 'carousel' => 'Карусель']],
        'video'        => ['icon' => '▶',  'title' => 'Видео (YouTube/Vimeo)', 'variants' => ['normal' => 'Обычное', 'shorts' => 'Вертикальное Shorts']],
        'audio'        => ['icon' => '♪',  'title' => 'Аудио / радиообмен', 'variants' => []],
        'panorama'     => ['icon' => '◐',  'title' => 'Панорама 360°',    'variants' => []],
        'model3d'      => ['icon' => '⟠', 'title' => '3D-модель (GLB)',   'variants' => []],
        'before_after' => ['icon' => '⇄', 'title' => 'До / После',         'variants' => []],
        'file'         => ['icon' => '⤓', 'title' => 'Файл (ливрея/мод)', 'variants' => []],
        'embed'        => ['icon' => '⧉', 'title' => 'Iframe-врезка',     'variants' => []],
        // Авиационные
        'specs_table'  => ['icon' => '⚙', 'title' => 'Блок ТТХ',          'variants' => []],
        'aircraft_ref' => ['icon' => '✈', 'title' => 'Карточка борта',    'variants' => []],
        'metar'        => ['icon' => '☁', 'title' => 'METAR аэропорта',   'variants' => []],
        'map_route'    => ['icon' => '⤳', 'title' => 'Карта маршрута',    'variants' => []],
        'timeline'     => ['icon' => '⌛', 'title' => 'Таймлайн',          'variants' => []],
        'compare_two'  => ['icon' => '⚖', 'title' => 'Сравнение (2 колонки)', 'variants' => []],
        // Интерактив
        'poll'         => ['icon' => '☑', 'title' => 'Опрос / голосование', 'variants' => []],
        'quiz'         => ['icon' => '✱', 'title' => 'Мини-викторина',    'variants' => []],
    ];

    /** Рендер списка блоков */
    public static function renderList(?array $blocks): string
    {
        if (!is_array($blocks)) {
            return '';
        }
        $html = '';
        foreach ($blocks as $b) {
            $html .= self::renderBlock(is_array($b) ? $b : []);
        }
        return $html !== '' ? '<div class="blk-list">' . $html . '</div>' : '';
    }

    /** Декодирует JSON-строку в блоки (с защитой от переполнения) */
    public static function decode(string $json): ?array
    {
        if (strlen($json) > 2_000_000 || $json === '') {
            return null;
        }
        $d = json_decode($json, true);
        if (!is_array($d)) {
            return null;
        }
        $out = [];
        foreach ($d as $b) {
            if (!is_array($b) || !is_string($b['t'] ?? null) || !isset(self::TYPES[$b['t']])) {
                continue;
            }
            $out[] = [
                't' => $b['t'],
                'v' => is_string($b['v'] ?? null) ? substr($b['v'], 0, 20) : '',
                'p' => is_string($b['p'] ?? null) ? substr($b['p'], 0, 20) : '',
                'd' => is_array($b['d'] ?? null) ? $b['d'] : [],
            ];
            if (count($out) >= 200) {
                break;
            }
        }
        return $out;
    }

    private static function renderBlock(array $b): string
    {
        $t = (string)($b['t'] ?? '');
        $v = (string)($b['v'] ?? '');
        $p = (string)($b['p'] ?? '');
        $d = is_array($b['d'] ?? null) ? $b['d'] : [];
        $cls = 'blk blk-' . $t . ($v !== '' ? ' v-' . $v : '') . ($p !== '' ? ' p-' . $p : '');
        $s = static fn(string $k, string $def = '') => e((string)($d[$k] ?? $def));
        $rows = static fn(string $k): array => is_array($d[$k] ?? null) ? $d[$k] : [];

        return match ($t) {
            'text' => '<div class="' . $cls . ' blk-text">' . nl2br($s('text')) . '</div>',
            'heading' => '<' . ($v !== '' ? $v : 'h2') . ' class="' . $cls . '">' . $s('text') . '</' . ($v !== '' ? $v : 'h2') . '>',
            'list' => self::renderList_($cls, $v, $rows('items')),
            'table' => self::renderTable($cls, $rows('rows'), $s('title')),
            'code' => '<pre class="' . $cls . ' mono">' . $s('code') . '</pre>',
            'quote' => '<blockquote class="' . $cls . '"><p>' . nl2br($s('text')) . '</p><footer>'
                . $s('author') . ($d['photo'] ?? '' ? ' <img src="' . e(url((string)$d['photo'])) . '" alt="" class="blk-quote-photo">' : '') . '</footer></blockquote>',
            'details' => '<details class="' . $cls . '"><summary>' . $s('summary') . '</summary><div class="blk-details-body">' . nl2br($s('text')) . '</div></details>',
            'callout' => '<div class="' . $cls . '"><b class="blk-callout-title">' . $s('title') . '</b><div>' . nl2br($s('text')) . '</div></div>',
            'divider' => '<hr class="' . $cls . '">',
            'button' => '<div class="' . $cls . '"><a class="btn btn--' . ($v === 'ghost' ? 'ghost' : 'primary') . '" href="' . $s('url') . '">' . $s('label') . '</a></div>',
            'image' => '<figure class="' . $cls . '"><img src="' . e(url((string)($d['src'] ?? ''))) . '" alt="' . $s('alt') . '" loading="lazy">'
                . ($d['caption'] ?? '' ? '<figcaption>' . $s('caption') . '</figcaption>' : '') . '</figure>',
            'gallery' => self::renderGallery($cls, $v, $rows('items')),
            'video' => self::renderVideo($cls, $v, (string)($d['url'] ?? ''), $s('caption')),
            'audio' => '<figure class="' . $cls . '"><figcaption>♪ ' . $s('title', 'Аудиозапись') . '</figcaption>'
                . '<audio controls preload="none" src="' . e(url((string)($d['src'] ?? ''))) . '"></audio>'
                . ($d['caption'] ?? '' ? '<figcaption class="muted small">' . $s('caption') . '</figcaption>' : '') . '</figure>',
            'panorama' => '<figure class="' . $cls . '"><div class="blk-pano-stub">◐ 360° ' . $s('title') . ' — интерактивная панорама (просмотрщик v0.4)</div>'
                . ($d['src'] ?? '' ? '<img src="' . e(url((string)$d['src'])) . '" alt="' . $s('title') . '" loading="lazy">' : '') . '</figure>',
            'model3d' => '<figure class="' . $cls . '"><div class="blk-3d-stub">⟠ 3D-модель' . ($d['src'] ?? '' ? ': <span class="mono">' . $s('src') . '</span>' : '')
                . '</div><figcaption class="muted small">Интерактивный WebGL-просмотрщик — v0.4 ' . $s('caption') . '</figcaption></figure>',
            'before_after' => '<figure class="' . $cls . '"><div class="ba" data-ba>'
                . '<img src="' . e(url((string)($d['before'] ?? ''))) . '" alt="до"><img src="' . e(url((string)($d['after'] ?? ''))) . '" alt="после" class="ba-after">'
                . '<input type="range" min="0" max="100" value="50" aria-label="До/После"></div>'
                . ($d['caption'] ?? '' ? '<figcaption>' . $s('caption') . '</figcaption>' : '') . '</figure>',
            'file' => '<div class="' . $cls . '"><a class="blk-file" href="' . e(url((string)($d['url'] ?? ''))) . '" download>⤓ <b>' . $s('title', 'Файл') . '</b>'
                . ($d['version'] ?? '' ? ' <span class="tag-ver">' . $s('version') . '</span>' : '') . '</a>'
                . ($d['note'] ?? '' ? '<div class="muted small">' . $s('note') . '</div>' : '') . '</div>',
            'embed' => '<div class="' . $cls . '"><iframe src="' . $s('url') . '" style="height:' . max(120, min(1200, (int)($d['height'] ?? 320))) . 'px" loading="lazy" title="embed" referrerpolicy="no-referrer"></iframe></div>',
            'specs_table' => self::renderSpecs($cls, $s('title'), $rows('rows')),
            'aircraft_ref' => self::renderAircraftRef($cls, (string)($d['slug'] ?? '')),
            'metar' => '<div class="' . $cls . '" data-metar="' . $s('icao') . '"><div class="blk-metar-head">☁ METAR <b class="mono">' . $s('icao') . '</b></div>'
                . '<div class="blk-metar-body muted">Загружаю живую сводку NOAA AWC…</div></div>',
            'map_route' => self::renderRoute($cls, $s('title'), $rows('points')),
            'timeline' => self::renderTimeline($cls, $rows('items')),
            'compare_two' => self::renderCompare($cls, $s('left'), $s('right'), $rows('rows')),
            'poll' => '<div class="' . $cls . '" data-poll><div class="blk-qa-title">☑ ' . $s('question') . '</div>'
                . '<div class="blk-poll-opts">' . self::renderPollOptions($rows('options')) . '</div>'
                . '<div class="blk-poll-res muted small" hidden></div></div>',
            'quiz' => '<div class="' . $cls . '" data-quiz data-correct="' . (int)($d['correct'] ?? 1) . '"><div class="blk-qa-title">✱ ' . $s('question') . '</div>'
                . '<div class="blk-quiz-opts">' . self::renderQuizOptions($rows('options')) . '</div>'
                . '<div class="blk-quiz-explain" hidden><b>Разбор:</b> ' . nl2br($s('explain')) . '</div></div>',
            default => '',
        };
    }

    private static function renderList_(string $cls, string $v, array $items): string
    {
        $tag = $v === 'ol' ? 'ol' : 'ul';
        $html = '<' . $tag . ' class="' . $cls . '">';
        foreach ($items as $it) {
            $html .= '<li>' . ($v === 'check' ? '☑ ' : '') . e((string)($it['text'] ?? '')) . '</li>';
        }
        return $html . '</' . $tag . '>';
    }

    private static function renderTable(string $cls, array $rows, string $title): string
    {
        if ($rows === []) {
            return '';
        }
        $html = '<div class="' . $cls . '">';
        if ($title !== '') {
            $html .= '<div class="blk-subtitle">' . e($title) . '</div>';
        }
        $html .= '<div class="table-wrap"><table class="table"><tbody>';
        foreach ($rows as $r) {
            $html .= '<tr>';
            for ($i = 1; $i <= 4; $i++) {
                $html .= '<td>' . e((string)($r['c' . $i] ?? '')) . '</td>';
            }
            $html .= '</tr>';
        }
        return $html . '</tbody></table></div></div>';
    }

    private static function renderSpecs(string $cls, string $title, array $rows): string
    {
        if ($rows === []) {
            return '';
        }
        $html = '<div class="' . $cls . '">';
        if ($title !== '') {
            $html .= '<div class="blk-subtitle">⚙ ' . e($title) . '</div>';
        }
        $html .= '<div class="kv">';
        foreach ($rows as $r) {
            $html .= '<div class="kv-row"><span>' . e((string)($r['label'] ?? '')) . '</span><b class="mono">'
                . e((string)($r['value'] ?? '')) . ' ' . e((string)($r['unit'] ?? '')) . '</b></div>';
        }
        return $html . '</div></div>';
    }

    private static function renderAircraftRef(string $cls, string $slug): string
    {
        $slug = trim($slug);
        if ($slug === '') {
            return '';
        }
        $ac = \App\Models\Aircraft::findBySlug($slug);
        if ($ac === null) {
            return '<div class="' . $cls . ' blk-ref-missing">✈ Борт «' . e($slug) . '» не найден в энциклопедии</div>';
        }
        $s = is_array($ac['specs']) ? $ac['specs'] : [];
        $mini = '';
        foreach (['cruise_speed_kmh', 'range_km', 'ceiling_m', 'pax'] as $k) {
            if (isset($s[$k]) && $s[$k] !== '') {
                $mini .= '<div><b>' . e(number_format((float)$s[$k], 0, '', ' ')) . '</b><span>' . e(__('spec_short.' . $k, )) . '</span></div>';
            }
        }
        return '<a class="' . $cls . ' blk-ac-ref" href="' . url('/aircraft/' . $ac['slug']) . '">'
            . '<div class="blk-ac-ref__top"><b>' . e($ac['name_ru']) . '</b>'
            . '<span class="ac-badge ac-badge--' . e($ac['status']) . '">' . e(__('ac.status.' . $ac['status'])) . '</span></div>'
            . ($mini !== '' ? '<div class="ac-mini">' . $mini . '</div>' : '')
            . '<span class="muted small">' . e($ac['manufacturer'] ?? '') . ' →</span></a>';
    }

    private static function renderGallery(string $cls, string $v, array $items): string
    {
        if ($items === []) {
            return '';
        }
        $html = '<div class="' . $cls . '">';
        foreach ($items as $it) {
            $src = (string)($it['src'] ?? '');
            if ($src === '') {
                continue;
            }
            $html .= '<a class="blk-gal-item" href="' . e(url($src)) . '" data-lightbox>'
                . '<img src="' . e(url($src)) . '" alt="' . e((string)($it['caption'] ?? '')) . '" loading="lazy">'
                . (($it['caption'] ?? '') !== '' ? '<span>' . e((string)$it['caption']) . '</span>' : '')
                . '</a>';
        }
        return $html . '</div>';
    }

    private static function renderVideo(string $cls, string $v, string $url, string $caption): string
    {
        $embed = self::videoEmbed($url);
        if ($embed === null) {
            return $url !== '' ? '<div class="' . $cls . ' blk-ref-missing">▶ Не удалось распознать видео: ' . e($url) . '</div>' : '';
        }
        $ratio = $v === 'shorts' ? '9:16' : '16:9';
        return '<figure class="' . $cls . '"><div class="blk-video" style="aspect-ratio:' . $ratio . '"><iframe src="' . e($embed)
            . '" loading="lazy" allowfullscreen title="video" referrerpolicy="no-referrer"></iframe></div>'
            . ($caption !== '' ? '<figcaption>' . $caption . '</figcaption>' : '') . '</figure>';
    }

    private static function videoEmbed(string $url): ?string
    {
        if (preg_match('#(?:youtube\.com/watch\?v=|youtu\.be/|youtube\.com/shorts/)([A-Za-z0-9_-]{6,})#', $url, $m)) {
            return 'https://www.youtube-nocookie.com/embed/' . $m[1];
        }
        if (preg_match('#vimeo\.com/(\d+)#', $url, $m)) {
            return 'https://player.vimeo.com/video/' . $m[1];
        }
        if (preg_match('#^https://.+#i', $url)) {
            return null;
        }
        return null;
    }

    private static function renderRoute(string $cls, string $title, array $points): string
    {
        if (count($points) < 2) {
            return '';
        }
        $coords = [];
        foreach ($points as $p) {
            $lat = (float)($p['lat'] ?? 0);
            $lng = (float)($p['lng'] ?? 0);
            if ($lat != 0 || $lng != 0) {
                $coords[] = [$lat, $lng, (string)($p['name'] ?? '')];
            }
        }
        if (count($coords) < 2) {
            return '';
        }
        $lats = array_map(static fn($c) => $c[0], $coords);
        $lngs = array_map(static fn($c) => $c[1], $coords);
        $minLat = min($lats) - 2;
        $maxLat = max($lats) + 2;
        $minLng = min($lngs) - 2;
        $maxLng = max($lngs) + 2;
        $w = 600.0;
        $h = 260.0;
        $x = static fn(float $lng): float => 20 + ($lng - $minLng) / max(0.01, $maxLng - $minLng) * ($w - 40);
        $y = static fn(float $lat): float => ($h - 20) - ($lat - $minLat) / max(0.01, $maxLat - $minLat) * ($h - 40);
        $path = '';
        foreach ($coords as $i => $c) {
            $path .= ($i === 0 ? 'M' : 'L') . round($x($c[1]), 1) . ' ' . round($y($c[0]), 1) . ' ';
        }
        $html = '<div class="' . $cls . '">';
        if ($title !== '') {
            $html .= '<div class="blk-subtitle">⤳ ' . e($title) . '</div>';
        }
        $html .= '<svg viewBox="0 0 600 260" class="blk-route-svg" role="img" aria-label="маршрут"><path d="' . $path . '" fill="none" stroke="#48CAE4" stroke-width="2" stroke-dasharray="6 4"/>';
        foreach ($coords as $c) {
            $html .= '<circle cx="' . round($x($c[1]), 1) . '" cy="' . round($y($c[0]), 1) . '" r="4" fill="#FFB703"/>'
                . '<text x="' . (round($x($c[1]), 1) + 7) . '" y="' . (round($y($c[0]), 1) + 4) . '" fill="#8FA3C4" font-size="11">' . e($c[2]) . '</text>';
        }
        return $html . '</svg><div class="muted small">Интерактивная карта (Leaflet) — v0.4</div></div>';
    }

    private static function renderTimeline(string $cls, array $items): string
    {
        if ($items === []) {
            return '';
        }
        $html = '<div class="' . $cls . '"><div class="blk-tl">';
        foreach ($items as $it) {
            $html .= '<div class="blk-tl-item"><div class="blk-tl-date mono">' . e((string)($it['date'] ?? '')) . '</div>'
                . '<div class="blk-tl-body"><b>' . e((string)($it['title'] ?? '')) . '</b>'
                . (($it['text'] ?? '') !== '' ? '<p>' . e((string)$it['text']) . '</p>' : '') . '</div></div>';
        }
        return $html . '</div></div>';
    }

    private static function renderCompare(string $cls, string $left, string $right, array $rows): string
    {
        if ($rows === []) {
            return '';
        }
        $html = '<div class="' . $cls . '"><div class="blk-subtitle">⚖ ' . e($left) . ' ↔ ' . e($right) . '</div>'
            . '<div class="table-wrap"><table class="table"><thead><tr><th></th><th>' . e($left) . '</th><th>' . e($right) . '</th></tr></thead><tbody>';
        foreach ($rows as $r) {
            $html .= '<tr><td class="muted">' . e((string)($r['label'] ?? '')) . '</td><td class="mono">' . e((string)($r['left'] ?? '')) . '</td><td class="mono">' . e((string)($r['right'] ?? '')) . '</td></tr>';
        }
        return $html . '</tbody></table></div></div>';
    }

    private static function renderPollOptions(array $options): string
    {
        $html = '';
        foreach ($options as $i => $o) {
            $html .= '<button type="button" class="blk-opt" data-i="' . (int)$i . '">' . e((string)($o['text'] ?? '')) . '</button>';
        }
        return $html;
    }

    private static function renderQuizOptions(array $options): string
    {
        $html = '';
        foreach ($options as $i => $o) {
            $html .= '<button type="button" class="blk-opt blk-opt--quiz" data-i="' . ((int)$i + 1) . '">' . e((string)($o['text'] ?? '')) . '</button>';
        }
        return $html;
    }
}
