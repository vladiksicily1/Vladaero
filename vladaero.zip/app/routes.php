<?php
/**
 * VladAero — таблица маршрутов.
 */
declare(strict_types=1);

use App\Core\Router;

return static function (Router $r): void {

    // ---------- Публичная часть ----------
    $r->get('/', 'HomeController@index');

    // Энциклопедия авиатехники (вопросы 6–9)
    $r->get('/aircraft', 'AircraftController@index');
    $r->get('/aircraft/{slug}', 'AircraftController@show');

    // Статьи (в.42, 108–115)
    $r->get('/articles', 'ArticlesController@index');
    $r->get('/articles/{slug}', 'ArticlesController@show');

    // Аэропорты (в.10, 33)
    $r->get('/airports', 'AirportsController@index');
    $r->get('/airports/{icao}', 'AirportsController@show');

    // Галерея споттинга (в.11–14)
    $r->get('/gallery', 'GalleryController@index');
    $r->get('/gallery/upload', 'GalleryController@uploadForm');
    $r->post('/gallery/upload', 'GalleryController@upload');
    $r->get('/gallery/{id}', 'GalleryController@show');
    $r->post('/gallery/{id}/like', 'GalleryController@like');

    // Versus — сравнение бортов (в.51–55)
    $r->get('/versus', 'VersusController@index');
    $r->get('/versus/{pair}', 'VersusController@index');

    // Радар полётов (в.16–20, 85–90, 230, 282–295)
    $r->get('/radar', 'RadarController@index');
    $r->get('/api/adsb', 'RadarController@api');
    $r->get('/api/adsb/stream', 'RadarController@stream');

    // Sitemap XML (в.104)
    $r->get('/sitemap.xml', 'SitemapController@index');
    $r->get('/sitemap-{section}.xml', 'SitemapController@section');

    // Погода и инструменты (в.46–47, 283–295)
    $r->get('/weather', 'WeatherController@index');
    $r->get('/api/wx', 'WeatherController@api');
    $r->get('/api/notam', 'WeatherController@notam');
    $r->get('/tools', 'ToolsController@index');
    $r->post('/tools/notam', 'ToolsController@notamDecode');

    // FIDS — онлайн-табло (в.279)
    $r->get('/fids', 'FidsController@index');
    $r->get('/api/fids', 'FidsController@api');

    // Веб-камеры аэропортов (в.278)
    $r->get('/webcams', 'WebcamsController@index');

    // Глобальный поиск Ctrl+K (вопросы 96–98)
    $r->get('/api/search', 'SearchController@api');

    // ИИ-штурман (в.156–160, 273–276)
    $r->get('/api/ai/state', 'AiController@state');
    $r->post('/api/ai/chat', 'AiController@chat');

    // Telegram-бот (в.116–119)
    $r->get('/telegram', 'TgController@page');
    $r->post('/tg/webhook', 'TgController@webhook');

    // ---------- v0.7: Сообщество, школа, события, PWA ----------
    // Календарь событий (в.56–60)
    $r->get('/events', 'EventsController@index');
    $r->get('/events/create', 'EventsController@createForm');
    $r->post('/events/create', 'EventsController@store');
    $r->get('/events/{slug}', 'EventsController@show');
    $r->post('/events/{slug}/attend', 'EventsController@attend');
    $r->get('/events/{slug}/ics', 'EventsController@ics');

    // Клубы (в.27)
    $r->get('/clubs', 'ClubsController@index');
    $r->get('/clubs/create', 'ClubsController@createForm');
    $r->post('/clubs/create', 'ClubsController@store');
    $r->get('/clubs/{slug}', 'ClubsController@show');
    $r->post('/clubs/{slug}/toggle', 'ClubsController@toggle');

    // Лётная школа (в.24)
    $r->get('/school', 'SchoolController@index');
    $r->get('/school/{slug}', 'SchoolController@show');
    $r->post('/school/{slug}/quiz', 'SchoolController@quiz');

    // Комментарии и закладки (в.26–27)
    $r->post('/comments', 'CommentsController@store');
    $r->post('/bookmarks/toggle', 'BookmarksController@toggle');
    $r->post('/versus/vote', 'VersusController@vote');

    // Профиль (в.26)
    $r->get('/profile', 'ProfileController@index');
    $r->post('/profile/notifications/read', 'ProfileController@readAll');

    // 3D-глобус (в.88)
    $r->get('/globe', 'GlobeController@index');

    // ---------- Соцконтур v0.8.1: лента, подписки, ЛС, споттинг-точки ----------
    $r->get('/feed', 'FeedController@index');
    $r->post('/profile/follow/{id}', 'FeedController@follow');
    $r->get('/im', 'DmController@index');
    $r->get('/im/{id}', 'DmController@thread');
    $r->post('/im/{id}', 'DmController@thread');
    $r->get('/tools/holding', 'HoldingController@index');
    $r->get('/spots', 'SpotController@index');
    $r->post('/spots/add', 'SpotController@add');
    $r->get('/profile/{id}', 'ProfileController@show');

    // ---------- Web Push (v0.8.1) ----------
    $r->post('/push/subscribe', 'PushController@subscribe');
    $r->post('/push/unsubscribe', 'PushController@unsubscribe');
    $r->get('/api/push/pending', 'PushController@pending');

    // Офлайн-страница PWA (в.73)
    $r->get('/offline', 'HomeController@offline');

    // ---------- Авторизация (вопросы 66–70) ----------
    $r->get('/login', 'AuthController@formLogin');
    $r->post('/login', 'AuthController@login');
    $r->post('/login/tg', 'AuthController@tgLogin');
    $r->get('/register', 'AuthController@formRegister');
    $r->post('/register', 'AuthController@register');
    $r->post('/logout', 'AuthController@logout');

    // ---------- Зона персонала: скрининг фото (в.107, 120) ----------
    $r->group('/admin', static function (Router $r): void {
        $r->get('/photos', 'Admin\\PhotosController@index');
        $r->post('/photos/{id}/verdict', 'Admin\\PhotosController@verdict');

        // Споттинг-точки: модерация (v0.8.1)
        $r->get('/spots', 'Admin\\SpotsController@index');
        $r->post('/spots/{id}/decide', 'Admin\\SpotsController@decide');
    }, ['staff']);

    // ---------- Панель администратора (вопросы 106–110) ----------
    $r->group('/admin', static function (Router $r): void {

        $r->get('', 'Admin\\AdminController@dashboard');

        // Web Push (v0.8.1)
        $r->get('/push', 'Admin\\PushController@index');
        $r->post('/push/genkeys', 'Admin\\PushController@genkeys');
        $r->post('/push/test', 'Admin\\PushController@test');
        $r->post('/maintenance', 'Admin\\AdminController@toggleMaintenance');
        $r->post('/clear-cache', 'Admin\\AdminController@clearCache');

        // Настройки (вопросы 152, 221–222)
        $r->get('/settings', 'Admin\\SettingsController@show');
        $r->get('/settings/{tab}', 'Admin\\SettingsController@show');
        $r->post('/settings/{tab}', 'Admin\\SettingsController@save');

        // Fetch v1/models — проверка AI-подключения (вопрос 151)
        $r->post('/api/ai-models', 'Admin\\SettingsController@apiModels');

        // Пользователи (вопрос 29)
        $r->get('/users', 'Admin\\UsersController@index');
        $r->post('/users/{id}/role', 'Admin\\UsersController@setRole');
        $r->post('/users/{id}/ban', 'Admin\\UsersController@ban');
        $r->post('/users/{id}/unban', 'Admin\\UsersController@unban');

        // Энциклопедия: авиатехника (вопросы 6–9)
        $r->get('/aircraft', 'Admin\\AircraftController@index');
        $r->get('/aircraft/new', 'Admin\\AircraftController@create');
        $r->post('/aircraft/create', 'Admin\\AircraftController@store');
        $r->get('/aircraft/{id}/edit', 'Admin\\AircraftController@edit');
        $r->post('/aircraft/{id}/update', 'Admin\\AircraftController@update');
        $r->post('/aircraft/{id}/delete', 'Admin\\AircraftController@delete');

        // Статьи (в.108–115)
        $r->get('/articles', 'Admin\\ArticlesController@index');
        $r->get('/articles/new', 'Admin\\ArticlesController@create');
        $r->post('/articles/create', 'Admin\\ArticlesController@store');
        $r->get('/articles/{id}/edit', 'Admin\\ArticlesController@edit');
        $r->post('/articles/{id}/update', 'Admin\\ArticlesController@update');
        $r->post('/articles/{id}/delete', 'Admin\\ArticlesController@delete');

        // Аэропорты (в.10, 33)
        $r->get('/airports', 'Admin\\AirportsController@index');
        $r->get('/airports/new', 'Admin\\AirportsController@create');
        $r->post('/airports/create', 'Admin\\AirportsController@store');
        $r->get('/airports/{id}/edit', 'Admin\\AirportsController@edit');
        $r->post('/airports/{id}/update', 'Admin\\AirportsController@update');
        $r->post('/airports/{id}/delete', 'Admin\\AirportsController@delete');

        // Медиатека (в.12–15, 79, 84)
        $r->get('/media', 'Admin\\MediaController@index');
        $r->get('/media/list', 'Admin\\MediaController@apiList');
        $r->post('/media/upload', 'Admin\\MediaController@upload');
        $r->post('/media/{id}/meta', 'Admin\\MediaController@meta');
        $r->post('/media/{id}/delete', 'Admin\\MediaController@delete');

        // Блоки: сохранение и черновики (в.108, 115)
        $r->post('/blocks/save', 'Admin\\BlocksController@save');
        $r->post('/blocks/draft', 'Admin\\BlocksController@draft');
        $r->get('/blocks/draft', 'Admin\\BlocksController@draftGet');

        // Супер-Агент (в.161–162, 271–277)
        $r->get('/agent', 'Admin\\AgentController@index');
        $r->post('/agent/chat', 'Admin\\AgentController@chat');
        $r->post('/agent/tool', 'Admin\\AgentController@tool');
        $r->post('/agent/batch', 'Admin\\AgentController@batch');
        $r->post('/agent/apply', 'Admin\\AgentController@apply');

        // Telegram: установка вебхука
        $r->post('/telegram/setwebhook', 'Admin\\SettingsController@setWebhook');

        // Telegram: мониторинг и.broadcast (в.269)
        $r->get('/telegram', 'Admin\\TelegramController@index');
        $r->post('/telegram/broadcast', 'Admin\\TelegramController@broadcast');

        // Модерация комментариев (в.194, 29)
        $r->get('/comments', 'Admin\\CommentsController@index');
        $r->post('/comments/{id}/status', 'Admin\\CommentsController@setStatus');
        $r->post('/comments/{id}/delete', 'Admin\\CommentsController@delete');

        // Календарь событий (в.56–60)
        $r->get('/events', 'Admin\\EventsController@index');
        $r->post('/events/create', 'Admin\\EventsController@store');
        $r->post('/events/{id}/status', 'Admin\\EventsController@setStatus');
        $r->post('/events/{id}/delete', 'Admin\\EventsController@delete');

        // Клубы (в.27, 162)
        $r->get('/clubs', 'Admin\\ClubsController@index');
        $r->post('/clubs/{id}/status', 'Admin\\ClubsController@setStatus');
        $r->post('/clubs/{id}/delete', 'Admin\\ClubsController@delete');

        // Лётная школа (в.24)
        $r->get('/lessons', 'Admin\\LessonsController@index');
        $r->get('/lessons/new', 'Admin\\LessonsController@create');
        $r->post('/lessons/create', 'Admin\\LessonsController@store');
        $r->get('/lessons/{id}/edit', 'Admin\\LessonsController@edit');
        $r->post('/lessons/{id}/update', 'Admin\\LessonsController@update');
        $r->post('/lessons/{id}/delete', 'Admin\\LessonsController@delete');

        // Журналы (вопрос 127)
        $r->get('/logs', 'Admin\\LogsController@index');
        $r->post('/logs/clear', 'Admin\\LogsController@clear');
        $r->get('/logs/download', 'Admin\\LogsController@download');

        // Система: бэкапы, сброс, обслуживание (вопросы 126, 149)
        $r->get('/system', 'Admin\\SystemController@index');
        $r->get('/system/backup', 'Admin\\SystemController@backup');
        $r->post('/system/drop-tables', 'Admin\\SystemController@dropTables');

    }, ['admin']);
};
