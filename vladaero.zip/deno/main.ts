/**
 * Universal Multi-Service API Reverse Proxy for Deno Deploy
 * Default Host: https://telegram.v7755837.deno.net
 *
 * Перенаправляет запросы на любые целевые API на основе заголовка:
 *  - X-Service: telegram | openai | assemblyai | firecrawl | skylink | adsb | aviationweather ...
 *  - X-Target-URL / X-Proxy-Target: https://api.telegram.org (или любой произвольный URL)
 *  - Автоматическое определение по пути (fallback): /bot... -> Telegram, /v2/upload -> AssemblyAI, и т.д.
 *
 * Поддерживает:
 *  - Все методы HTTP (GET, POST, PUT, DELETE, PATCH, OPTIONS)
 *  - Потоковую передачу данных (Streaming / duplex: half)
 *  - Передачу файлов и multipart/form-data
 *  - CORS для браузеров и веб-приложений
 */

const DEFAULT_ORIGIN = Deno.env.get("DEFAULT_TARGET_ORIGIN") || "https://api.telegram.org";

/** Предопределённая карта сервисов */
const SERVICE_ORIGINS: Record<string, string> = {
  telegram: "https://api.telegram.org",
  tg: "https://api.telegram.org",
  openai: "https://api.openai.com",
  ai: "https://api.openai.com",
  deepseek: "https://api.deepseek.com",
  openrouter: "https://openrouter.ai/api",
  assemblyai: "https://api.assemblyai.com",
  stt: "https://api.assemblyai.com",
  voice: "https://api.assemblyai.com",
  firecrawl: "https://api.firecrawl.dev",
  skylink: "https://skylinkapi.com",
  skylinkapi: "https://skylinkapi.com",
  adsb: "https://api.adsb.lol",
  "adsb.lol": "https://api.adsb.lol",
  aviationweather: "https://aviationweather.gov",
  weather: "https://aviationweather.gov",
  metar: "https://aviationweather.gov",
  wx: "https://aviationweather.gov",
  checkwx: "https://api.checkwx.com",
  avwx: "https://avwx.rest/api",
};

// Заголовки транспортного уровня и внутренние заголовки прокси
const STRIP_REQUEST_HEADERS = new Set([
  "connection",
  "keep-alive",
  "proxy-authenticate",
  "proxy-authorization",
  "te",
  "trailers",
  "transfer-encoding",
  "upgrade",
  "host",
  "x-service",
  "x-target-service",
  "x-target-url",
  "x-proxy-target",
  "x-target-base",
  "x-forwarded-for",
  "x-forwarded-host",
  "x-forwarded-proto",
]);

const STRIP_RESPONSE_HEADERS = new Set([
  "connection",
  "keep-alive",
  "transfer-encoding",
  "upgrade",
]);

function buildCorsHeaders(): Headers {
  const headers = new Headers();
  headers.set("Access-Control-Allow-Origin", "*");
  headers.set("Access-Control-Allow-Methods", "GET, POST, PUT, PATCH, DELETE, OPTIONS");
  headers.set("Access-Control-Allow-Headers", "*");
  headers.set("Access-Control-Max-Age", "86400");
  return headers;
}

/** Определение целевого Origin для запроса */
function resolveTargetOrigin(req: Request, url: URL): string {
  // 1. Прямой заголовок целевого URL
  const targetHeader = req.headers.get("x-target-url") ||
    req.headers.get("x-proxy-target") ||
    req.headers.get("x-target-base");

  if (targetHeader && targetHeader.trim() !== "") {
    const raw = targetHeader.trim();
    return raw.startsWith("http://") || raw.startsWith("https://") ? raw : `https://${raw}`;
  }

  // 2. Заголовок имени сервиса
  const serviceHeader = req.headers.get("x-service") || req.headers.get("x-target-service");
  if (serviceHeader && serviceHeader.trim() !== "") {
    const s = serviceHeader.trim().toLowerCase();
    if (SERVICE_ORIGINS[s]) {
      return SERVICE_ORIGINS[s];
    }
  }

  // 3. Автоопределение по шаблону пути
  const path = url.pathname;
  if (path.startsWith("/bot") || path.startsWith("/file/bot")) {
    return "https://api.telegram.org";
  }
  if (path.startsWith("/v1/chat/completions") || path.startsWith("/v1/models") || path.startsWith("/v1/audio")) {
    return "https://api.openai.com";
  }
  if (path.startsWith("/v2/upload") || path.startsWith("/v2/transcript")) {
    return "https://api.assemblyai.com";
  }
  if (path.startsWith("/v2/callsign") || path.startsWith("/v2/point") || path.startsWith("/v2/sq") || path.startsWith("/v2/hex")) {
    return "https://api.adsb.lol";
  }
  if (path.startsWith("/api/data/metar") || path.startsWith("/api/data/taf") || path.startsWith("/adds/")) {
    return "https://aviationweather.gov";
  }
  if (path.startsWith("/schedules/")) {
    return "https://skylinkapi.com/v2";
  }
  if (path.startsWith("/v1/scrape") || path.startsWith("/v1/search")) {
    return "https://api.firecrawl.dev/v1";
  }

  // 4. По умолчанию Telegram Bot API
  return DEFAULT_ORIGIN;
}

Deno.serve(async (req: Request): Promise<Response> => {
  // CORS Preflight
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 204,
      headers: buildCorsHeaders(),
    });
  }

  const incomingUrl = new URL(req.url);

  // Информация на главной странице
  if (incomingUrl.pathname === "/" || incomingUrl.pathname === "") {
    // Если на корень отправлен заголовок X-Service / X-Target-URL — пропускаем проксирование
    const hasProxyHeader = req.headers.get("x-service") ||
      req.headers.get("x-target-url") ||
      req.headers.get("x-proxy-target");

    if (!hasProxyHeader) {
      return new Response(
        JSON.stringify(
          {
            status: "ok",
            service: "VladAero Universal Multi-Service API Proxy",
            version: "2.0.0",
            proxy_endpoint: incomingUrl.origin,
            supported_services: SERVICE_ORIGINS,
            usage: {
              by_header_service: {
                header: "X-Service: telegram | openai | assemblyai | firecrawl | skylink | adsb | aviationweather",
                example: "curl -H 'X-Service: assemblyai' " + incomingUrl.origin + "/v2/transcript",
              },
              by_header_url: {
                header: "X-Target-URL: https://api.custom-service.com",
                example: "curl -H 'X-Target-URL: https://api.openai.com' " + incomingUrl.origin + "/v1/models",
              },
              auto_detected_paths: [
                "/bot<TOKEN>/<METHOD> -> https://api.telegram.org",
                "/file/bot<TOKEN>/<PATH> -> https://api.telegram.org",
                "/v2/upload -> https://api.assemblyai.com",
                "/v2/transcript -> https://api.assemblyai.com",
                "/v2/callsign/<CS> -> https://api.adsb.lol",
                "/api/data/metar -> https://aviationweather.gov",
              ],
            },
          },
          null,
          2,
        ),
        {
          status: 200,
          headers: {
            "Content-Type": "application/json; charset=utf-8",
            ...Object.fromEntries(buildCorsHeaders().entries()),
          },
        },
      );
    }
  }

  // Определяем целевой хост
  const rawTarget = resolveTargetOrigin(req, incomingUrl);
  const targetBaseUrl = new URL(rawTarget);

  // Склеиваем базовый путь таргета (если был, напр. /v1) с входящим путём
  let combinedPath = targetBaseUrl.pathname.replace(/\/+$/, "") + incomingUrl.pathname;
  if (!combinedPath.startsWith("/")) {
    combinedPath = "/" + combinedPath;
  }
  // Нормализуем двойные слэши
  combinedPath = combinedPath.replace(/\/{2,}/g, "/");

  const targetUrl = new URL(combinedPath + incomingUrl.search, targetBaseUrl.origin);

  // Подготавливаем заголовки запроса
  const forwardHeaders = new Headers();
  for (const [key, value] of req.headers.entries()) {
    const lower = key.toLowerCase();
    if (!STRIP_REQUEST_HEADERS.has(lower) && !lower.startsWith("cf-")) {
      forwardHeaders.set(key, value);
    }
  }

  // Устанавливаем Host на целевой сервер
  forwardHeaders.set("Host", targetUrl.host);

  const init: RequestInit = {
    method: req.method,
    headers: forwardHeaders,
    redirect: "follow",
  };

  if (req.method !== "GET" && req.method !== "HEAD") {
    init.body = req.body;
    // @ts-ignore: duplex mode required for streaming body in Deno
    init.duplex = "half";
  }

  try {
    const response = await fetch(targetUrl.toString(), init);

    const responseHeaders = new Headers();
    for (const [key, value] of response.headers.entries()) {
      const lower = key.toLowerCase();
      if (!STRIP_RESPONSE_HEADERS.has(lower)) {
        responseHeaders.set(key, value);
      }
    }

    // CORS заголовки
    const cors = buildCorsHeaders();
    for (const [k, v] of cors.entries()) {
      responseHeaders.set(k, v);
    }

    // Добавляем отладочный заголовок
    responseHeaders.set("X-Proxied-To", targetUrl.origin);

    return new Response(response.body, {
      status: response.status,
      statusText: response.statusText,
      headers: responseHeaders,
    });
  } catch (err: unknown) {
    const errorMessage = err instanceof Error ? err.message : String(err);
    return new Response(
      JSON.stringify({
        ok: false,
        error_code: 502,
        description: `Deno Proxy Bad Gateway: ${errorMessage}`,
        target: targetUrl.toString(),
      }),
      {
        status: 502,
        headers: {
          "Content-Type": "application/json; charset=utf-8",
          ...Object.fromEntries(buildCorsHeaders().entries()),
        },
      },
    );
  }
});
