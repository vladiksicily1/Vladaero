# VladAero Universal Multi-Service API Proxy (Deno Deploy)

Универсальный высокопроизводительный обратный прокси для [Deno Deploy](https://deno.com/deploy).
Позволяет проксировать запросы ко всем внешним API (Telegram Bot API, OpenAI, AssemblyAI, Firecrawl, SkyLink, ADS-B, AviationWeather) через единую точку входа:
**`https://telegram.v7755837.deno.net`** (или ваш собственный домен на Deno Deploy).

---

## 🎯 Как это работает

Прокси анализирует входящий запрос и определяет целевой сервис:

### 1. По заголовку `X-Service`
Вы можете передать имя сервиса в заголовке `X-Service`:
- `telegram` (или `tg`) $\to$ `https://api.telegram.org`
- `assemblyai` (или `stt`, `voice`) $\to$ `https://api.assemblyai.com`
- `openai` (или `ai`, `deepseek`, `openrouter`) $\to$ `https://api.openai.com`
- `firecrawl` $\to$ `https://api.firecrawl.dev`
- `skylink` $\to$ `https://skylinkapi.com`
- `adsb` $\to$ `https://api.adsb.lol`
- `aviationweather` (или `metar`, `wx`) $\to$ `https://aviationweather.gov`

### 2. По заголовку `X-Target-URL`
Вы можете передать абсолютно любой целевой URL:
```http
X-Target-URL: https://api.openai.com
```

### 3. Автоматическое определение по пути (fallback)
Если заголовок не передан:
- `/bot<TOKEN>/...` $\to$ `https://api.telegram.org`
- `/file/bot<TOKEN>/...` $\to$ `https://api.telegram.org`
- `/v1/chat/completions`, `/v1/models` $\to$ `https://api.openai.com`
- `/v2/upload`, `/v2/transcript` $\to$ `https://api.assemblyai.com`
- `/v2/callsign/...` $\to$ `https://api.adsb.lol`
- `/api/data/metar` $\to$ `https://aviationweather.gov`

---

## 🚀 Развёртывание на Deno Deploy

1. Зайдите на [dash.deno.com](https://dash.deno.com/).
2. Откройте проект (или создайте новый, например с доменом `telegram.v7755837.deno.net` / `your-subdomain.deno.dev`).
3. Вставьте код из `deno/main.ts` в редактор Playground или подключите GitHub репозиторий.
4. Нажмите **Deploy**.

---

## ⚙️ Интеграция с VladAero

В файле настроек по умолчанию и в веб-панели управления:
1. Перейдите в **Админка → Настройки → Интеграции** (или `/admin/settings/integrations`).
2. В поле **Telegram API Base URL** укажите:
   ```text
   https://telegram.v7755837.deno.net
   ```
3. Сохраните настройки. Все вызовы Telegram Bot API, распознавания речи AssemblyAI, метеослужб и ADS-B будут безопасно проксироваться через ваш Deno-сервис.

---

## 🔍 Примеры ручных вызовов

```bash
# 1. Проверка Telegram Bot API:
curl https://telegram.v7755837.deno.net/bot<BOT_TOKEN>/getMe

# 2. Вызов AssemblyAI через заголовок X-Service:
curl -H "X-Service: assemblyai" \
     -H "Authorization: <ASSEMBLYAI_KEY>" \
     https://telegram.v7755837.deno.net/v2/transcript

# 3. Вызов OpenAI через X-Target-URL:
curl -H "X-Target-URL: https://api.openai.com" \
     -H "Authorization: Bearer <OPENAI_KEY>" \
     https://telegram.v7755837.deno.net/v1/models
```
