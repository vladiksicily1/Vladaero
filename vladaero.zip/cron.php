<?php
/**
 * VladAero — точка входа фоновых задач (cron).
 * Пример crontab:  * * * * * php /path/to/cron.php >/dev/null 2>&1
 * Запуск через веб: /cron.php?key=CRON_KEY (ключ задаётся в установщике/админке).
 */
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    require __DIR__ . '/app/bootstrap.php';
    $key = (string)($_GET['key'] ?? '');
    $real = (string)setting('cron_key', '');
    if ($real === '' || !hash_equals($real, $key)) {
        http_response_code(403);
        exit('Forbidden');
    }
} else {
    if (!is_file(__DIR__ . '/app/config/app.php')) {
        fwrite(STDERR, "VladAero не установлен.\n");
        exit(1);
    }
    require __DIR__ . '/app/bootstrap.php';
}

$report = [
    'time' => date('Y-m-d H:i:s'),
    'cache_gc' => 0,
    'log_rotated' => false,
    'jobs' => [],
];

// 1. Очистка истёкшего файлового кэша
try {
    App\Core\Cache::gc();
    $report['cache_gc'] = 1;
} catch (Throwable $e) {
    App\Core\Logger::error('cron: cache gc — ' . $e->getMessage());
}

// 2. Ротация логов при превышении размера
try {
    $report['log_rotated'] = App\Core\Logger::rotateIfNeeded();
} catch (Throwable $e) {
    App\Core\Logger::error('cron: log rotate — ' . $e->getMessage());
}

// 3. Напоминания о событиях (в.60): за неделю и за день до начала,
//    тем, кто отметил «Я пойду». Дедупликация — файловый кэш на 48 ч.
try {
    $windows = ['week' => [6.5 * 86400, 7.5 * 86400], 'day' => [18 * 3600, 30 * 3600]];
    foreach ($windows as $when => [$from, $to]) {
        $events = App\Core\Database::i()->all(
            'SELECT id, slug, title_ru, starts_at, city FROM `{p}events`
             WHERE status = "published"
               AND UNIX_TIMESTAMP(starts_at) BETWEEN ? AND ?',
            [time() + (int)$from, time() + (int)$to]);
        foreach ($events as $ev) {
            $ck = 'evrem_' . $ev['id'] . '_' . $when;
            if (App\Core\Cache::get($ck) !== null) { continue; }
            App\Core\Cache::set($ck, 1, 172800);
            $attendees = App\Core\Database::i()->all(
                'SELECT user_id FROM `{p}event_attendees` WHERE event_id = ?', [(int)$ev['id']]);
            foreach ($attendees as $u) {
                App\Models\Notification::push((int)$u['user_id'], 'event_reminder', [
                    'when' => $when, 'event' => $ev['title_ru'],
                    'url' => '/events/' . $ev['slug'], 'starts' => $ev['starts_at'],
                ]);
                App\Services\TelegramService::notifyEventReminder((int)$u['user_id'], $ev, $when);
            }
            $report['jobs'][] = 'event_reminder:' . $ev['slug'] . ':' . $when . '(' . count($attendees) . ')';
        }
    }
} catch (Throwable $e) {
    App\Core\Logger::error('cron: event reminders — ' . $e->getMessage());
}

// Погодные и ADS-B данные обновляются лениво при визитах (в.83),
// поэтому cron чистит только кэш и логи.

App\Core\Logger::info('cron: выполнен запуск', $report);

echo PHP_SAPI === 'cli' ? json_encode($report, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . PHP_EOL : json_encode($report);
