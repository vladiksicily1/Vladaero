<?php
/**
 * ============================================================================
 * VladAero — мастер установки (вопросы 149, 201–220)
 * ============================================================================
 * Самодостаточный файл: загрузите ЕГО ОДНОГО в корень сайта и откройте в браузере.
 *
 * Возможности:
 *  1. Проверка системных требований (PHP 8.1+, PDO, cURL, GD, Zip) — в.202, 220
 *  2. Загрузка ZIP-архива с кодом VladAero прямо через браузер — в.149
 *  3. Проверка MySQL по AJAX, любой префикс таблиц, конфликты — в.203, 215
 *  4. Создание администратора (bcrypt cost 12) — в.207, 208
 *  5. Брендинг: логотип / фавикон / hero-обложка — в.213
 *  6. Анимированная пошаговая миграция таблиц — в.201, 212
 *  7. Финал: cron-команда, удаление install.php в один клик — в.211, 214, 219
 *
 * CLI-запуск заблокирован (вопрос 217).
 */
declare(strict_types=1);

/* ---------------------------------------------------------------------------
 * Охрана
 * ------------------------------------------------------------------------ */
if (PHP_SAPI === 'cli' && !defined('VA_INSTALLER_TEST')) {
    fwrite(STDERR, "Веб-установщик: запуск из консоли запрещён (в.217). Откройте install.php в браузере.\n");
    exit(1);
}

error_reporting(E_ALL);
ini_set('display_errors', '0');

define('VAInstaller', true);
define('VA_MIN_PHP', '8.1.0');
define('VA_TABLES', [
    'settings', 'users', 'audit_log', 'aircraft', 'airlines', 'airports',
    'articles', 'photos', 'events', 'notifications',
    'ai_requests', 'ai_chats', 'ai_chat_messages', 'tg_links',
    'media', 'blocks', 'block_drafts',
    'comments', 'versus_votes', 'clubs', 'club_members',
    'lessons', 'lesson_progress', 'bookmarks', 'event_attendees',
    'author_follows', 'dm', 'spot_points', 'push_subscriptions', 'flight_logs', 'tg_activity',
]);

/* ---------------------------------------------------------------------------
 * Хелперы
 * ------------------------------------------------------------------------ */
function iva_e(null|string|int|float $s): string
{
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

function iva_root(): string
{
    return __DIR__;
}

function iva_guess_base_url(): string
{
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
        || (($_SERVER['SERVER_PORT'] ?? '') === '443');
    $scheme = $https ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $dir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
    return $scheme . '://' . $host . $dir;
}

function iva_installed(): bool
{
    return is_file(__DIR__ . '/app/config/app.php')
        && is_file(__DIR__ . '/app/config/database.php')
        && is_file(__DIR__ . '/app/config/installed.lock');
}

function iva_code_present(): bool
{
    return is_file(__DIR__ . '/app/Core/App.php') && is_file(__DIR__ . '/index.php');
}

function iva_norm_prefix(string $p): string
{
    $p = strtolower(trim($p));
    $p = preg_replace('#[^a-z0-9_]#', '', $p) ?? '';
    return $p === '' ? 'va_' : $p;
}

function iva_token(): string
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_name('VAINSTALLER');
        session_start();
    }
    if (empty($_SESSION['iva_tok'])) {
        $_SESSION['iva_tok'] = bin2hex(random_bytes(24));
    }
    return $_SESSION['iva_tok'];
}

function iva_tok_ok(): bool
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_name('VAINSTALLER');
        session_start();
    }
    $t = $_POST['tok'] ?? $_GET['tok'] ?? $_SERVER['HTTP_X_INSTALLER_TOKEN'] ?? '';
    return is_string($t) && $t !== '' && hash_equals($_SESSION['iva_tok'] ?? '', $t);
}

function iva_json(array $data, int $code = 200): never
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function iva_flash_set(string $m): void
{
    $_SESSION['iva_flash'] = $m;
}

function iva_flash_get(): string
{
    $m = $_SESSION['iva_flash'] ?? '';
    unset($_SESSION['iva_flash']);
    return is_string($m) ? $m : '';
}

/* ---------------------------------------------------------------------------
 * Шаг 0: системные требования (в.202, 220)
 * ------------------------------------------------------------------------ */
function iva_requirements(): array
{
    $checks = [];

    $phpOk = version_compare(PHP_VERSION, VA_MIN_PHP, '>=');
    $checks[] = [
        'label' => 'PHP ≥ ' . VA_MIN_PHP . ' (найден ' . PHP_VERSION . ')',
        'status' => $phpOk ? 'ok' : 'fail',
        'hint' => $phpOk ? '' : 'Обратитесь к хостеру для переключения версии PHP',
    ];

    foreach ([
        'PDO'      => 'Работа с MySQL (PDO)',
        'pdo_mysql'=> 'Драйвер PDO_MySQL (в.202)',
        'curl'     => 'cURL — внешние API (OpenSky, NOAA, ИИ)',
        'mbstring' => 'Mbstring — UTF-8 тексты',
        'json'     => 'JSON',
        'fileinfo' => 'Fileinfo — проверка загружаемых файлов',
        'session'  => 'Сессии PHP',
        'filter'   => 'Filter — валидация данных',
    ] as $ext => $label) {
        $ok = extension_loaded($ext);
        $checks[] = ['label' => $label, 'status' => $ok ? 'ok' : 'fail', 'hint' => $ok ? '' : "Расширение $ext отсутствует"];
    }

    $gd = extension_loaded('gd') || extension_loaded('imagick');
    $checks[] = [
        'label' => 'GD или Imagick — обработка фото (в.84)',
        'status' => $gd ? 'ok' : 'warn',
        'hint' => $gd ? '' : 'Загрузка споттерских фото будет недоступна до v0.3, остальное работает',
    ];

    $zip = extension_loaded('zip') || extension_loaded('phar');
    $checks[] = [
        'label' => 'Zip / Phar — распаковка архива кода (шаг 1)',
        'status' => $zip ? 'ok' : 'fail',
        'hint' => $zip ? '' : 'Распакуйте архив VladAero вручную по FTP и обновите страницу',
    ];

    foreach ([
        'uploads/' => 'Фотографии и брендинг',
        'cache/'   => 'Файловый кэш (в.82)',
        'logs/'    => 'Журнал ошибок (в.127)',
        'app/config/' => 'Конфигурация установки',
    ] as $dir => $why) {
        $path = iva_root() . '/' . $dir;
        $ok = is_dir($path) ? is_writable($path) : @mkdir($path, 0755, true) && is_writable($path);
        $checks[] = [
            'label' => "Право записи: $dir — $why",
            'status' => $ok ? 'ok' : 'fail',
            'hint' => $ok ? '' : 'Выставьте права 755/775 (или 777 на время установки)',
        ];
    }

    $lim = [
        'memory_limit'        => ['128M', 'Память PHP'],
        'upload_max_filesize' => ['8M', 'Лимит загрузки файлов'],
        'post_max_size'       => ['8M', 'Лимит POST'],
        'max_execution_time'  => ['30', 'Время выполнения скрипта'],
    ];
    foreach ($lim as $key => [$min, $label]) {
        $cur = ini_get($key) ?: '0';
        $okBytes = iva_to_bytes($cur) >= iva_to_bytes($min);
        $checks[] = [
            'label' => "$label: $cur (рекомендуется ≥ $min)",
            'status' => $okBytes ? 'ok' : 'warn',
            'hint' => $okBytes ? '' : 'Можно увеличить в php.ini или через поддержку хостинга',
        ];
    }

    $hasFail = (bool)array_filter($checks, static fn($c) => $c['status'] === 'fail');
    return ['pass' => !$hasFail, 'checks' => $checks];
}

function iva_to_bytes(string $v): int
{
    $v = trim($v);
    if ($v === '-1') {
        return PHP_INT_MAX;
    }
    $unit = strtolower(substr($v, -1));
    $n = (int)$v;
    return match ($unit) {
        'g' => $n * 1073741824,
        'm' => $n * 1048576,
        'k' => $n * 1024,
        default => $n,
    };
}

/* ---------------------------------------------------------------------------
 * Шаг 1: загрузка и распаковка ZIP с кодом (в.149)
 * ------------------------------------------------------------------------ */
function iva_handle_zip_upload(): array
{
    if (iva_code_present()) {
        return ['ok' => true, 'msg' => 'Код VladAero уже находится на сервере'];
    }
    $f = $_FILES['codezip'] ?? null;
    if (!is_array($f) || ($f['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        return ['ok' => false, 'error' => 'Выберите ZIP-архив с кодом'];
    }
    if (($f['error'] ?? 1) !== UPLOAD_ERR_OK) {
        return ['ok' => false, 'error' => 'Ошибка загрузки файла (код ' . (int)$f['error'] . ')'];
    }
    $ext = strtolower(pathinfo((string)$f['name'], PATHINFO_EXTENSION));
    if ($ext !== 'zip') {
        return ['ok' => false, 'error' => 'Нужен именно ZIP-архив'];
    }

    $tmpZip = sys_get_temp_dir() . '/va_code_' . bin2hex(random_bytes(4)) . '.zip';
    if (!move_uploaded_file($f['tmp_name'], $tmpZip)) {
        return ['ok' => false, 'error' => 'Не удалось сохранить архив на сервере'];
    }

    $tmpDir = sys_get_temp_dir() . '/va_extract_' . bin2hex(random_bytes(4));
    @mkdir($tmpDir, 0755, true);

    try {
        if (class_exists('ZipArchive')) {
            $z = new ZipArchive();
            $r = $z->open($tmpZip);
            if ($r !== true) {
                throw new RuntimeException('Архив повреждён (ZipArchive code ' . $r . ')');
            }
            $z->extractTo($tmpDir);
            $z->close();
        } else {
            $phar = new PharData($tmpZip);
            $phar->extractTo($tmpDir, null, true);
        }
    } catch (Throwable $e) {
        @unlink($tmpZip);
        return ['ok' => false, 'error' => 'Распаковка не удалась: ' . $e->getMessage()];
    }
    @unlink($tmpZip);

    // Ищем корень проекта (каталог с app/ и index.php) на глубине до 3
    $root = iva_find_project_root($tmpDir);
    if ($root === null) {
        iva_rrmdir($tmpDir);
        return ['ok' => false, 'error' => 'В архиве не найден проект VladAero (нужны папка app/ и index.php)'];
    }

    $moved = iva_merge_dir($root, iva_root());
    iva_rrmdir($tmpDir);

    if (!iva_code_present()) {
        return ['ok' => false, 'error' => 'Файлы скопированы, но app/Core/App.php не найден. Проверьте архив.'];
    }
    return ['ok' => true, 'msg' => "Код развёрнут: перемещено $moved объектов. Установщик продолжает работу."];
}

/* ---------------------------------------------------------------------------
 * AJAX: загрузка ZIP-кода через base64 (обход лимитов upload_max_filesize)
 * ------------------------------------------------------------------------ */
function iva_ajax_upload_zip(): never
{
    if (!iva_tok_ok()) {
        iva_json(['ok' => false, 'error' => 'Сессия установки истекла — обновите страницу']);
    }
    if (iva_code_present()) {
        iva_json(['ok' => true, 'msg' => 'Код VladAero уже находится на сервере']);
    }

    $body = json_decode((string)file_get_contents('php://input'), true);
    $b64 = trim((string)($body['zip'] ?? ''));
    if ($b64 === '') {
        iva_json(['ok' => false, 'error' => 'Поле zip пустое — вставьте base64-строку архива']);
    }
    // data:URI обрезаем
    if (str_starts_with($b64, 'data:')) {
        $b64 = substr($b64, (int)strpos($b64, ',') + 1);
    }
    $bin = base64_decode($b64, true);
    if ($bin === false || $bin === '') {
        iva_json(['ok' => false, 'error' => 'Не удалось декодировать base64 — проверьте данные']);
    }
    $maxBytes = 60 * 1048576; // 60 МБ — с запасом относительно MAX_ZIP_SIZE
    if (strlen($bin) > $maxBytes) {
        iva_json(['ok' => false, 'error' => 'Архив слишком большой (' . intdiv(strlen($bin), 1048576) . ' МБ, лимит 60 МБ)']);
    }

    $tmpZip = sys_get_temp_dir() . '/va_code_' . bin2hex(random_bytes(4)) . '.zip';
    if (file_put_contents($tmpZip, $bin) === false) {
        iva_json(['ok' => false, 'error' => 'Не удалось записать архив во временную папку']);
    }

    $tmpDir = sys_get_temp_dir() . '/va_extract_' . bin2hex(random_bytes(4));
    @mkdir($tmpDir, 0755, true);

    try {
        if (class_exists('ZipArchive')) {
            $z = new ZipArchive();
            $r = $z->open($tmpZip);
            if ($r !== true) {
                throw new RuntimeException('Архив повреждён (ZipArchive code ' . $r . ')');
            }
            $z->extractTo($tmpDir);
            $z->close();
        } else {
            $phar = new PharData($tmpZip);
            $phar->extractTo($tmpDir, null, true);
        }
    } catch (Throwable $e) {
        @unlink($tmpZip);
        iva_rrmdir($tmpDir);
        iva_json(['ok' => false, 'error' => 'Распаковка не удалась: ' . $e->getMessage()]);
    }
    @unlink($tmpZip);

    $root = iva_find_project_root($tmpDir);
    if ($root === null) {
        iva_rrmdir($tmpDir);
        iva_json(['ok' => false, 'error' => 'В архиве не найден проект VladAero (нужны папка app/ и index.php)']);
    }

    $moved = iva_merge_dir($root, iva_root());
    iva_rrmdir($tmpDir);

    if (!iva_code_present()) {
        iva_json(['ok' => false, 'error' => 'Файлы скопированы, но app/Core/App.php не найден. Проверьте архив.']);
    }
    iva_json(['ok' => true, 'msg' => "Код развёрнут: перемещено $moved объектов. Обновите страницу и продолжите установку."]);
}

function iva_find_project_root(string $dir, int $depth = 0): ?string
{
    if ($depth > 3) {
        return null;
    }
    if (is_file($dir . '/app/Core/App.php') && is_file($dir . '/index.php')) {
        return $dir;
    }
    foreach (glob($dir . '/*', GLOB_ONLYDIR) ?: [] as $sub) {
        $name = basename($sub);
        if (in_array($name, ['__MACOSX', '.git', 'node_modules'], true)) {
            continue;
        }
        $found = iva_find_project_root($sub, $depth + 1);
        if ($found !== null) {
            return $found;
        }
    }
    return null;
}

/** Копирует содержимое $src в $dst, не удаляя существующие данные (кроме install.php) */
function iva_merge_dir(string $src, string $dst): int
{
    $n = 0;
    foreach (scandir($src) ?: [] as $item) {
        if ($item === '.' || $item === '..') {
            continue;
        }
        if ($item === 'install.php' || $item === '.git' || str_starts_with($item, '._')) {
            continue; // текущий установщик не трогаем
        }
        $from = $src . '/' . $item;
        $to = $dst . '/' . $item;
        if (is_dir($from)) {
            if (!is_dir($to)) {
                @mkdir($to, 0755, true);
            }
            $n += iva_merge_dir($from, $to);
        } else {
            if (!is_dir(dirname($to))) {
                @mkdir(dirname($to), 0755, true);
            }
            if (@copy($from, $to)) {
                $n++;
            }
        }
    }
    return $n;
}

function iva_rrmdir(string $dir): void
{
    if (!is_dir($dir)) {
        return;
    }
    foreach (scandir($dir) ?: [] as $item) {
        if ($item === '.' || $item === '..') {
            continue;
        }
        $p = $dir . '/' . $item;
        is_dir($p) ? iva_rrmdir($p) : @unlink($p);
    }
    @rmdir($dir);
}

/* ---------------------------------------------------------------------------
 * Шаг 2: база данных (в.203, 204, 215)
 * ------------------------------------------------------------------------ */
function iva_db_connect(array $c): PDO
{
    $pdo = new PDO(
        sprintf('mysql:host=%s;port=%s;charset=utf8mb4', $c['host'], $c['port']),
        $c['user'],
        $c['pass'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_TIMEOUT => 8]
    );
    return $pdo;
}

function iva_ajax_dbtest(): never
{
    if (!iva_tok_ok()) {
        iva_json(['ok' => false, 'error' => 'Сессия установки истекла — обновите страницу']);
    }
    $c = [
        'host' => trim((string)($_POST['host'] ?? 'localhost')),
        'port' => trim((string)($_POST['port'] ?? '3306')) ?: '3306',
        'name' => trim((string)($_POST['name'] ?? '')),
        'user' => trim((string)($_POST['user'] ?? '')),
        'pass' => (string)($_POST['pass'] ?? ''),
        'prefix' => iva_norm_prefix((string)($_POST['prefix'] ?? 'va_')),
    ];
    if ($c['name'] === '' || $c['user'] === '') {
        iva_json(['ok' => false, 'error' => 'Укажите имя базы и пользователя']);
    }
    try {
        $pdo = iva_db_connect($c);
    } catch (Throwable $e) {
        iva_json(['ok' => false, 'error' => 'Подключение не удалось: ' . $e->getMessage()]);
    }

    $ver = (string)$pdo->getAttribute(PDO::ATTR_SERVER_VERSION);
    // MySQL >= 5.7 или MariaDB >= 10.2 (тип JSON, utf8mb4)
    $isMaria = stripos($ver, 'mariadb') !== false;
    $minorOk = true;
    if (preg_match('#(\d+)\.(\d+)#', $ver, $m)) {
        $minorOk = $isMaria ? (((int)$m[1] > 10) || ((int)$m[1] === 10 && (int)$m[2] >= 2))
                            : (((int)$m[1] > 5) || ((int)$m[1] === 5 && (int)$m[2] >= 7));
    }
    if (!$minorOk) {
        iva_json(['ok' => false, 'error' => "Сервер $ver слишком стар: нужен MySQL ≥ 5.7 или MariaDB ≥ 10.2 (тип JSON, в.202)"]);
    }
    try {
        $pdo->exec("USE `{$c['name']}`");
    } catch (Throwable $e) {
        iva_json(['ok' => false, 'error' => "База «{$c['name']}» недоступна: " . $e->getMessage()
            . '. Создайте базу в панели хостинга и повторите.']);
    }

    $coll = (string)$pdo->query("SELECT @@character_set_database")->fetchColumn();
    $tables = [];
    $st = $pdo->prepare('SHOW TABLES LIKE ?');
    $st->execute([$c['prefix'] . '%']);
    foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $t) {
        $tables[] = (string)$t;
    }

    iva_json([
        'ok'      => true,
        'version' => $ver,
        'charset' => $coll,
        'conflict' => count($tables),
        'prefix'  => $c['prefix'],
        'msg'     => 'Соединение установлено · MySQL ' . $ver . ' · таблиц с префиксом ' . $c['prefix'] . ': ' . count($tables),
    ]);
}

/* ---------------------------------------------------------------------------
 * Схема таблиц (utf8mb4_unicode_ci, в.204) — выполняется по одной таблице
 * ------------------------------------------------------------------------ */
function iva_table_sql(string $prefix, string $table): string
{
    $t = $prefix . $table;
    return match ($table) {
        'settings' => "CREATE TABLE IF NOT EXISTS `$t` (
            `k` VARCHAR(64) NOT NULL PRIMARY KEY,
            `v` MEDIUMTEXT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'users' => "CREATE TABLE IF NOT EXISTS `$t` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `username` VARCHAR(32) NOT NULL UNIQUE,
            `email` VARCHAR(190) NOT NULL UNIQUE,
            `password_hash` VARCHAR(255) NOT NULL,
            `role` ENUM('user','editor','screener','moderator','admin') NOT NULL DEFAULT 'user',
            `rank` ENUM('cadet','second','first','cpt') NOT NULL DEFAULT 'cadet',
            `reputation` INT NOT NULL DEFAULT 0,
            `avatar` VARCHAR(255) NULL,
            `about` TEXT NULL,
            `status` ENUM('active','banned') NOT NULL DEFAULT 'active',
            `failed_attempts` TINYINT UNSIGNED NOT NULL DEFAULT 0,
            `locked_until` DATETIME NULL,
            `telegram_id` BIGINT UNSIGNED NULL UNIQUE,
            `last_seen` DATETIME NULL,
            `created_at` DATETIME NOT NULL,
            INDEX `idx_users_role` (`role`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'audit_log' => "CREATE TABLE IF NOT EXISTS `$t` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `user_id` INT UNSIGNED NULL,
            `action` VARCHAR(64) NOT NULL,
            `entity` VARCHAR(32) NULL,
            `entity_id` INT UNSIGNED NULL,
            `details` JSON NULL,
            `ip` VARCHAR(45) NULL,
            `created_at` DATETIME NOT NULL,
            INDEX `idx_audit_entity` (`entity`,`entity_id`),
            INDEX `idx_audit_user` (`user_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'aircraft' => "CREATE TABLE IF NOT EXISTS `$t` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `slug` VARCHAR(150) NOT NULL UNIQUE,
            `name_ru` VARCHAR(190) NOT NULL,
            `name_en` VARCHAR(190) NULL,
            `icao_code` VARCHAR(8) NULL,
            `iata_code` VARCHAR(8) NULL,
            `category` ENUM('civil','military','ga','historic','uav') NOT NULL DEFAULT 'civil',
            `manufacturer` VARCHAR(120) NULL,
            `country` VARCHAR(120) NULL,
            `first_flight` DATE NULL,
            `status` ENUM('active','stored','retired','prototype') NOT NULL DEFAULT 'active',
            `specs` JSON NULL,
            `description_ru` MEDIUMTEXT NULL,
            `description_en` MEDIUMTEXT NULL,
            `hero_photo` VARCHAR(255) NULL,
            `model_3d` VARCHAR(255) NULL,
            `views` INT UNSIGNED NOT NULL DEFAULT 0,
            `created_at` DATETIME NOT NULL,
            `updated_at` DATETIME NULL,
            FULLTEXT KEY `ft_aircraft` (`name_ru`, `name_en`, `icao_code`),
            INDEX `idx_ac_cat` (`category`),
            INDEX `idx_ac_mfr` (`manufacturer`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'airlines' => "CREATE TABLE IF NOT EXISTS `$t` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `iata` VARCHAR(4) NULL,
            `icao` VARCHAR(6) NULL,
            `callsign` VARCHAR(64) NULL,
            `name_ru` VARCHAR(190) NOT NULL,
            `name_en` VARCHAR(190) NULL,
            `country` VARCHAR(120) NULL,
            `hub` VARCHAR(64) NULL,
            `founded` SMALLINT NULL,
            `logo` VARCHAR(255) NULL,
            `description_ru` MEDIUMTEXT NULL,
            INDEX `idx_al_iata` (`iata`), INDEX `idx_al_icao` (`icao`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'airports' => "CREATE TABLE IF NOT EXISTS `$t` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `icao` VARCHAR(6) NOT NULL UNIQUE,
            `iata` VARCHAR(4) NULL,
            `name_ru` VARCHAR(190) NOT NULL,
            `name_en` VARCHAR(190) NULL,
            `city_ru` VARCHAR(120) NULL,
            `city_en` VARCHAR(120) NULL,
            `country_code` CHAR(2) NULL,
            `lat` DECIMAL(9,6) NULL,
            `lng` DECIMAL(9,6) NULL,
            `elevation_ft` SMALLINT NULL,
            `runways` JSON NULL,
            `frequencies` JSON NULL,
            `timezone` VARCHAR(64) NULL,
            `website` VARCHAR(255) NULL,
            `description_ru` MEDIUMTEXT NULL,
            INDEX `idx_ap_iata` (`iata`), INDEX `idx_ap_country` (`country_code`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'articles' => "CREATE TABLE IF NOT EXISTS `$t` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `slug` VARCHAR(190) NOT NULL UNIQUE,
            `title_ru` VARCHAR(220) NOT NULL,
            `title_en` VARCHAR(220) NULL,
            `excerpt_ru` TEXT NULL,
            `body_json` LONGTEXT NULL,
            `cover` VARCHAR(255) NULL,
            `status` ENUM('draft','review','published') NOT NULL DEFAULT 'draft',
            `author_id` INT UNSIGNED NULL,
            `published_at` DATETIME NULL,
            `views` INT UNSIGNED NOT NULL DEFAULT 0,
            `created_at` DATETIME NOT NULL,
            `updated_at` DATETIME NULL,
            FULLTEXT KEY `ft_articles` (`title_ru`, `title_en`, `excerpt_ru`),
            INDEX `idx_art_status` (`status`,`published_at`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'photos' => "CREATE TABLE IF NOT EXISTS `$t` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `user_id` INT UNSIGNED NULL,
            `aircraft_id` INT UNSIGNED NULL,
            `airline_id` INT UNSIGNED NULL,
            `airport_id` INT UNSIGNED NULL,
            `event_id` INT UNSIGNED NULL,
            `registration` VARCHAR(20) NULL,
            `filename` VARCHAR(255) NOT NULL,
            `original_name` VARCHAR(255) NULL,
            `title` VARCHAR(220) NULL,
            `license` VARCHAR(64) NULL DEFAULT 'ARR',
            `exif` JSON NULL,
            `status` ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
            `reject_reason` VARCHAR(255) NULL,
            `taken_at` DATETIME NULL,
            `lat` DECIMAL(9,6) NULL,
            `lng` DECIMAL(9,6) NULL,
            `likes` INT UNSIGNED NOT NULL DEFAULT 0,
            `views` INT UNSIGNED NOT NULL DEFAULT 0,
            `created_at` DATETIME NOT NULL,
            INDEX `idx_ph_status` (`status`,`created_at`),
            INDEX `idx_ph_reg` (`registration`),
            INDEX `idx_ph_user` (`user_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'events' => "CREATE TABLE IF NOT EXISTS `$t` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `slug` VARCHAR(190) NOT NULL UNIQUE,
            `title_ru` VARCHAR(220) NOT NULL,
            `type` ENUM('airshow','spotting','virtual','museum','meetup') NOT NULL DEFAULT 'airshow',
            `status` ENUM('published','pending','rejected') NOT NULL DEFAULT 'published',
            `starts_at` DATETIME NOT NULL,
            `ends_at` DATETIME NULL,
            `country_code` CHAR(2) NULL,
            `city` VARCHAR(120) NULL,
            `venue` VARCHAR(190) NULL,
            `lat` DECIMAL(9,6) NULL,
            `lng` DECIMAL(9,6) NULL,
            `description_ru` MEDIUMTEXT NULL,
            `url` VARCHAR(255) NULL,
            `created_by` INT UNSIGNED NULL,
            `created_at` DATETIME NOT NULL,
            INDEX `idx_ev_start` (`starts_at`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'comments' => "CREATE TABLE IF NOT EXISTS `$t` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `user_id` INT UNSIGNED NOT NULL,
            `entity_type` VARCHAR(24) NOT NULL,
            `entity_id` INT UNSIGNED NOT NULL,
            `parent_id` INT UNSIGNED NULL,
            `body` TEXT NOT NULL,
            `status` ENUM('approved','pending','rejected') NOT NULL DEFAULT 'approved',
            `ip` VARCHAR(45) NULL,
            `created_at` DATETIME NOT NULL,
            INDEX `idx_cm_entity` (`entity_type`,`entity_id`,`status`,`created_at`),
            INDEX `idx_cm_user` (`user_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'versus_votes' => "CREATE TABLE IF NOT EXISTS `$t` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `user_id` INT UNSIGNED NOT NULL,
            `aircraft_a` INT UNSIGNED NOT NULL,
            `aircraft_b` INT UNSIGNED NOT NULL,
            `winner_id` INT UNSIGNED NOT NULL,
            `created_at` DATETIME NOT NULL,
            UNIQUE KEY `uq_vv_pair` (`user_id`,`aircraft_a`,`aircraft_b`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'clubs' => "CREATE TABLE IF NOT EXISTS `$t` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `slug` VARCHAR(190) NOT NULL UNIQUE,
            `title` VARCHAR(190) NOT NULL,
            `kind` ENUM('airport','actype','sim','other') NOT NULL DEFAULT 'other',
            `description` TEXT NULL,
            `owner_id` INT UNSIGNED NOT NULL,
            `status` ENUM('approved','pending','rejected') NOT NULL DEFAULT 'pending',
            `created_at` DATETIME NOT NULL,
            INDEX `idx_cl_status` (`status`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'club_members' => "CREATE TABLE IF NOT EXISTS `$t` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `club_id` INT UNSIGNED NOT NULL,
            `user_id` INT UNSIGNED NOT NULL,
            `joined_at` DATETIME NOT NULL,
            UNIQUE KEY `uq_cm2` (`club_id`,`user_id`),
            INDEX `idx_cm2_user` (`user_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'lessons' => "CREATE TABLE IF NOT EXISTS `$t` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `slug` VARCHAR(190) NOT NULL UNIQUE,
            `level` ENUM('basic','vfr','ifr','avionics','pro') NOT NULL DEFAULT 'basic',
            `sort` SMALLINT UNSIGNED NOT NULL DEFAULT 100,
            `title_ru` VARCHAR(220) NOT NULL,
            `summary_ru` VARCHAR(500) NULL,
            `body_json` LONGTEXT NULL,
            `quiz_json` LONGTEXT NULL,
            `published` TINYINT UNSIGNED NOT NULL DEFAULT 1,
            `created_at` DATETIME NOT NULL,
            `updated_at` DATETIME NULL,
            INDEX `idx_ls_level` (`level`,`sort`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'lesson_progress' => "CREATE TABLE IF NOT EXISTS `$t` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `user_id` INT UNSIGNED NOT NULL,
            `lesson_id` INT UNSIGNED NOT NULL,
            `quiz_score` TINYINT UNSIGNED NOT NULL DEFAULT 0,
            `passed_at` DATETIME NOT NULL,
            UNIQUE KEY `uq_lp` (`user_id`,`lesson_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'bookmarks' => "CREATE TABLE IF NOT EXISTS `$t` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `user_id` INT UNSIGNED NOT NULL,
            `entity_type` VARCHAR(24) NOT NULL,
            `entity_id` INT UNSIGNED NOT NULL,
            `created_at` DATETIME NOT NULL,
            UNIQUE KEY `uq_bm` (`user_id`,`entity_type`,`entity_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'event_attendees' => "CREATE TABLE IF NOT EXISTS `$t` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `event_id` INT UNSIGNED NOT NULL,
            `user_id` INT UNSIGNED NOT NULL,
            `created_at` DATETIME NOT NULL,
            UNIQUE KEY `uq_ea` (`event_id`,`user_id`),
            INDEX `idx_ea_user` (`user_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'author_follows' => "CREATE TABLE IF NOT EXISTS `$t` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `user_id` INT UNSIGNED NOT NULL,
            `author_id` INT UNSIGNED NOT NULL,
            `created_at` DATETIME NOT NULL,
            UNIQUE KEY `uq_af_pair` (`user_id`,`author_id`),
            INDEX `idx_af_author` (`author_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'dm' => "CREATE TABLE IF NOT EXISTS `$t` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `from_user` INT UNSIGNED NOT NULL,
            `to_user` INT UNSIGNED NOT NULL,
            `body` TEXT NOT NULL,
            `read_at` DATETIME NULL,
            `created_at` DATETIME NOT NULL,
            INDEX `idx_dm_dialog` (`from_user`,`to_user`,`created_at`),
            INDEX `idx_dm_inbox` (`to_user`,`read_at`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'spot_points' => "CREATE TABLE IF NOT EXISTS `$t` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `icao` VARCHAR(8) NOT NULL,
            `title_ru` VARCHAR(160) NOT NULL,
            `description_ru` TEXT NOT NULL,
            `lat` DECIMAL(9,6) NOT NULL,
            `lng` DECIMAL(9,6) NOT NULL,
            `light_hint` VARCHAR(240) NULL,
            `status` ENUM('published','pending','rejected') NOT NULL DEFAULT 'pending',
            `created_by` INT UNSIGNED NOT NULL DEFAULT 0,
            `created_at` DATETIME NOT NULL,
            INDEX `idx_sp_icao` (`icao`,`status`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'push_subscriptions' => "CREATE TABLE IF NOT EXISTS `$t` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `user_id` INT UNSIGNED NOT NULL,
            `endpoint` VARCHAR(500) NOT NULL,
            `p256dh` VARCHAR(200) NOT NULL,
            `auth` VARCHAR(120) NOT NULL,
            `lang` VARCHAR(8) NOT NULL DEFAULT 'ru',
            `created_at` DATETIME NOT NULL,
            `last_push_at` DATETIME NULL,
            UNIQUE KEY `uq_ps_endpoint` (`endpoint`(191)),
            INDEX `idx_ps_user` (`user_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'notifications' => "CREATE TABLE IF NOT EXISTS `$t` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `user_id` INT UNSIGNED NOT NULL,
            `type` VARCHAR(48) NOT NULL,
            `payload` JSON NULL,
            `read_at` DATETIME NULL,
            `created_at` DATETIME NOT NULL,
            INDEX `idx_ntf_user` (`user_id`,`read_at`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'flight_logs' => "CREATE TABLE IF NOT EXISTS `$t` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `user_id` INT UNSIGNED NOT NULL,
            `chat_id` BIGINT UNSIGNED NOT NULL DEFAULT 0,
            `route` VARCHAR(32) NOT NULL DEFAULT '—',
            `aircraft` VARCHAR(32) NOT NULL DEFAULT '—',
            `duration_min` SMALLINT UNSIGNED NOT NULL DEFAULT 0,
            `source` ENUM('tg','web') NOT NULL DEFAULT 'tg',
            `ticket_url` VARCHAR(255) NULL,
            `created_at` DATETIME NOT NULL,
            INDEX `idx_fl_user` (`user_id`,`created_at`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'tg_activity' => "CREATE TABLE IF NOT EXISTS `$t` (
            `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `chat_id` BIGINT NOT NULL DEFAULT 0,
            `direction` ENUM('in','out') NOT NULL DEFAULT 'in',
            `kind` VARCHAR(32) NULL,
            `command` VARCHAR(60) NULL,
            `length` SMALLINT UNSIGNED NOT NULL DEFAULT 0,
            `created_at` DATETIME NOT NULL,
            INDEX `idx_tga_time` (`created_at`),
            INDEX `idx_tga_chat` (`chat_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'ai_requests' => "CREATE TABLE IF NOT EXISTS `$t` (
            `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `user_id` INT UNSIGNED NULL,
            `ip` VARCHAR(45) NULL,
            `context` ENUM('widget','admin','quiz','briefing') NOT NULL DEFAULT 'widget',
            `model` VARCHAR(96) NULL,
            `prompt_tokens` INT UNSIGNED NULL,
            `completion_tokens` INT UNSIGNED NULL,
            `tool_calls` SMALLINT UNSIGNED NULL,
            `created_at` DATETIME NOT NULL,
            INDEX `idx_ai_user` (`user_id`,`created_at`),
            INDEX `idx_ai_time` (`created_at`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'ai_chats' => "CREATE TABLE IF NOT EXISTS `$t` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `user_id` INT UNSIGNED NOT NULL,
            `title` VARCHAR(190) NULL,
            `created_at` DATETIME NOT NULL,
            `updated_at` DATETIME NULL,
            INDEX `idx_chat_user` (`user_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'ai_chat_messages' => "CREATE TABLE IF NOT EXISTS `$t` (
            `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `chat_id` INT UNSIGNED NOT NULL,
            `role` ENUM('system','user','assistant','tool') NOT NULL,
            `content` LONGTEXT NULL,
            `meta` JSON NULL,
            `created_at` DATETIME NOT NULL,
            INDEX `idx_msg_chat` (`chat_id`,`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'tg_links' => "CREATE TABLE IF NOT EXISTS `$t` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `user_id` INT UNSIGNED NOT NULL,
            `telegram_id` BIGINT UNSIGNED NOT NULL,
            `chat_id` BIGINT UNSIGNED NOT NULL,
            `username` VARCHAR(64) NULL,
            `notify_flags` JSON NULL,
            `created_at` DATETIME NOT NULL,
            UNIQUE KEY `uq_tg_telegram` (`telegram_id`),
            INDEX `idx_tg_user` (`user_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'media' => "CREATE TABLE IF NOT EXISTS `$t` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `user_id` INT UNSIGNED NULL,
            `kind` ENUM('image','video','audio','panorama','model3d','file') NOT NULL DEFAULT 'image',
            `filename` VARCHAR(255) NOT NULL,
            `original_name` VARCHAR(255) NULL,
            `path` VARCHAR(255) NOT NULL,
            `thumb_path` VARCHAR(255) NULL,
            `width` SMALLINT UNSIGNED NULL,
            `height` SMALLINT UNSIGNED NULL,
            `size` INT UNSIGNED NOT NULL DEFAULT 0,
            `mime` VARCHAR(100) NULL,
            `exif` JSON NULL,
            `alt` VARCHAR(255) NULL,
            `credit` VARCHAR(190) NULL,
            `license` VARCHAR(64) NULL DEFAULT 'ARR',
            `created_at` DATETIME NOT NULL,
            INDEX `idx_media_kind` (`kind`),
            INDEX `idx_media_user` (`user_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'blocks' => "CREATE TABLE IF NOT EXISTS `$t` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `entity` VARCHAR(32) NOT NULL,
            `entity_id` INT UNSIGNED NOT NULL,
            `blocks` LONGTEXT NULL,
            `updated_at` DATETIME NOT NULL,
            `updated_by` INT UNSIGNED NULL,
            UNIQUE KEY `uq_blocks_entity` (`entity`, `entity_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'block_drafts' => "CREATE TABLE IF NOT EXISTS `$t` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `entity` VARCHAR(32) NOT NULL,
            `entity_id` INT UNSIGNED NOT NULL,
            `user_id` INT UNSIGNED NOT NULL,
            `blocks` LONGTEXT NULL,
            `updated_at` DATETIME NOT NULL,
            UNIQUE KEY `uq_draft` (`entity`, `entity_id`, `user_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        default => throw new RuntimeException("Неизвестная таблица: $table"),
    };
}

/* ---------------------------------------------------------------------------
 * Конфиги (в.205)
 * ------------------------------------------------------------------------ */
function iva_config_app(string $baseUrl, string $tz, string $siteName): string
{
    $baseUrl = var_export(rtrim($baseUrl, '/'), true);
    $tz = var_export($tz, true);
    $siteName = var_export($siteName, true);
    return <<<PHP
<?php
/**
 * VladAero — конфигурация приложения (создано установщиком).
 * Не храните этот файл в публичном доступе: прикрыт .htaccess.
 */
return [
    'url'      => $baseUrl,
    'timezone' => $tz,
    'site_name'=> $siteName,
    'version'  => '0.8.3',
    'debug'    => false,
];
PHP;
}

function iva_config_db(array $c): string
{
    $host = var_export($c['host'], true);
    $port = var_export((string)(int)$c['port'], true);
    $name = var_export($c['name'], true);
    $user = var_export($c['user'], true);
    $pass = var_export($c['pass'], true);
    $prefix = var_export($c['prefix'], true);
    return <<<PHP
<?php
/**
 * VladAero — подключение к базе данных (создано установщиком, в.205).
 */
return [
    'host'   => $host,
    'port'   => $port,
    'name'   => $name,
    'user'   => $user,
    'pass'   => $pass,
    'prefix' => $prefix,
];
PHP;
}

/* ---------------------------------------------------------------------------
 * AJAX: миграция по одной таблице (в.212) + финализация
 * ------------------------------------------------------------------------ */
function iva_state(): array
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_name('VAINSTALLER');
        session_start();
    }
    return $_SESSION['iva_state'] ?? [];
}

function iva_state_set(array $s): void
{
    $_SESSION['iva_state'] = $s;
}

function iva_ajax_migrate(): never
{
    if (!iva_tok_ok()) {
        iva_json(['ok' => false, 'error' => 'Сессия истекла — начните установку заново']);
    }
    $s = iva_state();
    $need = ['host', 'port', 'name', 'user', 'pass', 'prefix', 'drop_mode'];
    foreach ($need as $k) {
        if (!isset($s[$k])) {
            iva_json(['ok' => false, 'error' => "Нет данных шага БД ($k) — вернитесь к шагу 2"]);
        }
    }

    $step = max(0, (int)($_POST['step'] ?? 0));
    try {
        $pdo = iva_db_connect($s);
        $pdo->exec("USE `{$s['name']}`");

        if ($step === 0 && $s['drop_mode'] === 'drop') {
            foreach (VA_TABLES as $t) {
                $pdo->exec("DROP TABLE IF EXISTS `{$s['prefix']}$t`");
            }
        }

        if ($step < count(VA_TABLES)) {
            $table = VA_TABLES[$step];
            $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");
            $pdo->exec(iva_table_sql($s['prefix'], $table));
            $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");
            iva_json([
                'ok'    => true,
                'step'  => $step + 1,
                'total' => count(VA_TABLES),
                'table' => $table,
                'done'  => false,
            ]);
        }

        // Все таблицы готовы — заполняем настройки и админа
        $now = date('Y-m-d H:i:s');
        $st = $pdo->prepare("REPLACE INTO `{$s['prefix']}settings` (k, v) VALUES (?, ?)");
        $defaults = [
            'site_name'     => $s['site_name'],
            'tagline'       => 'Авиационный портал',
            'default_theme' => 'dark',
            'default_lang'  => 'ru',
            'timezone'      => $s['timezone'],
            'maintenance'   => '0',
            'maintenance_text' => '',
            'registration_enabled' => $s['registration'] ?? '1',
            'cron_key'      => bin2hex(random_bytes(16)),
            'ai_limit_guest' => '15',
            'ai_limit_user'  => '100',
            'schema_version' => '8', // базовая схема создана установщиком; миграции 09+ применятся автоматически
        ];
        foreach ($defaults as $k => $v) {
            $st->execute([$k, $v]);
        }

        $admin = $s['admin'] ?? null;
        if (!is_array($admin) || empty($admin['login']) || empty($admin['password'])) {
            iva_json(['ok' => false, 'error' => 'Нет данных администратора — вернитесь к шагу 3']);
        }
        $ins = $pdo->prepare(
            "INSERT INTO `{$s['prefix']}users`
             (username, email, password_hash, role, rank, status, created_at, last_seen)
             VALUES (?, ?, ?, 'admin', 'cpt', 'active', ?, ?)"
        );
        $ins->execute([
            $admin['login'],
            $admin['email'],
            password_hash($admin['password'], PASSWORD_BCRYPT, ['cost' => 12]),
            $now,
            $now,
        ]);
        if (!empty($admin['recovery'])) {
            $st->execute(['admin_recovery_hash', password_hash($admin['recovery'], PASSWORD_BCRYPT, ['cost' => 12])]);
        }

        // Программа Лётной школы (в.24) — редакционный контент системы
        iva_seed_lessons($pdo, $s['prefix']);

        // Демо-данные (в.206) — по чекбоксу шага 5
        if (($s['demo_data'] ?? '1') === '1') {
            iva_seed_demo($pdo, $s['prefix']);
        }

        // Финальный шаг: конфиги + замок (в.211)
        $cfgDir = iva_root() . '/app/config';
        if (!is_dir($cfgDir)) {
            @mkdir($cfgDir, 0755, true);
        }
        file_put_contents($cfgDir . '/app.php', iva_config_app($s['base_url'], $s['timezone'], $s['site_name']));
        @chmod($cfgDir . '/app.php', 0644);
        file_put_contents($cfgDir . '/database.php', iva_config_db($s));
        @chmod($cfgDir . '/database.php', 0644);
        file_put_contents($cfgDir . '/installed.lock', 'installed ' . $now . "\n");
        @chmod($cfgDir . '/installed.lock', 0644);

        // Подхватываем брендинг, загруженный на шаге 4
        if (!empty($s['branding'])) {
            foreach ($s['branding'] as $k => $relPath) {
                $st->execute([$k, $relPath]);
            }
        }

        unset($_SESSION['iva_state']);
        iva_json(['ok' => true, 'step' => count(VA_TABLES), 'total' => count(VA_TABLES), 'done' => true]);
    } catch (Throwable $e) {
        iva_json(['ok' => false, 'error' => 'Шаг ' . $step . ': ' . $e->getMessage(), 'step' => $step]);
    }
}

/**
 * Демо-данные (в.206): аэропорты, борта, авиакомпании, статьи, события.
 * Компактный стартовый набор — всё заменяется в админке.
 */
function iva_seed_demo(PDO $pdo, string $prefix): void
{
    $now = date('Y-m-d H:i:s');
    $ev = static fn(int $d, string $h) => date('Y-m-d H:i:s', strtotime("+$d day $h"));

    $ap = $pdo->prepare("INSERT IGNORE INTO `{$prefix}airports` (icao,iata,name_ru,city_ru,country_code,lat,lng,elevation_ft,runways,timezone,description_ru) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
    foreach ([
        ['UUEE','SVO','Шереметьево','Москва','RU',55.9726,37.4146,630,'[{"name":"24L/06R","len_m":3550},{"name":"24R/06L","len_m":3700}]','Europe/Moscow','Крупнейший аэропорт России, хаб Аэрофлота.'],
        ['UUDD','DME','Домодедово','Москва','RU',55.4088,37.9063,588,'[{"name":"14L/32R","len_m":3800}]','Europe/Moscow','Современный южный терминал столицы.'],
        ['ULLI','LED','Пулково','Санкт-Петербург','RU',59.8003,30.2625,79,'[{"name":"10L/28R","len_m":3782}]','Europe/Moscow','Ворота Северной столицы.'],
        ['LIRF','FCO','Фьюмичино','Рим','IT',41.8003,12.2389,13,'[{"name":"16R/34L","len_m":3900}]','Europe/Rome','Главный аэропорт Италии.'],
        ['EGLL','LHR','Хитроу','Лондон','GB',51.4700,-0.4543,83,'[{"name":"09R/27L","len_m":3902}]','Europe/London','Один из самых загруженных аэропортов мира.'],
        ['LFPG','CDG','Шарль-де-Голль','Париж','FR',49.0097,2.5479,392,'[{"name":"08L/26R","len_m":4215}]','Europe/Paris','Хаб Air France.'],
        ['KJFK','JFK','Кеннеди','Нью-Йорк','US',40.6413,-73.7781,13,'[{"name":"13L/31R","len_m":3048}]','America/New_York','Ворота в США.'],
        ['OMDB','DXB','Дубай','Дубай','AE',25.2532,55.3657,62,'[{"name":"12R/30L","len_m":4000}]','Asia/Dubai','Самый загруженный аэропорт международного трафика.'],
    ] as $r) { $ap->execute([$r[0],$r[1],$r[2],$r[3],$r[4],$r[5],$r[6],$r[7],$r[8],$r[9],$r[10]]); }

    $ac = $pdo->prepare("INSERT IGNORE INTO `{$prefix}aircraft` (slug,name_ru,name_en,icao_code,category,manufacturer,country,first_flight,status,specs,description_ru,views,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
    foreach ([
        ['tu-154m','Ту-154М','Tupolev Tu-154M','T154','civil','Туполев','RU','1984-01-01','retired','{"wingspan_m":37.6,"length_m":47.9,"cruise_speed_kmh":850,"max_speed_kmh":950,"range_km":6600,"ceiling_m":11900,"pax_max":180,"engines":3,"mtow_kg":100000,"takeoff_run_m":2050}','Легенда советской гражданской авиации, «буханка» — три двигателя НК-8-2 на пилоне.',11],
        ['il-96-300','Ил-96-300','Ilyushin Il-96-300','IL96','civil','Ил','RU','1988-09-28','active','{"wingspan_m":60.1,"length_m":55.3,"cruise_speed_kmh":850,"max_speed_kmh":900,"range_km":11000,"ceiling_m":12000,"pax_max":262,"engines":4,"mtow_kg":250000,"takeoff_run_m":2700}','Широкофюзеляжный дальнемагистральник для маршрутной сети «Аэрофлота».',8],
        ['ssj-100','Sukhoi Superjet 100','Sukhoi Superjet 100','SU95','civil','Sukhoi','RU','2008-05-19','active','{"wingspan_m":27.8,"length_m":29.9,"cruise_speed_kmh":830,"max_speed_kmh":910,"range_km":3000,"ceiling_m":12200,"pax_max":98,"engines":2,"mtow_kg":49450,"takeoff_run_m":1800}','Российский региональный самолёт нового поколения.',15],
        ['b737-800','Boeing 737-800','Boeing 737-800','B738','civil','Boeing','US','1994-07-31','active','{"wingspan_m":35.8,"length_m":39.5,"cruise_speed_kmh":840,"max_speed_kmh":940,"range_km":5400,"ceiling_m":12500,"pax_max":189,"engines":2,"mtow_kg":79010,"takeoff_run_m":2300}','Самый массовый узкофюзеляжник планеты.',21],
        ['a320neo','Airbus A320neo','Airbus A320neo','A20N','civil','Airbus','FR','2012-09-25','active','{"wingspan_m":35.8,"length_m":37.6,"cruise_speed_kmh":830,"max_speed_kmh":920,"range_km":6300,"ceiling_m":12000,"pax_max":195,"engines":2,"mtow_kg":79000,"takeoff_run_m":2100}','Тихие и экономичные двигатели — новая эра одномагистральных перелётов.',17],
        ['b777-300er','Boeing 777-300ER','Boeing 777-300ER','B77W','civil','Boeing','US','2003-02-24','active','{"wingspan_m":64.8,"length_m":73.9,"cruise_speed_kmh":890,"max_speed_kmh":980,"range_km":13650,"ceiling_m":13100,"pax_max":550,"engines":2,"mtow_kg":351530,"takeoff_run_m":3100}','Рекордсмен дальности среди двухмоторных лайнеров.',13],
    ] as $r) { $ac->execute([$r[0],$r[1],$r[2],$r[3],$r[4],$r[5],$r[6],$r[7],$r[8],$r[9],$r[10],$r[11],$now,$now]); }

    $al = $pdo->prepare("INSERT IGNORE INTO `{$prefix}airlines` (icao,iata,name_ru,name_en,country,hub,description_ru) VALUES (?,?,?,?,?,?,?)");
    foreach ([
        ['AFL','SU','Аэрофлот','Aeroflot','RU','UUEE','Старейшая авиакомпания мира (с 1923 года).'],
        ['SBI','S7','S7 Airlines','S7 Airlines','RU','UUEE','Крупнейшая частная авиакомпания России.'],
        ['UAE','EK','Emirates','Emirates','AE','OMDB','Флагман Дубая, огромный флот A380 и B777.'],
        ['RYR','FR','Ryanair','Ryanair','IE','EGSS','Крупнейший лоукост Европы.'],
    ] as $r) { $al->execute([$r[0],$r[1],$r[2],$r[3],$r[4],$r[5],$r[6]]); }

    $blocks1 = json_encode([
        ['t'=>'heading','d'=>['text'=>'Пять причин смотреть в небо']],
        ['t'=>'text','d'=>['text'=>'Споттинг — это наблюдение за самолётами с фото- или видеотехникой. Портал VladAero собирает всё для этого хобби: расписания, радар, погоду и точки наблюдения.']],
        ['t'=>'list','v'=>'ul','d'=>['items'=>['Живой радар ADS-B с историей треков','METAR/TAF с расшифровкой для новичков','Онлайн-табло 2000+ аэропортов','Карта веб-камер и дни споттинга']]],
        ['t'=>'callout','d'=>['title'=>'Совет','text'=>'Начните с таблицы лучшего времени света — золотой час делает кадр.']],
    ], JSON_UNESCAPED_UNICODE);
    $blocks2 = json_encode([
        ['t'=>'heading','d'=>['text'=>'Как читать METAR за 5 минут']],
        ['t'=>'text','d'=>['text'=>'METAR — это регулярная сводка фактической погоды аэродрома. Разберём пример по полям.']],
        ['t'=>'code','d'=>['code'=>'METAR UUEE 031400Z 27008MPS 9999 BKN016 18/12 Q1015 NOSIG']],
        ['t'=>'metar','d'=>['icao'=>'UUEE']],
    ], JSON_UNESCAPED_UNICODE);
    $art = $pdo->prepare("INSERT IGNORE INTO `{$prefix}articles` (slug,title_ru,excerpt_ru,body_json,status,author_id,published_at,views,created_at,updated_at) VALUES (?,?,?,?,'published',1,?,?,?,?)");
    $art->execute(['spotting-guide','Споттинг: с чего начать','Пять шагов к первым кадрам самолётов',$blocks1,$now,42,$now,$now]);
    $art->execute(['metar-5min','METAR за 5 минут','Читаем погодную сводку как пилот',$blocks2,$now,30,$now,$now]);

    $sp = $pdo->prepare("INSERT IGNORE INTO `{$prefix}spot_points` (icao,title_ru,description_ru,lat,lng,light_hint,status,created_by,created_at) VALUES (?,?,?,?,?,?,'published',0,?)");
    foreach ([
        ['UUEE','Шереметьево, площадка у 25 ЛП','Классика для заходов на 24L: борт проходит прямо над головой на глиссаде. Ограждение, поле, летом — высокая трава.',55.9841,37.4167,'Утро: контровой свет вечером, лучший свет с 16:00'],
        ['UUDD','Домодедово, стрелка 32R','Смотровая у деревни: выходы на 32R и руление грузового терминала.',55.4312,37.9201,'Вечером — боковой свет на выпуск'],
        ['ULLI','Пулково, бухта у взлётной 10L','Вид на разбег и левый разворот на север.',59.8109,30.2689,'Первая половина дня'],
    ] as $r) { $sp->execute([$r[0],$r[1],$r[2],$r[3],$r[4],$r[5],$now]); }

    $evo = $pdo->prepare("INSERT IGNORE INTO `{$prefix}events` (slug,title_ru,type,status,starts_at,ends_at,country_code,city,venue,lat,lng,description_ru,created_by,created_at) VALUES (?,?,?,'published',?,?,?,?,?,?,?,?,0,?)");
    foreach ([
        ['demo-airshow','Демо: день споттинга в Шереметьево','spotting',$ev(14,'09:00'),$ev(14,'18:00'),'RU','Москва','Шереметьево, площадка у 25 ЛП',55.98,37.41,'Собираемся у ограждения: заходы на 24L, свет с утра. Дресс-код: тёплая куртка.'],
        ['demo-max','Демо: авиасалон МАКС','airshow',$ev(60,'10:00'),$ev(63,'18:00'),'RU','Жуковский','Аэродром ЛИИ им. Громова',55.55,38.14,'Пилотажные группы, статика и торговые ряды.'],
        ['demo-vatsim','Демо: виртуальный слёт VATSIM','virtual',$ev(7,'18:00'),$ev(7,'23:00'),'RU','Онлайн','VATSIM RFE',null,null,'Групповой перелёт симмеров: полукруг Европы, полная ATC-обслуга.'],
    ] as $r) { $evo->execute([$r[0],$r[1],$r[2],$r[3],$r[4],$r[5],$r[6],$r[7],$r[8],$r[9],$r[10],$now]); }
}

/**
 * Сид программы «Лётная школа» (в.24): 9 уроков с тестами.
 * Контент системный (как глоссарий), вставляется только в пустую таблицу.
 */
function iva_seed_lessons(PDO $pdo, string $prefix): void
{
    $n = (int)$pdo->query("SELECT COUNT(*) FROM `{$prefix}lessons`")->fetchColumn();
    if ($n > 0) { return; }
    $t = static fn(string $x) => ['t' => 'text', 'd' => ['text' => $x]];
    $h = static fn(string $x) => ['t' => 'heading', 'd' => ['text' => $x]];
    $ul = static fn(array $x) => ['t' => 'list', 'v' => 'ul', 'd' => ['items' => $x]];
    $call = static fn(string $a, string $b) => ['t' => 'callout', 'v' => 'warn', 'd' => ['title' => $a, 'text' => $b]];
    $q = static fn(array $questions) => json_encode(['pass' => 70, 'questions' => $questions], JSON_UNESCAPED_UNICODE);

    $lessons = [
        ['osnovy-aerodinamiki', 'basic', 10, 'Основы аэродинамики: четыре силы',
         'Почему самолёт летает: подъёмная сила, тяга, вес и сопротивление — и что происходит на больших углах атаки.',
         [
             $h('Четыре силы'),
             $t('В установившемся горизонтальном полёте четыре силы попарно уравновешены: подъёмная сила равна весу, тяга — лобовому сопротивлению. Любое маневрирование — это намеренное нарушение равновесия.'),
             $ul(['Подъёмная сила (Lift) — перпендикулярна набегающему потоку, растёт с углом атаки и квадратом скорости',
                  'Тяга (Thrust) — движущая сила двигателя, вперёд по оси самолёта',
                  'Вес (Weight) — к центру Земли, всегда против подъёмной силы',
                  'Сопротивление (Drag) — назад, по потоку; складывается из индуктивного и вредного']),
             $h('Угол атаки и срыв потока'),
             $t('Угол атаки (AoA) — угол между хордой крыла и набегающим потоком. С ростом AoA подъёмная сила растёт примерно линейно, но лишь до критического угла (у большинства профилей 15–18°). Дальше поток срывается с верхней поверхности крыла — подъёмная сила резко падает. Это сваливание (stall).'),
             $call('Запомните', 'Сваливание зависит от угла атаки, а не от скорости. Свалить самолёт можно и на большой скорости — резким движением рулём высоты.'),
             $t('Элероны управляют креном, руль высоты — углом тангажа (и косвенно AoA), руль направления — скольжением, закрылки увеличивают подъёмную силу и сопротивление, позволяя лететь медленнее на взлёте и посадке.'),
         ],
         $q([
             ['q' => 'От чего напрямую зависит наступление срыва потока?', 'options' => ['От скорости', 'От угла атаки', 'От высоты полёта'], 'correct' => 1, 'explain' => 'Срыв наступает при превышении критического угла атаки независимо от скорости.'],
             ['q' => 'Как скорость влияет на подъёмную силу?', 'options' => ['Линейно', 'Пропорционально квадрату скорости', 'Не влияет'], 'correct' => 1, 'explain' => 'Подъёмная сила пропорциональна квадрату скорости потока.'],
             ['q' => 'Что делают закрылки при посадке?', 'options' => ['Позволяют лететь медленнее с большей подъёмной силой', 'Увеличивают только скорость', 'Уменьшают сопротивление'], 'correct' => 0, 'explain' => 'Закрылки дают подъёмную силу и сопротивление — ниже скорость захода и круче глиссада.'],
         ])],
        ['polet-po-krugu', 'basic', 20, 'Взлёт, полёт по кругу и посадка',
         'Классическая схема полёта по кругу: четыре разворота, скорости на каждом этапе и стабилизированный заход.',
         [
             $h('Схема круга'),
             $t('Аэродромный круг — прямоугольный маршрут вокруг ВПП против часовой стрелки (левый круг), если иное не установлено. Он состоит из взлётной прямой, четырёх разворотов и посадочной прямой.'),
             $ul(['1-й разворот — на высоте не менее 100–150 м (по правилам аэродрома)',
                  '2-й разворот — выход на линию, удалённую от ВПП на 3–4 км',
                  '3-й разворот — на траверзе торца ВПП, вход в базу',
                  '4-й разворот — выход на посадочную прямую и глиссаду']),
             $h('Стабилизированный заход'),
             $t('Заход считается стабилизированным, если к высоте 150–200 м самолёт находится на осевой линии, на профиле глиссады (обычно 3°), с посадочной конфигурацией и установившейся скоростью Vref + поправки. Если хоть один параметр «поплыл» — уход на второй круг, это самый дешёвый маневр в авиации.'),
             $call('Правило', 'Приземление на главные опоры, носовое колесо опускается по мере падения скорости. Никогда не «сажайте» самолёт силой — он сам касается полосы, ваша задача — удержать направление и продольную ось.'),
         ],
         $q([
             ['q' => 'Сколько разворотов в стандартной схеме круга?', 'options' => ['Три', 'Четыре', 'Пять'], 'correct' => 1, 'explain' => 'Четыре разворота: после взлёта, дальняя, база, посадочная прямая.'],
             ['q' => 'Что делать при нестабилизированном заходе на 150 м?', 'options' => ['Продолжать заход', 'Уйти на второй круг', 'Добавить крен'], 'correct' => 1, 'explain' => 'Нестабилизированный заход — главный фактор грубых посадок; уход на второй круг обязателен.'],
         ])],
        ['chtenie-metar', 'vfr', 10, 'Чтение METAR и TAF',
         'Разбираем сводку погоды по полям: ветер, видимость, явления, облачность, температура и давление.',
         [
             $h('Структура METAR'),
             $t('METAR — регулярная фактическая погода аэродрома. Порядок всегда один: код станции, время, ветер, видимость, явления, облачность, температура/точка росы, давление, добавления.'),
             ['t' => 'code', 'd' => ['code' => 'METAR UUEE 031400Z 27008G14MPS 9999 -RA BKN016 18/12 Q1015 NOSIG']],
             $ul(['031400Z — число месяца 03, время 14:00 UTC (Zulu)',
                  '27008G14MPS — ветер 270°, 8 м/с, порывы до 14 м/с',
                  '9999 — видимость 10 км и более (в метрах)',
                  '-RA — слабый дождь (минус слабое, плюс сильное; RA дождь, SN снег, FG туман)',
                  'BKN016 — значительная облачность, нижняя кромка 1600 футов (FEW 1–2, SCT 3–4, BKN 5–7, OVC 8 октантов)',
                  '18/12 — температура 18 °C, точка росы 12 °C',
                  'Q1015 — QNH 1015 гПа; NOSIG — без значимых изменений']),
             $h('Живая сводка'),
             ['t' => 'metar', 'd' => ['icao' => 'UUEE']],
             $t('TAF — прогноз по той же грамматике на 9–30 часов. Ключевые группы изменений: FM (с такого-то времени), TEMPO (временами), BECMG (постепенно), PROB30/PROB40 (вероятность).'),
         ],
         $q([
             ['q' => 'Что означает BKN016?', 'options' => ['Ясно', 'Облачность 5–7 октантов на 1600 футов', 'Видимость 1600 м'], 'correct' => 1, 'explain' => 'BKN — 5–7 октантов, число — высота нижней кромки в сотнях футов.'],
             ['q' => 'Ветер 27008MPS — это…', 'options' => ['270°, 8 м/с', '27°, 800 м', '8 узлов'], 'correct' => 0, 'explain' => 'Первые три цифры — направление, следующие две — скорость в м/с (в РФ) или узлах (KT).'],
             ['q' => 'Что значит TEMPO в TAF?', 'options' => ['Постепенное изменение', 'Временами, менее половины периода', 'Ошибка наблюдателя'], 'correct' => 1, 'explain' => 'TEMPO — колебания менее 1 часа и суммарно менее половины периода.'],
         ])],
        ['vfr-nav', 'vfr', 20, 'Навигация визуального полёта',
         'Штурманская подготовка: маршрут, безопасная высота, ветер и снос, расчёт топлива и времени.',
         [
             $h('Подготовка к полёту'),
             $ul(['Проложить маршрут, измерить курс и расстояние по участкам',
                  'Определить безопасные высоты (LSALT) по рельефу и препятствиям',
                  'Оценить погоду по METAR/TAF вдоль маршрута и на запасных',
                  'Рассчитать топливо: маршрут + 30 мин резерв + запас на запасной']),
             $h('Ветер и снос'),
             $t('Боковой ветер сносит самолёт с линии заданного пути. Угол сноса тем больше, чем сильнее боковая составляющая и чем меньше истинная скорость. Путевая скорость = истинная воздушная ± продольная составляющая ветра: попутный прибавляет, встречный вычитает.'),
             $call('Практика', 'Держите в поле зрения наземные ориентиры и сверяйтесь каждые несколько минут: GPS — помощник, но взгляд наружу — главный инструмент VFR.'),
             $t('Расчёт топлива: для каждого участка время = расстояние / путевую скорость, расход = время × часовой расход. Итог складывается, добавляется 30-минутный резерв (правило VFR) и топливо на запасной аэродром.'),
         ],
         $q([
             ['q' => 'Минимальный топливный резерв днём по VFR?', 'options' => ['20 минут', '30 минут', '45 минут'], 'correct' => 1, 'explain' => '30 минут полёта на крейсерском режиме — стандартный резерв VFR.'],
             ['q' => 'Встречный ветер…', 'options' => ['Увеличивает путевую скорость', 'Уменьшает путевую скорость', 'Не влияет'], 'correct' => 1, 'explain' => 'Путевая скорость = воздушная минус встречная составляющая ветра.'],
         ])],
        ['sid-star', 'ifr', 10, 'Схемы SID, STAR и заход ILS',
         'Как читать стандартные маршруты вылета и прибытия и что происходит на точном заходе по курсоглиссадной системе.',
         [
             $h('SID — Standard Instrument Departure'),
             $t('SID — стандартный маршрут вылета по приборам от ВПП до точки маршрута. На схеме: начальный набор (например, минимум 500 футов/мин), ограничения скорости и высоты на промежуточных точках, радионавигационные ориентиры. SID выдаётся в clearance: «Выполняйте LOVOK1F…».'),
             $h('STAR — Standard Terminal Arrival'),
             $t('STAR ведёт от точки маршрута к началу захода (IAF). Типичные ограничения «не ниже/не выше» на точках и требования по скорости. Современные STAR часто строятся под CDA — непрерывное снижение.'),
             $h('Заход ILS'),
             $ul(['LLZ (курсовой маяк) — горизонтальное наведение на ось ВПП',
                  'GP (глиссадный маяк) — вертикальный луч, обычно 3°',
                  'Маркеры/DME — контроль дальности: OM ≈ 7–11 км, MM ≈ 1 км',
                  'DA(H) — высота принятия решения: не увидел огней — уход на второй круг']),
             $call('Золотое правило', 'К 1000 футов (IMC) самолёт должен быть на курсе, глиссаде, с конфигурацией и скоростью. Иначе — go-around.'),
         ],
         $q([
             ['q' => 'Стандартный угол глиссады ILS?', 'options' => ['2,5°', '3°', '3,5°'], 'correct' => 1, 'explain' => 'Стандарт — 3°, это ~300 футов снижения на милю.'],
             ['q' => 'Что такое DA?', 'options' => ['Высота принятия решения', 'Дальность до маяка', 'Скорость снижения'], 'correct' => 0, 'explain' => 'Decision Altitude — минимум, на котором принимается решение: посадка или уход.'],
             ['q' => 'STAR — это…', 'options' => ['Маршрут вылета', 'Стандартный маршрут прибытия', 'Схема руления'], 'correct' => 1, 'explain' => 'Standard Terminal Arrival Route.'],
         ])],
        ['ifr-principy', 'ifr', 20, 'Приборный полёт: приоритеты и скан',
         'Философия IFR: управление, навигация, связь — в этом порядке, и дисциплинированный скан приборов.',
         [
             $h('Три приоритета'),
             $ul(['Aviate — управляй самолётом: крен, тангаж, мощность, траектория',
                  'Navigate — знай, где ты: курс, радиалы, следующая точка',
                  'Communicate — говори в последнюю очередь: доклады по запросу']),
             $h('Скан приборов'),
             $t('На «стекле» PFD объединяет авиагоризонт, скорость, высоту и курс в один экран — скан медленный и контролируемый. На аналоговой панели классика — избранный радикал: АГ — курс — АГ — вариометр — АГ — скорость. Взгляд возвращается на авиагоризонт каждые 2–3 секунды.'),
             $h('Пространственная дезориентация'),
             $t('Вестибулярный аппарат без визуальных ориентиров обманывает. Единственная защита — доверять приборам: необычное положение распознаётся и исправляется по АГ стандартными, без резкостей, движениями.'),
             $call('Мнемоника ухода на второй круг', 'Power — Pitch — Configuration — Climb — Cleanup — Communicate. Мощность и тангаж — прежде всего.'),
         ],
         $q([
             ['q' => 'Правильный порядок приоритетов пилота?', 'options' => ['Навигация — связь — управление', 'Управление — навигация — связь', 'Связь — управление — навигация'], 'correct' => 1, 'explain' => 'Aviate — Navigate — Communicate, всегда в этом порядке.'],
             ['q' => 'Что делать при пространственной дезориентации?', 'options' => ['Доверять ощущениям', 'Доверять приборам', 'Закрыть глаза'], 'correct' => 1, 'explain' => 'Ощущения без визуальных ориентиров ненадёжны — только приборы.'],
         ])],
        ['g1000-obzor', 'avionics', 10, 'Garmin G1000: обзор кабины',
         'Стеклянная кабина Garmin: PFD, MFD, аудиопанель и логика работы со страницами.',
         [
             $h('Компоненты системы'),
             $ul(['PFD (Primary Flight Display) — авиагоризонт, лента скорости слева, высоты справа, курс снизу',
                  'MFD (Multi-Function Display) — карта, двигатель, топливо, чек-листы',
                  'GMA — аудиопанель: радиостанции, интерком, маркер',
                  'GIA/GRS/GMU — блоки навигации, AHRS (вычислитель горизонта), магнитный датчик']),
             $h('Ключевые навыки'),
             $t('Основные инструменты — Softkeys по нижней кромке экрана и ручка FMS между сиденьями: курс, высота, выбранные параметры, план полёта. Страницы MFD собраны в кольцо: Map, Traffic, Weather, Engine.'),
             $call('Совет', 'Отработайте отказ PFD: переход на резервные указатели скорости и высоты и использование MFD как резервного источника.'),
         ],
         $q([
             ['q' => 'Где на PFD находится лента скорости?', 'options' => ['Слева', 'Справа', 'Снизу'], 'correct' => 0, 'explain' => 'Скорость — слева, высота — справа, курс — снизу.'],
             ['q' => 'Что показывает MFD?', 'options' => ['Только авиагоризонт', 'Карту, двигатель, системы', 'Только радиостанции'], 'correct' => 1, 'explain' => 'MFD — многофункциональный дисплей.'],
         ])],
        ['fmc-mcdu', 'avionics', 20, 'FMS и MCDU: логика управления',
         'Boeing FMC и Airbus MCDU: маршруты, PERF-страницы и правило «сначала план — потом исполнение».',
         [
             $h('Философия'),
             $t('FMS — мозг маршрута: она ведёт самолёт по заложенному плану, считает скорости и высоты. Правило: полный план готовится на земле, в воздухе — только корректировки. Импровизация в FMC в полёте — источник ошибок.'),
             $h('Основные страницы'),
             $ul(['IDENT / POS INIT — идентификация и инициализация места',
                  'RTE — маршрут: пункты, трассы, SID/STAR',
                  'CLB / CRZ / DES — вертикальный профиль по этапам',
                  'PERF — скорости: V1, VR, V2, закрылки, переходы этапов']),
             $h('Airbus и Boeing'),
             $t('MCDU Airbus требует строгой последовательности и подсвечивает обязательные поля; FMC Boeing мягче к правкам, но обе системы наказывают за поспешные EXEC. Золотое правило: прочитал — проверил — выполнил.'),
             $call('Чек на ошибку', 'После каждой правки маршрута сверяйте активные legs, страницу прогресса и карту: три источника должны показывать одно и то же.'),
         ],
         $q([
             ['q' => 'Когда закладывается маршрут в FMS?', 'options' => ['На земле до вылета', 'В наборе эшелона', 'На снижении'], 'correct' => 0, 'explain' => 'Полный план — на земле; в полёте только корректировки.'],
             ['q' => 'Страница PERF отвечает за…', 'options' => ['Топливо', 'Скорости и вертикальный профиль', 'Радиосвязь'], 'correct' => 1, 'explain' => 'PERF — скорости этапов и вертикальные параметры.'],
         ])],
        ['radio-frazeologiya', 'pro', 10, 'Радиообмен и фразеология',
         'Стандартная фразеология ИКАО: структура вызова, докладов и обязательное подтверждение (readback).',
         [
             $h('Структура передачи'),
             $t('Сначала — кто меня слышит, затем — это я, затем — сообщение: «Шереметьево-Контроль, 65709, на TRAPA, эшелон 110». Коротко, стандартно, без лишних слов — эфир один на всех.'),
             $h('Обязательный readback'),
             $ul(['Высоты и эшелоны: «Эшелон 110, 65709»',
                  'Курсы и разрешения на полосу: «Занимаю 06 правую»',
                  'Частоты при переходе: «134.15, до связи»',
                  'Взлётные и посадочные разрешения — полностью']),
             $h('Пример диалога'),
             ['t' => 'code', 'd' => ['code' => 'APP: Aeroflot 123, descend to altitude 3000 feet QNH 1013.
Pilot: Descend to 3000 feet, QNH 1013, Aeroflot 123.']],
             $call('PAN-PAN и MAYDAY', 'PAN-PAN (трижды) — срочность без прямой опасности. MAYDAY — опасность для жизни. После этого эфир работает на вас.'),
         ],
         $q([
             ['q' => 'Что означает PAN-PAN?', 'options' => ['Опасность для жизни', 'Срочность без прямой опасности', 'Медицинский запрос'], 'correct' => 1, 'explain' => 'PAN-PAN — срочность, MAYDAY — опасность.'],
             ['q' => 'Что подтверждается полностью (readback)?', 'options' => ['Прогноз погоды', 'Высоты и взлётные/посадочные разрешения', 'Номер стоянки'], 'correct' => 1, 'explain' => 'Readback обязателен для высот, курсов, полос, частот и разрешений.'],
             ['q' => 'Правильный порядок вызова на загруженной частоте?', 'options' => ['Кто вызывает — сообщение — кого', 'Кого вызываю — свой позывной — сообщение', 'Сообщение — кто вызывает'], 'correct' => 1, 'explain' => 'Сначала адресат, затем свой позывной и сообщение.'],
         ])],
    ];

    $ins = $pdo->prepare(
        "INSERT INTO `{$prefix}lessons` (slug, level, sort, title_ru, summary_ru, body_json, quiz_json, published, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?)"
    );
    $now = date('Y-m-d H:i:s');
    foreach ($lessons as [$slug, $level, $sort, $title, $summary, $body, $quiz]) {
        $ins->execute([$slug, $level, $sort, $title, $summary,
            json_encode($body, JSON_UNESCAPED_UNICODE), $quiz, $now]);
    }
}

/** Загрузка брендинга (в.213) — вызывается на шаге 4 до миграции */
function iva_handle_branding(): array
{
    $out = [];
    $map = ['b_logo' => 'logo', 'b_favicon' => 'favicon', 'b_hero' => 'hero_image'];
    $allowed = ['image/png' => 'png', 'image/jpeg' => 'jpg', 'image/webp' => 'webp', 'image/svg+xml' => 'svg', 'image/x-icon' => 'ico'];
    $dir = iva_root() . '/uploads/brand';
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
    foreach ($map as $field => $key) {
        $f = $_FILES[$field] ?? null;
        if (!is_array($f) || ($f['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
            continue;
        }
        if (($f['error'] ?? 1) !== UPLOAD_ERR_OK || ($f['size'] ?? 0) > 8 * 1048576) {
            return ['ok' => false, 'error' => "Файл $key: ошибка загрузки или больше 8 МБ"];
        }
        $fi = new finfo(FILEINFO_MIME_TYPE);
        $mime = (string)$fi->file($f['tmp_name']);
        if (!isset($allowed[$mime])) {
            return ['ok' => false, 'error' => "Файл $key: допустимы PNG, JPG, WebP, SVG, ICO"];
        }
        $name = $key . '-' . date('Ymd-His') . '-' . substr(bin2hex(random_bytes(3)), 0, 6) . '.' . $allowed[$mime];
        if (!move_uploaded_file($f['tmp_name'], $dir . '/' . $name)) {
            return ['ok' => false, 'error' => "Файл $key: не удалось сохранить"];
        }
        $out[$key] = 'uploads/brand/' . $name;
    }
    return ['ok' => true, 'branding' => $out];
}

/* ---------------------------------------------------------------------------
 * AJAX: самозапуск install.php (в.211)
 * ------------------------------------------------------------------------ */
function iva_ajax_selfdelete(): never
{
    if (!iva_tok_ok()) {
        iva_json(['ok' => false, 'error' => 'Сессия истекла']);
    }
    if (!iva_installed()) {
        iva_json(['ok' => false, 'error' => 'Установка ещё не завершена']);
    }
    $ok = @unlink(__FILE__);
    iva_json(['ok' => $ok, 'error' => $ok ? '' : 'Не удалось удалить — удалите файл по FTP (обязательно!)']);
}

/* ---------------------------------------------------------------------------
 * HTML-каркас мастера (в.201)
 * ------------------------------------------------------------------------ */
function iva_page(string $title, string $body, int $activeStep = -1): string
{
    $steps = ['Проверка системы', 'Код проекта', 'База данных', 'Администратор', 'Брендинг', 'Миграция', 'Готово'];
    $stepper = '';
    if ($activeStep >= 0) {
        $stepper = '<div class="steps">';
        foreach ($steps as $i => $label) {
            $cls = $i < $activeStep ? 'done' : ($i === $activeStep ? 'act' : '');
            $stepper .= '<div class="step ' . $cls . '"><i>' . ($i < $activeStep ? '✓' : $i + 1) . '</i>' . iva_e($label) . '</div>';
        }
        $stepper .= '</div><div class="pbar"><div class="pfill" style="width:' . (int)($activeStep / 6 * 100) . '%"></div></div>';
    }
    $flash = iva_flash_get();
    $flashHtml = $flash !== '' ? '<div class="alert">' . iva_e($flash) . '</div>' : '';
    return '<!DOCTYPE html><html lang="ru"><head><meta charset="UTF-8">'
        . '<meta name="viewport" content="width=device-width, initial-scale=1.0">'
        . '<meta name="robots" content="noindex, nofollow">'
        . '<title>' . iva_e($title) . ' · Установка VladAero</title>'
        . '<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 64 64%22%3E%3Crect width=%2264%22 height=%2264%22 rx=%2214%22 fill=%22%230B132B%22/%3E%3Cpath d=%22M32 20 L35 30 L45 34 L35 36 L34 43 L32 40 L30 43 L29 36 L19 34 L29 30 Z%22 fill=%22%2348CAE4%22/%3E%3C/svg%3E">'
        . '<style>' . iva_css() . '</style></head><body>'
        . '<div class="sky"><div class="sweep"></div></div>'
        . '<main class="wrap">'
        . '<header class="head"><div class="logo">✈</div><div><h1>VladAero <span>installer</span></h1>'
        . '<p>Мастер установки авиационного портала · v0.1</p></div></header>'
        . $stepper . $flashHtml . $body
        . '<footer class="foot">VladAero · установка занимает 2–3 минуты · email/SMTP не требуется (в.218)</footer>'
        . '</main><script>' . iva_js() . '</script></body></html>';
}

function iva_css(): string
{
    return <<<'CSS'
*{box-sizing:border-box}
body{margin:0;font:15px/1.6 "Inter","Segoe UI",Roboto,Arial,sans-serif;color:#E8F1FF;
 background:radial-gradient(1100px 500px at 85% -10%,rgba(0,119,182,.3),transparent 60%),radial-gradient(800px 400px at -10% 110%,rgba(72,202,228,.14),transparent 55%),#0B132B;min-height:100vh}
.sky{position:fixed;inset:0;overflow:hidden;pointer-events:none;z-index:0}
.sweep{position:absolute;right:-280px;top:-280px;width:820px;height:820px;border-radius:50%;border:1px solid rgba(72,202,228,.22);
 background:conic-gradient(from 0deg,rgba(72,202,228,.14),transparent 80deg);animation:sweep 10s linear infinite}
@keyframes sweep{to{transform:rotate(360deg)}}
.wrap{position:relative;z-index:2;max-width:860px;margin:0 auto;padding:34px 18px 60px}
.head{display:flex;gap:16px;align-items:center;margin-bottom:22px}
.logo{width:54px;height:54px;border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:1.5em;
 background:linear-gradient(135deg,#0077B6,#48CAE4);color:#04101F;box-shadow:0 0 22px rgba(72,202,228,.35)}
h1{margin:0;font-size:1.5em;letter-spacing:.03em}h1 span{color:#48CAE4;font-family:monospace;font-size:.7em}
.head p{margin:2px 0 0;color:#8FA3C4;font-size:.85em}
.steps{display:flex;gap:4px;flex-wrap:wrap;margin:18px 0 8px}
.step{display:flex;align-items:center;gap:7px;font-size:.72em;color:#8FA3C4;padding:6px 10px;border-radius:99px;border:1px solid rgba(72,202,228,.14)}
.step i{font-style:normal;font-family:monospace;width:18px;height:18px;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;border:1px solid rgba(72,202,228,.3);font-size:.85em}
.step.done{color:#4ADE80}.step.done i{border-color:#4ADE80;color:#4ADE80}
.step.act{color:#48CAE4;border-color:rgba(72,202,228,.5);background:rgba(72,202,228,.08)}.step.act i{background:#48CAE4;color:#04101F;border-color:#48CAE4}
.pbar{height:5px;border-radius:99px;background:rgba(28,37,65,.9);overflow:hidden;margin-bottom:22px}
.pfill{height:100%;border-radius:99px;background:linear-gradient(90deg,#0077B6,#48CAE4);transition:width .4s}
.card{background:rgba(28,37,65,.75);border:1px solid rgba(72,202,228,.22);border-radius:16px;padding:26px 28px;backdrop-filter:blur(10px);box-shadow:0 12px 44px rgba(2,6,20,.5)}
.card h2{margin:0 0 6px;font-size:1.15em}.card .sub{color:#8FA3C4;font-size:.88em;margin:0 0 18px}
.frow{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px}
label.f{display:flex;flex-direction:column;gap:6px;font-size:.84em;color:#8FA3C4;font-weight:600}
input,select{background:rgba(11,19,43,.6);border:1px solid rgba(72,202,228,.2);border-radius:9px;color:#E8F1FF;padding:11px 14px;font:inherit;width:100%}
input:focus,select:focus{outline:none;border-color:#48CAE4;box-shadow:0 0 14px rgba(72,202,228,.25)}
input[type=checkbox]{width:auto}
.btn{display:inline-flex;align-items:center;gap:8px;border:none;border-radius:10px;padding:12px 22px;font:inherit;font-weight:700;cursor:pointer;
 background:linear-gradient(90deg,#0077B6,#48CAE4);color:#04101F;transition:filter .15s,transform .12s}
.btn:hover{filter:brightness(1.1);transform:translateY(-1px)}
.btn[disabled]{opacity:.4;cursor:not-allowed;transform:none}
.btn.ghost{background:transparent;border:1px solid rgba(72,202,228,.3);color:#E8F1FF}
.btn.small{padding:8px 14px;font-size:.85em}
.actions{display:flex;gap:12px;margin-top:22px;flex-wrap:wrap;align-items:center}
.checks{display:flex;flex-direction:column;gap:8px}
.check{display:flex;align-items:center;gap:10px;padding:10px 14px;border-radius:9px;background:rgba(11,19,43,.5);border:1px solid rgba(72,202,228,.12);font-size:.9em}
.dot{width:10px;height:10px;border-radius:50%;flex:0 0 10px}
.ok .dot{background:#4ADE80;box-shadow:0 0 8px #4ADE80}.warn .dot{background:#FFB703;box-shadow:0 0 8px #FFB703}.fail .dot{background:#FF5C7A;box-shadow:0 0 8px #FF5C7A}
.check.fail{border-color:rgba(255,92,122,.4)}
.hint{color:#8FA3C4;font-size:.78em;margin-left:auto;text-align:right}
.alert{background:rgba(255,183,3,.1);border:1px solid rgba(255,183,3,.4);color:#FFB703;border-radius:10px;padding:12px 16px;margin-bottom:16px;font-size:.9em}
.okmsg{background:rgba(74,222,128,.1);border:1px solid rgba(74,222,128,.4);color:#4ADE80;border-radius:10px;padding:12px 16px;margin-bottom:16px;font-size:.9em}
.drop{border:2px dashed rgba(72,202,228,.35);border-radius:14px;padding:34px;text-align:center;color:#8FA3C4;transition:all .2s;cursor:pointer}
.drop.hover{border-color:#48CAE4;background:rgba(72,202,228,.06);color:#E8F1FF}
.drop b{color:#E8F1FF}
.mono{font-family:"JetBrains Mono",Consolas,monospace;font-size:.92em}
.status{font-size:.85em;margin-top:10px;min-height:1.2em}
.status.err{color:#FF5C7A}.status.good{color:#4ADE80}.status.wait{color:#FFB703}
.mig{display:flex;flex-direction:column;gap:6px;margin:18px 0}
.mig .row{display:flex;align-items:center;gap:10px;font-size:.85em;color:#8FA3C4;padding:7px 12px;border-radius:8px;background:rgba(11,19,43,.5)}
.mig .row.doing{color:#48CAE4;border:1px solid rgba(72,202,228,.4)}
.mig .row.did{color:#4ADE80}
.spin{display:inline-block;width:14px;height:14px;border:2px solid rgba(72,202,228,.3);border-top-color:#48CAE4;border-radius:50%;animation:rot .8s linear infinite}
@keyframes rot{to{transform:rotate(360deg)}}
.kv{display:grid;grid-template-columns:auto 1fr;gap:6px 18px;font-size:.9em;margin:14px 0}
.kv b{color:#48CAE4;font-weight:600}
.cron{display:flex;gap:10px;align-items:center;background:rgba(5,10,24,.8);border:1px solid rgba(72,202,228,.25);border-radius:10px;padding:12px 14px;font-family:monospace;font-size:.8em;overflow:auto;white-space:nowrap}
.strength{height:5px;border-radius:99px;background:rgba(11,19,43,.9);overflow:hidden;margin-top:6px}
#sbar{height:100%;width:0;background:#FF5C7A;transition:all .25s}
.pwd-note{font-size:.75em;color:#8FA3C4;font-weight:400}
.foot{margin-top:26px;text-align:center;color:#5B6E8C;font-size:.78em}
.hidden{display:none}
a{color:#48CAE4}
CSS;
}

function iva_js(): string
{
    return <<<'JS'
(function(){
 var $=function(s,c){return (c||document).querySelector(s)};
 var TOK=(document.querySelector('input[name=tok]')||{}).value||'';
 function post(url,data,cb){
  var fd=new FormData();
  Object.keys(data).forEach(function(k){fd.append(k,data[k])});
  fd.append('tok',TOK);
  fetch(url,{method:'POST',body:fd,headers:{'X-Requested-With':'XMLHttpRequest'}})
   .then(function(r){return r.json()}).then(cb).catch(function(e){cb({ok:false,error:e.message})});
 }
 window.ivaPost=post;

 /* дропзона */
 var drop=$('.drop');
 if(drop){
  var inp=$('input[type=file]',drop);
  drop.addEventListener('click',function(){inp.click()});
  ['dragenter','dragover'].forEach(function(ev){drop.addEventListener(ev,function(e){e.preventDefault();drop.classList.add('hover')})});
  ['dragleave','drop'].forEach(function(ev){drop.addEventListener(ev,function(e){e.preventDefault();drop.classList.remove('hover')})});
  drop.addEventListener('drop',function(e){if(e.dataTransfer.files.length){inp.files=e.dataTransfer.files}});
  inp.addEventListener('change',function(){
   $('#zipName').textContent=inp.files.length?inp.files[0].name:'';
   if(inp.files.length)$('#zipBtn').disabled=false;
  });
 }

 /* пароль */
 var p=$('#adminPass');
 if(p){
  p.addEventListener('input',function(){
   var v=p.value,s=0;
   if(v.length>=8)s++; if(/[A-ZА-Я]/.test(v)&&/[a-zа-я]/.test(v))s++; if(/\d/.test(v))s++; if(/[^A-Za-zА-Яа-я0-9]/.test(v))s++;
   var c=['#FF5C7A','#FFB703','#48CAE4','#4ADE80'];
   $('#sbar').style.width=(s*25)+'%'; $('#sbar').style.background=c[Math.max(0,s-1)]||c[0];
  });
 }
})();
JS;
}

/* ---------------------------------------------------------------------------
 * Экраны шагов
 * ------------------------------------------------------------------------ */

/** Подключение к БД из сохранённой конфигурации установленного сайта */
function iva_db_from_config(): ?array
{
    $dbFile = iva_root() . '/app/config/database.php';
    if (!is_file($dbFile)) {
        return null;
    }
    $c = @include $dbFile;
    return is_array($c) ? $c : null;
}

/** Текущее состояние maintenance-режима (true/false) из БД */
function iva_maint_status(): bool
{
    try {
        $c = iva_db_from_config();
        if ($c === null || empty($c['name'])) {
            return false;
        }
        $pdo = iva_db_connect($c);
        $pdo->exec("USE `{$c['name']}`");
        $p = $pdo->query("SELECT v FROM `{$c['prefix']}settings` WHERE k = 'maintenance' LIMIT 1");
        $row = $p ? $p->fetch(PDO::FETCH_NUM) : false;
        return $row ? (string)$row[0] === '1' : false;
    } catch (Throwable $e) {
        return false;
    }
}

/** Текст maintenance-режима из БД */
function iva_maint_text(): string
{
    try {
        $c = iva_db_from_config();
        if ($c === null || empty($c['name'])) {
            return '';
        }
        $pdo = iva_db_connect($c);
        $pdo->exec("USE `{$c['name']}`");
        $p = $pdo->query("SELECT v FROM `{$c['prefix']}settings` WHERE k = 'maintenance_text' LIMIT 1");
        $row = $p ? $p->fetch(PDO::FETCH_NUM) : false;
        return $row ? (string)$row[0] : '';
    } catch (Throwable $e) {
        return '';
    }
}

/** AJAX: выгрузка SQL-дампа базы установленного сайта (в.126, 149) */
function iva_ajax_backup(): never
{
    if (!iva_tok_ok()) {
        iva_json(['ok' => false, 'error' => 'Сессия истекла — обновите страницу']);
    }
    $c = iva_db_from_config();
    if ($c === null || empty($c['name'])) {
        iva_json(['ok' => false, 'error' => 'Конфигурация базы не найдена']);
    }
    try {
        $pdo = iva_db_connect($c);
        $pdo->exec("USE `{$c['name']}`");
        $prefix = $c['prefix'];
        $name = 'vladaero-db-' . date('Ymd-His') . '.sql';
        header('Content-Type: application/sql; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $name . '"');
        echo "-- VladAero SQL-дамп\n-- Дата: " . date('Y-m-d H:i:s')
            . "\n-- Префикс: `$prefix`\nSET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS = 0;\n";

        $tables = array_column($pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_NUM), 0);
        foreach ($tables as $table) {
            if (!str_starts_with((string)$table, (string)$prefix)) {
                continue;
            }
            echo "\n-- ---- $table ----\n";
            $create = $pdo->query("SHOW CREATE TABLE `$table`")->fetch(PDO::FETCH_NUM);
            echo "DROP TABLE IF EXISTS `$table`;\n" . ($create[1] ?? '') . ";\n\n";
            $total = (int)$pdo->query("SELECT COUNT(*) FROM `$table`")->fetchColumn();
            if ($total === 0) {
                continue;
            }
            $rows = $pdo->query("SELECT * FROM `$table`")->fetchAll(PDO::FETCH_NUM);
            foreach ($rows as $r) {
                $vals = array_map(static function ($v) use ($pdo) {
                    return $v === null ? 'NULL' : $pdo->quote((string)$v);
                }, $r);
                echo "INSERT INTO `$table` VALUES (" . implode(', ', $vals) . ");\n";
            }
        }
        echo "\nSET FOREIGN_KEY_CHECKS = 1;\n-- Конец дампа\n";
        exit;
    } catch (Throwable $e) {
        iva_json(['ok' => false, 'error' => 'Ошибка дампа: ' . $e->getMessage()]);
    }
}

/** AJAX: обновление кода установленного сайта из ZIP (в.149) — без потери конфига и данных */
function iva_ajax_update_zip(): never
{
    if (!iva_tok_ok()) {
        iva_json(['ok' => false, 'error' => 'Сессия истекла — обновите страницу']);
    }
    $body = json_decode((string)file_get_contents('php://input'), true);
    $b64 = trim((string)($body['zip'] ?? ''));
    if ($b64 === '') {
        iva_json(['ok' => false, 'error' => 'Поле zip пустое — вставьте base64-строку архива']);
    }
    if (str_starts_with($b64, 'data:')) {
        $b64 = substr($b64, (int)strpos($b64, ',') + 1);
    }
    $bin = base64_decode($b64, true);
    if ($bin === false || $bin === '') {
        iva_json(['ok' => false, 'error' => 'Не удалось декодировать base64 — проверьте данные']);
    }
    $maxBytes = 60 * 1048576;
    if (strlen($bin) > $maxBytes) {
        iva_json(['ok' => false, 'error' => 'Архив слишком большой (' . intdiv(strlen($bin), 1048576) . ' МБ, лимит 60 МБ)']);
    }

    $tmpZip = sys_get_temp_dir() . '/va_upd_' . bin2hex(random_bytes(4)) . '.zip';
    if (file_put_contents($tmpZip, $bin) === false) {
        iva_json(['ok' => false, 'error' => 'Не удалось записать архив во временную папку']);
    }
    $tmpDir = sys_get_temp_dir() . '/va_upext_' . bin2hex(random_bytes(4));
    @mkdir($tmpDir, 0755, true);

    try {
        if (class_exists('ZipArchive')) {
            $z = new ZipArchive();
            $r = $z->open($tmpZip);
            if ($r !== true) {
                throw new RuntimeException('Архив повреждён (ZipArchive code ' . $r . ')');
            }
            $z->extractTo($tmpDir);
            $z->close();
        } else {
            $phar = new PharData($tmpZip);
            $phar->extractTo($tmpDir, null, true);
        }
    } catch (Throwable $e) {
        @unlink($tmpZip);
        iva_rrmdir($tmpDir);
        iva_json(['ok' => false, 'error' => 'Распаковка не удалась: ' . $e->getMessage()]);
    }
    @unlink($tmpZip);

    $root = iva_find_project_root($tmpDir);
    if ($root === null) {
        iva_rrmdir($tmpDir);
        iva_json(['ok' => false, 'error' => 'В архиве не найден проект VladAero (нужны папка app/ и index.php)']);
    }

    // Конфигурацию БД/приложения и установщика не трогаем при обновлении (в.149)
    $protect = [iva_root() . '/app/config'];
    foreach ($protect as $p) {
        $rel = ltrim(str_replace(iva_root(), '', $p), '/');
        if (is_dir($root . '/' . $rel)) {
            iva_rrmdir($root . '/' . $rel);
        } elseif (is_file($root . '/' . $rel)) {
            @unlink($root . '/' . $rel);
        }
    }

    $n = 0;
    foreach (scandir($root) ?: [] as $item) {
        if ($item === '.' || $item === '..' || $item === 'install.php' || str_starts_with($item, '._')) {
            continue;
        }
        $from = $root . '/' . $item;
        $to = iva_root() . '/' . $item;
        if (is_dir($from)) {
            $n += iva_merge_dir($from, $to);
        } else {
            if (!is_dir(dirname($to))) {
                @mkdir(dirname($to), 0755, true);
            }
            if (@copy($from, $to)) {
                $n++;
            }
        }
    }
    iva_rrmdir($tmpDir);

    iva_json(['ok' => true, 'msg' => "Обновление применено: обновлено $n объектов. Конфигурация и данные сохранены."]);
}

/** AJAX: включить/выключить maintenance-режим из пост-установочной панели */
function iva_ajax_toggle_maint(): never
{
    if (!iva_tok_ok()) {
        iva_json(['ok' => false, 'error' => 'Сессия истекла — обновите страницу']);
    }
    $c = iva_db_from_config();
    if ($c === null || empty($c['name'])) {
        iva_json(['ok' => false, 'error' => 'Конфигурация базы не найдена']);
    }
    try {
        $action = (string)($_POST['action'] ?? 'toggle');
        $pdo = iva_db_connect($c);
        $pdo->exec("USE `{$c['name']}`");
        if ($action === 'set_text') {
            $txt = (string)($_POST['text'] ?? '');
            $st = $pdo->prepare("REPLACE INTO `{$c['prefix']}settings` (k, v) VALUES ('maintenance_text', ?)");
            $st->execute([$txt]);
            iva_json(['ok' => true, 'maintenance' => iva_maint_status(), 'msg' => 'Текст обслуживания сохранён']);
        }
        // toggle
        $on = !iva_maint_status();
        $st = $pdo->prepare("REPLACE INTO `{$c['prefix']}settings` (k, v) VALUES ('maintenance', ?)");
        $st->execute([$on ? '1' : '0']);
        iva_json([
            'ok'          => true,
            'maintenance' => $on,
            'msg'         => $on ? 'Режим обслуживания включён' : 'Режим обслуживания выключен',
        ]);
    } catch (Throwable $e) {
        iva_json(['ok' => false, 'error' => 'Ошибка: ' . $e->getMessage()]);
    }
}

function iva_screen_locked(): never
{
    $url = ((is_file(iva_root() . '/app/config/app.php')) ? rtrim((string)(require iva_root() . '/app/config/app.php')['url'], '/') : '');
    $tok = iva_token();
    $on = iva_maint_status() ? 1 : 0;
    $text = iva_maint_text();
    $body = '<div class="card"><h2>VladAero уже установлен ✅</h2>'
        . '<p class="sub">Обнаружен файл блокировки <span class="mono">app/config/installed.lock</span> (в.211).</p>'
        . '<div class="actions">'
        . ($url !== '' ? '<a class="btn" href="' . iva_e($url) . '/">Перейти на сайт →</a>' : '')
        . '<a class="btn ghost" href="' . iva_e($url) . '/admin">В админку</a>'
        . '</div>'
        . '<p class="sub" style="margin-top:16px">Переустановка: Админка → Система → «Удалить таблицы VladAero», либо удалите файлы '
        . '<span class="mono">app/config/app.php</span>, <span class="mono">app/config/database.php</span> и <span class="mono">app/config/installed.lock</span> вручную.</p>'
        . '<div class="card" style="margin-top:18px">'
        . '<h2 style="font-size:1.05em">🛠 Панель обслуживания (maintenance)</h2>'
        . '<p class="sub">Быстрое включение/выключение режима техобслуживания прямо с установщика (в.149, 606)</p>'
        . '<div class="kv" style="margin:12px 0">'
        . '<b>Текущий статус</b><span id="maintStatus">' . ($on ? '⛔ режим обслуживания ВКЛЮЧЁН' : '✅ номинальный режим') . '</span>'
        . '</div>'
        . '<div class="actions"><button class="btn" type="button" id="maintGo">'
        . ($on ? '⛔ Выключить обслуживание' : '🛠 Включить обслуживание')
        . '</button><span class="status" id="maintMsg"></span></div>'
        . '<label class="f" style="margin-top:12px;display:block"><span style="font-size:.84em;color:#8FA3C4;font-weight:600">Текст для посетителей (показывается на странице 503)</span>'
        . '<textarea id="maintText" rows="2" style="background:rgba(11,19,43,.6);border:1px solid rgba(72,202,228,.2);border-radius:9px;color:#E8F1FF;padding:11px 14px;font:inherit;width:100%;font-size:.82em;resize:vertical">' . iva_e($text) . '</textarea></label>'
        . '<div class="actions" style="margin-top:8px"><button class="btn ghost" type="button" id="maintSaveText">💾 Сохранить текст</button></div>'
        . '</div>'
        . '<div class="card" style="margin-top:18px">'
        . '<h2 style="font-size:1.05em">⤓ Резервная копия (backup)</h2>'
        . '<p class="sub">Скачать SQL-дамп всех таблиц VladAero одной кнопкой (в.126, 149)</p>'
        . '<div class="actions"><a class="btn" href="?ajax=backup&tok=' . rawurlencode($tok) . '">⤓ Скачать SQL-дамп</a></div>'
        . '</div>'
        . '<div class="card" style="margin-top:18px">'
        . '<h2 style="font-size:1.05em">⬆ Обновление кода из ZIP</h2>'
        . '<p class="sub">Загрузите новый release-архив — код обновится, конфигурация и данные БД сохранятся (в.149)</p>'
        . '<div class="drop" id="udrop"><b>Перетащите ZIP сюда</b> или кликните для выбора<br>'
        . '<span class="mono" id="uzipName" style="font-size:.85em"></span>'
        . '<input type="file" id="uzipFile" accept=".zip" class="hidden"></div>'
        . '<div class="actions"><button class="btn" type="button" id="ugo">⬆ Загрузить и обновить</button>'
        . '<span class="status" id="ustatus"></span></div>'
        . '<details style="margin:14px 0 0"><summary style="cursor:pointer;color:#8FA3C4;font-size:.88em">или вставьте base64 вручную</summary>'
        . '<div style="margin-top:10px"><textarea id="ub64" rows="4" style="background:rgba(11,19,43,.6);border:1px solid rgba(72,202,228,.2);border-radius:9px;color:#E8F1FF;padding:11px 14px;font:inherit;width:100%;font-size:.82em;resize:vertical" placeholder="UEsDBBQAAAAIAA..."></textarea>'
        . '<div class="actions" style="margin-top:8px"><button class="btn ghost" type="button" id="ub64go">⬆ Обновить из base64</button></div></div></details>'
        . '</div>'
        . '<script>(function(){'
        . 'var tok="' . $tok . '",go=document.getElementById("maintGo"),ms=document.getElementById("maintMsg"),'
        . 'st=document.getElementById("maintStatus"),mt=document.getElementById("maintText");'
        . 'function post(action,extra,cb){var fd=new FormData();fd.append("action",action);fd.append("tok",tok);'
        . 'extra=(extra||{});Object.keys(extra).forEach(function(k){fd.append(k,extra[k])});'
        . 'fetch("?ajax=toggle_maint",{method:"POST",body:fd})'
        . '.then(function(r){return r.json()}).then(cb)'
        . '.catch(function(e){ms.className="status err";ms.textContent="✕ Сеть: "+e.message;});}'
        . 'go.addEventListener("click",function(){'
        . 'go.disabled=true;ms.className="status wait";ms.textContent="…";'
        . 'post("toggle",{},function(r){'
        . 'go.disabled=false;ms.className=r.ok?"status good":"status err";ms.textContent=r.ok?"✓ "+r.msg:"✕ "+r.error;'
        . 'if(r.ok){var on=r.maintenance;'
        . 'st.textContent=on?"⛔ режим обслуживания ВКЛЮЧЁН":"✅ номинальный режим";'
        . 'go.textContent=on?"⛔ Выключить обслуживание":"🛠 Включить обслуживание";}'
        . '});});'
        . 'document.getElementById("maintSaveText").addEventListener("click",function(){'
        . 'var b=this;b.disabled=true;ms.className="status wait";ms.textContent="…";'
        . 'post("set_text",{text:mt.value},function(r){b.disabled=false;ms.className=r.ok?"status good":"status err";ms.textContent=r.ok?"✓ "+r.msg:"✕ "+r.error;});});'
        . 'var udrop=document.getElementById("udrop"),uinp=document.getElementById("uzipFile"),'
        . 'ugo=document.getElementById("ugo"),ust=document.getElementById("ustatus"),unm=document.getElementById("uzipName"),'
        . 'ub64=document.getElementById("ub64"),ub64go=document.getElementById("ub64go");'
        . 'function updateZip(b64,name){'
        . 'ugo.disabled=true;ust.className="status wait";ust.textContent="→ обновляю "+name+"…";'
        . 'fetch("?ajax=update_zip",{method:"POST",headers:{"Content-Type":"application/json","X-Installer-Token":tok},'
        . 'body:JSON.stringify({zip:b64})})'
        . '.then(function(r){return r.json()})'
        . '.then(function(r){'
        . 'if(!r.ok){ust.className="status err";ust.textContent="✕ "+r.error;ugo.disabled=false;return}'
        . 'ust.className="status good";ust.textContent="✓ "+r.msg;'
        . 'setTimeout(function(){location.reload()},1200);'
        . '})'
        . '.catch(function(e){ust.className="status err";ust.textContent="✕ Сеть: "+e.message;ugo.disabled=false;});}'
        . 'function readUpdate(f){'
        . 'if(!f||!/\\.zip$/i.test(f.name)){ust.className="status err";ust.textContent="✕ Нужен ZIP-файл";return}'
        . 'unm.textContent=f.name;ugo.disabled=true;ust.className="status wait";ust.textContent="→ читаю "+f.name+"…";'
        . 'var reader=new FileReader();'
        . 'reader.onload=function(){updateZip(reader.result.split(",")[1],f.name)};'
        . 'reader.onerror=function(){ust.className="status err";ust.textContent="✕ Не удалось прочитать файл";ugo.disabled=false;};'
        . 'reader.readAsDataURL(f);}'
        . 'udrop.addEventListener("click",function(){uinp.click()});'
        . '["dragenter","dragover"].forEach(function(e){udrop.addEventListener(e,function(ev){ev.preventDefault();udrop.classList.add("hover")})});'
        . '["dragleave","drop"].forEach(function(e){udrop.addEventListener(e,function(ev){ev.preventDefault();udrop.classList.remove("hover")})});'
        . 'udrop.addEventListener("drop",function(e){if(e.dataTransfer.files.length)readUpdate(e.dataTransfer.files[0])});'
        . 'uinp.addEventListener("change",function(){if(uinp.files.length)readUpdate(uinp.files[0])});'
        . 'ugo.addEventListener("click",function(){uinp.click()});'
        . 'ub64go.addEventListener("click",function(){'
        . 'var v=ub64.value.replace(/^\\s+|\\s+$/g,"");'
        . 'if(!v){ust.className="status err";ust.textContent="✕ Вставьте base64-строку";return}'
        . 'updateZip(v,"base64");});'
        . '})();</script>'
        . '</div>';
    http_response_code(200);
    echo iva_page('Уже установлено', $body);
    exit;
}

function iva_screen_requirements(array $req): never
{
    $rows = '';
    foreach ($req['checks'] as $c) {
        $rows .= '<div class="check ' . $c['status'] . '"><span class="dot"></span><span>' . iva_e($c['label'])
            . ($c['hint'] !== '' ? '<span class="hint">' . iva_e($c['hint']) . '</span>' : '') . '</span></div>';
    }
    $body = '<div class="card"><h2>Шаг 1 · Проверка системных требований</h2>'
        . '<p class="sub">PHP-хостинг, MySQL и пара минут — всё, что нужно порталу (в.202, 220)</p>'
        . '<div class="checks">' . $rows . '</div>'
        . '<form method="post" class="actions">'
        . '<input type="hidden" name="tok" value="' . iva_token() . '">'
        . '<button class="btn" name="to_step" value="code" ' . ($req['pass'] ? '' : 'disabled') . '>Продолжить →</button>'
        . ($req['pass'] ? '' : '<span class="status err">Исправьте пункты с красным статусом и обновите страницу</span>')
        . '</form></div>';
    echo iva_page('Проверка системы', $body, 0);
    exit;
}

function iva_screen_code(): never
{
    $present = iva_code_present();
    if ($present) {
        $body = '<div class="card"><h2>Шаг 2 · Код проекта</h2>'
            . '<p class="sub">Ядро VladAero обнаружено на сервере</p>'
            . '<div class="okmsg">✓ app/Core/App.php и index.php на месте — загрузка ZIP не требуется</div>'
            . '<form method="post" class="actions"><input type="hidden" name="tok" value="' . iva_token() . '">'
            . '<button class="btn" name="to_step" value="db">Продолжить →</button></form></div>';
    } else {
        $tok = iva_token();
        $body = '<div class="card"><h2>Шаг 2 · Загрузка кода проекта</h2>'
            . '<p class="sub">Загрузите ZIP-архив VladAero — мастер распакует его прямо на сервер (в.149)</p>'
            . '<div class="drop" id="drop"><b>Перетащите ZIP сюда</b> или кликните для выбора<br>'
            . '<span class="mono" id="zipName" style="font-size:.85em"></span>'
            . '<input type="file" id="zipFile" accept=".zip" class="hidden"></div>'
            . '<div class="actions">'
            . '<button class="btn" id="zipBtn" disabled>⤒ Загрузить и распаковать</button>'
            . '<span class="status" id="zipStatus">Архив выдаётся вместе с релизом (vladaero-vX.Y.zip)</span>'
            . '</div>'
            . '<details style="margin:18px 0 0"><summary style="cursor:pointer;color:#8FA3C4;font-size:.88em"> или вставьте base64 вручную</summary>'
            . '<div style="margin-top:10px">'
            . '<label class="f" style="margin-bottom:8px"><span style="font-size:.84em;color:#8FA3C4;font-weight:600">base64-строка ZIP-архива</span>'
            . '<textarea id="b64area" rows="4" style="background:rgba(11,19,43,.6);border:1px solid rgba(72,202,228,.2);border-radius:9px;color:#E8F1FF;padding:11px 14px;font:inherit;width:100%;font-size:.82em;resize:vertical" placeholder="UEsDBBQAAAAIAA..."></textarea></label>'
            . '<div class="actions">'
            . '<button class="btn" type="button" id="b64go">⤒ Декодировать и распаковать</button>'
            . '<span class="status" id="b64status">Вставьте base64-код архива и нажмите кнопку</span>'
            . '</div></div></details>'
            . '<form method="post" class="actions" style="margin-top:18px"><input type="hidden" name="tok" value="' . $tok . '">'
            . '<button class="btn ghost" name="to_step" value="db">Код уже загружен по FTP — пропустить →</button></form>'
            . '</div>'
            . '<script>window.addEventListener("DOMContentLoaded",function(){'
            . 'var drop=document.getElementById("drop"),inp=document.getElementById("zipFile"),'
            . 'btn=document.getElementById("zipBtn"),st=document.getElementById("zipStatus"),nm=document.getElementById("zipName"),'
            . 'tok="' . $tok . '";'
            . 'function sendZip(b64,name){'
            . 'btn.disabled=true;st.className="status wait";st.textContent="→ загружаю "+name+"…";'
            . 'fetch("?ajax=upload_zip",{method:"POST",headers:{"Content-Type":"application/json","X-Installer-Token":tok},'
            . 'body:JSON.stringify({zip:b64})})'
            . '.then(function(r){return r.json()})'
            . '.then(function(r){'
            . 'if(!r.ok){st.className="status err";st.textContent="✕ "+r.error;btn.disabled=false;return}'
            . 'st.className="status good";st.textContent="✓ "+r.msg;'
            . 'setTimeout(function(){location.reload()},1200);'
            . '})'
            . '.catch(function(e){st.className="status err";st.textContent="✕ Ошибка сети: "+e.message;btn.disabled=false;});}'
            . 'function readAndSend(f){'
            . 'if(!f||f.type!=="application/zip"&&!/\\.zip$/i.test(f.name)){st.className="status err";st.textContent="✕ Нужен ZIP-файл";return}'
            . 'nm.textContent=f.name;btn.disabled=true;st.className="status wait";st.textContent="→ читаю "+f.name+"…";'
            . 'var reader=new FileReader();'
            . 'reader.onload=function(){sendZip(reader.result.split(",")[1],f.name)};'
            . 'reader.onerror=function(){st.className="status err";st.textContent="✕ Не удалось прочитать файл";btn.disabled=false;};'
            . 'reader.readAsDataURL(f);}'
            . 'drop.addEventListener("click",function(){inp.click()});'
            . '["dragenter","dragover"].forEach(function(e){drop.addEventListener(e,function(ev){ev.preventDefault();drop.classList.add("hover")})});'
            . '["dragleave","drop"].forEach(function(e){drop.addEventListener(e,function(ev){ev.preventDefault();drop.classList.remove("hover")})});'
            . 'drop.addEventListener("drop",function(e){if(e.dataTransfer.files.length)readAndSend(e.dataTransfer.files[0])});'
            . 'inp.addEventListener("change",function(){if(inp.files.length)readAndSend(inp.files[0])});'
            . 'btn.addEventListener("click",function(){inp.click()});'
            . 'var go=document.getElementById("b64go"),ta=document.getElementById("b64area"),bs=document.getElementById("b64status");'
            . 'go.addEventListener("click",function(){'
            . 'var v=ta.value.replace(/^\\s+|\\s+$/g,"");'
            . 'if(!v){bs.className="status err";bs.textContent="✕ Вставьте base64-строку";return}'
            . 'go.disabled=true;bs.className="status wait";bs.textContent="→ декодирую и загружаю…";'
            . 'fetch("?ajax=upload_zip",{method:"POST",headers:{"Content-Type":"application/json","X-Installer-Token":tok},'
            . 'body:JSON.stringify({zip:v})})'
            . '.then(function(r){return r.json()})'
            . '.then(function(r){'
            . 'if(!r.ok){bs.className="status err";bs.textContent="✕ "+r.error;go.disabled=false;return}'
            . 'bs.className="status good";bs.textContent="✓ "+r.msg;'
            . 'st.className="status good";st.textContent="✓ "+r.msg;'
            . 'setTimeout(function(){location.reload()},1200);'
            . '})'
            . '.catch(function(e){bs.className="status err";bs.textContent="✕ Ошибка сети: "+e.message;go.disabled=false;});'
            . '});});</script>';
    }
    echo iva_page('Код проекта', $body, 1);
    exit;
}

function iva_screen_db(array $prev = []): never
{
    $v = static fn(string $k, string $d) => iva_e($prev[$k] ?? $d);
    $body = '<div class="card"><h2>Шаг 3 · База данных MySQL</h2>'
        . '<p class="sub">Данные создаёт панель хостинга. Проверка подключения — по AJAX в реальном времени (в.203)</p>'
        . '<form method="post" id="dbForm">'
        . '<input type="hidden" name="tok" value="' . iva_token() . '">'
        . '<div class="frow">'
        . '<label class="f">Хост<input name="host" id="dbHost" value="' . $v('host', 'localhost') . '" required></label>'
        . '<label class="f">Порт<input name="port" id="dbPort" value="' . $v('port', '3306') . '"></label>'
        . '<label class="f">Имя базы<input name="name" id="dbName" value="' . $v('name', '') . '" required></label>'
        . '<label class="f">Пользователь<input name="user" id="dbUser" value="' . $v('user', '') . '" required></label>'
        . '<label class="f">Пароль<input type="password" name="pass" id="dbPass"></label>'
        . '<label class="f">Префикс таблиц<input name="prefix" id="dbPrefix" value="' . $v('prefix', 'va_') . '" pattern="[a-zA-Z0-9_]*" title="латиница, цифры и _">'
        . '<span class="pwd-note">любой — несколько копий сайта в одной базе (в.149)</span></label>'
        . '</div>'
        . '<div class="status" id="dbStatus">Нажмите «Проверить соединение»</div>'
        . '<div id="conflictBox" class="alert hidden">В базе уже есть таблицы с таким префиксом (в.215).<br>'
        . '<label style="display:flex;gap:8px;align-items:center;margin:6px 0"><input type="radio" name="drop_mode" value="keep" checked> Оставить и сменить префикс (безопасно)</label>'
        . '<label style="display:flex;gap:8px;align-items:center"><input type="radio" name="drop_mode" value="drop"> Удалить существующие таблицы этого префикса (в.215)</label>'
        . '</div>'
        . '<div class="actions">'
        . '<button type="button" class="btn ghost" id="dbTest">⚡ Проверить соединение</button>'
        . '<button class="btn" name="to_step" value="admin" id="dbNext" disabled>Продолжить →</button>'
        . '</div></form></div>'
        . '<script>'
        . "window.addEventListener('DOMContentLoaded',function(){"
        . "var b=document.getElementById('dbTest');"
        . "b.addEventListener('click',function(){"
        . "var s=document.getElementById('dbStatus');s.className='status wait';s.textContent='→ проверяю…';"
        . "ivaPost('?ajax=dbtest',{host:dbHost.value,port:dbPort.value,name:dbName.value,user:dbUser.value,pass:dbPass.value,prefix:dbPrefix.value},function(r){"
        . "if(!r.ok){s.className='status err';s.textContent='✕ '+r.error;document.getElementById('dbNext').disabled=true;document.getElementById('conflictBox').classList.add('hidden');return}"
        . "s.className='status good';s.textContent='✓ '+r.msg;"
        . "var cb=document.getElementById('conflictBox');"
        . "if(r.conflict>0){cb.classList.remove('hidden')}else{cb.classList.add('hidden')}"
        . "document.getElementById('dbNext').disabled=false;"
        . "});});"
        . "document.getElementById('dbPrefix').addEventListener('input',function(){this.value=this.value.toLowerCase().replace(/[^a-z0-9_]/g,'')});"
        . "});</script>";
    echo iva_page('База данных', $body, 2);
    exit;
}

function iva_screen_admin(array $prev = []): never
{
    $v = static fn(string $k, string $d) => iva_e($prev[$k] ?? $d);
    $base = $prev['base_url'] ?? iva_guess_base_url();
    $tz = $prev['timezone'] ?? 'Europe/Moscow';
    $tzs = '';
    foreach (['Europe/Moscow', 'Europe/Kaliningrad', 'Europe/Samara', 'Europe/Kyiv', 'Europe/Minsk', 'Europe/Riga', 'Europe/Berlin', 'Europe/Rome', 'Europe/London', 'UTC', 'Asia/Almaty', 'Asia/Novosibirsk', 'Asia/Vladivostok'] as $z) {
        $tzs .= '<option value="' . $z . '"' . ($z === $tz ? ' selected' : '') . '>' . $z . '</option>';
    }
    $body = '<div class="card"><h2>Шаг 4 · Сайт и главный администратор</h2>'
        . '<p class="sub">Без email-подтверждений и SMTP (в.218) — пароль хешируется bcrypt cost 12 (в.208)</p>'
        . '<form method="post">'
        . '<input type="hidden" name="tok" value="' . iva_token() . '">'
        . '<div class="frow">'
        . '<label class="f">Название сайта<input name="site_name" value="' . $v('site_name', 'VladAero') . '" required></label>'
        . '<label class="f">Base URL<input name="base_url" value="' . iva_e($base) . '" required><span class="pwd-note">определён автоматически (в.209)</span></label>'
        . '<label class="f">Часовой пояс<select name="timezone">' . $tzs . '</select></label>'
        . '</div>'
        . '<h2 style="margin-top:22px;font-size:1em">Администратор</h2>'
        . '<div class="frow">'
        . '<label class="f">Логин<input name="a_login" value="' . $v('a_login', '') . '" pattern="[A-Za-z0-9_]{3,32}" required></label>'
        . '<label class="f">Email (только для входа)<input type="email" name="a_email" value="' . $v('a_email', '') . '" required></label>'
        . '</div>'
        . '<div class="frow">'
        . '<label class="f">Пароль<input type="password" name="a_pass" id="adminPass" required minlength="8">'
        . '<div class="strength"><div id="sbar"></div></div><span class="pwd-note">минимум 8 символов, буквы и цифры</span></label>'
        . '<label class="f">Повтор пароля<input type="password" name="a_pass2" required minlength="8"></label>'
        . '</div>'
        . '<label class="f" style="margin-top:8px">Кодовое слово восстановления (необязательно, в.207)'
        . '<input name="a_recovery" placeholder="секретная фраза — сохраните её"></label>'
        . '<div class="actions">'
        . '<button class="btn ghost" name="to_step" value="db">← Назад</button>'
        . '<button class="btn" name="to_step" value="brand">Продолжить →</button>'
        . '</div></form></div>';
    echo iva_page('Администратор', $body, 3);
    exit;
}

function iva_screen_brand(array $prev = []): never
{
    $logo = is_file(iva_root() . '/assets/images/logo.svg') ? 'assets/images/logo.svg' : '';
    $body = '<div class="card"><h2>Шаг 5 · Брендинг</h2>'
        . '<p class="sub">Логотип, фавикон и обложку можно загрузить сейчас или позже в админке (в.213, 226)</p>'
        . '<form method="post" enctype="multipart/form-data">'
        . '<input type="hidden" name="tok" value="' . iva_token() . '">'
        . '<div class="frow">'
        . '<label class="f">Логотип (PNG/SVG)<input type="file" name="b_logo" accept="image/png,image/svg+xml,image/jpeg,image/webp"></label>'
        . '<label class="f">Фавикон (PNG/ICO/SVG)<input type="file" name="b_favicon" accept="image/png,image/svg+xml,image/x-icon"></label>'
        . '<label class="f">Обложка главной (Hero, в.226)<input type="file" name="b_hero" accept="image/png,image/jpeg,image/webp"></label>'
        . '</div>'
        . '<p class="sub" style="margin-top:14px">По умолчанию установлен фирменный круглый знак VladAero (раундель) — легко заменить своим прямо здесь или в админке.</p>'
        . '<label class="chk" style="display:flex;gap:8px;align-items:center;margin:12px 0">'
        . '<input type="checkbox" name="demo_data" value="1" checked> <b>Демо-данные</b> — аэропорты, борта, авиакомпании, статьи и события для наполнения (в.206; можно очистить позже)</label>'
        . '<div class="actions">'
        . '<button class="btn ghost" name="to_step" value="skip_brand">Пропустить →</button>'
        . '<button class="btn" name="to_step" value="migrate">Загрузить и продолжить →</button>'
        . '</div></form></div>';
    echo iva_page('Брендинг', $body, 4);
    exit;
}

function iva_screen_migrate(): never
{
    $rows = '';
    foreach (VA_TABLES as $i => $t) {
        $rows .= '<div class="row" id="row' . $i . '"><span class="dot"></span><span class="mono">' . iva_e($t) . '</span></div>';
    }
    $tok = iva_token();
    $total = count(VA_TABLES);
    $body = '<div class="card"><h2>Шаг 6 · Миграция базы данных</h2>'
        . '<p class="sub">Создание таблиц utf8mb4_unicode_ci и учётной записи администратора (в.204, 212)</p>'
        . '<input type="hidden" name="tok" value="' . $tok . '">'
        . '<div class="mig" id="migList">' . $rows . '</div>'
        . '<div class="status" id="migStatus">Готов к запуску</div>'
        . '<div class="actions">'
        . '<button class="btn" id="migGo">🚀 Запустить миграцию</button>'
        . '<span id="migSpin" class="hidden"><span class="spin"></span> выполняю…</span>'
        . '</div></div>'
        . '<script>(function(){'
        . 'var tok="' . $tok . '";'
        . 'var go=document.getElementById("migGo"),st=document.getElementById("migStatus"),sp=document.getElementById("migSpin");'
        . 'go.addEventListener("click",function(){go.disabled=true;sp.classList.remove("hidden");run(0);});'
        . 'function run(step){st.className="status wait";st.textContent="Миграция: шаг "+(step+1)+" из ' . $total . '";'
        . 'var row=document.getElementById("row"+step);if(row){row.classList.add("doing")}'
        . 'var fd=new FormData();fd.append("step",step);fd.append("tok",tok);'
        . 'fetch("?ajax=migrate",{method:"POST",body:fd})'
        . '.then(function(r){if(!r.ok)throw new Error("HTTP "+r.status);return r.json()})'
        . '.then(function(r){'
        . 'if(!r.ok){st.className="status err";st.textContent="✕ "+r.error;sp.classList.add("hidden");go.disabled=false;return}'
        . 'if(row){row.classList.remove("doing");row.classList.add("did")}'
        . 'if(r.done){st.className="status good";st.textContent="✓ Готово! Конфигурация сохранена.";sp.classList.add("hidden");'
        . 'setTimeout(function(){location.href="?step=done"},700);return}'
        . 'run(r.step);})'
        . '.catch(function(e){st.className="status err";st.textContent="✕ Сеть: "+e.message;sp.classList.add("hidden");go.disabled=false;});}'
        . '})();</script>';
    echo iva_page('Миграция', $body, 5);
    exit;
}

function iva_screen_done(): never
{
    if (!iva_installed()) {
        iva_flash_set('Установка не завершена — пройдите все шаги мастера.');
        header('Location: install.php');
        exit;
    }
    $cfg = require iva_root() . '/app/config/app.php';
    $dbc = require iva_root() . '/app/config/database.php';
    $cron = '* * * * * php ' . iva_root() . '/cron.php >/dev/null 2>&1';
    $body = '<div class="card"><h2>🎉 Установка завершена!</h2>'
        . '<p class="sub">VladAero v' . iva_e((string)($cfg['version'] ?? '0.1.0')) . ' готов к полётам (в.214)</p>'
        . '<div class="okmsg">Все таблицы созданы, администратор добавлен, конфигурация защищена.</div>'
        . '<div class="kv">'
        . '<b>Сайт</b><span>' . iva_e((string)$cfg['url']) . '</span>'
        . '<b>Панель администратора</b><span><a href="' . iva_e((string)$cfg['url']) . '/admin">' . iva_e((string)$cfg['url']) . '/admin</a></span>'
        . '<b>База</b><span class="mono">' . iva_e((string)$dbc['name']) . ' · префикс ' . iva_e((string)$dbc['prefix']) . '</span>'
        . '<b>PHP / ОС</b><span class="mono">' . PHP_VERSION . ' / ' . PHP_OS_FAMILY . '</span>'
        . '</div>'
        . '<h2 style="font-size:1em;margin-top:18px">Cron — фоновые задачи (в.219)</h2>'
        . '<div class="cron"><span id="cronLine">' . iva_e($cron) . '</span>'
        . '<button class="btn small ghost" type="button" onclick="navigator.clipboard.writeText(document.getElementById(\'cronLine\').textContent).then(function(){this.textContent=\'✓ Скопировано\'}.bind(this))">Копировать</button></div>'
        . '<p class="sub">Добавьте строку в crontab панели хостинга. Без cron портал тоже работает — данные обновляются лениво (в.83).</p>'
        . '<h2 style="font-size:1em;margin-top:18px">Безопасность (в.211)</h2>'
        . '<div class="actions">'
        . '<button class="btn" id="delMe">🗑 Удалить install.php (обязательно!)</button>'
        . '<a class="btn ghost" href="' . iva_e((string)$cfg['url']) . '">Перейти на сайт →</a>'
        . '</div>'
        . '<div class="status" id="delStatus"></div></div>'
        . '<script>window.addEventListener("DOMContentLoaded",function(){'
        . 'document.getElementById("delMe").addEventListener("click",function(){'
        . 'ivaPost("?ajax=selfdelete",{},function(r){var s=document.getElementById("delStatus");'
        . 's.className=r.ok?"status good":"status err";s.textContent=r.ok?"✓ install.php удалён. Приятных полётов! ✈":"✕ "+r.error;});});});</script>';
    echo iva_page('Готово', $body, 6);
    exit;
}

/* ---------------------------------------------------------------------------
 * Маршрутизатор мастера
 * ------------------------------------------------------------------------ */
$ajax = $_GET['ajax'] ?? '';
if (is_string($ajax) && $ajax !== '') {
    session_name('VAINSTALLER');
    session_start();
    match ($ajax) {
        'dbtest'       => iva_ajax_dbtest(),
        'migrate'      => iva_ajax_migrate(),
        'upload_zip'   => iva_ajax_upload_zip(),
        'selfdelete'   => iva_ajax_selfdelete(),
        'toggle_maint' => iva_ajax_toggle_maint(),
        'backup'       => iva_ajax_backup(),
        'update_zip'   => iva_ajax_update_zip(),
        default        => iva_json(['ok' => false, 'error' => 'Неизвестный AJAX-метод'], 404),
    };
}

if (PHP_SAPI === 'cli' && defined('VA_INSTALLER_TEST')) {
    return; // режим самопроверки: функции доступны, маршрутизация не запускается
}

session_name('VAINSTALLER');
session_start();
iva_token();

// Финальный экран доступен и после блокировки (в.211)
if (($_GET['step'] ?? '') === 'done') {
    iva_screen_done();
}

// Уже установлено? (в.211)
if (iva_installed() && !isset($_GET['force'])) {
    iva_screen_locked();
}

$toStep = $_POST['to_step'] ?? null;

// Пошаговая навигация вперёд/назад
if (is_string($toStep) && iva_tok_ok()) {
    switch ($toStep) {
        case 'code':
            iva_screen_code();

        case 'upload':
            $res = iva_handle_zip_upload();
            if (!$res['ok']) {
                iva_flash_set('✕ ' . $res['error']);
                iva_screen_code();
            }
            iva_flash_set('✓ ' . $res['msg']);
            iva_screen_db(iva_state());

        case 'db':
        case 'admin': // кнопка «Продолжить →» на шаге БД шлёт to_step=admin (в.203)
            // Из формы БД в форму админа — запоминаем данные (в сессию)
            // «Назад» с шага администратора: POST пуст → просто показать форму с прежними данными
            if (trim((string)($_POST['name'] ?? '')) === '' && trim((string)($_POST['user'] ?? '')) === '') {
                iva_screen_db(iva_state());
            }
            $s = iva_state();
            $s['host'] = trim((string)($_POST['host'] ?? 'localhost'));
            $s['port'] = trim((string)($_POST['port'] ?? '3306')) ?: '3306';
            $s['name'] = trim((string)($_POST['name'] ?? ''));
            $s['user'] = trim((string)($_POST['user'] ?? ''));
            $s['pass'] = (string)($_POST['pass'] ?? '');
            $s['prefix'] = iva_norm_prefix((string)($_POST['prefix'] ?? 'va_'));
            $dropMode = (string)($_POST['drop_mode'] ?? 'keep');
            $s['drop_mode'] = in_array($dropMode, ['keep', 'drop'], true) ? $dropMode : 'keep';
            if ($s['name'] === '' || $s['user'] === '') {
                iva_flash_set('✕ Укажите имя базы и пользователя');
                iva_screen_db($s);
            }
            iva_state_set($s);
            iva_screen_admin($s);

        case 'brand':
            $s = iva_state();
            $s['site_name'] = trim((string)($_POST['site_name'] ?? 'VladAero')) ?: 'VladAero';
            $s['base_url'] = rtrim(trim((string)($_POST['base_url'] ?? iva_guess_base_url())), '/');
            $s['timezone'] = (string)($_POST['timezone'] ?? 'Europe/Moscow');
            if (!in_array($s['timezone'], timezone_identifiers_list(), true)) {
                $s['timezone'] = 'Europe/Moscow';
            }
            $s['registration'] = '1';
            $aLogin = trim((string)($_POST['a_login'] ?? ''));
            $aEmail = strtolower(trim((string)($_POST['a_email'] ?? '')));
            $aPass = (string)($_POST['a_pass'] ?? '');
            $aPass2 = (string)($_POST['a_pass2'] ?? '');
            if (!preg_match('/^[A-Za-z0-9_]{3,32}$/', $aLogin)
                || !filter_var($aEmail, FILTER_VALIDATE_EMAIL)
                || strlen($aPass) < 8 || !preg_match('/[A-Za-zА-Яа-я]/u', $aPass) || !preg_match('/\d/', $aPass)
                || $aPass !== $aPass2) {
                iva_flash_set('✕ Проверьте поля администратора: логин 3–32 латинских символа, корректный email, пароль от 8 символов с буквой и цифрой, оба пароля совпадают');
                iva_state_set($s);
                iva_screen_admin($s + ['a_login' => $aLogin, 'a_email' => $aEmail]);
            }
            $s['admin'] = [
                'login'    => $aLogin,
                'email'    => $aEmail,
                'password' => $aPass,
                'recovery' => trim((string)($_POST['a_recovery'] ?? '')),
            ];
            iva_state_set($s);
            iva_screen_brand($s);

        case 'skip_brand':
            $s = iva_state();
            $s['demo_data'] = ($_POST['demo_data'] ?? '') === '1' ? '1' : '0';
            iva_state_set($s);
            iva_screen_migrate();

        case 'migrate':
            $s = iva_state();
            $s['demo_data'] = ($_POST['demo_data'] ?? '') === '1' ? '1' : '0';
            iva_state_set($s);
            $res = iva_handle_branding();
            if (!$res['ok']) {
                iva_flash_set('✕ ' . $res['error']);
                iva_screen_brand();
            }
            if (!empty($res['branding'])) {
                $s = iva_state();
                $s['branding'] = $res['branding'];
                iva_state_set($s);
            }
            iva_screen_migrate();

        default:
            // неизвестный переход — на первый экран
    }
}

// Стартовый экран: проверка системных требований (в.202)
iva_screen_requirements(iva_requirements());
