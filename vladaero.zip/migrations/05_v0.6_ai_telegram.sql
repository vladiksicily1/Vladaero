-- VladAero v0.6.0 — обновление с v0.5.x
-- Новых таблиц нет: используются ai_requests / ai_chats / ai_chat_messages / tg_links.
-- Настройки добавляются автоматически при первом сохранении вкладки «Интеграции»,
-- либо задайте их SQL-скриптом ({p} — ваш префикс):

INSERT IGNORE INTO `{p}settings` (`key`, `value`) VALUES
  ('firecrawl_api_key', ''),
  ('tg_webhook_secret', '');
-- Секрет вебхука лучше сгенерировать свой:
-- UPDATE `{p}settings` SET value = SHA2(RAND(), 256) WHERE `key` = 'tg_webhook_secret';
