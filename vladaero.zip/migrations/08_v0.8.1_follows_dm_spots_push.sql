-- VladAero v0.8.1 — подписки, личные сообщения, споттинг-точки, Web Push (для обновления с v0.8.0).
-- Свежая установка создаёт всё сама (install.php). Здесь — апгрейд существующей БД.
-- Префикс va_ приведён для примера; подставьте свой.

CREATE TABLE IF NOT EXISTS `va_author_follows` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT UNSIGNED NOT NULL,
  `author_id` INT UNSIGNED NOT NULL,
  `created_at` DATETIME NOT NULL,
  UNIQUE KEY `uq_af_pair` (`user_id`,`author_id`),
  INDEX `idx_af_author` (`author_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `va_dm` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `from_user` INT UNSIGNED NOT NULL,
  `to_user` INT UNSIGNED NOT NULL,
  `body` TEXT NOT NULL,
  `read_at` DATETIME NULL,
  `created_at` DATETIME NOT NULL,
  INDEX `idx_dm_dialog` (`from_user`,`to_user`,`created_at`),
  INDEX `idx_dm_inbox` (`to_user`,`read_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `va_spot_points` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `icao` VARCHAR(8) NOT NULL,
  `title_ru` VARCHAR(160) NOT NULL,
  `description_ru` TEXT NOT NULL,
  `lat` DECIMAL(9,6) NOT NULL,
  `lng` DECIMAL(9,6) NOT NULL,
  `light_hint` VARCHAR(240) NULL,
  `status` ENUM('published','pending','rejected') NOT NULL DEFAULT 'pending',
  `created_by` INT UNSIGNED NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL,
  INDEX `idx_sp_icao` (`icao`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `va_push_subscriptions` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT UNSIGNED NOT NULL,
  `endpoint` VARCHAR(500) NOT NULL,
  `p256dh` VARCHAR(200) NOT NULL,
  `auth` VARCHAR(120) NOT NULL,
  `lang` VARCHAR(8) NOT NULL DEFAULT 'ru',
  `created_at` DATETIME NOT NULL,
  `last_push_at` DATETIME NULL,
  UNIQUE KEY `uq_ps_endpoint` (`endpoint`(191)),
  INDEX `idx_ps_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
