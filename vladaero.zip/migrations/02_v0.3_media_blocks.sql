-- VladAero v0.3.0 — обновление с v0.2.x (выполнить при уже установленном портале)
-- {p} замените на ваш префикс таблиц (например va_)
CREATE TABLE IF NOT EXISTS `{p}media` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED NULL,
    `kind` ENUM('image','video','audio','panorama','model3d','file') NOT NULL DEFAULT 'image',
    `filename` VARCHAR(255) NOT NULL,
    `original_name` VARCHAR(255) NULL,
    `path` VARCHAR(255) NOT NULL,
    `thumb_path` VARCHAR(255) NULL,
    `width` SMALLINT UNSIGNED NULL,
    `height` SMALLINT UNSIGNED NULL,
    `size` INT UNSIGNED NOT NULL DEFAULT 0,
    `mime` VARCHAR(100) NULL,
    `exif` JSON NULL,
    `alt` VARCHAR(255) NULL,
    `credit` VARCHAR(190) NULL,
    `license` VARCHAR(64) NULL DEFAULT 'ARR',
    `created_at` DATETIME NOT NULL,
    INDEX `idx_media_kind` (`kind`),
    INDEX `idx_media_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `{p}blocks` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `entity` VARCHAR(32) NOT NULL,
    `entity_id` INT UNSIGNED NOT NULL,
    `blocks` LONGTEXT NULL,
    `updated_at` DATETIME NOT NULL,
    `updated_by` INT UNSIGNED NULL,
    UNIQUE KEY `uq_blocks_entity` (`entity`, `entity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `{p}block_drafts` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `entity` VARCHAR(32) NOT NULL,
    `entity_id` INT UNSIGNED NOT NULL,
    `user_id` INT UNSIGNED NOT NULL,
    `blocks` LONGTEXT NULL,
    `updated_at` DATETIME NOT NULL,
    UNIQUE KEY `uq_draft` (`entity`, `entity_id`, `user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
