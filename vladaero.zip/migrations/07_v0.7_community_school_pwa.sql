-- VladAero v0.7.0 — Сообщество, школа, события, PWA (для обновления с v0.6.x).
-- Свежая установка создаёт всё сама (install.php). Здесь — апгрейд существующей БД.
-- Префикс va_ приведён для примера; подставьте свой.

CREATE TABLE IF NOT EXISTS `va_comments` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT UNSIGNED NOT NULL,
  `entity_type` VARCHAR(24) NOT NULL,
  `entity_id` INT UNSIGNED NOT NULL,
  `parent_id` INT UNSIGNED NULL,
  `body` TEXT NOT NULL,
  `status` ENUM('approved','pending','rejected') NOT NULL DEFAULT 'approved',
  `ip` VARCHAR(45) NULL,
  `created_at` DATETIME NOT NULL,
  INDEX `idx_cm_entity` (`entity_type`,`entity_id`,`status`,`created_at`),
  INDEX `idx_cm_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `va_versus_votes` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT UNSIGNED NOT NULL,
  `aircraft_a` INT UNSIGNED NOT NULL,
  `aircraft_b` INT UNSIGNED NOT NULL,
  `winner_id` INT UNSIGNED NOT NULL,
  `created_at` DATETIME NOT NULL,
  UNIQUE KEY `uq_vv_pair` (`user_id`,`aircraft_a`,`aircraft_b`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `va_clubs` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `slug` VARCHAR(190) NOT NULL UNIQUE,
  `title` VARCHAR(190) NOT NULL,
  `kind` ENUM('airport','actype','sim','other') NOT NULL DEFAULT 'other',
  `description` TEXT NULL,
  `owner_id` INT UNSIGNED NOT NULL,
  `status` ENUM('approved','pending','rejected') NOT NULL DEFAULT 'pending',
  `created_at` DATETIME NOT NULL,
  INDEX `idx_cl_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `va_club_members` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `club_id` INT UNSIGNED NOT NULL,
  `user_id` INT UNSIGNED NOT NULL,
  `joined_at` DATETIME NOT NULL,
  UNIQUE KEY `uq_cm2` (`club_id`,`user_id`),
  INDEX `idx_cm2_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `va_lessons` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `slug` VARCHAR(190) NOT NULL UNIQUE,
  `level` ENUM('basic','vfr','ifr','avionics','pro') NOT NULL DEFAULT 'basic',
  `sort` SMALLINT UNSIGNED NOT NULL DEFAULT 100,
  `title_ru` VARCHAR(220) NOT NULL,
  `summary_ru` VARCHAR(500) NULL,
  `body_json` LONGTEXT NULL,
  `quiz_json` LONGTEXT NULL,
  `published` TINYINT UNSIGNED NOT NULL DEFAULT 1,
  `created_at` DATETIME NOT NULL,
  `updated_at` DATETIME NULL,
  INDEX `idx_ls_level` (`level`,`sort`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `va_lesson_progress` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT UNSIGNED NOT NULL,
  `lesson_id` INT UNSIGNED NOT NULL,
  `quiz_score` TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `passed_at` DATETIME NOT NULL,
  UNIQUE KEY `uq_lp` (`user_id`,`lesson_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `va_bookmarks` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT UNSIGNED NOT NULL,
  `entity_type` VARCHAR(24) NOT NULL,
  `entity_id` INT UNSIGNED NOT NULL,
  `created_at` DATETIME NOT NULL,
  UNIQUE KEY `uq_bm` (`user_id`,`entity_type`,`entity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `va_event_attendees` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `event_id` INT UNSIGNED NOT NULL,
  `user_id` INT UNSIGNED NOT NULL,
  `created_at` DATETIME NOT NULL,
  UNIQUE KEY `uq_ea` (`event_id`,`user_id`),
  INDEX `idx_ea_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Новые колонки существующих таблиц
ALTER TABLE `va_events` ADD COLUMN IF NOT EXISTS `status` ENUM('published','pending','rejected') NOT NULL DEFAULT 'published' AFTER `type`;
ALTER TABLE `va_photos` ADD COLUMN IF NOT EXISTS `event_id` INT UNSIGNED NULL AFTER `airport_id`;

-- Уроки школы: сидируется свежей установкой; при апгрейде заполните
-- через админку (Настройки → Лётная школа) или Супер-Агента.
