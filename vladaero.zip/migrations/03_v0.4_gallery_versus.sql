-- VladAero v0.4.0 — обновление с v0.3.x (выполнить при уже установленном портале)
-- {p} замените на ваш префикс таблиц (например va_).
-- Если колонка уже существует, соответствующий ALTER можно пропустить.

-- Галерея споттинга (в.11–14): название кадра и лицензия автора
ALTER TABLE `{p}photos` ADD COLUMN `title` VARCHAR(220) NULL AFTER `original_name`;
ALTER TABLE `{p}photos` ADD COLUMN `license` VARCHAR(64) NULL DEFAULT 'ARR' AFTER `title`;

-- Радару и Versus новые таблицы не требуются:
--   ADS-B снимки живут в файловом кэше (cache/, TTL 30 c),
--   сравнение читает ТТХ карточек {p}aircraft.specs.
-- Скрининг использует существующие статусы {p}photos.status (pending/approved/rejected).
