-- VladAero v0.8.3 — PIREP / налёт ВАК через Telegram (в.263).
-- Применяется автоматически (MigrationService) при обновлении с v0.8.2.
-- Свежая установка создаёт всё в install.php.
-- {p} — плейсхолдер префикса таблиц (подставляется автоматически).

CREATE TABLE IF NOT EXISTS `{p}flight_logs` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT UNSIGNED NOT NULL,
  `chat_id` BIGINT unsigned NOT NULL DEFAULT 0,
  `route` VARCHAR(32) NOT NULL DEFAULT '—',
  `aircraft` VARCHAR(32) NOT NULL DEFAULT '—',
  `duration_min` SMALLINT unsigned NOT NULL DEFAULT 0,
  `source` ENUM('tg','web') NOT NULL DEFAULT 'tg',
  `ticket_url` VARCHAR(255) NULL,
  `created_at` DATETIME NOT NULL,
  INDEX `idx_fl_user` (`user_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Лог телеметрии для админки (в.269)
CREATE TABLE IF NOT EXISTS `{p}tg_activity` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `chat_id` BIGINT NOT NULL DEFAULT 0,
  `direction` ENUM('in','out') NOT NULL DEFAULT 'in',
  `kind` VARCHAR(32) NULL,
  `command` VARCHAR(60) NULL,
  `length` SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL,
  INDEX `idx_tga_time` (`created_at`),
  INDEX `idx_tga_chat` (`chat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
