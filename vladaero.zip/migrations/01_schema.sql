-- VladAero v0.1.0 — эталонная схема БД (генерируется install.php)
-- {p} — плейсхолдер префикса таблиц
-- Кодировка: utf8mb4 / utf8mb4_unicode_ci (в.204)

DROP TABLE IF EXISTS `{p}ai_chat_messages`;
CREATE TABLE `{p}ai_chat_messages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `chat_id` int(10) unsigned NOT NULL,
  `role` enum('system','user','assistant','tool') NOT NULL,
  `content` longtext DEFAULT NULL,
  `meta` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`meta`)),
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_msg_chat` (`chat_id`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
DROP TABLE IF EXISTS `{p}ai_chats`;
CREATE TABLE `{p}ai_chats` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `title` varchar(190) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_chat_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
DROP TABLE IF EXISTS `{p}ai_requests`;
CREATE TABLE `{p}ai_requests` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `context` enum('widget','admin','quiz','briefing') NOT NULL DEFAULT 'widget',
  `model` varchar(96) DEFAULT NULL,
  `prompt_tokens` int(10) unsigned DEFAULT NULL,
  `completion_tokens` int(10) unsigned DEFAULT NULL,
  `tool_calls` smallint(5) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ai_user` (`user_id`,`created_at`),
  KEY `idx_ai_time` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
DROP TABLE IF EXISTS `{p}aircraft`;
CREATE TABLE `{p}aircraft` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(150) NOT NULL,
  `name_ru` varchar(190) NOT NULL,
  `name_en` varchar(190) DEFAULT NULL,
  `icao_code` varchar(8) DEFAULT NULL,
  `iata_code` varchar(8) DEFAULT NULL,
  `category` enum('civil','military','ga','historic','uav') NOT NULL DEFAULT 'civil',
  `manufacturer` varchar(120) DEFAULT NULL,
  `country` varchar(120) DEFAULT NULL,
  `first_flight` date DEFAULT NULL,
  `status` enum('active','stored','retired','prototype') NOT NULL DEFAULT 'active',
  `specs` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`specs`)),
  `description_ru` mediumtext DEFAULT NULL,
  `description_en` mediumtext DEFAULT NULL,
  `hero_photo` varchar(255) DEFAULT NULL,
  `model_3d` varchar(255) DEFAULT NULL,
  `views` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `idx_ac_cat` (`category`),
  KEY `idx_ac_mfr` (`manufacturer`),
  FULLTEXT KEY `ft_aircraft` (`name_ru`,`name_en`,`icao_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
DROP TABLE IF EXISTS `{p}airlines`;
CREATE TABLE `{p}airlines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `iata` varchar(4) DEFAULT NULL,
  `icao` varchar(6) DEFAULT NULL,
  `callsign` varchar(64) DEFAULT NULL,
  `name_ru` varchar(190) NOT NULL,
  `name_en` varchar(190) DEFAULT NULL,
  `country` varchar(120) DEFAULT NULL,
  `hub` varchar(64) DEFAULT NULL,
  `founded` smallint(6) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `description_ru` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_al_iata` (`iata`),
  KEY `idx_al_icao` (`icao`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
DROP TABLE IF EXISTS `{p}airports`;
CREATE TABLE `{p}airports` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `icao` varchar(6) NOT NULL,
  `iata` varchar(4) DEFAULT NULL,
  `name_ru` varchar(190) NOT NULL,
  `name_en` varchar(190) DEFAULT NULL,
  `city_ru` varchar(120) DEFAULT NULL,
  `city_en` varchar(120) DEFAULT NULL,
  `country_code` char(2) DEFAULT NULL,
  `lat` decimal(9,6) DEFAULT NULL,
  `lng` decimal(9,6) DEFAULT NULL,
  `elevation_ft` smallint(6) DEFAULT NULL,
  `runways` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`runways`)),
  `frequencies` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`frequencies`)),
  `timezone` varchar(64) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `description_ru` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `icao` (`icao`),
  KEY `idx_ap_iata` (`iata`),
  KEY `idx_ap_country` (`country_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
DROP TABLE IF EXISTS `{p}articles`;
CREATE TABLE `{p}articles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(190) NOT NULL,
  `title_ru` varchar(220) NOT NULL,
  `title_en` varchar(220) DEFAULT NULL,
  `excerpt_ru` text DEFAULT NULL,
  `body_json` longtext DEFAULT NULL,
  `cover` varchar(255) DEFAULT NULL,
  `status` enum('draft','review','published') NOT NULL DEFAULT 'draft',
  `author_id` int(10) unsigned DEFAULT NULL,
  `published_at` datetime DEFAULT NULL,
  `views` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `idx_art_status` (`status`,`published_at`),
  FULLTEXT KEY `ft_articles` (`title_ru`,`title_en`,`excerpt_ru`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
DROP TABLE IF EXISTS `{p}audit_log`;
CREATE TABLE `{p}audit_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `action` varchar(64) NOT NULL,
  `entity` varchar(32) DEFAULT NULL,
  `entity_id` int(10) unsigned DEFAULT NULL,
  `details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`details`)),
  `ip` varchar(45) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_audit_entity` (`entity`,`entity_id`),
  KEY `idx_audit_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
DROP TABLE IF EXISTS `{p}events`;
CREATE TABLE `{p}events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(190) NOT NULL,
  `title_ru` varchar(220) NOT NULL,
  `type` enum('airshow','spotting','virtual','museum','meetup') NOT NULL DEFAULT 'airshow',
  `starts_at` datetime NOT NULL,
  `ends_at` datetime DEFAULT NULL,
  `country_code` char(2) DEFAULT NULL,
  `city` varchar(120) DEFAULT NULL,
  `venue` varchar(190) DEFAULT NULL,
  `lat` decimal(9,6) DEFAULT NULL,
  `lng` decimal(9,6) DEFAULT NULL,
  `description_ru` mediumtext DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `idx_ev_start` (`starts_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
DROP TABLE IF EXISTS `{p}notifications`;
CREATE TABLE `{p}notifications` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `type` varchar(48) NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`payload`)),
  `read_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ntf_user` (`user_id`,`read_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
DROP TABLE IF EXISTS `{p}photos`;
CREATE TABLE `{p}photos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `aircraft_id` int(10) unsigned DEFAULT NULL,
  `airline_id` int(10) unsigned DEFAULT NULL,
  `airport_id` int(10) unsigned DEFAULT NULL,
  `registration` varchar(20) DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `original_name` varchar(255) DEFAULT NULL,
  `exif` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`exif`)),
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `reject_reason` varchar(255) DEFAULT NULL,
  `taken_at` datetime DEFAULT NULL,
  `lat` decimal(9,6) DEFAULT NULL,
  `lng` decimal(9,6) DEFAULT NULL,
  `likes` int(10) unsigned NOT NULL DEFAULT 0,
  `views` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ph_status` (`status`,`created_at`),
  KEY `idx_ph_reg` (`registration`),
  KEY `idx_ph_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
DROP TABLE IF EXISTS `{p}settings`;
CREATE TABLE `{p}settings` (
  `k` varchar(64) NOT NULL,
  `v` mediumtext DEFAULT NULL,
  PRIMARY KEY (`k`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
DROP TABLE IF EXISTS `{p}tg_links`;
CREATE TABLE `{p}tg_links` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `telegram_id` bigint(20) unsigned NOT NULL,
  `chat_id` bigint(20) unsigned NOT NULL,
  `username` varchar(64) DEFAULT NULL,
  `notify_flags` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`notify_flags`)),
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_tg_telegram` (`telegram_id`),
  KEY `idx_tg_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
DROP TABLE IF EXISTS `{p}users`;
CREATE TABLE `{p}users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL,
  `email` varchar(190) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('user','editor','screener','moderator','admin') NOT NULL DEFAULT 'user',
  `rank` enum('cadet','second','first','cpt') NOT NULL DEFAULT 'cadet',
  `reputation` int(11) NOT NULL DEFAULT 0,
  `avatar` varchar(255) DEFAULT NULL,
  `about` text DEFAULT NULL,
  `status` enum('active','banned') NOT NULL DEFAULT 'active',
  `failed_attempts` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `locked_until` datetime DEFAULT NULL,
  `telegram_id` bigint(20) unsigned DEFAULT NULL,
  `last_seen` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `telegram_id` (`telegram_id`),
  KEY `idx_users_role` (`role`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


