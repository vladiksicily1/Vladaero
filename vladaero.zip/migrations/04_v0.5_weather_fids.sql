-- VladAero v0.5.0 — обновление с v0.4.x
-- Новых таблиц нет: погода/табло/камеры используют файловый кэш (cache/)
-- и настройки. Ключи SkyLink (FIDS + NOTAM) вводятся в админке:
--   Настройки → Интеграции → SkyLink API (бесплатный тариф RapidAPI, в.281/284).
-- Ниже — необязательные INSERT'ы настроек, если хотите задать их SQL-скриптом
-- (замените {p} на префикс таблиц; ключ — ваш с rapidapi.com).

INSERT IGNORE INTO `{p}settings` (`key`, `value`) VALUES
  ('skylink_api_key', ''),
  ('skylink_api_base', 'https://skylinkapi.com/v2'),
  ('webcam_custom', '');
