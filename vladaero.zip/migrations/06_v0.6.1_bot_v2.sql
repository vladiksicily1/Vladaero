-- VladAero v0.6.1 — настройки бота @vladaero_bot (информационный файл).
-- Выполнять НЕ обязательно: ключи создаются при сохранении вкладки «Интеграции».
-- ВНИМАНИЕ: в таблице va_settings колонки называются k и v (не key/value).
INSERT IGNORE INTO `va_settings` (`k`,`v`) VALUES
  ('telegram_bot_username','vladaero_bot'),
  ('tg_api_base','https://api.telegram.org');
