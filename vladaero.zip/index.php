<?php
/**
 * VladAero — точка входа (front controller).
 * Вся маршрутизация идёт через index.php (см. .htaccess).
 */
declare(strict_types=1);

define('VA_START', microtime(true));

// Если проект ещё не установлен — отправляем в мастер установки
if (!is_file(__DIR__ . '/app/config/app.php') || !is_file(__DIR__ . '/app/config/database.php')) {
    if (is_file(__DIR__ . '/install.php')) {
        header('Location: install.php');
        exit;
    }
    http_response_code(503);
    exit('VladAero не установлен. Загрузите install.php в корень сайта.');
}

require __DIR__ . '/app/bootstrap.php';

(new App\Core\App())->run();
