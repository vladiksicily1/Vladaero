/*
 * VladAero Service Worker v0.7 — офлайн-режим PWA (в.73).
 * Стратегии:
 *  • навигация (страницы) — network-first, фолбэк: кэш → /offline;
 *  • статика (assets/) — stale-while-revalidate;
 *  • API (/api/, /tg/, /admin/) и наружные URL — всегда сеть, без кэша.
 */
const VA_SW_VERSION = 'va-0.8.3';
const CACHE_CORE = VA_SW_VERSION + '-core';
const CACHE_PAGES = VA_SW_VERSION + '-pages';
const CACHE_ASSETS = VA_SW_VERSION + '-assets';

const PRECACHE = [
    './offline',
    './assets/css/app.css',
    './assets/js/app.js',
    './assets/js/blocks-front.js',
    './assets/images/logo.svg',
    './assets/images/icon-192.png',
];

self.addEventListener('install', (event) => {
    event.waitUntil((async () => {
        const cache = await caches.open(CACHE_CORE);
        await Promise.allSettled(PRECACHE.map((u) => cache.add(new Request(u, { cache: 'reload' }))));
        await self.skipWaiting();
    })());
});

self.addEventListener('activate', (event) => {
    event.waitUntil((async () => {
        const names = await caches.keys();
        await Promise.all(names.filter((n) => !n.startsWith(VA_SW_VERSION)).map((n) => caches.delete(n)));
        await self.clients.claim();
    })());
});

self.addEventListener('message', (event) => {
    if (event.data === 'skip-waiting') { self.skipWaiting(); }
});

self.addEventListener('fetch', (event) => {
    const req = event.request;
    if (req.method !== 'GET') { return; }

    let url;
    try { url = new URL(req.url); } catch (e) { return; }
    const sameOrigin = url.origin === self.location.origin;

    // Админку, API и вебхуки не кэшируем никогда (спека: ИИ не кэшируется)
    const path = url.pathname;
    if (!sameOrigin || path.startsWith('/admin') || path.startsWith('/api/') || path.startsWith('/tg/')
        || path.startsWith('/cron.php') || path.startsWith('/install')) {
        return;
    }

    if (req.mode === 'navigate') {
        // Страницы: сеть → кэш → офлайн-страница
        event.respondWith((async () => {
            try {
                const fresh = await fetch(req);
                const cache = await caches.open(CACHE_PAGES);
                cache.put(req, fresh.clone());
                return fresh;
            } catch (e) {
                const cached = await caches.match(req);
                if (cached) { return cached; }
                const offline = await caches.match('./offline');
                return offline || new Response('VladAero offline', { status: 503, headers: { 'Content-Type': 'text/plain; charset=utf-8' } });
            }
        })());
        return;
    }

    // Статика: stale-while-revalidate
    event.respondWith((async () => {
        const cache = await caches.open(CACHE_ASSETS);
        const cached = await cache.match(req);
        const network = fetch(req).then((res) => {
            if (res && (res.ok || res.type === 'opaque')) { cache.put(req, res.clone()); }
            return res;
        }).catch(() => null);
        return cached || (await network) || new Response('', { status: 502 });
    })());
});

/* ── Web Push (v0.8.1): без payload — текст подтягивается из /api/push/pending ── */
self.addEventListener('push', (event) => {
    event.waitUntil((async () => {
        let data = { title: 'VladAero \u2708', body: 'Новое в вашей ленте', url: './feed' };
        try {
            const r = await fetch('./api/push/pending', { credentials: 'include' });
            if (r.ok) { const j = await r.json(); if (j && j.title) { data = j; } }
        } catch (e) { /* офлайн — дефолтный текст */ }
        return self.registration.showNotification(data.title, {
            body: data.body,
            icon: './assets/images/icon-192.png',
            badge: './assets/images/icon-192.png',
            tag: 'va-push',
            data: { url: data.url }
        });
    })());
});

self.addEventListener('notificationclick', (event) => {
    event.notification.close();
    const url = (event.notification.data && event.notification.data.url) || './';
    event.waitUntil(clients.matchAll({ type: 'window', includeUncontrolled: true }).then((list) => {
        for (const c of list) { if ('focus' in c) { c.navigate(url); return c.focus(); } }
        return clients.openWindow(url);
    }));
});
