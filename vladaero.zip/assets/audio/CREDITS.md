# Реальные аудиозаписи авиационных предупреждений (в.141–145)

Файлы — подлинные записи сигналов GPWS/TCAS с Wikimedia Commons (свободные лицензии).

| Файл | Источник (Wikimedia Commons) |
|---|---|
| gpws-pull-up.wav | «飛行機のPull upの音声.wav» — реальный голосовой сигнал GPWS «Pull up» |
| gpws-sink-rate.wav | «Sink rate.wav» — GPWS «Sink rate» |
| gpws-too-low-gear.wav | «Too low gear.wav» — GPWS «Too low gear» |
| tcas-traffic.ogg | «Tcas traffic.ogg» — TCAS «Traffic, Traffic» |
| tcas-climb-now.ogg | «Tcas climb now.ogg» — TCAS «Climb, climb now» |
| ui-click.ogg | «Clickick switch.ogg» — щелчок тумблера (UI, в.141) |

Источник: https://commons.wikimedia.org — файлы размещены под свободными лицензиями
(CC/GFDL/общественное достояние, см. страницы файлов). При массовом использовании
проверьте лицензию конкретного файла на Commons.
