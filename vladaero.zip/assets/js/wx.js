/**
 * VladAero Wx — блок NOTAM на странице погоды + живые METAR-блоки в статьях ([data-metar]).
 */
(function () {
    'use strict';
    var base = (document.querySelector('meta[name="va-base"]') || {}).content
        || document.documentElement.dataset.base || '';
    base = base.replace(/\/$/, '');

    // NOTAM на /weather
    var box = document.getElementById('wxNotam');
    if (box) {
        var icao = box.dataset.icao;
        fetch(base + '/api/notam?icao=' + encodeURIComponent(icao), { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
            .then(function (r) { return r.json(); })
            .then(function (r) {
                var body = box.querySelector('.wx-notam-body');
                if (!body) return;
                if (r.ok && r.items && r.items.length) {
                    body.className = 'wx-notam-body';
                    body.innerHTML = r.items.slice(0, 10).map(function (n) {
                        return '<details class="nt-det"><summary class="mono">' + (n.id || 'NOTAM') +
                            ' <span class="muted">' + (n.start || '').slice(0, 10) + ' → ' + (n.end || '').slice(0, 10) + '</span></summary>' +
                            '<div class="small">' + (n.raw || '').replace(/</g, '&lt;') + '</div></details>';
                    }).join('');
                } else if (r.error === 'no_key') {
                    body.innerHTML = '🔑 ' + (window.VA_L_WX && VA_L_WX.nokey || 'Ключ SkyLink не задан — NOTAM недоступен (Настройки → Интеграции)');
                } else {
                    body.innerHTML = '— ' + (window.VA_L_WX && VA_L_WX.no_notams || 'Активных NOTAM нет или источник недоступен');
                }
            })
            .catch(function () {});
    }

    // Живые METAR-блоки BlockRenderer: [data-metar="UUEE"]
    var metarBlocks = document.querySelectorAll('[data-metar]');
    if (metarBlocks.length) {
        var icaos = [];
        metarBlocks.forEach(function (el) {
            var i = el.getAttribute('data-metar');
            if (icaos.indexOf(i) === -1) icaos.push(i);
        });
        icaos.forEach(function (icao2) {
            fetch(base + '/api/wx?icao=' + encodeURIComponent(icao2), { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
                .then(function (r) { return r.json(); })
                .then(function (r) {
                    if (!r.metar || !r.metar.ok) return;
                    var m = r.metar;
                    document.querySelectorAll('[data-metar="' + icao2 + '"]').forEach(function (el) {
                        var head = el.querySelector('.blk-metar-head b');
                        if (head) head.textContent = m.icao + ' · ' + m.obs;
                        var body = el.querySelector('.blk-metar-body');
                        if (body) {
                            body.className = 'blk-metar-body';
                            var keys = { wind: 'Ветер', vis: 'Видимость', clouds: 'Облачность', wx: 'Явления', temp: 'Температура', qnh: 'QNH', fltcat: 'Категория' };
                            var h = '';
                            Object.keys(keys).forEach(function (k) {
                                if (m.dec[k]) h += '<div><b>' + keys[k] + ':</b> ' + m.dec[k] + '</div>';
                            });
                            h += '<div class="mono small muted">' + m.raw.replace(/</g, '&lt;') + '</div>';
                            body.innerHTML = h;
                        }
                    });
                })
                .catch(function () {});
        });
    }
})();
