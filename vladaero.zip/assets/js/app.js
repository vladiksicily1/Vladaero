/* ============================================================
   VladAero app.js v0.1 — тема, тосты, график, AI Fetch models
   ============================================================ */
(function () {
    'use strict';

    var $ = function (sel, ctx) { return (ctx || document).querySelector(sel); };
    var $$ = function (sel, ctx) { return Array.prototype.slice.call((ctx || document).querySelectorAll(sel)); };

    /* ---------- Тема: тёмная / светлая / системная (в.72, 222) ---------- */
    function applyTheme(mode) {
        var pref = localStorage.getItem('va-theme') || 'dark';
        var dark = pref === 'dark' || (pref === 'auto' && window.matchMedia('(prefers-color-scheme: dark)').matches);
        document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
        var btn = $('#themeToggle');
        if (btn) btn.querySelector('span') && (btn.querySelector('span').textContent = dark ? 'Тёмная' : 'Светлая');
    }
    applyTheme();
    var themeBtn = $('#themeToggle');
    if (themeBtn) {
        themeBtn.addEventListener('click', function () {
            var cur = localStorage.getItem('va-theme') || 'dark';
            localStorage.setItem('va-theme', cur === 'dark' ? 'light' : 'dark');
            applyTheme();
        });
    }
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', applyTheme);

    /* ---------- Звук интерфейса (заглушка, в.141) ---------- */
    var soundBtn = $('#soundToggle');
    if (soundBtn) {
        var upd = function () { soundBtn.style.opacity = localStorage.getItem('va-sound') === 'off' ? '0.4' : '1'; };
        upd();
        soundBtn.addEventListener('click', function () {
            var off = localStorage.getItem('va-sound') === 'off';
            localStorage.setItem('va-sound', off ? 'on' : 'off');
            upd();
        });
    }

    /* ---------- Мобильный сайдбар ---------- */
    var burger = $('#burger');
    if (burger) {
        burger.addEventListener('click', function () {
            var sb = $('#sidebar') || $('.admin-side');
            if (sb) sb.classList.toggle('open');
        });
    }
    document.addEventListener('click', function (e) {
        var sb = $('#sidebar');
        if (sb && sb.classList.contains('open') && !sb.contains(e.target) && e.target !== burger) {
            sb.classList.remove('open');
        }
    });

    /* ---------- Тосты: автозакрытие (в.229) ---------- */
    $$('.toast').forEach(function (t) {
        var kill = function () { t.remove(); };
        t.querySelector('.toast-x').addEventListener('click', kill);
        setTimeout(kill, 6000);
    });

    /* ---------- Подтверждение опасных действий (в.165) ---------- */
    $$('form[data-confirm]').forEach(function (f) {
        f.addEventListener('submit', function (e) {
            if (!window.confirm(f.getAttribute('data-confirm'))) e.preventDefault();
        });
    });

    /* ---------- Индикатор надёжности пароля ---------- */
    var pwd = $('#reg-password');
    if (pwd) {
        var bar = $('#strengthBar');
        pwd.addEventListener('input', function () {
            var v = pwd.value, score = 0;
            if (v.length >= 8) score++;
            if (/[A-ZА-Я]/.test(v) && /[a-zа-я]/.test(v)) score++;
            if (/\d/.test(v)) score++;
            if (/[^A-Za-zА-Яа-я0-9]/.test(v)) score++;
            var colors = ['#FF5C7A', '#FFB703', '#48CAE4', '#4ADE80'];
            bar.style.width = (score * 25) + '%';
            bar.style.background = colors[Math.max(0, score - 1)] || colors[0];
        });
    }

    /* ---------- Ctrl+K: палитра глобального поиска (в.96–98) ---------- */
    var BASE = (document.documentElement.getAttribute('data-base') || '').replace(/\/$/, '');
    var paletteState = { open: false, items: [], active: 0, timer: null };

    function openSearch() {
        if (paletteState.open) { closeSearch(); return; }
        paletteState.open = true;
        var m = document.createElement('div');
        m.id = 'va-search-modal';
        m.innerHTML = '<div class="pal" role="dialog" aria-label="Поиск">'
            + '<div class="pal-head"><span class="pal-ico">⌕</span>'
            + '<input id="palInput" type="text" autocomplete="off" spellcheck="false"'
            + ' placeholder="' + (document.documentElement.getAttribute('data-search-ph') || 'Поиск…') + '">'
            + '<kbd>ESC</kbd></div>'
            + '<div class="pal-body" id="palBody">'
            + '<div class="pal-hint">Начните вводить: Boeing, Боинг, B738, Ил-76…</div>'
            + '</div>'
            + '<div class="pal-foot"><span class="pal-codes">Ctrl K</span><span class="muted">умная палитра VladAero</span></div>'
            + '</div>';
        m.addEventListener('click', function (e) { if (e.target === m) closeSearch(); });
        document.body.appendChild(m);

        var input = m.querySelector('#palInput');
        input.focus();
        input.addEventListener('input', function () {
            clearTimeout(paletteState.timer);
            var q = input.value.trim();
            if (q.length < 2) {
                renderPal([], q);
                return;
            }
            paletteState.timer = setTimeout(function () { fetchPal(q); }, 250);
        });
        input.addEventListener('keydown', function (e) {
            var st = paletteState;
            if (e.key === 'ArrowDown') { e.preventDefault(); movePal(1); }
            else if (e.key === 'ArrowUp') { e.preventDefault(); movePal(-1); }
            else if (e.key === 'Enter') {
                e.preventDefault();
                var it = st.items[st.active];
                if (it) { closeSearch(); window.location.href = it.url; }
            }
        });
    }

    function closeSearch() {
        var m = $('#va-search-modal');
        if (m) m.remove();
        paletteState.open = false;
        paletteState.items = [];
        paletteState.active = 0;
    }

    function fetchPal(q) {
        var body = $('#palBody');
        if (body) body.innerHTML = '<div class="pal-hint"><span class="spin"></span> поиск…</div>';
        fetch(BASE + '/api/search?q=' + encodeURIComponent(q), { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
            .then(function (r) { return r.json(); })
            .then(function (res) { renderPal(res.results || [], q); })
            .catch(function () { renderPal([], q); });
    }

    var GROUP_LABELS = { aircraft: 'Самолёты', airports: 'Аэропорты', articles: 'Статьи' };

    function renderPal(items, q) {
        var body = $('#palBody');
        if (!body) return;
        paletteState.items = items;
        paletteState.active = 0;
        if (q && q.length >= 2 && items.length === 0) {
            body.innerHTML = '<div class="pal-hint">Ничего не найдено' + (q ? ' по «' + escapeHtml(q) + '»' : '') + '</div>';
            return;
        }
        if (items.length === 0) {
            body.innerHTML = '<div class="pal-hint">Начните вводить: Boeing, Боинг, B738, Ил-76…</div>';
            return;
        }
        var html = '';
        var lastGroup = null;
        items.forEach(function (it, i) {
            if (it.group !== lastGroup) {
                html += '<div class="pal-group">' + (GROUP_LABELS[it.group] || it.group) + '</div>';
                lastGroup = it.group;
            }
            html += '<a class="pal-item' + (i === 0 ? ' is-active' : '') + '" data-i="' + i + '" href="' + it.url + '">'
                + '<span class="pal-item-ico">' + (it.icon || '•') + '</span>'
                + '<span class="pal-item-main"><b>' + escapeHtml(it.title) + '</b>'
                + (it.sub ? '<small>' + escapeHtml(it.sub) + '</small>' : '') + '</span>'
                + (it.soon ? '<span class="tag-soon">скоро</span>' : '')
                + '</a>';
        });
        body.innerHTML = html;
        $$('.pal-item', body).forEach(function (el) {
            el.addEventListener('mouseenter', function () {
                $$('.pal-item').forEach(function (x) { x.classList.remove('is-active'); });
                el.classList.add('is-active');
                paletteState.active = parseInt(el.getAttribute('data-i'), 10) || 0;
            });
        });
    }

    function movePal(d) {
        var st = paletteState;
        if (st.items.length === 0) return;
        st.active = (st.active + d + st.items.length) % st.items.length;
        var els = $$('.pal-item');
        els.forEach(function (x) { x.classList.remove('is-active'); });
        if (els[st.active]) {
            els[st.active].classList.add('is-active');
            els[st.active].scrollIntoView({ block: 'nearest' });
        }
    }

    function escapeHtml(s) {
        return String(s).replace(/[&<>"']/g, function (c) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
        });
    }

    var st = $('#searchTrigger');
    if (st) st.addEventListener('click', openSearch);
    document.addEventListener('keydown', function (e) {
        if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); openSearch(); }
        if (e.key === 'Escape' && paletteState.open) closeSearch();
    });

    /* ---------- Мини-график активности (админ-дашборд) ---------- */
    var canvas = $('#dashChart');
    if (canvas && canvas.getContext) {
        try {
            var data = JSON.parse(canvas.getAttribute('data-chart') || '{}');
            drawChart(canvas, data);
        } catch (e) { /* нет данных — не критично */ }
    }

    function drawChart(cv, data) {
        var dpr = window.devicePixelRatio || 1;
        var w = cv.clientWidth || cv.parentElement.clientWidth || 600;
        var h = 220;
        cv.width = w * dpr; cv.height = h * dpr;
        var ctx = cv.getContext('2d');
        ctx.scale(dpr, dpr);
        var pad = { l: 30, r: 12, t: 14, b: 24 };
        var iw = w - pad.l - pad.r, ih = h - pad.t - pad.b;
        var labels = data.labels || [], users = data.users || [], ai = data.ai || [];
        var max = 1;
        users.concat(ai).forEach(function (v) { max = Math.max(max, v); });
        if (max < 4) max = 4;
        var css = getComputedStyle(document.documentElement);
        var cGrid = 'rgba(72,202,228,0.12)', cTxt = css.getPropertyValue('--muted').trim() || '#8FA3C4';

        // Сетка
        ctx.strokeStyle = cGrid; ctx.fillStyle = cTxt; ctx.font = '10px monospace'; ctx.lineWidth = 1;
        for (var g = 0; g <= 4; g++) {
            var y = pad.t + ih - (ih * g / 4);
            ctx.beginPath(); ctx.moveTo(pad.l, y); ctx.lineTo(w - pad.r, y); ctx.stroke();
            ctx.fillText(String(Math.round(max * g / 4)), 4, y + 3);
        }
        var n = labels.length || 1;
        var xAt = function (i) { return pad.l + iw * (n === 1 ? 0.5 : i / (n - 1)); };
        labels.forEach(function (lb, i) {
            if (i % 2 === 0) ctx.fillText(lb, xAt(i) - 12, h - 6);
        });

        function line(series, color) {
            ctx.strokeStyle = color; ctx.lineWidth = 2; ctx.beginPath();
            series.forEach(function (v, i) {
                var x = xAt(i), y = pad.t + ih - ih * (v / max);
                i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
            });
            ctx.stroke();
            // Заливка
            ctx.lineTo(xAt(series.length - 1), pad.t + ih);
            ctx.lineTo(xAt(0), pad.t + ih);
            ctx.closePath();
            ctx.globalAlpha = 0.10; ctx.fillStyle = color; ctx.fill(); ctx.globalAlpha = 1;
            // Точки
            series.forEach(function (v, i) {
                ctx.beginPath();
                ctx.arc(xAt(i), pad.t + ih - ih * (v / max), 2.6, 0, Math.PI * 2);
                ctx.fillStyle = color; ctx.fill();
            });
        }
        if (users.length) line(users, '#48CAE4');
        if (ai.length) line(ai, '#FFB703');
    }

    /* ---------- Fetch /v1/models (вопрос 151) ---------- */
    var fetchBtn = $('#fetchModels');
    if (fetchBtn) {
        fetchBtn.addEventListener('click', function () {
            var base = ($('#ai-base-url') || {}).value || '';
            var key = ($('#ai-key') || {}).value || '';
            var status = $('#fetchStatus'), input = $('#ai-model'), list = $('#modelList');
            status.textContent = '→ запрос…';
            fetch(fetchBtn.getAttribute('data-url') || '/admin/api/ai-models', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-Token': (document.querySelector('input[name="_token"]') || {}).value || '',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify({ base_url: base, api_key: key })
            })
            .then(function (r) { return r.json(); })
            .then(function (res) {
                if (!res.ok) { status.textContent = '✕ ' + (res.error || 'ошибка'); return; }
                status.textContent = '✓ найдено моделей: ' + res.models.length + ' — кликните, чтобы выбрать:';
                if (list) {
                    list.innerHTML = '';
                    res.models.forEach(function (m) {
                        var o = document.createElement('option');
                        o.value = m; list.appendChild(o);
                    });
                }
                if (res.models[0] && input && !input.value) input.value = res.models[0];
            })
            .catch(function (e) { status.textContent = '✕ сеть: ' + e.message; });
        });
    }
    // Ссылка AJAX-эндпоинта задаётся через data-url, добавим её из базового URL
    if (fetchBtn && !fetchBtn.getAttribute('data-url')) {
        fetchBtn.setAttribute('data-url', window.location.pathname.replace(/\/settings\/ai\/?$/, '/api/ai-models'));
    }

    /* ---------- Копирование по клику ---------- */
    $$('[data-copy]').forEach(function (el) {
        el.addEventListener('click', function () {
            var text = el.getAttribute('data-copy');
            if (navigator.clipboard) {
                navigator.clipboard.writeText(text).then(function () {
                    el.classList.add('copied');
                    setTimeout(function () { el.classList.remove('copied'); }, 900);
                });
            }
        });
    });

    /* ---------- PWA service worker ---------- */
    if ('serviceWorker' in navigator && window.location.protocol === 'https:') {
        window.addEventListener('load', function () {
            navigator.serviceWorker.register('sw.js').catch(function () {});
        });
    }
})();
