/* VladAero blocks-front: интерактив блоков на публичных страницах
   (лайтбокс, До/После, опросы, викторины) — в.112–113 */
(function () {
    'use strict';

    /* ---------- Лайтбокс галерей ---------- */
    var lb = null;
    document.addEventListener('click', function (e) {
        var a = e.target.closest('[data-lightbox]');
        if (a) {
            e.preventDefault();
            if (!lb) {
                lb = document.createElement('div');
                lb.id = 'va-lightbox';
                lb.innerHTML = '<img alt="">';
                lb.addEventListener('click', function () { lb.classList.remove('open'); });
                document.body.appendChild(lb);
            }
            var img = a.querySelector('img');
            if (img) {
                lb.querySelector('img').src = img.src;
                lb.classList.add('open');
            }
            return;
        }
        if (e.target === lb) lb.classList.remove('open');
    });

    /* ---------- До / После ---------- */
    document.addEventListener('input', function (e) {
        var r = e.target;
        if (r && r.parentElement && r.parentElement.hasAttribute('data-ba')) {
            var after = r.parentElement.querySelector('.ba-after');
            if (after) after.style.clipPath = 'inset(0 ' + (100 - r.value) + '% 0 0)';
        }
    });

    /* ---------- Опросы (в.113): локальный голос ---------- */
    document.addEventListener('click', function (e) {
        var opt = e.target.closest('.blk-opt:not(.blk-opt--quiz)');
        if (!opt) return;
        var box = opt.closest('[data-poll]');
        if (!box || box.getAttribute('data-voted') === '1') return;
        box.setAttribute('data-voted', '1');
        var opts = box.querySelectorAll('.blk-opt');
        opts.forEach(function (o) { o.disabled = true; });
        opt.classList.add('is-picked');
        var res = box.querySelector('.blk-poll-res');
        if (res) {
            res.hidden = false;
            res.textContent = '✓ Голос учтён (локально). Серверный подсчёт появится с модулем сообщества (v0.6).';
        }
        try {
            var id = 'va_poll_' + location.pathname + '_' + Array.prototype.indexOf.call(document.querySelectorAll('[data-poll]'), box);
            localStorage.setItem(id, opt.getAttribute('data-i'));
        } catch (err) {}
    });

    /* ---------- Мини-викторины (в.113) ---------- */
    document.addEventListener('click', function (e) {
        var opt = e.target.closest('.blk-opt--quiz');
        if (!opt) return;
        var box = opt.closest('[data-quiz]');
        if (!box || box.getAttribute('data-answered') === '1') return;
        box.setAttribute('data-answered', '1');
        var correct = parseInt(box.getAttribute('data-correct'), 10) || 1;
        box.querySelectorAll('.blk-opt').forEach(function (o) {
            o.disabled = true;
            var i = parseInt(o.getAttribute('data-i'), 10);
            if (i === correct) o.classList.add('is-correct');
            else if (o === opt) o.classList.add('is-wrong');
        });
        var ex = box.querySelector('.blk-quiz-explain');
        if (ex) ex.hidden = false;
    });
})();
