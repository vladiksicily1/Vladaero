/* ============================================================
   VladAero Block Editor v1 (в.108, 111–115)
   27 типов блоков · варианты · пресеты · медиа-пикер · автосохранение
   Инициализация: <div class="vabe" data-entity data-entity-id> + input#vabeJson
   ============================================================ */
(function () {
    'use strict';

    var $ = function (s, c) { return (c || document).querySelector(s); };
    var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };

    function esc(s) {
        return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
        });
    }

    /* ---------- Описание полей ---------- */
    var T = function (name, label, ph) { return { name: name, label: label, type: 'text', ph: ph || '' }; };
    var TA = function (name, label, rows) { return { name: name, label: label, type: 'textarea', rows: rows || 3 }; };
    var MED = function (name, label) { return { name: name, label: label, type: 'media' }; };
    var ROWS = function (name, label, rowFields, addLabel) { return { name: name, label: label, type: 'rows', rowFields: rowFields, addLabel: addLabel || '＋ строка' }; };

    var TYPES = {
        text: { cat: 'Текст и структура', icon: '¶', title: 'Текст', variants: { plain: 'Обычный', lead: 'Лид-абзац', small: 'Сноска' }, presetable: true, fields: [TA('text', 'Текст', 4)] },
        heading: { cat: 'Текст и структура', icon: 'H', title: 'Заголовок', variants: { h2: 'H2', h3: 'H3', h4: 'H4' }, fields: [T('text', 'Текст заголовка')] },
        list: { cat: 'Текст и структура', icon: '≡', title: 'Список', variants: { ul: 'Маркированный', ol: 'Нумерованный', check: 'Чек-лист' }, fields: [ROWS('items', 'Пункты', [{ name: 'text', label: 'Текст', type: 'text' }], '＋ пункт')] },
        table: { cat: 'Текст и структура', icon: '▦', title: 'Таблица', variants: {}, presetable: true, fields: [T('title', 'Заголовок (необязательно)'), ROWS('rows', 'Строки (до 4 колонок)', [{ name: 'c1', label: 'Кол. 1', type: 'text' }, { name: 'c2', label: 'Кол. 2', type: 'text' }, { name: 'c3', label: 'Кол. 3', type: 'text' }, { name: 'c4', label: 'Кол. 4', type: 'text' }])] },
        code: { cat: 'Текст и структура', icon: '⌘', title: 'Код / формула', variants: {}, fields: [TA('code', 'Код', 4)] },
        quote: { cat: 'Текст и структура', icon: '❝', title: 'Цитата', variants: { plain: 'Обычная', frame: 'С фото автора' }, presetable: true, fields: [TA('text', 'Цитата', 3), T('author', 'Автор'), MED('photo', 'Фото автора')] },
        details: { cat: 'Текст и структура', icon: '▸', title: 'Спойлер', variants: {}, fields: [T('summary', 'Заголовок спойлера'), TA('text', 'Скрытый текст', 3)] },
        callout: { cat: 'Текст и структура', icon: '!', title: 'Врезка', variants: { info: 'Инфо', warning: 'Caution', danger: 'Warning', success: 'ОК' }, fields: [T('title', 'Заголовок'), TA('text', 'Текст', 3)] },
        divider: { cat: 'Текст и структура', icon: '—', title: 'Разделитель', variants: { line: 'Линия', dots: 'Пунктир', ornament: 'Орнамент' }, fields: [] },
        button: { cat: 'Текст и структура', icon: '▭', title: 'Кнопка (CTA)', variants: { primary: 'Основная', ghost: 'Обводка' }, fields: [T('label', 'Надпись'), T('url', 'Ссылка', 'https://…')] },

        image: { cat: 'Медиа', icon: '🖼', title: 'Изображение', variants: { normal: 'Обычное', wide: 'Широкое', side: 'С обтеканием' }, fields: [MED('src', 'Файл'), T('alt', 'Alt-текст'), T('caption', 'Подпись')] },
        gallery: { cat: 'Медиа', icon: '▣', title: 'Галерея', variants: { masonry: 'Плитки', carousel: 'Карусель' }, fields: [ROWS('items', 'Фото', [{ name: 'src', label: 'Файл', type: 'media' }, { name: 'caption', label: 'Подпись', type: 'text' }], '＋ фото')] },
        video: { cat: 'Медиа', icon: '▶', title: 'Видео', variants: { normal: 'Обычное', shorts: 'Вертикальное' }, fields: [T('url', 'Ссылка YouTube/Vimeo', 'https://youtube.com/watch?v=…'), T('caption', 'Подпись')] },
        audio: { cat: 'Медиа', icon: '♪', title: 'Аудио', variants: {}, fields: [MED('src', 'Аудio-файл'), T('title', 'Название'), T('caption', 'Описание')] },
        panorama: { cat: 'Медиа', icon: '◐', title: 'Панорама 360°', variants: {}, fields: [MED('src', 'Превью-изображение'), T('title', 'Название сцены')] },
        model3d: { cat: 'Медиа', icon: '⟠', title: '3D-модель', variants: {}, fields: [T('src', 'Файл .glb', 'uploads/media/…/model.glb'), T('caption', 'Подпись')] },
        before_after: { cat: 'Медиа', icon: '⇄', title: 'До / После', variants: {}, fields: [MED('before', 'Фото «до»'), MED('after', 'Фото «после»'), T('caption', 'Подпись')] },
        file: { cat: 'Медиа', icon: '⤓', title: 'Файл', variants: {}, fields: [T('title', 'Название'), T('url', 'Ссылка на файл'), T('version', 'Версия', 'v1.0'), T('note', 'Примечание')] },
        embed: { cat: 'Медиа', icon: '⧉', title: 'Iframe-врезка', variants: {}, fields: [T('url', 'URL', 'https://…'), { name: 'height', label: 'Высота, px', type: 'number' }] },

        specs_table: { cat: 'Авиационные', icon: '⚙', title: 'Блок ТТХ', variants: {}, presetable: true, fields: [T('title', 'Заголовок'), ROWS('rows', 'Характеристики', [{ name: 'label', label: 'Параметр', type: 'text' }, { name: 'value', label: 'Значение', type: 'text' }, { name: 'unit', label: 'Ед.', type: 'text' }], '＋ характеристика')] },
        aircraft_ref: { cat: 'Авиационные', icon: '✈', title: 'Карточка борта', variants: {}, fields: [T('slug', 'Slug борта из энциклопедии', 'tu-154m')] },
        metar: { cat: 'Авиационные', icon: '☁', title: 'METAR аэропорта', variants: {}, fields: [T('icao', 'ICAO аэропорта', 'UUEE')] },
        map_route: { cat: 'Авиационные', icon: '⤳', title: 'Карта маршрута', variants: {}, fields: [T('title', 'Название маршрута'), ROWS('points', 'Точки', [{ name: 'name', label: 'Имя', type: 'text' }, { name: 'lat', label: 'Широта', type: 'text' }, { name: 'lng', label: 'Долгота', type: 'text' }], '＋ точка')] },
        timeline: { cat: 'Авиационные', icon: '⌛', title: 'Таймлайн', variants: {}, presetable: true, fields: [ROWS('items', 'События', [{ name: 'date', label: 'Дата', type: 'text' }, { name: 'title', label: 'Событие', type: 'text' }, { name: 'text', label: 'Описание', type: 'text' }], '＋ событие')] },
        compare_two: { cat: 'Авиационные', icon: '⚖', title: 'Сравнение', variants: {}, fields: [T('left', 'Левый объект'), T('right', 'Правый объект'), ROWS('rows', 'Строки сравнения', [{ name: 'label', label: 'Параметр', type: 'text' }, { name: 'left', label: 'Слева', type: 'text' }, { name: 'right', label: 'Справа', type: 'text' }], '＋ строка')] },

        poll: { cat: 'Интерактив', icon: '☑', title: 'Опрос', variants: {}, fields: [T('question', 'Вопрос'), ROWS('options', 'Варианты', [{ name: 'text', label: 'Вариант', type: 'text' }], '＋ вариант')] },
        quiz: { cat: 'Интерактив', icon: '✱', title: 'Мини-викторина', variants: {}, fields: [T('question', 'Вопрос'), { name: 'correct', label: 'Номер правильного ответа', type: 'number' }, TA('explain', 'Разбор правильного ответа', 2), ROWS('options', 'Варианты', [{ name: 'text', label: 'Вариант', type: 'text' }], '＋ вариант')] }
    };

    var PRESETS = { '': 'Без стиля', hud: 'Авиационный HUD', warn: 'Warning/Caution', parchment: 'Пергамент', tech: 'Техдокумент' };

    /* ---------- Инициализация ---------- */
    function initEditor(root) {
        var entity = root.getAttribute('data-entity');
        var entityId = parseInt(root.getAttribute('data-entity-id'), 10) || 0;
        var base = (root.getAttribute('data-base') || '/').replace(/\/$/, '');
        var csrf = (document.querySelector('form input[name="_token"]') || {}).value
            || (document.querySelector('meta[name="va-csrf"]') || {}).content || '';
        var listEl = $('.vabe-list', root), jsonEl = $('#vabeJson', root), statusEl = $('#vabeStatus', root);
        var blocks;
        try { blocks = JSON.parse(jsonEl.value || '[]'); } catch (e) { blocks = []; }
        if (!Array.isArray(blocks)) blocks = [];
        var dirty = false;
        var draftTimer = null;

        function serialize() {
            jsonEl.value = JSON.stringify(blocks);
        }
        function touch(serverToo) {
            dirty = true;
            serialize();
            try { localStorage.setItem(lsKey(), jsonEl.value); } catch (e) {}
            if (serverToo !== false) scheduleDraft();
        }
        function lsKey() { return 'va_blocks_' + entity + '_' + entityId; }

        /* ----- черновики: сервер каждые 30 сек (в.115) ----- */
        function scheduleDraft() {
            if (draftTimer || entityId <= 0) return;
            draftTimer = setTimeout(function () {
                draftTimer = null;
                if (!dirty) return;
                fetch(base + '/admin/blocks/draft', {
                    method: 'POST', headers: { 'X-CSRF-Token': csrf, 'X-Requested-With': 'XMLHttpRequest' },
                    body: new URLSearchParams({ entity: entity, entity_id: entityId, blocks_json: jsonEl.value, _token: csrf })
                }).then(function (r) { return r.json(); }).then(function (r) {
                    if (r.ok) { statusEl.textContent = '💾 черновик ' + r.saved_at; dirty = false; }
                }).catch(function () {});
            }, 30000);
        }

        (function checkDraft() {
            if (entityId <= 0) return;
            fetch(base + '/admin/blocks/draft?entity=' + encodeURIComponent(entity) + '&entity_id=' + entityId, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
                .then(function (r) { return r.json(); }).then(function (r) {
                    var d = r.draft;
                    if (!d || d.blocks === jsonEl.value) return;
                    var b = $('#vabeDraftBanner', root);
                    b.hidden = false;
                    b.innerHTML = '<span>♻ Найден несохранённый черновик от <b class="mono">' + esc(d.updated_at) + '</b></span>'
                        + '<button type="button" class="btn btn--primary btn--sm" id="vabeRestore">Восстановить</button>'
                        + '<button type="button" class="btn btn--ghost btn--sm" id="vabeDiscard">Отбросить</button>';
                    $('#vabeRestore', b).addEventListener('click', function () {
                        try { blocks = JSON.parse(d.blocks); } catch (e) { return; }
                        render(); touch(false); b.hidden = true;
                    });
                    $('#vabeDiscard', b).addEventListener('click', function () {
                        fetch(base + '/admin/blocks/draft', {
                            method: 'POST', headers: { 'X-CSRF-Token': csrf },
                            body: new URLSearchParams({ entity: entity, entity_id: entityId, blocks_json: jsonEl.value, _token: csrf })
                        });
                        b.hidden = true;
                    });
                }).catch(function () {});
        })();

        /* ----- рендер списка ----- */
        function render() {
            listEl.innerHTML = '';
            if (blocks.length === 0) {
                listEl.innerHTML = '<div class="vabe-empty muted">Блоков пока нет — нажмите «Добавить блок»</div>';
                return;
            }
            blocks.forEach(function (b, i) { listEl.appendChild(renderCard(b, i)); });
        }

        function renderCard(b, i) {
            var cfg = TYPES[b.t] || TYPES.text;
            var card = document.createElement('div');
            card.className = 'vabe-card';
            card.setAttribute('data-i', i);

            var head = document.createElement('div');
            head.className = 'vabe-card-head';
            var varOpts = '';
            Object.keys(cfg.variants).forEach(function (k) {
                varOpts += '<option value="' + k + '"' + (b.v === k ? ' selected' : '') + '>' + esc(cfg.variants[k]) + '</option>';
            });
            var presetSel = '';
            if (cfg.presetable) {
                presetSel = '<select class="vabe-preset" title="Стиль (в.114)">' + Object.keys(PRESETS).map(function (k) {
                    return '<option value="' + k + '"' + (b.p === k ? ' selected' : '') + '>' + PRESETS[k] + '</option>';
                }).join('') + '</select>';
            }
            head.innerHTML = '<span class="vabe-ico">' + cfg.icon + '</span><b>' + esc(cfg.title) + '</b>'
                + (varOpts ? '<select class="vabe-variant">' + varOpts + '</select>' : '')
                + presetSel
                + '<span class="vabe-card-btns">'
                + '<button type="button" data-act="up" title="Выше">↑</button>'
                + '<button type="button" data-act="down" title="Ниже">↓</button>'
                + '<button type="button" data-act="dup" title="Дублировать">⧉</button>'
                + '<button type="button" data-act="del" class="vabe-del" title="Удалить">✕</button></span>';
            card.appendChild(head);

            var body = document.createElement('div');
            body.className = 'vabe-card-body';
            if (cfg.fields.length === 0) {
                body.innerHTML = '<div class="muted small">У блока нет настроек</div>';
            }
            cfg.fields.forEach(function (f) { body.appendChild(renderField(f, b)); });
            card.appendChild(body);

            /* события */
            head.addEventListener('click', function (e) {
                var btn = e.target.closest('button[data-act]');
                if (!btn) return;
                var act = btn.getAttribute('data-act');
                if (act === 'up' && i > 0) { blocks.splice(i - 1, 0, blocks.splice(i, 1)[0]); }
                else if (act === 'down' && i < blocks.length - 1) { blocks.splice(i + 1, 0, blocks.splice(i, 1)[0]); }
                else if (act === 'dup') { blocks.splice(i + 1, 0, JSON.parse(JSON.stringify(b))); }
                else if (act === 'del') { blocks.splice(i, 1); }
                render(); touch();
            });
            var vSel = $('.vabe-variant', head);
            if (vSel) vSel.addEventListener('change', function () { b.v = vSel.value; touch(); });
            var pSel = $('.vabe-preset', head);
            if (pSel) pSel.addEventListener('change', function () { b.p = pSel.value; touch(); });
            return card;
        }

        function renderField(f, block) {
            var wrap = document.createElement('label');
            wrap.className = 'vabe-field vabe-field--' + f.type;
            var html = '<span class="vabe-field-label">' + esc(f.label) + '</span>';
            if (f.type === 'textarea') {
                html += '<textarea rows="' + (f.rows || 3) + '">' + esc(block.d[f.name] || '') + '</textarea>';
            } else if (f.type === 'media') {
                html += '<span class="vabe-media-row"><input type="text" value="' + esc(block.d[f.name] || '') + '" placeholder="uploads/media/…">'
                    + '<button type="button" class="btn btn--ghost btn--sm vabe-pick">🖼 выбрать</button>'
                    + (block.d[f.name] ? '<img class="vabe-media-thumb" src="' + esc(block.d[f.name]) + '" alt="">' : '') + '</span>';
            } else if (f.type === 'rows') {
                html = '<div class="vabe-rows"><div class="vabe-field-label">' + esc(f.label) + '</div><div class="vabe-rows-list"></div>'
                    + '<button type="button" class="btn btn--ghost btn--sm vabe-row-add">' + esc(f.addLabel) + '</button></div>';
                wrap.innerHTML = html;
                renderRows($('.vabe-rows-list', wrap), f, block);
                $('.vabe-row-add', wrap).addEventListener('click', function () {
                    if (!Array.isArray(block.d[f.name])) block.d[f.name] = [];
                    block.d[f.name].push({});
                    renderRows($('.vabe-rows-list', wrap), f, block);
                    touch();
                });
                return wrap;
            } else {
                html += '<input type="' + (f.type === 'number' ? 'number' : 'text') + '" value="' + esc(block.d[f.name] || '') + '"' + (f.ph ? ' placeholder="' + esc(f.ph) + '"' : '') + '>';
            }
            wrap.innerHTML = html;
            var inp = $('input,textarea', wrap);
            if (inp) inp.addEventListener('input', function () { block.d[f.name] = inp.value; touch(); });
            var pick = $('.vabe-pick', wrap);
            if (pick) pick.addEventListener('click', function (e) {
                e.preventDefault();
                openPicker(function (path) {
                    inp.value = path; block.d[f.name] = path;
                    var old = $('.vabe-media-thumb', wrap);
                    if (old) old.remove();
                    var img = document.createElement('img');
                    img.className = 'vabe-media-thumb'; img.src = path;
                    inp.parentNode.appendChild(img);
                    touch();
                });
            });
            return wrap;
        }

        function renderRows(container, f, block) {
            container.innerHTML = '';
            if (!Array.isArray(block.d[f.name])) block.d[f.name] = [];
            block.d[f.name].forEach(function (row, idx) {
                var rowEl = document.createElement('div');
                rowEl.className = 'vabe-row';
                var inner = '';
                f.rowFields.forEach(function (rf) {
                    if (rf.type === 'media') {
                        inner += '<span class="vabe-media-row"><input type="text" data-k="' + rf.name + '" value="' + esc(row[rf.name] || '') + '" placeholder="файл">'
                            + '<button type="button" class="btn btn--ghost btn--sm vabe-pick" data-k="' + rf.name + '">🖼</button></span>';
                    } else {
                        inner += '<input type="text" data-k="' + rf.name + '" value="' + esc(row[rf.name] || '') + '" placeholder="' + esc(rf.label) + '"' + (rf.type === 'number' ? ' inputmode="numeric"' : '') + '>';
                    }
                });
                rowEl.innerHTML = inner + '<button type="button" class="vabe-row-del" title="Удалить строку">✕</button>';
                container.appendChild(rowEl);

                $$('input', rowEl).forEach(function (inp) {
                    inp.addEventListener('input', function () { row[inp.getAttribute('data-k')] = inp.value; touch(); });
                });
                $('.vabe-row-del', rowEl).addEventListener('click', function () {
                    block.d[f.name].splice(idx, 1); renderRows(container, f, block); touch();
                });
                $$('.vabe-pick', rowEl).forEach(function (btn) {
                    btn.addEventListener('click', function (e) {
                        e.preventDefault();
                        var k = btn.getAttribute('data-k');
                        openPicker(function (path) { row[k] = path; btn.parentNode.querySelector('input').value = path; touch(); });
                    });
                });
            });
        }

        /* ----- палитра типов ----- */
        $('#vabeAdd', root).addEventListener('click', function () {
            var cats = {};
            Object.keys(TYPES).forEach(function (k) {
                (cats[TYPES[k].cat] = cats[TYPES[k].cat] || []).push(k);
            });
            var html = '';
            Object.keys(cats).forEach(function (cat) {
                html += '<div class="pal-group">' + esc(cat) + '</div>';
                cats[cat].forEach(function (k) {
                    html += '<button type="button" class="vabe-type" data-t="' + k + '"><span class="vabe-ico">' + TYPES[k].icon + '</span>' + esc(TYPES[k].title) + '</button>';
                });
            });
            openModal('＋ Блок — выберите тип (' + Object.keys(TYPES).length + ')', html).then(function (t) {
                if (!t) return;
                var defV = Object.keys(TYPES[t].variants)[0] || '';
                var d = {};
                TYPES[t].fields.forEach(function (f) {
                    if (f.type === 'rows') d[f.name] = [{}];
                    if (f.name === 'correct') d[f.name] = '1';
                });
                blocks.push({ t: t, v: defV, p: '', d: d });
                render(); touch();
                var last = listEl.lastChild;
                if (last) last.scrollIntoView({ behavior: 'smooth', block: 'center' });
            });
        });

        /* ----- быстрое добавление фото из медиатеки ----- */
        $('#vabeFromMedia', root).addEventListener('click', function () {
            openPicker(function (path) {
                blocks.push({ t: 'image', v: 'normal', p: '', d: { src: path } });
                render(); touch();
            }, true);
        });

        /* ----- модалка ----- */
        var modalResolve = null;
        function openModal(title, html) {
            closeModal();
            var m = document.createElement('div');
            m.id = 'vabeModal';
            m.innerHTML = '<div class="pal vabe-modal-box"><div class="pal-head"><b>' + esc(title) + '</b>'
                + '<button type="button" class="toast-x" data-x>×</button></div><div class="pal-body vabe-modal-body">' + html + '</div></div>';
            document.body.appendChild(m);
            m.addEventListener('click', function (e) { if (e.target === m) { closeModal(); modalResolve && modalResolve(null); } });
            $('[data-x]', m).addEventListener('click', function () { closeModal(); modalResolve && modalResolve(null); });
            return { then: function (cb) { modalResolve = cb; window.__vabeResolve = cb; } };
        }
        function closeModal() {
            var m = $('#vabeModal');
            if (m) m.remove();
            window.__vabeResolve = null;
        }

        /* ----- пикер медиа ----- */
        function openPicker(onPick, onlyImage) {
            var html = '<div class="vabe-picker">'
                + '<div class="vabe-picker-bar"><input type="search" id="vpQ" placeholder="Поиск по медиатеке…">'
                + '<label class="btn btn--ghost btn--sm">⤒ Загрузить<input type="file" id="vpFile" class="hidden" accept="image/*,video/*,audio/*,.pdf,.zip,.glb"></label>'
                + (onlyImage ? '' : '<input type="text" id="vpManual" placeholder="или вставьте путь/URL вручную → Enter">')
                + '</div>'
                + '<div class="vabe-picker-grid" id="vpGrid"><div class="pal-hint"><span class="spin"></span></div></div>'
                + '</div>';
            openModal('🖼 Медиатека', html);
            var grid = $('#vpGrid');
            var q = '';

            function load() {
                grid.innerHTML = '<div class="pal-hint"><span class="spin"></span> загрузка…</div>';
                fetch(base + '/admin/media/list?q=' + encodeURIComponent(q) + (onlyImage ? '&kind=image' : ''), { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
                    .then(function (r) { return r.json(); })
                    .then(function (r) {
                        grid.innerHTML = '';
                        (r.items || []).forEach(function (it) {
                            var el = document.createElement('button');
                            el.type = 'button';
                            el.className = 'vabe-mi';
                            el.innerHTML = (it.kind === 'image'
                                    ? '<img src="' + esc(base + '/' + it.thumb) + '" loading="lazy" alt="">'
                                    : '<span class="media-kind-ico">' + ({ video: '▶', audio: '♪', model3d: '⟠', panorama: '◐', file: '⤓' })[it.kind] + '</span>')
                                + '<span class="vabe-mi-name">' + esc(it.name) + '</span>';
                            el.addEventListener('click', function () {
                                closeModal();
                                onPick(it.path.charAt(0) === '/' || it.path.indexOf('http') === 0 ? it.path : it.path);
                            });
                            grid.appendChild(el);
                        });
                        if ((r.items || []).length === 0) grid.innerHTML = '<div class="pal-hint">Медиатека пуста — загрузите первый файл</div>';
                    }).catch(function () { grid.innerHTML = '<div class="pal-hint">Ошибка загрузки медиатеки</div>'; });
            }
            load();

            $('#vpQ').addEventListener('input', function () { clearTimeout(window.__vpT); window.__vpT = setTimeout(function () { q = $('#vpQ').value; load(); }, 300); });
            $('#vpFile').addEventListener('change', function () {
                var f = this.files[0];
                if (!f) return;
                var fd = new FormData();
                fd.append('file', f);
                fd.append('_token', csrf);
                grid.innerHTML = '<div class="pal-hint"><span class="spin"></span> загрузка файла…</div>';
                fetch(base + '/admin/media/upload', { method: 'POST', body: fd, headers: { 'X-Requested-With': 'XMLHttpRequest', 'X-CSRF-Token': csrf } })
                    .then(function (r) { return r.json(); })
                    .then(function (r) {
                        if (r.ok && r.mode === 'single') { closeModal(); onPick(r.media.path); }
                        else if (r.ok) { grid.innerHTML = '<div class="pal-hint">✓ ZIP: +' + (r.count || 0) + ' файл(ов) в медиатеку' + ((r.skipped || []).length ? ', пропущено: ' + r.skipped.length : '') + '</div>'; load(); }
                        else grid.innerHTML = '<div class="pal-hint">✕ ' + esc(r.error || 'ошибка') + '</div>';
                    }).catch(function () { grid.innerHTML = '<div class="pal-hint">Ошибка сети</div>'; });
            });
            var man = $('#vpManual');
            if (man) man.addEventListener('keydown', function (e) {
                if (e.key === 'Enter' && man.value.trim() !== '') { e.preventDefault(); closeModal(); onPick(man.value.trim()); }
            });
        }

        render();
        serialize();
    }

    /* Делегирование кликов по типам в открытых модалках */
    document.addEventListener('click', function (e) {
        var t = e.target.closest('.vabe-type');
        if (!t) return;
        var m = $('#vabeModal');
        var type = t.getAttribute('data-t');
        if (m) m.remove();
        if (window.__vabeResolve) { window.__vabeResolve(type); window.__vabeResolve = null; }
    });

    /* Патч: перехватываем promise-резолв модалки через событие */
    var origOpen = null;

    /* Автозапуск */
    function boot() {
        var root = $('#vabe');
        if (root && !root.__vabeInited) { root.__vabeInited = true; initEditor(root); }
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
    else boot();
})();
