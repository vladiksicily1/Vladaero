/**
 * VladAero FIDS — онлайн-табло (в.279): загрузка, фильтры, автообновление, связь с радаром.
 */
(function () {
    'use strict';
    var board = document.getElementById('fidsBoard');
    if (!board) return;
    var base = (document.querySelector('meta[name="va-base"]') || {}).content
        || document.documentElement.dataset.base || '';
    base = base.replace(/\/$/, '');
    var rows = document.getElementById('fidsRows');
    var filter = document.getElementById('fidsFilter');
    var L = window.VA_L_FIDS || {};
    var icao = board.dataset.icao, type = board.dataset.type, hasKey = board.dataset.haskey === '1';
    var cache = [];

    function esc(s) { return String(s == null ? '' : s).replace(/</g, '&lt;'); }
    function time(t) { return t ? String(t).slice(11, 16) : '—'; }

    function statusRu(s, delay) {
        var map = {
            'scheduled': L.st_scheduled || 'по расписанию', 'delayed': L.st_delayed || 'задержан',
            'departed': L.st_departed || 'вылетел', 'en route': L.st_enroute || 'в полёте',
            'landed': L.st_landed || 'прибыл', 'cancelled': L.st_cancelled || 'отменён',
            'boarding': L.st_boarding || 'посадка', 'gate closed': L.st_gate || 'выход закрыт',
            'check-in': L.st_checkin || 'регистрация'
        };
        var k = String(s || '').toLowerCase();
        var base2 = map[k] || s || '—';
        if (delay > 0) base2 += ' <b class="is-bad">+' + delay + 'м</b>';
        return base2;
    }

    function render() {
        var q = (filter.value || '').toLowerCase();
        var list = cache.filter(function (f) {
            return q === '' || (f.flight + ' ' + f.airline + ' ' + f.dest + ' ' + f.terminal + ' ' + f.gate).toLowerCase().indexOf(q) !== -1;
        });
        if (!list.length) {
            rows.innerHTML = '<tr><td colspan="8" class="muted fids-empty">' + (cache.length ? (L.no_match || 'нет совпадений') : (L.empty || 'рейсов нет')) + '</td></tr>';
            return;
        }
        rows.innerHTML = list.map(function (f) {
            return '<tr>' +
                '<td class="mono"><b>' + esc(f.flight) + '</b></td>' +
                '<td>' + esc(f.airline) + '</td>' +
                '<td class="mono">' + esc(f.dest) + '</td>' +
                '<td class="mono">' + time(f.sched) + (f.est && f.est !== f.sched ? ' <span class="muted">(' + time(f.est) + ')</span>' : '') + '</td>' +
                '<td>' + esc(f.terminal) + '</td>' +
                '<td>' + esc(f.gate) + '</td>' +
                '<td>' + statusRu(f.status, f.delay) + '</td>' +
                '<td><a class="wx-chip" target="_blank" rel="noopener" href="' + base + '/radar?cs=' + encodeURIComponent(f.flight) + '">◎ ' + (L.radar || 'радар') + '</a></td>' +
                '</tr>';
        }).join('');
    }

    function load() {
        if (!icao) { return; }
        if (!hasKey) {
            rows.innerHTML = '<tr><td colspan="8" class="muted fids-empty">' + (L.nokey || 'ключ не задан') + '</td></tr>';
            return;
        }
        fetch(base + '/api/fids?icao=' + encodeURIComponent(icao) + '&type=' + type, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
            .then(function (r) { return r.json(); })
            .then(function (r) {
                if (r.ok) { cache = r.flights || []; }
                else { cache = []; rows.innerHTML = '<tr><td colspan="8" class="muted fids-empty">' + (L.src_err || 'источник недоступен') + '</td></tr>'; return; }
                render();
            })
            .catch(function () {});
    }

    filter && filter.addEventListener('input', render);
    load();
    setInterval(load, 60000); // автообновление раз в минуту
})();
