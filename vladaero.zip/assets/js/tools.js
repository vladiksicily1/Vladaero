/**
 * VladAero Tools — калькуляторы, декодеры, глоссарий (в.46–50).
 * Шаринг: состояние инструментов складывается в location.hash (короткая ссылка, в.50).
 */
(function () {
    'use strict';
    var $ = function (id) { return document.getElementById(id); };
    if (!$('panel-calc')) return;
    var L = window.VA_L_TOOLS || {};

    /* ---------------- Табы ---------------- */
    var tabs = document.querySelectorAll('#toolTabs a');
    function openTab(name) {
        tabs.forEach(function (a) { a.classList.toggle('is-cur', a.getAttribute('href') === '#' + name); });
        ['calc', 'notam', 'squawk', 'glossary'].forEach(function (t) {
            var p = $('panel-' + t);
            if (p) p.hidden = t !== name;
        });
        if (history.replaceState) history.replaceState(null, '', '#' + name);
    }
    tabs.forEach(function (a) { a.addEventListener('click', function (e) { e.preventDefault(); openTab(a.getAttribute('href').slice(1)); }); });

    /* ---------------- Состояние и шаринг (в.50) ---------------- */
    function collectState() {
        var s = { t: location.hash.replace('#', '') || 'calc' };
        document.querySelectorAll('[data-calc] input, [data-calc] select').forEach(function (el) {
            if (el.id) s[el.id] = el.value;
        });
        s.wb = [];
        document.querySelectorAll('#wbRows tr').forEach(function (tr) {
            s.wb.push([tr.querySelector('.wb-n').value, tr.querySelector('.wb-w').value, tr.querySelector('.wb-a').value]);
        });
        return s;
    }
    function applyState() {
        try {
            var s = JSON.parse(decodeURIComponent(escape(atob(decodeURIComponent(location.hash.slice(1))))) || '{}');
            if (!s || !s.t) return;
            Object.keys(s).forEach(function (k) {
                var el = $(k);
                if (el && k !== 't' && k !== 'wb') el.value = s[k];
            });
            if (Array.isArray(s.wb) && s.wb.length) {
                var tb = $('wbRows');
                tb.innerHTML = '';
                s.wb.forEach(function (r) { addWbRow(r[0], r[1], r[2]); });
            }
            openTab(s.t);
        } catch (e) { /* битый хэш — игнорируем */ }
    }
    function saveState() {
        try {
            var b = btoa(unescape(encodeURIComponent(JSON.stringify(collectState()))));
            if (history.replaceState) history.replaceState(null, '', '#' + encodeURIComponent(b));
        } catch (e) {}
    }
    var shareBtn = $('toolShare');
    shareBtn && shareBtn.addEventListener('click', function () {
        saveState();
        navigator.clipboard && navigator.clipboard.writeText(location.href);
        shareBtn.textContent = '✓ ' + (L.copied || 'Скопировано');
        setTimeout(function () { shareBtn.textContent = '🔗 ' + (L.share || 'Ссылка'); }, 1500);
    });
    var printBtn = $('toolPrint');
    printBtn && printBtn.addEventListener('click', function () { saveState(); window.print(); });

    /* ---------------- 1. Конвертер единиц ---------------- */
    var UNITS = [
        ['kt', 'узлы', 1.852, 'v'], ['kmh', 'км/ч', 1, 'v'],
        ['mph', 'мили/ч', 1.609344, 'v'], ['ms', 'м/с', 3.6, 'v'],
        ['ft', 'футы', 0.3048, 'l'], ['m', 'метры', 1, 'l'],
        ['nm', 'мор. мили', 1852, 'l'], ['km', 'километры', 1000, 'l'],
        ['lb', 'фунты', 0.45359237, 'm'], ['kg', 'килограммы', 1, 'm'],
        ['hPa', 'гПа', 1, 'p'], ['inHg', 'inHg', 33.8639, 'p']
    ];
    var cvFrom = $('cvFrom'), cvTo = $('cvTo');
    UNITS.forEach(function (u, i) {
        cvFrom.add(new Option(u[1] + ' (' + u[0] + ')', u[0], i === 0, i === 0));
        cvTo.add(new Option(u[1] + ' (' + u[0] + ')', u[0], i === 1, i === 1));
    });
    function conv() {
        var v = parseFloat($('cvV').value);
        var f = UNITS.find(function (u) { return u[0] === cvFrom.value; });
        var t = UNITS.find(function (u) { return u[0] === cvTo.value; });
        if (!isFinite(v) || !f || !t) { $('cvOut').textContent = '—'; return; }
        var r;
        if (f[3] !== t[3]) {
            r = '⚠ ' + (L.conv_mismatch || 'разные типы величин');
        } else {
            r = (v * f[2] / t[2]);
            r = r >= 100 ? Math.round(r) : Math.round(r * 100) / 100;
            r += ' ' + t[0];
        }
        $('cvOut').textContent = v + ' ' + f[0] + ' = ' + r;
    }
    ['cvV', 'cvFrom', 'cvTo'].forEach(function (id) { $(id).addEventListener('input', function () { conv(); saveState(); }); });

    /* ---------------- 2. Компоненты ветра ---------------- */
    function rwyHeading(v) {
        v = String(v).trim();
        if (/^\d{1,2}$/.test(v)) return (parseInt(v, 10) * 10) % 360;
        var n = parseInt(v, 10);
        return isFinite(n) ? ((n % 360) + 360) % 360 : null;
    }
    function windCalc() {
        var rwy = rwyHeading($('wdRwy').value);
        var dir = parseFloat($('wdDir').value);
        var spd = parseFloat($('wdSpd').value);
        if (rwy === null || !isFinite(dir) || !isFinite(spd)) { $('wdOut').textContent = '—'; return; }
        var ang = (dir - rwy + 540) % 360 - 180; // ±180 от оси
        var hw = Math.round(spd * Math.cos(ang * Math.PI / 180) * 10) / 10;
        var xw = Math.round(spd * Math.sin(ang * Math.PI / 180) * 10) / 10;
        var hwT = hw > 0.05 ? (L.headwind || 'встречный') + ' ' + Math.abs(hw) : hw < -0.05 ? (L.tailwind || 'попутный') + ' ' + Math.abs(hw) : (L.calm || 'нет');
        var side = xw > 0 ? (L.right || 'справа') : (L.left || 'слева');
        $('wdOut').innerHTML = 'HW <b>' + hwT + '</b> · XW <b>' + (Math.abs(xw) < 0.05 ? (L.calm || 'нет') : Math.abs(xw) + ' ' + (L.from || 'с') + ' ' + side) + '</b>';
    }
    ['wdRwy', 'wdDir', 'wdSpd'].forEach(function (id) { $(id).addEventListener('input', function () { windCalc(); saveState(); }); });

    /* ---------------- 3. Плотностная высота ---------------- */
    function daCalc() {
        var elev = parseFloat($('daElev').value) || 0;
        var oat = parseFloat($('daOat').value);
        var qnh = parseFloat($('daQnh').value) || 1013.25;
        if (!isFinite(oat)) { $('daOut').textContent = '—'; return; }
        var pa = elev + (1013.25 - qnh) * 27;
        var isaT = 15 - 1.98 * pa / 1000;
        var da = pa + 118.8 * (oat - isaT);
        $('daOut').innerHTML = 'PA <b>' + Math.round(pa) + ' ft</b> · DA <b>' + Math.round(da) + ' ft (' + Math.round(da * 0.3048) + ' м)</b> · ISA ' + (oat - isaT >= 0 ? '+' : '') + Math.round((oat - isaT) * 10) / 10 + '°C';
    }
    ['daElev', 'daOat', 'daQnh'].forEach(function (id) { $(id).addEventListener('input', function () { daCalc(); saveState(); }); });

    /* ---------------- 4. Глиссада / вертикальная скорость ---------------- */
    function glideCalc() {
        var gs = parseFloat($('glGs').value);
        var ang = parseFloat($('glAng').value);
        if (!isFinite(gs) || !isFinite(ang) || gs <= 0) { $('glOut').textContent = '—'; return; }
        var fpm = Math.round(gs * 101.2686 * Math.tan(ang * Math.PI / 180));
        $('glOut').innerHTML = 'V/S <b>' + fpm + ' ft/min</b> (' + Math.round(fpm * 0.00508) + ' м/с) · ' + Math.round(gs * 1.852) + ' км/ч';
    }
    ['glGs', 'glAng'].forEach(function (id) { $(id).addEventListener('input', function () { glideCalc(); saveState(); }); });

    /* ---------------- 5. Ортодромия (Great Circle) ---------------- */
    var AIRPORTS = window.VA_AIRPORTS || [];
    var selA = $('gcA'), selB = $('gcB');
    selA.add(new Option(L.manual || 'вручную', ''));
    selB.add(new Option(L.manual || 'вручную', ''));
    AIRPORTS.forEach(function (a) {
        selA.add(new Option(a.i + ' — ' + a.n, a.i));
        selB.add(new Option(a.i + ' — ' + a.n, a.i));
    });
    function gcPoint(sel, latId, lonId) {
        if (sel.value === '') {
            return [parseFloat($(latId).value), parseFloat($(lonId).value)];
        }
        var a = AIRPORTS.find(function (x) { return x.i === sel.value; });
        return a ? [a.la, a.lo] : [NaN, NaN];
    }
    function gcCalc() {
        var A = gcPoint(selA, 'gcAlat', 'gcAlon'), B = gcPoint(selB, 'gcBlat', 'gcBlon');
        var gs = parseFloat($('gcGs').value) || 450;
        var φ1 = A[0] * Math.PI / 180, λ1 = A[1] * Math.PI / 180;
        var φ2 = B[0] * Math.PI / 180, λ2 = B[1] * Math.PI / 180;
        if (!isFinite(A[0]) || !isFinite(B[0]) || (A[0] === 0 && A[1] === 0) || (B[0] === 0 && B[1] === 0)) {
            $('gcOut').textContent = L.gc_need || 'выберите аэропорты или введите координаты';
            return;
        }
        var d = Math.acos(Math.sin(φ1) * Math.sin(φ2) + Math.cos(φ1) * Math.cos(φ2) * Math.cos(λ2 - λ1));
        var nm = d * 180 / Math.PI * 60;
        var y = Math.sin(λ2 - λ1) * Math.cos(φ2);
        var x = Math.cos(φ1) * Math.sin(φ2) - Math.sin(φ1) * Math.cos(φ2) * Math.cos(λ2 - λ1);
        var brg = Math.round((Math.atan2(y, x) * 180 / Math.PI + 360) % 360);
        var h = Math.floor(nm / gs), m = Math.round(60 * (nm / gs - h));
        $('gcOut').innerHTML = nm.toFixed(0) + ' nm (' + (nm * 1.852).toFixed(0) + ' км) · ' + (L.course || 'курс') + ' ' + brg + '° · ETE ≈ <b>' + h + 'ч ' + m + 'м</b> @ ' + gs + ' kt';
    }
    ['gcA', 'gcB', 'gcAlat', 'gcAlon', 'gcBlat', 'gcBlon', 'gcGs'].forEach(function (id) {
        $(id).addEventListener('input', function () {
            var manual = id === 'gcAlat' || id === 'gcAlon';
            if (manual) { selA.value = ''; }
            if (id === 'gcBlat' || id === 'gcBlon') { selB.value = ''; }
            gcCalc(); saveState();
        });
    });

    /* ---------------- 6. Центровка (Weight & Balance) ---------------- */
    function addWbRow(n, w, a) {
        var tr = document.createElement('tr');
        tr.innerHTML = '<td><input class="wb-n" value="' + (n || '') + '" placeholder="' + (L.item_ph || 'Пустый самолёт') + '"></td>' +
            '<td><input class="wb-w" type="number" step="any" value="' + (w || '') + '"></td>' +
            '<td><input class="wb-a" type="number" step="any" value="' + (a || '') + '"></td>' +
            '<td><button class="wb-x" title="✕">×</button></td>';
        tr.querySelector('.wb-x').addEventListener('click', function () { tr.remove(); wbCalc(); saveState(); });
        ['wb-w', 'wb-a'].forEach(function (c) {
            tr.querySelector('.' + c).addEventListener('input', function () { wbCalc(); saveState(); });
        });
        $('wbRows').appendChild(tr);
    }
    function wbCalc() {
        var tw = 0, tm = 0;
        document.querySelectorAll('#wbRows tr').forEach(function (tr) {
            var w = parseFloat(tr.querySelector('.wb-w').value) || 0;
            var a = parseFloat(tr.querySelector('.wb-a').value) || 0;
            tw += w; tm += w * a;
        });
        $('wbTw').textContent = Math.round(tw * 10) / 10;
        $('wbTm').textContent = Math.round(tm / 10) / 10 + ' кг·м';
        $('wbCg').textContent = tw > 0 ? (Math.round(tm / tw * 10) / 10 + ' см') : '—';
    }
    $('wbAdd') && $('wbAdd').addEventListener('click', function () { addWbRow(); saveState(); });
    addWbRow(L.ac_empty || 'Пустой самолёт', '', '');
    addWbRow(L.pilot || 'Пилот и пассажиры', '', '');
    addWbRow(L.fuel || 'Топливо', '', '');

    /* ---------------- NOTAM-декодер ---------------- */
    var ntBtn = $('ntBtn');
    ntBtn && ntBtn.addEventListener('click', function () {
        var txt = $('ntIn').value.trim();
        if (!txt) return;
        ntBtn.disabled = true;
        var fd = new FormData();
        fd.append('text', txt);
        var csrf = (document.querySelector('meta[name="va-csrf"]') || {}).content || '';
        fd.append('_token', csrf);
        fetch(window.VA_BASE + '/tools/notam', {
            method: 'POST', body: fd, headers: { 'X-CSRF-Token': csrf, 'X-Requested-With': 'XMLHttpRequest' }
        }).then(function (r) { return r.json(); }).then(function (r) {
            ntBtn.disabled = false;
            if (!r.ok) { $('ntOut').textContent = '—'; return; }
            var n = r.notam, h = '';
            if (n.q && n.q.code) {
                h += '<div class="nt-q">Q) <b class="mono">' + n.q.code + '</b> · ' + (n.q.subj || '') +
                    ' · ' + (n.q.scope || '') + ' · FL' + (n.q.fl || '—') +
                    ' · ' + (n.q.from || '') + '→' + (n.q.to || '') + '</div>';
            }
            if (n.coords) { h += '<div class="nt-coord">◎ ' + n.coords + '</div>'; }
            if (n.schedule) { h += '<div class="nt-sched">⏱ ' + n.schedule + '</div>'; }
            h += '<dl class="kv">';
            Object.keys(n.sections).forEach(function (k) {
                h += '<div><dt>' + k + '</dt><dd>' + n.sections[k] + '</dd></div>';
            });
            h += '</dl>';
            $('ntOut').innerHTML = h;
        }).catch(function () { ntBtn.disabled = false; });
    });

    /* ---------------- Squawk-декодер ---------------- */
    var SQ = {
        '7500': ['⛔ ' + (L.sq7500 || 'незаконное вмешательство (захват)'), 'is-bad'],
        '7600': ['📡 ' + (L.sq7600 || 'потеря радиосвязи'), 'is-warn'],
        '7700': ['⚠ ' + (L.sq7700 || 'общая авария / чрезвычайная ситуация'), 'is-bad'],
        '7000': ['VFR (Европа) — визуальные полёты', ''],
        '1200': ['VFR (США) — визуальные полёты', ''],
        '2000': ['IFR (Европа) в контролируемом пространстве', ''],
        '0033': ['парашютные работы ( некоторые страны )', ''],
        '7701': ['поиск и спасение (SAR)', 'is-warn']
    };
    function sq() {
        var v = $('sqIn').value.replace(/\D/g, '');
        var known = SQ[v];
        $('sqOut').innerHTML = known
            ? '<span class="wx-cat ' + known[1] + '">' + known[0] + '</span>'
            : (v.length === 4 ? '· ' + (L.sq_std || 'стандартный код, особых значений нет') : '—');
    }
    $('sqIn') && $('sqIn').addEventListener('input', sq);

    /* ---------------- Глоссарий ---------------- */
    var GLOSSARY = [
        ['V1', 'скорость принятия решения: после неё взлёт прекращается только по критической причине'],
        ['Vr', 'скорость подъёма носовой стойки'],
        ['V2', 'безопасная скорость взлёта с отказавшим двигателем'],
        ['Vs', 'скорость сваливания'],
        ['Vne', 'непревышаемая скорость'],
        ['ETOPS', 'правила полётов двухмоторных ВС за пределами рубежа запасного аэродрома'],
        ['TCAS', 'бортовая система предупреждения столкновений'],
        ['GPWS / EGPWS', 'система предупреждения о близости земли'],
        ['APU', 'вспомогательная силовая установка'],
        ['ILS', 'система посадки по маякам: курс + глиссада'],
        ['CAT I/II/III', 'категории ILS по минимумам видимости и высоте решения'],
        ['VOR', 'всенаправленный азимутальный радиомаяк'],
        ['DME', 'дальномерное оборудование'],
        ['NDB', 'приводная радиостанция / автоматический радиокомпас'],
        ['RNAV', 'зональная навигация'],
        ['RNP', 'требуемые навигационные характеристики'],
        ['SID', 'стандартная схема вылета'],
        ['STAR', 'стандартная схема прилёта'],
        ['DA/DH', 'высота решения (приборного захода)'],
        ['MDA/MDH', 'минимальная высота снижения'],
        ['QNH', 'давление, приведённое к уровню моря → высота над порогом'],
        ['QFE', 'давление на аэродроме → высота над аэродромом'],
        ['QNE', 'стандартное давление 1013,25 гПа → эшелон'],
        ['FL', 'эшелон полёта (сотни футов при QNE)'],
        ['ISA', 'стандартная атмосфера: 15°C у земли, −1,98°C/1000 футов'],
        ['MTOW', 'максимальная взлётная масса'],
        ['MLW', 'максимальная посадочная масса'],
        ['ZFW', 'масса без топлива'],
        ['CG', 'центровка (положение центра масс)'],
        ['VMCA', 'минимальная скорость управления в воздухе с отказом двигателя'],
        ['MEL', 'перечень минимального оборудования (допуск к вылету с отказами)'],
        ['PFD', 'первичный индикатор полётных данных'],
        ['ND', 'навигационный дисплей'],
        ['ECAM / EICAS', 'электронная централизованная мониторинга самолёта'],
        ['FMS / FMC', 'система управления полётом'],
        ['ELT', 'аварийный радиомаяк'],
        ['SAR', 'поиск и спасение'],
        ['Squawk', 'код ответчика УВД; 7500/7600/7700 — аварийные'],
        ['METAR', 'метеосводка по фактической погоде'],
        ['TAF', 'прогноз погоды по аэродрому'],
        ['NOTAM', 'извещение для лётного состава об изменениях']
    ];
    function glossary() {
        var q = ($('glQ').value || '').toLowerCase();
        var h = '';
        GLOSSARY.forEach(function (g) {
            if (q === '' || g[0].toLowerCase().indexOf(q) !== -1 || g[1].toLowerCase().indexOf(q) !== -1) {
                h += '<div><dt><b>' + g[0] + '</b></dt><dd>' + g[1] + '</dd></div>';
            }
        });
        $('glList').innerHTML = h || '<div><dt>—</dt><dd></dd></div>';
    }
    $('glQ') && $('glQ').addEventListener('input', glossary);

    /* ---------------- Старт ---------------- */
    conv(); windCalc(); daCalc(); glideCalc(); gcCalc(); wbCalc(); sq(); glossary();
    if (location.hash.length > 8) { applyState(); }
    else { openTab('calc'); }
})();
