/*
 * VladAero PWA (в.73): регистрация сервис-воркера, кнопка «Установить»,
 * индикатор офлайна. Работает и из подкаталога (vladinc.ru/aviation).
 */
(function () {
    'use strict';

    // ── Регистрация SW (только https/localhost) ──
    if ('serviceWorker' in navigator) {
        window.addEventListener('load', function () {
            navigator.serviceWorker.register('sw.js', { scope: './' }).catch(function () {
                // тихо: на http-хостинге без SW ничего не показываем
            });
        });
    }

    // ── Индикатор онлайна ──
    var bar = document.createElement('div');
    bar.id = 'offlineBar';
    bar.hidden = true;
    document.body.appendChild(bar);
    function syncState() {
        bar.hidden = navigator.onLine;
        if (navigator.onLine && !bar.dataset.done) {
            bar.textContent = '✈ Снова в сети';
            bar.dataset.done = '1';
            setTimeout(function () { bar.hidden = true; delete bar.dataset.done; }, 2500);
        } else if (!navigator.onLine) {
            bar.textContent = '✈ Нет сети — показан офлайн-режим';
        }
    }
    window.addEventListener('online', syncState);
    window.addEventListener('offline', syncState);
    syncState();

    // ── Установка на домашний экран (Chrome/Edge; iOS — через «Поделиться») ──
    var deferred = null;
    window.addEventListener('beforeinstallprompt', function (e) {
        e.preventDefault();
        deferred = e;
        mountInstallBtn();
    });

    function mountInstallBtn() {
        if (document.getElementById('pwaInstall') || !deferred) { return; }
        var top = document.querySelector('.topbar');
        if (!top) { return; }
        var btn = document.createElement('button');
        btn.id = 'pwaInstall';
        btn.className = 'top-btn top-btn--primary';
        btn.type = 'button';
        btn.textContent = '⤓ App';
        btn.title = 'Установить VladAero как приложение';
        btn.addEventListener('click', function () {
            deferred.prompt();
            deferred.userChoice.then(function () {
                btn.remove();
                deferred = null;
            });
        });
        var spacer = top.querySelector('.topbar-spacer');
        spacer ? top.insertBefore(btn, spacer.nextSibling) : top.appendChild(btn);
    }

    window.addEventListener('appinstalled', function () {
        var b = document.getElementById('pwaInstall');
        b && b.remove();
    });
})();
