/**
 * VladAero Copilot — плавающий ИИ-виджет (в.159–160, 273–274).
 * SSE-стрим: reasoning / delta / tool_call / tool_result / done / error.
 */
(function () {
    'use strict';
    var fab = document.getElementById('aiwFab');
    var box = document.getElementById('aiWidget');
    if (!fab || !box) return;
    var base = (document.querySelector('meta[name="va-base"]') || document.documentElement).content || document.documentElement.dataset.base || '';
    base = String(base).replace(/\/$/, '');
    var msgs = document.getElementById('aiwMsgs');
    var txt = document.getElementById('aiwText');
    var foot = document.getElementById('aiwFoot');
    var chatId = 0, busy = false;

    function sfx(name) {
        if (localStorage.getItem('va_sound') !== '1') return;
        try { new Audio(base + '/assets/audio/' + name).play().catch(function () {}); } catch (e) {}
    }
    function esc(s) { return String(s == null ? '' : s).replace(/</g, '&lt;').replace(/\n/g, '<br>'); }
    function el(tag, cls, html) { var d = document.createElement(tag); if (cls) d.className = cls; if (html !== undefined) d.innerHTML = html; return d; }

    function open() {
        box.hidden = false; fab.classList.add('is-open');
        sfx('ui-click.ogg');
        if (!foot.dataset.done) {
            fetch(base + '/api/ai/state', { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
                .then(function (r) { return r.json(); })
                .then(function (s) {
                    foot.textContent = s.enabled
                        ? (s.model + ' · ' + (s.left < 0 ? '∞' : s.left) + ' ' + (window.VA_L_AI && VA_L_AI.left || 'запросов осталось'))
                        : (window.VA_L_AI && VA_L_AI.off || 'ИИ не настроен');
                    foot.dataset.done = '1';
                }).catch(function () {});
        }
        txt.focus();
    }
    function close() { box.hidden = true; fab.classList.remove('is-open'); }
    fab.addEventListener('click', function (e) { e.stopPropagation(); box.hidden ? open() : close(); });
    var closeBtn = document.getElementById('aiwClose');
    if (closeBtn) closeBtn.addEventListener('click', close);
    box.addEventListener('click', function (e) { if (e.target === box) close(); });
    document.addEventListener('keydown', function (e) {
        if ((e.ctrlKey || e.metaKey) && (e.key === 'j' || e.key === 'J')) { e.preventDefault(); box.hidden ? open() : close(); }
        if (e.key === 'Escape' && !box.hidden) close();
    });

    function addMsg(role) {
        var wrap = el('div', 'aiw-msg ' + (role === 'user' ? 'is-user' : 'is-ai'));
        var b = el('div', 'aiw-bubble', role === 'user' ? '' : '…');
        wrap.appendChild(b); msgs.appendChild(wrap); msgs.scrollTop = msgs.scrollHeight;
        return b;
    }

    function send(text) {
        if (busy || !text) return;
        busy = true;
        addMsg('user').innerHTML = esc(text);
        var bubble = addMsg('ai');
        bubble.innerHTML = '';
        var out = '', rbox = null, toolNote = null;

        fetch(base + '/api/ai/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'text/event-stream' },
            body: JSON.stringify({ messages: history.concat([{ role: 'user', content: text }]), tone: (document.getElementById('aiwTone') || {}).value || 'instructor', chat_id: chatId })
        }).then(function (r) { return r.body.getReader(); }).then(function (rd) {
            var dec = new TextDecoder(), buf = '';
            function frame(chunk) {
                buf += chunk;
                var parts = buf.split('\n\n'); buf = parts.pop() || '';
                parts.forEach(function (p) {
                    var ev = '', da = '';
                    p.split('\n').forEach(function (l) {
                        if (l.indexOf('event:') === 0) ev = l.slice(6).trim();
                        if (l.indexOf('data:') === 0) da += l.slice(5).trim();
                    });
                    handle(ev, da);
                });
            }
            function handle(ev, da) {
                var d; try { d = JSON.parse(da); } catch (e) { d = {}; }
                if (ev === 'delta') { out += (typeof d === 'string' ? d : ''); bubble.innerHTML = esc(out); }
                else if (ev === 'reasoning') {
                    rbox = rbox || (function () { var r = el('details', 'aiw-reasoning'); r.innerHTML = '<summary>💭 reasoning</summary><div></div>'; bubble.parentNode.insertBefore(r, bubble); return r; })();
                    rbox.querySelector('div').innerHTML += esc(typeof d === 'string' ? d : '');
                } else if (ev === 'tool_call') {
                    toolNote = el('div', 'aiw-tool', '⚙ ' + (d.tool || '') + '…');
                    bubble.appendChild(toolNote); sfx('ui-click.ogg');
                } else if (ev === 'tool_result') {
                    if (toolNote) { toolNote.className = 'aiw-tool is-ok'; toolNote.textContent = '⚙ ' + (d.tool || '') + ' ✓'; toolNote = null; }
                } else if (ev === 'chat') { chatId = d.chat_id || 0; }
                else if (ev === 'error') { bubble.appendChild(el('div', 'aiw-err', '✕ ' + esc(d.message))); }
                else if (ev === 'done') {
                    if (d.usage && d.usage.completion_tokens) {
                        foot.textContent = foot.textContent.replace(/\s\d+\s.*$/, '') + ' · ' + d.usage.completion_tokens + ' tok';
                    }
                    if (Array.isArray(d.actions) && d.actions.length) {
                        var row = el('div', 'aiw-actions');
                        d.actions.forEach(function (act) {
                            var b2 = el('button', 'aiw-act', act.label || '→');
                            b2.type = 'button';
                            b2.addEventListener('click', function () { window.open(/^https?:\/\//i.test(act.url) ? act.url : base + act.url, '_blank'); });
                            row.appendChild(b2);
                        });
                        bubble.appendChild(row);
                    }
                }
                msgs.scrollTop = msgs.scrollHeight;
            }
            function pump() { rd.read().then(function (x) { if (x.done) { busy = false; return; } frame(dec.decode(x.value)); pump(); }); }
            pump();
        }).catch(function () { busy = false; bubble.innerHTML = '✕ ' + (window.VA_L_AI && VA_L_AI.err || 'сеть'); });

        history.push({ role: 'user', content: text });
        var sync = setInterval(function () {
            if (!busy) { clearInterval(sync); history.push({ role: 'assistant', content: out }); if (history.length > 10) history = history.slice(-10); }
        }, 400);
    }

    var history = [];
    var sendBtn = document.getElementById('aiwSend');
    if (sendBtn) sendBtn.addEventListener('click', function () { var v = txt.value.trim(); txt.value = ''; send(v); });
    txt.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); var v = txt.value.trim(); txt.value = ''; send(v); }
    });
    var chips = document.querySelectorAll('#aiwChips button');
    for (var i = 0; i < chips.length; i++) {
        (function (b) { b.addEventListener('click', function () { send(b.dataset.q); }); })(chips[i]);
    }
})();
