/**
 * VladAero LiveATC мини-плеер (в.231) + UI-звуки (в.141, 144–145).
 * Потоки LiveATC за Cloudflare: .pls открываем во внешнем плеере;
 * прямую ссылку (прокси/зеркало) можно проиграть в фоне с визуализацией.
 */
(function () {
    'use strict';
    var root = document.getElementById('atcPlayer');
    if (!root) return;
    var audio = document.getElementById('atcAudio');
    var wave = document.getElementById('atcWave');

    document.getElementById('atcOpen').addEventListener('click', function () {
        var icao = document.getElementById('atcIcao').value.trim().toUpperCase();
        var ch = document.getElementById('atcCh').value;
        if (!/^[A-Z0-9]{3,4}$/.test(icao)) return;
        window.open('https://www.liveatc.net/play/' + icao + '_' + ch + '.pls', '_blank', 'noopener');
    });

    function play() {
        var u = document.getElementById('atcUrl').value.trim();
        if (!u) return;
        audio.src = u;
        audio.play().then(function () { wave.hidden = false; }).catch(function () { wave.hidden = true; });
    }
    document.getElementById('atcPlay').addEventListener('click', play);
    document.getElementById('atcUrl').addEventListener('keydown', function (e) { if (e.key === 'Enter') play(); });
    audio.addEventListener('pause', function () { wave.hidden = true; });
    audio.addEventListener('play', function () { wave.hidden = false; });

    /* ---------- UI-звуки (в.141): тумблеры + Master Caution (в.144) ---------- */
    window.VA_SFX = {
        enabled: function () { return localStorage.getItem('va_sound') === '1'; },
        play: function (name) {
            if (!this.enabled()) return;
            try { new Audio(document.documentElement.dataset.base.replace(/\/$/, '') + '/assets/audio/' + name).play().catch(function () {}); } catch (e) {}
        },
        click: function () { this.play('ui-click.ogg'); },
        caution: function () { this.play('tcas-traffic.ogg'); },   // Master Caution / TCAS (в.144)
        gpws: function () { this.play('gpws-pull-up.wav'); }
    };
    document.addEventListener('click', function (e) {
        var b = e.target.closest('.btn, .side-link, .scr-tabs a, .radar-lbtn');
        if (b) window.VA_SFX.click();
    });
    var soundBtn = document.getElementById('soundToggle');
    soundBtn && soundBtn.addEventListener('click', function () {
        setTimeout(function () { if (window.VA_SFX.enabled()) window.VA_SFX.play('gpws-too-low-gear.wav'); }, 50);
    });
})();
