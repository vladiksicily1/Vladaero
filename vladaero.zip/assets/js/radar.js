/**
 * VladAero Radar — Leaflet + Canvas overlay (в.85–90).
 * Данные: SSE /api/adsb/stream с фолбэком на polling /api/adsb (в.80).
 */
(function () {
    'use strict';
    if (typeof L === 'undefined') return;

    var mapEl = document.getElementById('vaMap');
    if (!mapEl) return;
    var base = (document.querySelector('meta[name="va-base"]') || {}).content
        || (window.VA_BASE || '');
    base = base.replace(/\/$/, '');

    // ---------- Подложки (в.87): тёмная авиационная / спутник / OSM ----------
    var tiles = {
        dark: L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
            attribution: '© OpenStreetMap, © CARTO', maxZoom: 12, minZoom: 3
        }),
        sat: L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
            attribution: '© Esri, Maxar, Earthstar Geographics', maxZoom: 12, minZoom: 3
        }),
        osm: L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap', maxZoom: 12, minZoom: 3
        })
    };
    var map = L.map(mapEl, {
        center: [47.5, 12], zoom: 5, zoomControl: true,
        preferCanvas: true, worldCopyJump: true
    });
    tiles.dark.addTo(map);

    document.querySelectorAll('.radar-lbtn').forEach(function (b) {
        b.addEventListener('click', function () {
            document.querySelectorAll('.radar-lbtn').forEach(function (x) { x.classList.remove('is-on'); });
            b.classList.add('is-on');
            Object.keys(tiles).forEach(function (k) { map.removeLayer(tiles[k]); });
            tiles[b.dataset.tiles].addTo(map);
        });
    });

    // ---------- Canvas-оверлей (в.90: сотни бортов без DOM-нагрузки) ----------
    var canvas = document.createElement('canvas');
    canvas.className = 'radar-canvas';
    mapEl.appendChild(canvas);
    var ctx = canvas.getContext('2d');
    var dpr = Math.min(2, window.devicePixelRatio || 1);

    function resize() {
        canvas.width = mapEl.clientWidth * dpr;
        canvas.height = mapEl.clientHeight * dpr;
        canvas.style.width = mapEl.clientWidth + 'px';
        canvas.style.height = mapEl.clientHeight + 'px';
        draw();
    }
    window.addEventListener('resize', resize);

    var planes = [];           // текущий снимок
    var trails = {};           // icao → [latlng] (пройденный трек, в.89)
    var selected = null;

    function altColor(a, sq) {
        if (sq === '7700' || sq === '7600' || sq === '7500') return '#FF5C5C';
        if (a === null || a === undefined) return '#7A8699';
        if (a < 3000) return '#3FBF7F';
        if (a < 9000) return '#48CAE4';
        return '#A78BFA';
    }

    function draw() {
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        var t = Date.now();
        planes.forEach(function (p) {
            if (!filterOk(p)) return;
            var pt = map.latLngToContainerPoint([p.lat, p.lon]);
            if (pt.x < -30 || pt.y < -30 || pt.x > canvas.width / dpr + 30 || pt.y > canvas.height / dpr + 30) return;
            var col = altColor(p.alt, p.sq);
            var emg = p.sq === '7700' || p.sq === '7600' || p.sq === '7500';

            // аварийный пульс (в.19)
            if (emg) {
                var r = 10 + 6 * (0.5 + 0.5 * Math.sin(t / 300));
                ctx.beginPath();
                ctx.arc(pt.x, pt.y, r, 0, Math.PI * 2);
                ctx.strokeStyle = 'rgba(255,92,92,.55)';
                ctx.lineWidth = 2;
                ctx.stroke();
            }
            // трек выбранного борта (в.89)
            if (selected === p.icao && trails[p.icao] && trails[p.icao].length > 1) {
                ctx.beginPath();
                trails[p.icao].forEach(function (ll, i) {
                    var q = map.latLngToContainerPoint([ll[0], ll[1]]);
                    i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y);
                });
                ctx.strokeStyle = 'rgba(72,202,228,.8)';
                ctx.lineWidth = 2;
                ctx.stroke();
            }
            // силуэт по истинному курсу (в.89)
            ctx.save();
            ctx.translate(pt.x, pt.y);
            ctx.rotate(((p.trk || 0) * Math.PI) / 180);
            ctx.beginPath();
            ctx.moveTo(0, -9); ctx.lineTo(2, -3); ctx.lineTo(9, 1); ctx.lineTo(9, 3);
            ctx.lineTo(2, 3); ctx.lineTo(1.5, 7); ctx.lineTo(4, 9); ctx.lineTo(0, 8);
            ctx.lineTo(-4, 9); ctx.lineTo(-1.5, 7); ctx.lineTo(-2, 3); ctx.lineTo(-9, 3);
            ctx.lineTo(-9, 1); ctx.lineTo(-2, -3); ctx.closePath();
            ctx.fillStyle = col;
            ctx.globalAlpha = p.g ? 0.55 : 0.95;
            ctx.fill();
            if (selected === p.icao) {
                ctx.lineWidth = 1.5; ctx.strokeStyle = '#fff'; ctx.stroke();
            }
            ctx.restore();
            ctx.globalAlpha = 1;
        });
    }

    // ---------- Фильтры (в.17) ----------
    var fCs = document.getElementById('vaFltCs');
    var fMin = document.getElementById('vaFltAltMin');
    var fMax = document.getElementById('vaFltAltMax');
    var fAlert = document.getElementById('vaFltAlert');
    var fGround = document.getElementById('vaFltGround');
    [fCs, fMin, fMax, fAlert, fGround].forEach(function (el) {
        el.addEventListener('input', draw);
    });

    function filterOk(p) {
        if (fAlert.checked && !['7700', '7600', '7500'].includes(p.sq)) return false;
        if (!fGround.checked && p.g) return false;
        if (fCs.value && !(p.cs || '').toUpperCase().includes(fCs.value.toUpperCase())
            && !(p.reg || '').toUpperCase().includes(fCs.value.toUpperCase())) return false;
        var a = p.alt;
        if (fMin.value !== '' && a !== null && a !== undefined && a < +fMin.value) return false;
        if (fMax.value !== '' && a !== null && a !== undefined && a > +fMax.value) return false;
        return true;
    }

    // ---------- Клик: телеметрия выбранного борта (в.18) ----------
    mapEl.addEventListener('click', function (e) {
        if (e.target.closest('.leaflet-control')) return;
        var rect = mapEl.getBoundingClientRect();
        var mx = e.clientX - rect.left, my = e.clientY - rect.top;
        var best = null, bestD = 400; // px²
        planes.forEach(function (p) {
            if (!filterOk(p)) return;
            var pt = map.latLngToContainerPoint([p.lat, p.lon]);
            var d = (pt.x - mx) * (pt.x - mx) + (pt.y - my) * (pt.y - my);
            if (d < bestD) { bestD = d; best = p; }
        });
        select(best);
    });

    var card = document.getElementById('vaCard');
    function select(p) {
        selected = p ? p.icao : null;
        if (!p) { card.hidden = true; draw(); return; }
        card.hidden = false;
        document.getElementById('vcCs').textContent = p.cs || p.icao.toUpperCase();
        document.getElementById('vcSub').textContent =
            [p.reg, p.type, p.ctry].filter(Boolean).join(' · ');
        document.getElementById('vcAlt').textContent = p.g ? 'GND' : (p.alt !== null && p.alt !== undefined ? Math.round(p.alt / 30.48) * 100 / 10 + ' м ≈ FL' + Math.round(p.alt / 30.48) : '—');
        document.getElementById('vcGs').textContent = p.gs !== null && p.gs !== undefined ? p.gs + ' км/ч' : '—';
        document.getElementById('vcTrk').textContent = p.trk !== null && p.trk !== undefined ? p.trk + '°' : '—';
        document.getElementById('vcVr').textContent = p.vr !== null && p.vr !== undefined ? (p.vr > 0 ? '▲ ' : p.vr < 0 ? '▼ ' : '') + Math.abs(p.vr) + ' м/с' : '—';
        document.getElementById('vcSq').textContent = p.sq || '—';
        var acts = document.getElementById('vcActs');
        acts.innerHTML = '';
        if (p.cs || p.reg) {
            var q = p.reg || p.cs;
            var a1 = document.createElement('a');
            a1.href = base + '/aircraft?q=' + encodeURIComponent(q);
            a1.className = 'radar-card-btn';
            a1.textContent = '⌕ ' + (window.VA_L && VA_L.open_card || 'Найти в энциклопедии');
            acts.appendChild(a1);
            var a2 = document.createElement('a');
            a2.href = base + '/gallery?reg=' + encodeURIComponent(q);
            a2.className = 'radar-card-btn is-ghost';
            a2.textContent = '▣ ' + (window.VA_L && VA_L.open_gallery || 'Фото в галерее');
            acts.appendChild(a2);
        }
        draw();
    }
    document.getElementById('vaCardX').addEventListener('click', function () { select(null); });

    // ---------- Тосты аварийных squawk (в.19, 230) ----------
    var alerted = {};
    var toasts = document.getElementById('vaToasts');
    function toast(msg, cls) {
        var d = document.createElement('div');
        d.className = 'radar-toast ' + (cls || '');
        d.textContent = msg;
        toasts.appendChild(d);
        setTimeout(function () { d.classList.add('is-out'); }, 7000);
        setTimeout(function () { d.remove(); }, 7600);
    }
    function checkAlerts(list) {
        list.forEach(function (p) {
            var code = ['7700', '7600', '7500'].includes(p.sq) ? p.sq : null;
            if (!code || alerted[p.icao + code]) return;
            alerted[p.icao + code] = 1;
            var label = code === '7700' ? (VA_L.emg7700 || 'Общая авария')
                : code === '7600' ? (VA_L.emg7600 || 'Потеря связи')
                : (VA_L.emg7500 || 'Захват');
            toast('⚠ ' + (p.cs || p.icao.toUpperCase()) + ' · squawk ' + code + ' — ' + label, 'is-emg');
            if (window.VA_SFX) { window.VA_SFX.caution(); }
        });
    }

    // ---------- Данные: SSE → фолбэк polling ----------
    var cnt = document.getElementById('vaCnt');
    var srcEl = document.getElementById('vaSrc');
    var staleEl = document.getElementById('vaStale');

    function apply(snap) {
        var prev = {};
        planes.forEach(function (p) { prev[p.icao] = p; });
        planes = snap.ac || [];
        planes.forEach(function (p) {
            var t = trails[p.icao] || (trails[p.icao] = []);
            var last = t[t.length - 1];
            if (!last || Math.abs(last[0] - p.lat) > 0.001 || Math.abs(last[1] - p.lon) > 0.001) {
                t.push([p.lat, p.lon]);
                if (t.length > 60) t.shift();
            }
            void prev;
        });
        cnt.textContent = planes.length;
        srcEl.textContent = (snap.src || '—') + (snap.stale ? ' · ' + (VA_L.stale || 'нет свежих данных') : '');
        staleEl.hidden = !snap.stale;
        checkAlerts(planes);
        draw();
    }

    function bbox() {
        var b = map.getBounds();
        return 'lamin=' + b.getSouth().toFixed(3) + '&lomin=' + b.getWest().toFixed(3)
            + '&lamax=' + b.getNorth().toFixed(3) + '&lomax=' + b.getEast().toFixed(3);
    }

    var es = null, pollTimer = null, esFails = 0;
    function startPolling() {
        if (pollTimer) return;
        var tick = function () {
            fetch(base + '/api/adsb?' + bbox(), { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
                .then(function (r) { return r.json(); })
                .then(apply)
                .catch(function () {});
        };
        tick();
        pollTimer = setInterval(tick, 5000);
    }
    function startSse() {
        try {
            es = new EventSource(base + '/api/adsb/stream?' + bbox());
            es.onmessage = function (ev) {
                try { apply(JSON.parse(ev.data)); } catch (e) { /* пропускаем битый кадр */ }
            };
            es.addEventListener('reconnect', function () { es.close(); startPolling(); });
            es.onerror = function () {
                esFails++;
                if (esFails >= 2 && es) { es.close(); startPolling(); }
            };
        } catch (e) { startPolling(); }
    }

    map.on('moveend zoomend', function () {
        if (es) { try { es.close(); } catch (e) {} es = null; }
        if (pollTimer) { clearInterval(pollTimer); pollTimer = null; }
        esFails = 0;
        startSse();
    });
    map.on('move zoom', draw);
    (function loop() { draw(); requestAnimationFrame(loop); })();

    // ---------- Полный экран (в.230) ----------
    document.getElementById('vaFsBtn').addEventListener('click', function () {
        if (document.fullscreenElement) { document.exitFullscreen(); }
        else { document.documentElement.requestFullscreen(); }
    });
    document.addEventListener('keydown', function (e) {
        if (e.key === 'f' || e.key === 'F') { document.getElementById('vaFsBtn').click(); }
        if (e.key === 'Escape') { select(null); }
    });

    resize();
    startSse();
})();
