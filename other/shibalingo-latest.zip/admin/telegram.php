<?php
/**
 * Admin Telegram Bot Manager (Enable/Disable, Change Token, Webhook)
 */

$adminTitle = 'Telegram Бот';
require_once __DIR__ . '/header.php';

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = trim($_POST['telegram_bot_token'] ?? '');
    $enabled = isset($_POST['telegram_bot_enabled']) ? '1' : '0';
    $welcomeMsg = trim($_POST['telegram_welcome_msg'] ?? '');

    setSetting('telegram_bot_token', $token);
    setSetting('telegram_bot_enabled', $enabled);
    setSetting('telegram_welcome_msg', $welcomeMsg);

    // Auto set webhook if requested
    if (isset($_POST['set_webhook']) && !empty($token)) {
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https://" : "http://";
        $currentDomain = $protocol . $_SERVER['HTTP_HOST'];
        $webhookUrl = $currentDomain . dirname(dirname($_SERVER['PHP_SELF'])) . '/telegram_bot.php';
        
        $ch = curl_init("https://api.telegram.org/bot{$token}/setWebhook?url=" . urlencode($webhookUrl));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $res = curl_exec($ch);
        curl_close($ch);
        $resData = json_decode($res, true);
        
        if (!empty($resData['ok'])) {
            $message = "Настройки сохранены! Webhook успешно установлен на: {$webhookUrl}";
        } else {
            $message = "Настройки сохранены, но ошибка Webhook: " . ($resData['description'] ?? 'неизвестная ошибка');
        }
    } else {
        $message = 'Настройки Telegram бота успешно обновлены!';
    }
}

$botToken = getSetting('telegram_bot_token', '');
$botEnabled = getSetting('telegram_bot_enabled', '0');
$welcomeMsg = getSetting('telegram_welcome_msg', 'Привет! Я бот Сиба-сэнсэй 🐕. Готов учить слова Vladikish и напоминать о стрике!');
?>

<div style="max-width: 800px;">
    <div style="margin-bottom: 24px;">
        <h1 style="font-size: 1.8rem; font-weight: 900;">✈️ Управление Telegram-ботом</h1>
        <p style="color: var(--text-muted);">Интеграция с ботом: обучение словам в Telegram, уведомления о стриках и квизы</p>
    </div>

    <?php if (!empty($message)): ?>
        <div class="alert alert-success" style="background: var(--primary-light); color: var(--primary-shadow); padding: 14px; border-radius: 12px; font-weight: 700; margin-bottom: 20px;">
            ✓ <?= e($message) ?>
        </div>
    <?php endif; ?>

    <form method="POST">
        <div class="card-duo">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h3 style="font-size: 1.2rem; font-weight: 800;">Состояние и токен бота</h3>
                <label style="font-weight: 800; font-size: 1rem; display: flex; align-items: center; gap: 8px; cursor: pointer;">
                    <input type="checkbox" name="telegram_bot_enabled" value="1" <?= ($botEnabled === '1') ? 'checked' : '' ?>>
                    <span>Включить бота</span>
                </label>
            </div>

            <div style="margin-bottom: 16px;">
                <label style="font-weight: 700; font-size: 0.9rem; margin-bottom: 6px; display: block;">
                    Telegram Bot Token (от @BotFather):
                </label>
                <input type="password" name="telegram_bot_token" value="<?= e($botToken) ?>" class="chat-input" placeholder="123456789:ABCdefGhIJKlmNoPQRsTUVwxyZ">
                <div style="font-size: 0.85rem; color: var(--text-muted); margin-top: 4px;">
                    Вы можете в любой момент изменить токен или отключить бота.
                </div>
            </div>

            <div style="margin-bottom: 20px;">
                <label style="font-weight: 700; font-size: 0.9rem; margin-bottom: 6px; display: block;">
                    Приветственное сообщение бота (/start):
                </label>
                <textarea name="telegram_welcome_msg" rows="3" class="chat-input"><?= e($welcomeMsg) ?></textarea>
            </div>

            <div style="display: flex; gap: 12px; flex-wrap: wrap;">
                <button type="submit" class="btn-duo btn-primary" style="flex: 1;">
                    Сохранить настройки 💾
                </button>
                <button type="submit" name="set_webhook" value="1" class="btn-duo btn-secondary" style="flex: 1;">
                    🔗 Установить Webhook
                </button>
            </div>
        </div>
    </form>

    <div class="card-duo">
        <h3 style="font-size: 1.15rem; font-weight: 800; margin-bottom: 12px;">Команды бота для пользователей:</h3>
        <ul style="padding-left: 20px; color: var(--text-muted); line-height: 1.8;">
            <li><code>/start</code> — Запуск бота и выбор языка</li>
            <li><code>/word</code> — Случайное слово дня с переводом и озвучкой</li>
            <li><code>/quiz</code> — Быстрый тест из 1 вопроса с кнопками выбора</li>
            <li><code>/streak</code> — Проверка личного стрика и сердечек</li>
            <li><code>/chat &lt;сообщение&gt;</code> — Поговорить с Сиба-сэнсэем через NVIDIA AI</li>
        </ul>
    </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
