<?php
/**
 * ShibaLingo - Telegram Bot Webhook Handler
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';

$botEnabled = getSetting('telegram_bot_enabled', '0');
$botToken = getSetting('telegram_bot_token', '');

if ($botEnabled !== '1' || empty($botToken)) {
    http_response_code(200);
    echo "Bot is currently disabled in Admin settings.";
    exit;
}

$updateRaw = file_get_contents('php://input');
$update = json_decode($updateRaw, true);

if (!$update) {
    http_response_code(200);
    exit;
}

function sendTgMessage($chatId, $text, $keyboard = null) {
    global $botToken;
    $url = "https://api.telegram.org/bot{$botToken}/sendMessage";
    $payload = [
        'chat_id' => $chatId,
        'text' => $text,
        'parse_mode' => 'HTML'
    ];
    if ($keyboard) {
        $payload['reply_markup'] = json_encode($keyboard);
    }

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_exec($ch);
    curl_close($ch);
}

$message = $update['message'] ?? null;
$callbackQuery = $update['callback_query'] ?? null;

if ($message) {
    $chatId = $message['chat']['id'];
    $text = trim($message['text'] ?? '');
    $db = getDb();

    if ($text === '/start') {
        $welcome = getSetting('telegram_welcome_msg', 'Привет! Я Сиба-сэнсэй 🐕. Готов учить языки и язык Vladikish!');
        $kb = [
            'inline_keyboard' => [
                [
                    ['text' => '📖 Слово дня', 'callback_data' => 'word_of_day'],
                    ['text' => '🎮 Быстрый квиз', 'callback_data' => 'quick_quiz']
                ],
                [
                    ['text' => '🌐 Открыть веб-сайт', 'url' => 'http://' . $_SERVER['HTTP_HOST']]
                ]
            ]
        ];
        sendTgMessage($chatId, "🐕 <b>ShibaLingo Bot</b>\n\n{$welcome}\n\nВыберите действие ниже:", $kb);
    } elseif ($text === '/word') {
        $w = $db->query("SELECT * FROM conlang_dictionary ORDER BY " . (Database::getDriver() === 'sqlite' ? 'RANDOM()' : 'RAND()') . " LIMIT 1")->fetch();
        if ($w) {
            $msg = "🐕 <b>Слово на Vladikish:</b> <code>{$w['word']}</code>\n"
                 . "<b>Часть речи:</b> {$w['part_of_speech']}\n"
                 . "<b>Перевод (RU):</b> {$w['translation_ru']}\n"
                 . "<b>Произношение:</b> [{$w['pronunciation']}]\n"
                 . "<b>Пример:</b> <i>{$w['example_sentence']}</i>";
            sendTgMessage($chatId, $msg);
        }
    } elseif ($text === '/streak') {
        sendTgMessage($chatId, "🔥 Ваш стрик активен! Не забудьте пройти сегодняшний урок на сайте!");
    } elseif (strpos($text, '/chat') === 0) {
        $query = trim(substr($text, 5));
        if (empty($query)) {
            sendTgMessage($chatId, "Напишите: <code>/chat Привет, Шиба!</code>");
        } else {
            // Call AI
            $conlangContext = getVladikishContext();
            $messages = [
                ['role' => 'system', 'content' => "You are Shiba-sensei, a cute Japanese Shiba Inu language tutor teaching Vladikish and English. Answer concisely with puppy emotes!\nContext:\n{$conlangContext}"],
                ['role' => 'user', 'content' => $query]
            ];
            $res = callNvidiaApi($messages);
            $reply = $res['success'] ? $res['content'] : "Гав! Ошибка подключения к AI: {$res['error']}";
            sendTgMessage($chatId, "🐕 <b>Сиба-сэнсэй:</b>\n" . $reply);
        }
    }
}

if ($callbackQuery) {
    $chatId = $callbackQuery['message']['chat']['id'];
    $data = $callbackQuery['data'];
    $db = getDb();

    if ($data === 'word_of_day') {
        $w = $db->query("SELECT * FROM conlang_dictionary ORDER BY " . (Database::getDriver() === 'sqlite' ? 'RANDOM()' : 'RAND()') . " LIMIT 1")->fetch();
        if ($w) {
            $msg = "🐕 <b>Слово на Vladikish:</b> <code>{$w['word']}</code>\n"
                 . "<b>Перевод (RU):</b> {$w['translation_ru']}\n"
                 . "<b>Пример:</b> <i>{$w['example_sentence']}</i>";
            sendTgMessage($chatId, $msg);
        }
    } elseif ($data === 'quick_quiz') {
        $w = $db->query("SELECT * FROM conlang_dictionary ORDER BY " . (Database::getDriver() === 'sqlite' ? 'RANDOM()' : 'RAND()') . " LIMIT 1")->fetch();
        if ($w) {
            $kb = [
                'inline_keyboard' => [
                    [['text' => $w['translation_ru'] . ' (Правильно)', 'callback_data' => 'quiz_correct']],
                    [['text' => 'Ночь', 'callback_data' => 'quiz_wrong']]
                ]
            ];
            sendTgMessage($chatId, "❓ <b>Как переводится:</b> <code>{$w['word']}</code>?", $kb);
        }
    } elseif ($data === 'quiz_correct') {
        sendTgMessage($chatId, "🎉 <b>Верно! +10 XP</b> Отличная работа, держи лапу! 🐾");
    } elseif ($data === 'quiz_wrong') {
        sendTgMessage($chatId, "💔 Не совсем так! Попробуй еще раз.");
    }
}
