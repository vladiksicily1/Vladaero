<?php
/**
 * ShibaLingo - User Login Page
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($login) || empty($password)) {
        $error = 'Пожалуйста, заполните все поля!';
    } else {
        $db = getDb();
        $stmt = $db->prepare("SELECT * FROM " . tbl('users') . " WHERE (username = :u OR email = :u) AND status = 'active'");
        $stmt->execute(['u' => $login]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password_hash'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['current_language'] = $user['current_language'] ?? 'vladikish';
            header("Location: index.php");
            exit;
        } else {
            $error = 'Неверное имя пользователя или пароль!';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Вход в аккаунт — ShibaLingo</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/animations.css">
    <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🐕</text></svg>">
</head>
<body style="display: flex; align-items: center; justify-content: center; min-height: 100vh; background: var(--bg-main); padding: 20px;">

<div class="card-duo anim-bounce" style="max-width: 440px; width: 100%; padding: 40px 32px; text-align: center;">
    <div style="font-size: 3.5rem; margin-bottom: 8px;">🐕 🎓</div>
    <h1 style="font-size: 1.8rem; font-weight: 900; color: var(--primary); margin-bottom: 6px;">
        Вход в ShibaLingo
    </h1>
    <p style="color: var(--text-muted); font-size: 0.95rem; margin-bottom: 24px;">
        Продолжайте изучать языки и тайный язык Vladikish!
    </p>

    <?php if (!empty($error)): ?>
        <div style="background: var(--danger-light); color: var(--danger-shadow); padding: 12px; border-radius: 12px; font-weight: 700; margin-bottom: 18px; font-size: 0.9rem;">
            ✕ <?= e($error) ?>
        </div>
    <?php endif; ?>

    <form method="POST" style="text-align: left;">
        <div style="margin-bottom: 16px;">
            <label style="font-weight: 700; font-size: 0.9rem; display: block; margin-bottom: 6px;">Имя пользователя или Email:</label>
            <input type="text" name="login" class="chat-input" placeholder="Ваш логин или email" required autofocus>
        </div>

        <div style="margin-bottom: 24px;">
            <label style="font-weight: 700; font-size: 0.9rem; display: block; margin-bottom: 6px;">Пароль:</label>
            <input type="password" name="password" class="chat-input" placeholder="••••••••" required>
        </div>

        <button type="submit" class="btn-duo btn-primary" style="width: 100%; font-size: 1.1rem; padding: 14px;">
            Войти в аккаунт 🐾
        </button>
    </form>

    <div style="margin-top: 24px; padding-top: 18px; border-top: 2px solid var(--border-color); display: flex; justify-content: space-between; font-size: 0.9rem;">
        <span style="color: var(--text-muted);">Нет аккаунта?</span>
        <a href="register.php" style="color: var(--secondary); font-weight: 800; text-decoration: none;">
            Зарегистрироваться 🚀
        </a>
    </div>

    <div style="margin-top: 12px;">
        <a href="index.php" style="color: var(--text-muted); font-size: 0.85rem; text-decoration: none;">
            ← На главную
        </a>
    </div>
</div>

</body>
</html>
