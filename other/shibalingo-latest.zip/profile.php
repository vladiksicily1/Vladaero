<?php
/**
 * ShibaLingo - Public Student Profile Showcase (Feature #25)
 */

$pageTitle = 'Профиль ученика';
require_once __DIR__ . '/includes/header.php';

$db = getDb();
$targetId = (int)($_GET['id'] ?? 0);
$targetUsername = trim($_GET['u'] ?? '');

$isOwnProfile = true;
$profileUser = $user;

if ($targetId > 0 && $targetId !== (int)$user['id']) {
    $pStmt = $db->prepare("SELECT * FROM " . tbl('users') . " WHERE id = :id LIMIT 1");
    $pStmt->execute(['id' => $targetId]);
    $found = $pStmt->fetch(PDO::FETCH_ASSOC);
    if ($found) {
        $profileUser = $found;
        $isOwnProfile = false;
    }
} elseif (!empty($targetUsername) && $targetUsername !== $user['username']) {
    $pStmt = $db->prepare("SELECT * FROM " . tbl('users') . " WHERE username = :u LIMIT 1");
    $pStmt->execute(['u' => $targetUsername]);
    $found = $pStmt->fetch(PDO::FETCH_ASSOC);
    if ($found) {
        $profileUser = $found;
        $isOwnProfile = false;
    }
}

// Check friendship status
$isFriend = false;
if (!$isOwnProfile) {
    try {
        $fCheck = $db->prepare("SELECT id FROM friendships WHERE user_id = :uid AND friend_id = :fid");
        $fCheck->execute(['uid' => $user['id'], 'fid' => $profileUser['id']]);
        $isFriend = (bool)$fCheck->fetch();
    } catch (Exception $e) {}
}

// User stats
$completedLessonsCount = $db->query("SELECT COUNT(*) FROM user_progress WHERE user_id = {$profileUser['id']}")->fetchColumn();
?>

<div style="max-width: 750px; margin: 0 auto;">
    <!-- Profile Card -->
    <div class="card-duo anim-bounce" style="display: flex; align-items: center; gap: 24px; flex-wrap: wrap;">
        <div id="profile-mascot-avatar"></div>

        <div style="flex-grow: 1;">
            <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 6px; flex-wrap: wrap; gap: 8px;">
                <h1 style="font-size: 1.8rem; font-weight: 900;"><?= e($profileUser['username']) ?></h1>
                <div style="display: flex; gap: 8px;">
                    <?php if ($isOwnProfile): ?>
                        <span class="badge-tag" style="background: #fef08a; color: #854d0e; font-weight: 900;">
                            🥇 Золотая Лига
                        </span>
                        <button class="btn-duo btn-outline" style="padding: 4px 10px; font-size: 0.8rem;" onclick="document.getElementById('user-avatar-picker').click()">
                            📷 Сменить фото
                        </button>
                        <input type="file" id="user-avatar-picker" accept="image/*" style="display: none;" onchange="uploadUserAvatar(this.files)">
                    <?php else: ?>
                        <button class="btn-duo <?= $isFriend ? 'btn-outline' : 'btn-primary' ?>" id="btn-toggle-friend" onclick="toggleFriend(<?= (int)$profileUser['id'] ?>)" style="padding: 6px 14px; font-size: 0.85rem;">
                            <?= $isFriend ? '✓ В друзьях' : '+ Добавить в друзья' ?>
                        </button>
                    <?php endif; ?>
                </div>
            </div>
            <p style="color: var(--text-muted); font-size: 0.95rem; margin-bottom: 16px;">
                Изучает: <strong><?= e($currentLangObj['name']) ?></strong> | На платформе с <?= date('d.m.Y', strtotime($profileUser['created_at'] ?? 'now')) ?>
            </p>

            <!-- Stats Row -->
            <div style="display: flex; gap: 24px; font-weight: 800; font-size: 1.05rem; flex-wrap: wrap;">
                <div>
                    <div style="color: var(--streak-color);">🔥 <?= (int)$profileUser['streak'] ?></div>
                    <div style="font-size: 0.75rem; color: var(--text-muted); text-transform: uppercase;">Стрик дней</div>
                </div>
                <div>
                    <div style="color: #eab308;">⚡ <?= (int)$profileUser['xp'] ?></div>
                    <div style="font-size: 0.75rem; color: var(--text-muted); text-transform: uppercase;">Всего XP</div>
                </div>
                <div>
                    <div style="color: var(--secondary);">💎 <?= (int)($profileUser['gems'] ?? 50) ?></div>
                    <div style="font-size: 0.75rem; color: var(--text-muted); text-transform: uppercase;">Кристаллов</div>
                </div>
                <div>
                    <div style="color: var(--primary);"><?= $completedLessonsCount ?></div>
                    <div style="font-size: 0.75rem; color: var(--text-muted); text-transform: uppercase;">Уроков пройдено</div>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Navigation Links -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 14px; margin-top: 24px;">
        <a href="shop.php" class="card-duo" style="text-decoration: none; color: inherit; text-align: center; margin-bottom: 0; padding: 16px;">
            <div style="font-size: 2rem; margin-bottom: 4px;">🛍️</div>
            <div style="font-weight: 800; font-size: 0.95rem;">Магазин скинов</div>
        </a>
        <a href="achievements.php" class="card-duo" style="text-decoration: none; color: inherit; text-align: center; margin-bottom: 0; padding: 16px;">
            <div style="font-size: 2rem; margin-bottom: 4px;">🏅</div>
            <div style="font-weight: 800; font-size: 0.95rem;">Достижения</div>
        </a>
        <a href="leaderboard.php" class="card-duo" style="text-decoration: none; color: inherit; text-align: center; margin-bottom: 0; padding: 16px;">
            <div style="font-size: 2rem; margin-bottom: 4px;">🏆</div>
            <div style="font-weight: 800; font-size: 0.95rem;">Таблица лидеров</div>
        </a>
        <a href="friends.php" class="card-duo" style="text-decoration: none; color: inherit; text-align: center; margin-bottom: 0; padding: 16px;">
            <div style="font-size: 2rem; margin-bottom: 4px;">👥</div>
            <div style="font-weight: 800; font-size: 0.95rem;">Мои друзья</div>
        </a>
        <a href="tamagotchi.php" class="card-duo" style="text-decoration: none; color: inherit; text-align: center; margin-bottom: 0; padding: 16px;">
            <div style="font-size: 2rem; margin-bottom: 4px;">🐕</div>
            <div style="font-weight: 800; font-size: 0.95rem;">Тамагочи</div>
        </a>
        <a href="referral.php" class="card-duo" style="text-decoration: none; color: inherit; text-align: center; margin-bottom: 0; padding: 16px;">
            <div style="font-size: 2rem; margin-bottom: 4px;">🎁</div>
            <div style="font-weight: 800; font-size: 0.95rem;">Пригласи друга</div>
        </a>
        <a href="certificate.php" class="card-duo" style="text-decoration: none; color: inherit; text-align: center; margin-bottom: 0; padding: 16px;">
            <div style="font-size: 2rem; margin-bottom: 4px;">🎓</div>
            <div style="font-weight: 800; font-size: 0.95rem;">Диплом Vladikish</div>
        </a>
    </div>

    <!-- Account Actions & Danger Zone -->
    <div class="card-duo" style="margin-top: 24px; padding: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px;">
        <div>
            <h3 style="font-size: 1.1rem; font-weight: 800; margin-bottom: 4px;">Управление аккаунтом</h3>
            <p style="color: var(--text-muted); font-size: 0.85rem; margin: 0;">Сессия и безопасность профиля</p>
        </div>

        <div style="display: flex; gap: 12px; align-items: center;">
            <a href="logout.php" class="btn-duo btn-outline" style="padding: 8px 18px; font-size: 0.9rem;">
                Выйти 🚪
            </a>
            <a href="delete_account.php" class="btn-duo" style="padding: 8px 18px; font-size: 0.9rem; background: var(--danger-light); color: var(--danger-shadow); border-color: var(--danger);">
                Удалить аккаунт 🗑️
            </a>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    ShibaMascot.setSkin('<?= $profileUser['selected_skin'] ?? 'classic' ?>');
    ShibaMascot.update('profile-mascot-avatar', 'happy');
});

async function uploadUserAvatar(files) {
    if (!files || !files.length) return;
    const file = files[0];
    const formData = new FormData();
    formData.append('file', file);
    formData.append('type', 'avatar');

    try {
        const res = await fetch('api/upload_api.php', {
            method: 'POST',
            body: formData
        });
        const data = await res.json();
        if (data.success) {
            SoundEngine.play('correct');
            alert('✓ Аватар успешно обновлен!');
            location.reload();
        } else {
            alert('Ошибка: ' + (data.error || 'Не удалось загрузить'));
        }
    } catch(err) {
        alert('Ошибка при загрузке аватара.');
    }
}

async function toggleFriend(friendId) {
    try {
        const formData = new FormData();
        formData.append('action', 'toggle_friend');
        formData.append('friend_id', friendId);
        const res = await fetch('api/social_api.php', {
            method: 'POST',
            body: formData
        });
        const data = await res.json();
        if (data.success) {
            SoundEngine.play('correct');
            const btn = document.getElementById('btn-toggle-friend');
            if (btn) {
                btn.textContent = data.is_friend ? '✓ В друзьях' : '+ Добавить в друзья';
                btn.className = 'btn-duo ' + (data.is_friend ? 'btn-outline' : 'btn-primary');
            }
            alert(data.message);
        }
    } catch (e) {
        console.error('Friend toggle error', e);
    }
}
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
